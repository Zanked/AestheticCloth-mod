# Seller (shop assistant)

Every clothes payment goes through her. Hire her with a **Seller Contract** (paper, pink dye, emerald, gold ingot; Tools tab): use it on a block.

- Fitting room: try on and wear what you own. Buying (and gifts) works only within 10 blocks of a seller.
- Right click her: opens the wardrobe. Sneak + right click: haggle once a day (3-11% off until the end of the day; chance grows with the loyalty card).
- Loyalty card from total spent: Bronze $100 -3%, Silver $500 -5%, Gold $1500 -8%, Platinum $4000 -10%. Loyalty + haggle is capped at 30%.
- Each sale gives a paper receipt; the owner of the seller gets 30% commission (needs the bank's `deposit`, optional).
- She greets customers (chat + speech bubble), mentions the running sale. Owner / creative op: sneak + attack picks her up.
- Textures: `python3 tools/gen_seller.py` (3 skins 128x128, contract 32x32). Network version is now 4.

## Cart and seller screen
- In the fitting room the button is now "To cart": owned clothes are worn at once, unowned ones go into the cart (saved on the player).
- Right click the seller: pastel boutique window with her portrait and typewriter dialogue, the cart (remove items, empty it), loyalty card, discount, Pay / Haggle / Chat / Try on.
- Paying is only possible within 10 blocks of a seller; the bought clothes are put on right away. Network version 5.
