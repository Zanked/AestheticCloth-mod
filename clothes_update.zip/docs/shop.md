# Shop: clothes cost money

Clothes are paid from the player's account in the Aesthetic Jobs bank (USD, amounts in cents). The two mods
must be installed together: `fittingroom` requires `aestheticjobs` 0.8.0 or newer (the bank mod is not changed).

## How it works
- Open the fitting room (right click inside the cabin). The server sends the balance and the list of bought
  clothes, then the screen opens.
- Clothes you do not own are dimmed and have a gold `$`; the tooltip shows the price, owned ones say "Owned".
- Pick an outfit: the strip under the window shows your balance and the total price of the unpaid items.
  The button says **Buy** when something is unpaid, **Wear** otherwise. If the account has less than the total
  the button is grey and nothing happens.
- The server does the payment (`Shop.buyAndWear`): one withdrawal for the whole outfit, transaction type
  `WITHDRAW` (visible in `/bank history`), reason `fittingroom: <ids>`. Not enough money or a bank error means
  nothing is bought and the old outfit is put back on the player.
- Bought clothes are saved on the player (`fittingroom:owned`) and kept after death. Clothes can be worn again
  and again for free.
- Players who wore something before the shop existed get that clothing as owned, once, on login.
- No card or PIN is needed: the payment goes through the account of the player (same as wages and tips).

## Testing
`/bank give <player> 100000` (operator) puts $1,000.00 on the account, `/bank balance` shows it.

## Prices
`ClothingPrices.java`, one line per garment, in cents. For orientation: T-shirt $14.99-24.99, hoodie $49.99,
jeans $59.99, sneakers $79.99, leather jacket $249.99, combat boots $149.99, pearl necklace $99.99,
gold bangles $199.99, balloon $3.99. A garment that is missing in the table gets a price by category
(`fallback`), so nothing is free by accident. For comparison the cafe job pays $12 per hour.

## Sales (skidki)
`Sales.java`. Everything depends only on the date, so server and client agree (the server sends its date with the
wallet). An item gets the best sale that covers it, sales do not stack. The server charges the sale price.
- Daily: one category per day, they take turns, 15-25% off.
- Weekend (Sat, Sun): 10% off everything.
- Black Friday week (Monday before to Cyber Monday): 30% off everything.
- New Year (Dec 15 - Jan 14): 20% off the holiday clothes. Back to school (Aug 20 - Sep 10): 25% off the uniforms.
In the GUI: a red `%` on the slot, the old price crossed out and the new one in the tooltip, a "Sale -N%" banner
under the window (hover it for the list), and the "On sale" filter. Test another day with `-Dfittingroom.date=2026-11-27`.

## Gifts
Select clothes, press **Gift**, pick an online player, **Send**. The server (`Shop.gift`) takes the money from you
(sale applied, reason `fittingroom gift to <name>: <ids>`), skips what they already own (not charged) and puts the rest
in their wardrobe. Both of you get a chat message and a sound.

## Outfit slots
Five buttons under the window. Click a filled slot: put that outfit on (preview). Click an empty one, right click or
Shift+click: save the current outfit there (right click with nothing selected clears the slot). Saved on the player
(`fittingroom:outfit_slots`), kept after death. A saved outfit may contain things you do not own yet.

## Search, filter, Undress
- Search box: looks in all tabs by name while something is typed (click a tab to leave the search). Typing `e` does not
  close the screen. Esc leaves the box first.
- Filter button: All / Owned / Not owned / On sale (right click goes back).
- Undress: takes everything off in the preview, press Wear to confirm.

## Sounds
`assets/fittingroom/sounds/*.ogg`, registered in `FittingSounds`, listed in `sounds.json`. They are made by
`python3 tools/gen_sounds.py` (numpy, scipy, ffmpeg): rustle (clothes on), undress, purchase, gift, error, slot_save, sale.

## Text that fits
Every GUI text goes through `GuiText`: too wide text is shrunk (down to 65%), then cut with "...". Tooltips are wrapped.
