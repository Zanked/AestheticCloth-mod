package com.fittingroom.economy;

import com.mojang.logging.LogUtils;
import net.minecraft.server.MinecraftServer;
import org.slf4j.Logger;

import java.lang.reflect.Method;
import java.util.UUID;

/**
 * Link to the bank of the Aesthetic Jobs mod. It is done with reflection on purpose: this mod then compiles
 * without the aestheticjobs jar (CI, fresh clones) and still talks to the real bank when that mod is loaded.
 * If the bank is missing, the balance is 0 and every payment is refused, so nothing is ever bought for free.
 */
public final class BankBridge {
    private BankBridge() {}

    private static final Logger LOGGER = LogUtils.getLogger();

    private static final String BANK = "dev.aestheticjobs.economy.Bank";
    private static final String TRANSACTION_TYPE = "dev.aestheticjobs.economy.Transaction$Type";

    private static volatile boolean resolved;
    private static Method balanceMethod;
    private static Method withdrawMethod;
    private static Object withdrawType;
    private static Method depositMethod;
    private static Object wageType;

    private static synchronized void resolve() {
        if (resolved) {
            return;
        }
        resolved = true;
        try {
            Class<?> bank = Class.forName(BANK);
            Class<?> type = Class.forName(TRANSACTION_TYPE);
            balanceMethod = bank.getMethod("balance", MinecraftServer.class, UUID.class);
            withdrawMethod = bank.getMethod("withdraw", MinecraftServer.class, UUID.class, long.class, type, String.class);
            withdrawType = Enum.valueOf(type.asSubclass(Enum.class), "WITHDRAW");
            try {
                // only needed for the seller's commission to the shop owner; optional
                depositMethod = bank.getMethod("deposit", MinecraftServer.class, UUID.class, long.class, type, String.class);
                wageType = Enum.valueOf(type.asSubclass(Enum.class), "WAGE");
            } catch (ReflectiveOperationException | RuntimeException e) {
                depositMethod = null;
                LOGGER.warn("Bank.deposit not found, seller commission is disabled");
            }
        } catch (ReflectiveOperationException | RuntimeException | LinkageError e) {
            LOGGER.error("Aesthetic Jobs bank not found, the shop is disabled", e);
            balanceMethod = null;
            withdrawMethod = null;
        }
    }

    public static boolean available() {
        resolve();
        return balanceMethod != null && withdrawMethod != null;
    }

    /** Balance of the account in cents, 0 if the bank is not there. */
    public static long balance(MinecraftServer server, UUID account) {
        if (!available()) {
            return 0L;
        }
        try {
            return ((Number) balanceMethod.invoke(null, server, account)).longValue();
        } catch (ReflectiveOperationException | RuntimeException e) {
            LOGGER.error("Bank.balance failed", e);
            return 0L;
        }
    }

    /** Takes money from the account. Returns true only if the bank answered OK. */
    @SuppressWarnings("SameParameterValue")
    public static boolean withdraw(MinecraftServer server, UUID account, long cents, String reason) {
        if (!available()) {
            return false;
        }
        try {
            Object result = withdrawMethod.invoke(null, server, account, cents, withdrawType, reason);
            return result != null && "OK".equals(result.toString());
        } catch (ReflectiveOperationException | RuntimeException e) {
            LOGGER.error("Bank.withdraw failed", e);
            return false;
        }
    }

    /** Pays money into the account (the owner's commission). Returns true only if the bank answered OK. */
    public static boolean deposit(MinecraftServer server, UUID account, long cents, String reason) {
        if (!available() || depositMethod == null) {
            return false;
        }
        try {
            Object result = depositMethod.invoke(null, server, account, cents, wageType, reason);
            return result != null && "OK".equals(result.toString());
        } catch (ReflectiveOperationException | RuntimeException e) {
            LOGGER.error("Bank.deposit failed", e);
            return false;
        }
    }
}
