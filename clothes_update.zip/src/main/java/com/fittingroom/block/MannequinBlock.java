package com.fittingroom.block;

import com.fittingroom.blockentity.MannequinBlockEntity;
import com.fittingroom.wardrobe.ClothingCatalog;
import com.fittingroom.wardrobe.Looks;
import com.fittingroom.wardrobe.Sales;
import com.fittingroom.wardrobe.Shop;
import com.fittingroom.economy.Money;
import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

import java.util.List;

/**
 * Two-block-tall shop mannequin. It shows a ready-made look ({@link Looks}). Sneak + right click by the owner (or
 * anybody when it has no owner, or an op in creative) changes the look; a plain right click by a customer puts
 * the look into their cart. Only the lower block has a block entity; the figure is drawn by {@code MannequinRenderer}.
 */
public class MannequinBlock extends HorizontalDirectionalBlock implements EntityBlock {
    public static final MapCodec<MannequinBlock> CODEC = simpleCodec(MannequinBlock::new);
    public static final DirectionProperty FACING = HorizontalDirectionalBlock.FACING;
    public static final EnumProperty<DoubleBlockHalf> HALF = BlockStateProperties.DOUBLE_BLOCK_HALF;

    private static final VoxelShape SHAPE = Block.box(2, 0, 2, 14, 16, 14);

    public MannequinBlock(Properties properties) {
        super(properties);
        registerDefaultState(stateDefinition.any()
                .setValue(FACING, Direction.NORTH)
                .setValue(HALF, DoubleBlockHalf.LOWER));
    }

    @Override
    protected MapCodec<? extends HorizontalDirectionalBlock> codec() {
        return CODEC;
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(FACING, HALF);
    }

    @Override
    protected VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext ctx) {
        return SHAPE;
    }

    // ---------- placement (same rules as the fitting room) ----------

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext ctx) {
        BlockPos pos = ctx.getClickedPos();
        Level level = ctx.getLevel();
        if (pos.getY() < level.getMaxBuildHeight() - 1 && level.getBlockState(pos.above()).canBeReplaced(ctx)) {
            return defaultBlockState()
                    .setValue(FACING, ctx.getHorizontalDirection().getOpposite())
                    .setValue(HALF, DoubleBlockHalf.LOWER);
        }
        return null;
    }

    @Override
    public void setPlacedBy(Level level, BlockPos pos, BlockState state, LivingEntity placer, ItemStack stack) {
        level.setBlock(pos.above(), state.setValue(HALF, DoubleBlockHalf.UPPER), 3);
        if (!level.isClientSide && level.getBlockEntity(pos) instanceof MannequinBlockEntity mannequin) {
            if (placer != null) {
                mannequin.setOwner(placer.getUUID());
            }
            Looks.Look first = Looks.next("");
            if (first != null) {
                mannequin.setLook(first);
            }
        }
    }

    @Override
    protected boolean canSurvive(BlockState state, LevelReader level, BlockPos pos) {
        BlockPos below = pos.below();
        BlockState belowState = level.getBlockState(below);
        if (state.getValue(HALF) == DoubleBlockHalf.LOWER) {
            return belowState.isFaceSturdy(level, below, Direction.UP);
        }
        return belowState.is(this) && belowState.getValue(HALF) == DoubleBlockHalf.LOWER;
    }

    @Override
    protected BlockState updateShape(BlockState state, Direction direction, BlockState neighborState,
                                     LevelAccessor level, BlockPos pos, BlockPos neighborPos) {
        DoubleBlockHalf half = state.getValue(HALF);
        boolean towardOtherHalf = direction.getAxis() == Direction.Axis.Y
                && (half == DoubleBlockHalf.LOWER) == (direction == Direction.UP);
        if (towardOtherHalf) {
            if (neighborState.is(this) && neighborState.getValue(HALF) != half) {
                return state;
            }
            return Blocks.AIR.defaultBlockState();
        }
        if (half == DoubleBlockHalf.LOWER && direction == Direction.DOWN && !state.canSurvive(level, pos)) {
            return Blocks.AIR.defaultBlockState();
        }
        return super.updateShape(state, direction, neighborState, level, pos, neighborPos);
    }

    @Override
    public BlockState playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        if (!level.isClientSide && player.isCreative() && state.getValue(HALF) == DoubleBlockHalf.UPPER) {
            BlockPos below = pos.below();
            BlockState belowState = level.getBlockState(below);
            if (belowState.is(this) && belowState.getValue(HALF) == DoubleBlockHalf.LOWER) {
                level.setBlock(below, Blocks.AIR.defaultBlockState(), 35);
                level.levelEvent(player, 2001, below, Block.getId(belowState));
            }
        }
        return super.playerWillDestroy(level, pos, state, player);
    }

    // ---------- block entity ----------

    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return state.getValue(HALF) == DoubleBlockHalf.LOWER ? new MannequinBlockEntity(pos, state) : null;
    }

    // ---------- dressing ----------

    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player,
                                               BlockHitResult hit) {
        BlockPos lower = state.getValue(HALF) == DoubleBlockHalf.LOWER ? pos : pos.below();
        if (player instanceof ServerPlayer serverPlayer
                && level.getBlockEntity(lower) instanceof MannequinBlockEntity mannequin) {
            boolean mayChange = mannequin.owner() == null || player.getUUID().equals(mannequin.owner())
                    || (player.isCreative() && player.hasPermissions(2));
            if (player.isSecondaryUseActive() && mayChange) {
                Looks.Look next = Looks.next(mannequin.look());
                if (next != null) {
                    mannequin.setLook(next);
                    serverPlayer.displayClientMessage(Component.translatable("message.fittingroom.mannequin_look",
                            Component.translatable("look.fittingroom." + next.id())), true);
                    level.playSound(null, pos, SoundEvents.WOOL_PLACE, SoundSource.BLOCKS, 1.0F, 1.1F);
                }
            } else {
                Looks.Look look = Looks.byId(mannequin.look());
                if (look == null) {
                    serverPlayer.displayClientMessage(Component.translatable("message.fittingroom.mannequin_empty"), true);
                } else {
                    buyLook(serverPlayer, look);
                }
            }
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }

    /** A customer clicks the mannequin: whatever of the look they do not own yet goes into their cart. */
    private static void buyLook(ServerPlayer player, Looks.Look look) {
        List<String> fresh = new java.util.ArrayList<>();
        long total = 0;
        for (String id : Looks.items(look)) {
            ClothingCatalog.Item item = ClothingCatalog.byId(id);
            if (item != null && !Shop.owned(player).owns(id)) {
                fresh.add(id);
                total += Sales.price(item, ClothingCatalog.today());
            }
        }
        Component name = Component.translatable("look.fittingroom." + look.id());
        if (fresh.isEmpty()) {
            player.displayClientMessage(Component.translatable("message.fittingroom.mannequin_owned", name), true);
            return;
        }
        Shop.addToCart(player, fresh);
        player.displayClientMessage(Component.translatable("message.fittingroom.mannequin_added", name,
                Money.format(total), fresh.size()), true);
    }

    @Override
    protected BlockState rotate(BlockState state, Rotation rotation) {
        return state.setValue(FACING, rotation.rotate(state.getValue(FACING)));
    }

    @Override
    protected BlockState mirror(BlockState state, Mirror mirror) {
        return state.rotate(mirror.getRotation(state.getValue(FACING)));
    }
}
