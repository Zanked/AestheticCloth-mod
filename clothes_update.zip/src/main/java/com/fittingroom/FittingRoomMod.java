package com.fittingroom;

import com.fittingroom.block.FittingRoomBlock;
import com.fittingroom.block.MannequinBlock;
import com.fittingroom.blockentity.MannequinBlockEntity;
import com.fittingroom.network.ModNetwork;
import com.fittingroom.seller.CartData;
import com.fittingroom.seller.LoyaltyData;
import com.fittingroom.seller.SellerContractItem;
import com.fittingroom.seller.SellerEntity;
import com.fittingroom.wardrobe.OutfitSlotsData;
import com.fittingroom.wardrobe.OwnedData;
import com.fittingroom.wardrobe.WardrobeData;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.material.PushReaction;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.attachment.AttachmentType;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.NeoForgeRegistries;

import java.util.function.Supplier;

@Mod(FittingRoomMod.MOD_ID)
public class FittingRoomMod {
    public static final String MOD_ID = "fittingroom";

    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(MOD_ID);
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(MOD_ID);
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES =
            DeferredRegister.create(Registries.BLOCK_ENTITY_TYPE, MOD_ID);
    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES =
            DeferredRegister.create(Registries.ENTITY_TYPE, MOD_ID);
    public static final DeferredRegister<AttachmentType<?>> ATTACHMENT_TYPES =
            DeferredRegister.create(NeoForgeRegistries.ATTACHMENT_TYPES, MOD_ID);

    public static final DeferredBlock<Block> FITTING_ROOM = BLOCKS.register("fitting_room",
            () -> new FittingRoomBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.COLOR_CYAN)
                    .strength(1.0F)
                    .sound(SoundType.WOOL)
                    .noOcclusion()
                    .pushReaction(PushReaction.DESTROY)));

    public static final DeferredItem<BlockItem> FITTING_ROOM_ITEM =
            ITEMS.registerSimpleBlockItem("fitting_room", FITTING_ROOM);

    public static final DeferredBlock<Block> MANNEQUIN = BLOCKS.register("mannequin",
            () -> new MannequinBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.SAND)
                    .strength(1.0F)
                    .sound(SoundType.WOOL)
                    .noOcclusion()
                    .pushReaction(PushReaction.DESTROY)));

    public static final DeferredItem<BlockItem> MANNEQUIN_ITEM =
            ITEMS.registerSimpleBlockItem("mannequin", MANNEQUIN);

    public static final Supplier<EntityType<SellerEntity>> SELLER = ENTITY_TYPES.register("seller",
            () -> EntityType.Builder.of(SellerEntity::new, MobCategory.MISC)
                    .sized(0.6F, 1.8F).clientTrackingRange(8).build("seller"));

    public static final DeferredItem<Item> SELLER_CONTRACT = ITEMS.register("seller_contract",
            () -> new SellerContractItem(new Item.Properties().stacksTo(16)));

    public static final Supplier<BlockEntityType<MannequinBlockEntity>> MANNEQUIN_BE = BLOCK_ENTITIES.register("mannequin",
            () -> BlockEntityType.Builder.of(MannequinBlockEntity::new, MANNEQUIN.get()).build(null));

    /** What the player is wearing. Saved with the player and kept after death. */
    public static final Supplier<AttachmentType<WardrobeData>> WARDROBE = ATTACHMENT_TYPES.register("wardrobe",
            () -> AttachmentType.builder(() -> WardrobeData.EMPTY)
                    .serialize(WardrobeData.CODEC)
                    .copyOnDeath()
                    .build());

    /** What the player has bought. Saved with the player and kept after death. */
    public static final Supplier<AttachmentType<OwnedData>> OWNED = ATTACHMENT_TYPES.register("owned",
            () -> AttachmentType.builder(() -> OwnedData.EMPTY)
                    .serialize(OwnedData.CODEC)
                    .copyOnDeath()
                    .build());

    /** Saved outfits (slots in the fitting room). Saved with the player and kept after death. */
    public static final Supplier<AttachmentType<OutfitSlotsData>> SLOTS = ATTACHMENT_TYPES.register("outfit_slots",
            () -> AttachmentType.builder(() -> OutfitSlotsData.EMPTY)
                    .serialize(OutfitSlotsData.CODEC)
                    .copyOnDeath()
                    .build());

    /** What the player has spent at the seller (loyalty card). */
    public static final Supplier<AttachmentType<LoyaltyData>> LOYALTY = ATTACHMENT_TYPES.register("loyalty",
            () -> AttachmentType.builder(() -> LoyaltyData.EMPTY)
                    .serialize(LoyaltyData.CODEC)
                    .copyOnDeath()
                    .build());

    /** Clothes waiting in the cart to be paid at the seller. */
    public static final Supplier<AttachmentType<CartData>> CART = ATTACHMENT_TYPES.register("cart",
            () -> AttachmentType.builder(() -> CartData.EMPTY)
                    .serialize(CartData.CODEC)
                    .copyOnDeath()
                    .build());

    public FittingRoomMod(IEventBus modBus) {
        BLOCKS.register(modBus);
        ITEMS.register(modBus);
        BLOCK_ENTITIES.register(modBus);
        ENTITY_TYPES.register(modBus);
        modBus.addListener(this::registerAttributes);
        ATTACHMENT_TYPES.register(modBus);
        FittingSounds.SOUNDS.register(modBus);
        modBus.addListener(this::addToCreativeTab);
        modBus.addListener(ModNetwork::register);
    }

    private void registerAttributes(EntityAttributeCreationEvent event) {
        event.put(SELLER.get(), SellerEntity.createAttributes().build());
    }

    private void addToCreativeTab(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.FUNCTIONAL_BLOCKS) {
            event.accept(FITTING_ROOM_ITEM);
            event.accept(MANNEQUIN_ITEM);
        }
        if (event.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
            event.accept(SELLER_CONTRACT);
        }
    }
}
