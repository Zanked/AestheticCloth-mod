package com.fittingroom.wardrobe;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.MonthDay;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.List;

/**
 * Discounts. Everything is worked out from the date alone, so the server and the client always agree
 * (the server sends its date to the client together with the wallet). Sales do not stack: an item gets
 * the best discount that covers it.
 * <ul>
 *   <li>DAILY: one category per day (they take turns), 15-25% off;</li>
 *   <li>WEEKEND: Saturday and Sunday, 10% off everything;</li>
 *   <li>BLACK_FRIDAY: Monday before to Cyber Monday, 30% off everything;</li>
 *   <li>NEW_YEAR: Dec 15 - Jan 14, 20% off the holiday clothes;</li>
 *   <li>SCHOOL: Aug 20 - Sep 10, 25% off both school uniforms.</li>
 * </ul>
 */
public final class Sales {
    private Sales() {}

    public enum Kind { DAILY, WEEKEND, BLACK_FRIDAY, NEW_YEAR, SCHOOL }

    /** One running sale. {@code category} is only set for DAILY. */
    public record Offer(Kind kind, int percent, Category category) {
        public boolean covers(ClothingCatalog.Item item) {
            return switch (kind) {
                case DAILY -> item.category() == category;
                case NEW_YEAR -> item.seasonFrom() != null;
                case SCHOOL -> item.id().startsWith("school_") || item.id().startsWith("boy_");
                case WEEKEND, BLACK_FRIDAY -> true;
            };
        }
    }

    private static final MonthDay NEW_YEAR_FROM = MonthDay.of(12, 15);
    private static final MonthDay NEW_YEAR_TO = MonthDay.of(1, 14);
    private static final MonthDay SCHOOL_FROM = MonthDay.of(8, 20);
    private static final MonthDay SCHOOL_TO = MonthDay.of(9, 10);

    /** All sales running on that day (the daily one is always there). */
    public static List<Offer> active(LocalDate day) {
        List<Offer> out = new ArrayList<>();
        long n = day.toEpochDay();
        Category[] categories = Category.values();
        out.add(new Offer(Kind.DAILY, 15 + 5 * (int) Math.floorMod(n, 3L),
                categories[(int) Math.floorMod(n * 7 + 3, (long) categories.length)]));

        DayOfWeek dow = day.getDayOfWeek();
        if (dow == DayOfWeek.SATURDAY || dow == DayOfWeek.SUNDAY) {
            out.add(new Offer(Kind.WEEKEND, 10, null));
        }
        LocalDate blackFriday = LocalDate.of(day.getYear(), 11, 1)
                .with(TemporalAdjusters.dayOfWeekInMonth(4, DayOfWeek.THURSDAY)).plusDays(1);
        if (!day.isBefore(blackFriday.minusDays(4)) && !day.isAfter(blackFriday.plusDays(3))) {
            out.add(new Offer(Kind.BLACK_FRIDAY, 30, null));
        }
        if (inRange(day, NEW_YEAR_FROM, NEW_YEAR_TO)) {
            out.add(new Offer(Kind.NEW_YEAR, 20, null));
        }
        if (inRange(day, SCHOOL_FROM, SCHOOL_TO)) {
            out.add(new Offer(Kind.SCHOOL, 25, null));
        }
        return out;
    }

    private static boolean inRange(LocalDate day, MonthDay from, MonthDay to) {
        MonthDay today = MonthDay.from(day);
        if (from.compareTo(to) <= 0) {
            return today.compareTo(from) >= 0 && today.compareTo(to) <= 0;
        }
        return today.compareTo(from) >= 0 || today.compareTo(to) <= 0;
    }

    /** The biggest running sale (for the banner), or null if there is none. */
    public static Offer headline(LocalDate day) {
        Offer best = null;
        for (Offer offer : active(day)) {
            if (best == null || offer.percent() > best.percent()) {
                best = offer;
            }
        }
        return best;
    }

    /** The best sale that covers the item, or null. */
    public static Offer bestFor(ClothingCatalog.Item item, LocalDate day) {
        Offer best = null;
        for (Offer offer : active(day)) {
            if (offer.covers(item) && (best == null || offer.percent() > best.percent())) {
                best = offer;
            }
        }
        return best;
    }

    public static int percentOff(ClothingCatalog.Item item, LocalDate day) {
        Offer best = bestFor(item, day);
        return best == null ? 0 : best.percent();
    }

    /** Price to pay on that day, in cents. Never zero. */
    public static long price(ClothingCatalog.Item item, LocalDate day) {
        long base = item.priceCents();
        int percent = percentOff(item, day);
        if (percent <= 0) {
            return base;
        }
        return Math.max(1L, Math.round(base * (100 - percent) / 100.0));
    }
}
