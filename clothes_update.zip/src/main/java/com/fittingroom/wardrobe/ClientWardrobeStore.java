package com.fittingroom.wardrobe;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Client-side copy of what every nearby player wears. Plain Java on purpose (no Minecraft client
 * classes), so it is safe to touch from the network handler on a dedicated server too.
 */
public final class ClientWardrobeStore {
    private ClientWardrobeStore() {}

    private static final Map<UUID, List<String>> OUTFITS = new ConcurrentHashMap<>();

    public static List<String> get(UUID player) {
        return OUTFITS.getOrDefault(player, List.of());
    }

    public static void set(UUID player, List<String> items) {
        OUTFITS.put(player, List.copyOf(items));
    }

    // ---- the local player's wallet: what they have bought and what is on their bank account ----
    private static volatile Set<String> owned = Set.of();
    private static volatile long balanceCents = 0L;

    public static boolean owns(String id) {
        return owned.contains(id);
    }

    public static long balance() {
        return balanceCents;
    }

    // ---- the day the server uses for sale prices, and the saved outfits ----
    private static volatile long saleDay = LocalDate.now().toEpochDay();
    private static volatile List<List<String>> slots = List.of();

    /** The server's date: sale prices must be worked out with it, not with the date of this computer. */
    public static LocalDate saleDate() {
        return LocalDate.ofEpochDay(saleDay);
    }

    /** Saved outfit in slot {@code index} (empty list = empty slot). */
    public static List<String> slot(int index) {
        List<List<String>> all = slots;
        return index >= 0 && index < all.size() ? all.get(index) : List.of();
    }

    /** Shows a saved outfit at once; the server's answer follows with the same data. */
    public static void setSlot(int index, List<String> items) {
        if (index < 0 || index >= OutfitSlotsData.COUNT) {
            return;
        }
        List<List<String>> copy = new ArrayList<>(slots);
        while (copy.size() < OutfitSlotsData.COUNT) {
            copy.add(List.of());
        }
        copy.set(index, List.copyOf(items));
        slots = List.copyOf(copy);
    }

    public static void setWallet(Collection<String> ownedIds, long balance, long day, List<List<String>> savedSlots) {
        owned = Set.copyOf(ownedIds);
        balanceCents = balance;
        saleDay = day;
        List<List<String>> copy = new ArrayList<>();
        for (List<String> one : savedSlots) {
            copy.add(List.copyOf(one));
        }
        slots = List.copyOf(copy);
    }

    public static void clear() {
        OUTFITS.clear();
        owned = Set.of();
        balanceCents = 0L;
        slots = List.of();
    }
}
