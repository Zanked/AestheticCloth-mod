package com.fittingroom.wardrobe;

import com.mojang.serialization.Codec;

import java.util.ArrayList;
import java.util.List;

/** Saved outfits of a player ({@link #COUNT} slots, an empty list = empty slot). Kept after death. */
public record OutfitSlotsData(List<List<String>> slots) {
    public static final int COUNT = 5;
    public static final OutfitSlotsData EMPTY = new OutfitSlotsData(List.of());

    public static final Codec<OutfitSlotsData> CODEC =
            Codec.STRING.listOf().listOf().xmap(OutfitSlotsData::new, OutfitSlotsData::slots);

    /** Always exactly {@link #COUNT} lists. */
    public List<List<String>> padded() {
        List<List<String>> out = new ArrayList<>();
        for (int i = 0; i < COUNT; i++) {
            out.add(i < slots.size() ? List.copyOf(slots.get(i)) : List.of());
        }
        return out;
    }

    public OutfitSlotsData with(int index, List<String> items) {
        if (index < 0 || index >= COUNT) {
            return this;
        }
        List<List<String>> copy = new ArrayList<>(padded());
        copy.set(index, List.copyOf(items));
        return new OutfitSlotsData(copy);
    }
}
