package com.fittingroom.wardrobe;

import java.util.HashMap;
import java.util.Map;

/**
 * Shelf prices of the clothes, in US cents (same currency as the aestheticjobs bank: $24.99 = 2499).
 * The numbers follow what such things cost in a normal shop in the USA (before sales tax): a T-shirt about
 * $15-25, jeans about $60, a leather biker jacket a couple of hundred, a pearl necklace about a hundred.
 * For comparison, the cafe job pays $12 per hour.
 * <p>
 * An id that is missing here still gets a price: {@link #fallback(Category)}.
 */
public final class ClothingPrices {
    private ClothingPrices() {}

    private static final Map<String, Long> CENTS = new HashMap<>();

    private static void p(String id, long cents) {
        CENTS.put(id, cents);
    }

    static {
        // ---- New Year (seasonal) ----
        p("santa_hat", 1299);
        p("santa_coat", 4999);
        p("santa_pants", 2999);
        p("santa_boots", 3999);
        p("santa_sack", 1999);
        p("scarf_xmas", 2499);
        p("reindeer_antlers", 1499);
        p("snow_kokoshnik", 2999);
        p("xmas_sweater", 4499);
        p("snow_coat", 5999);
        p("snow_valenki", 3999);
        p("candy_cane", 799);
        p("necklace_snowflake", 3999);
        p("bracelet_bells", 1499);

        // ---- everyday clothes ----
        p("casual_cap", 2499);
        p("casual_hoodie", 4999);
        p("casual_jeans", 5999);
        p("casual_sneakers", 7999);
        p("casual_tee_white", 1499);
        p("casual_tee_black", 1999);
        p("casual_tee_pink", 1999);
        p("casual_tee_striped", 2499);
        p("casual_shorts_denim", 3499);
        p("casual_shorts_black", 2999);
        p("casual_shorts_khaki", 3499);
        p("casual_skirt_denim", 3999);
        p("casual_skirt_pink", 2999);
        p("casual_skirt_plaid", 3499);
        p("casual_cardigan_cream", 4499);
        p("casual_cardigan_pink", 4499);
        p("casual_cardigan_blue", 4499);
        p("casual_kedy_white", 6499);
        p("casual_kedy_red", 6499);
        p("casual_kedy_black", 6499);
        p("casual_backpack", 4999);
        p("halloween_pumpkin_hat", 3499);
        p("halloween_ghost_hood", 3299);
        p("halloween_bat_headband", 2799);
        p("halloween_devil_horns", 2799);
        p("halloween_ghost_sheet", 4999);
        p("halloween_vampire_cape", 7999);
        p("halloween_witch_dress", 5999);
        p("halloween_skeleton_top", 3999);
        p("halloween_skeleton_pants", 3499);
        p("halloween_mummy_top", 3999);
        p("halloween_mummy_pants", 3499);
        p("halloween_devil_pants", 4499);
        p("halloween_witch_boots", 4999);
        p("halloween_candy_bucket", 2999);
        p("pants_jeans_ripped", 4499);
        p("pants_jeans_flared", 4499);
        p("pants_jeans_white", 4299);
        p("pants_trousers_black", 4999);
        p("pants_chino_beige", 4299);
        p("pants_cargo_khaki", 4799);
        p("pants_sweat_gray", 3499);
        p("pants_sweat_black", 3499);
        p("pants_leggings_black", 2999);
        p("pants_leggings_pink", 2999);
        p("skirt_maxi_floral", 4999);
        p("skirt_maxi_satin", 5499);
        p("skirt_tennis", 3999);
        p("overalls_denim", 5999);
        p("overalls_cord", 5999);
        p("shoes_rain_yellow", 3999);
        p("shoes_rain_red", 3999);
        p("shoes_rain_pink", 4299);
        p("shoes_ballet_pink", 3499);
        p("shoes_ballet_black", 3499);
        p("shoes_ballet_white", 3499);
        p("shoes_platform_black", 5499);
        p("shoes_platform_white", 5499);
        p("shoes_platform_pink", 5499);
        p("shoes_bunny_white", 2999);
        p("shoes_bunny_pink", 2999);
        p("shoes_bunny_gray", 2999);
        p("dress_floral", 4999);
        p("dress_sundress", 3999);
        p("dress_evening", 12999);
        p("dress_polka", 4499);
        p("windbreaker_blue", 5499);
        p("windbreaker_pink", 5499);
        p("windbreaker_yellow", 5499);
        p("trench_beige", 12999);
        p("trench_black", 12999);
        p("coat_camel", 14999);
        p("coat_gray", 14999);
        p("coat_red", 15999);
        p("sweater_cable", 5999);
        p("sweater_nordic", 6499);
        p("sweater_pink", 4999);
        p("sweater_stripe", 4499);
        p("kimono_sakura", 17999);
        p("kimono_red", 19999);
        p("yukata_indigo", 8999);
        p("yukata_light", 8999);
        p("pajama_stars_top", 3499);
        p("pajama_stars_pants", 2999);
        p("pajama_hearts_top", 3499);
        p("pajama_hearts_pants", 2999);
        p("pajama_stripe_top", 3299);
        p("pajama_stripe_pants", 2799);

        // ---- punk ----
        p("punk_tee", 2499);
        p("punk_jeans", 6999);
        p("punk_jacket_black", 24999);
        p("punk_jacket_brown", 24999);
        p("punk_boots_black", 14999);
        p("punk_boots_brown", 14999);
        p("punk_cuffs", 1999);

        // ---- cat costume ----
        p("cat_ears", 999);
        p("cat_sweater", 3999);
        p("cat_pants", 3499);
        p("cat_paws", 2499);

        // ---- dino kigurumi (green and blue cost the same) ----
        for (String colour : new String[]{"", "blue_"}) {
            p("dino_" + colour + "hood", 2999);
            p("dino_" + colour + "top", 5999);
            p("dino_" + colour + "pants", 3499);
            p("dino_" + colour + "slippers", 2499);
        }

        // ---- school uniform, girls (white and black sets cost the same) ----
        for (String colour : new String[]{"", "black_"}) {
            p("school_" + colour + "bow", 699);
            p("school_" + colour + "top", 4499);
            p("school_" + colour + "skirt", 3999);
            p("school_" + colour + "socks", 6999);
            p("school_" + colour + "bag", 5999);
        }

        // ---- school uniform, boys (gakuran) ----
        p("boy_cap", 2999);
        p("boy_gakuran", 8999);
        p("boy_trousers", 4499);
        p("boy_shoes", 6999);

        // ---- plush backpacks ----
        p("plush_cat", 3499);
        p("plush_dino", 3499);
        p("plush_bear", 3499);

        // ---- balloons ----
        for (String colour : new String[]{"red", "pink", "blue", "yellow", "green", "purple"}) {
            p("balloon_" + colour, 399);
        }
        p("balloon_bunch_rainbow", 1299);
        p("balloon_bunch_pastel", 1299);

        // ---- gloves ----
        for (String colour : new String[]{"white", "black", "red", "pink", "blue", "yellow", "green", "purple"}) {
            p("gloves_" + colour, 1499);
        }

        // ---- glasses ----
        p("glasses_round", 4999);
        p("glasses_sun", 2999);
        p("glasses_heart", 1499);
        p("glasses_3d", 599);
        p("glasses_pixel", 1299);

        // ---- hats (all year) ----
        p("hat_witch", 3499);
        p("hat_mushroom", 2999);
        p("hat_crown", 4999);
        p("hat_bunny", 2499);
        p("hat_frog", 2799);
        p("hat_halo", 1999);
        p("hat_chef", 1999);
        p("hat_propeller", 1799);
        p("hat_strawberry", 2299);
        p("hat_flowers", 2499);

        // ---- hats (all year) ----
        p("hat_beanie_gray", 1999);
        p("hat_beanie_mustard", 2299);
        p("hat_beanie_pink", 2299);
        p("hat_beret_red", 2499);
        p("hat_beret_black", 2499);
        p("hat_beret_cream", 2499);
        p("hat_panama_natural", 2699);
        p("hat_panama_white", 2699);
        p("hat_panama_pink", 2699);
        p("hat_cowboy_brown", 3299);
        p("hat_cowboy_black", 3299);
        p("hat_cowboy_cream", 3299);

        // ---- bags, umbrellas, wings, masks, earrings ----
        p("bag_brown", 5999);
        p("bag_pink", 4499);
        p("bag_black", 8999);
        p("umbrella_pink", 2499);
        p("umbrella_rainbow", 2799);
        p("umbrella_black", 2999);
        p("wings_angel", 6999);
        p("wings_butterfly", 7999);
        p("wings_bat", 6999);
        p("mask_pink", 1499);
        p("mask_black", 1799);
        p("mask_lavender", 1499);
        p("earring_pearl", 3499);
        p("earring_hoop", 4999);
        p("earring_star", 2999);
        p("earring_heart", 2999);

        p("necklace_spider", 2499);
        // ---- suits (blue and white cost the same) and the skull tie ----
        p("suit_blue_jacket", 12999);
        p("suit_blue_pants", 5999);
        p("suit_white_jacket", 12999);
        p("suit_white_pants", 5999);
        p("tie_skull", 1999);
        p("tie_skull_red", 1999);
        p("tie_skull_blue", 1999);
        p("tie_skull_green", 1999);
        p("tie_skull_pink", 1999);
        p("tie_skull_black", 1999);
        p("tie_skull_white", 1999);

        // ---- long-coat costumes (white and black cost the same) ----
        p("jotaro_p4_cap", 3499);
        p("jotaro_p4_coat", 15999);
        p("jotaro_p4_pants", 6999);
        p("jotaro_p3_cap", 3499);
        p("jotaro_p3_coat", 15999);
        p("jotaro_p3_pants", 6999);
        p("jotaro_p3_chain", 2499);

        // ---- pink heart suit ----
        p("giorno_jacket", 14999);
        p("giorno_pants", 6999);
        p("giorno_shoes", 5499);

        // ---- navy jacket with the white collar ----
        p("josuke_jacket", 13999);
        p("josuke_pants", 6499);

        // ---- net and tattoo torso with purple studded pants ----
        p("diavolo_top", 8999);
        p("diavolo_pants", 9999);
        p("diavolo_boots", 6499);

        // ---- Joseph, young and old ----
        p("joseph_young_scarf", 2999);
        p("joseph_young_top", 6999);
        p("joseph_young_gloves", 3499);
        p("joseph_young_jeans", 5999);
        p("joseph_young_boots", 7499);
        p("joseph_old_hat", 4499);
        p("joseph_old_shirt", 6999);
        p("joseph_old_gloves", 3299);
        p("joseph_old_pants", 5499);
        p("joseph_old_boots", 6499);

        // ---- Joseph, young and old ----
        p("fugo_jacket", 11999);
        p("fugo_pants", 6499);
        p("fugo_tie", 1999);
        p("fugo_shoes", 6999);

        // ---- Joseph, young and old ----
        p("alucard_hat", 5499);
        p("alucard_glasses", 2499);
        p("alucard_coat", 14999);
        p("alucard_cravat", 1999);
        p("alucard_gloves", 2999);
        p("alucard_pants", 5999);
        p("alucard_boots", 7999);

        // ---- scarves ----
        p("scarf_red", 2499);
        p("scarf_blue", 2499);
        p("scarf_pink", 2799);
        p("scarf_plaid", 3499);
        p("scarf_rainbow", 2299);

        // ---- jewelry ----
        p("choker_black", 999);
        p("choker_pink", 899);
        p("choker_lace", 1299);
        p("choker_chain", 1499);
        p("choker_spiked", 1499);
        p("necklace_pearl", 9999);
        p("necklace_heart", 3999);
        p("necklace_star", 3999);
        p("necklace_beads", 1299);
        p("bracelet_gold", 19999);
        p("bracelet_charm", 5999);
        p("bracelet_beads", 999);
        p("bracelet_friendship", 499);
    }

    /** Price of a garment in cents. Never zero, so that nothing is free by accident. */
    public static long cents(String id, Category category) {
        Long cents = CENTS.get(id);
        return cents != null ? cents : fallback(category);
    }

    /** True if the id has its own price in the table (used by the self-check). */
    public static boolean hasOwnPrice(String id) {
        return CENTS.containsKey(id);
    }

    private static long fallback(Category category) {
        return switch (category) {
            case HAT -> 1999;
            case TOP -> 3499;
            case BOTTOM -> 3999;
            case SHOES -> 5999;
            case ACCESSORY -> 1999;
        };
    }
}
