package com.fittingroom.blockentity;

import com.fittingroom.FittingRoomMod;
import com.fittingroom.wardrobe.Looks;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/** What a mannequin wears. Lives in the lower block of the mannequin and is sent to the clients. */
public class MannequinBlockEntity extends BlockEntity {
    private List<String> outfit = List.of();
    private String look = "";
    private UUID owner;

    public MannequinBlockEntity(BlockPos pos, BlockState state) {
        super(FittingRoomMod.MANNEQUIN_BE.get(), pos, state);
    }

    public List<String> outfit() {
        return outfit;
    }

    /** Id of the shop look on show (empty if none). */
    public String look() {
        return look;
    }

    public UUID owner() {
        return owner;
    }

    public void setOwner(UUID owner) {
        this.owner = owner;
        setChanged();
    }

    /** Puts a ready-made look on the mannequin. */
    public void setLook(Looks.Look next) {
        this.look = next.id();
        setOutfit(Looks.items(next));
    }

    public void setOutfit(List<String> ids) {
        this.outfit = List.copyOf(ids);
        setChanged();
        if (level != null) {
            level.sendBlockUpdated(worldPosition, getBlockState(), getBlockState(), 3);
        }
    }

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        ListTag list = new ListTag();
        for (String id : outfit) {
            list.add(StringTag.valueOf(id));
        }
        tag.put("outfit", list);
        tag.putString("look", look);
        if (owner != null) {
            tag.putUUID("owner", owner);
        }
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        ListTag list = tag.getList("outfit", Tag.TAG_STRING);
        List<String> ids = new ArrayList<>();
        for (int i = 0; i < list.size(); i++) {
            ids.add(list.getString(i));
        }
        this.outfit = List.copyOf(ids);
        this.look = tag.getString("look");
        this.owner = tag.hasUUID("owner") ? tag.getUUID("owner") : null;
    }

    @Override
    public CompoundTag getUpdateTag(HolderLookup.Provider registries) {
        return saveWithoutMetadata(registries);
    }

    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }

    /**
     * The figure is two blocks tall: without this the upper half would disappear when the lower block is
     * out of view. (NeoForge asks the block entity for this box; if the name ever changes the mannequin only
     * gets culled a bit too early.)
     */
    public AABB getRenderBoundingBox() {
        return new AABB(worldPosition).expandTowards(0.0, 1.5, 0.0).inflate(0.8, 0.0, 0.8);
    }
}
