package com.fittingroom.client.render;

import com.fittingroom.FittingRoomMod;
import com.fittingroom.block.MannequinBlock;
import com.fittingroom.blockentity.MannequinBlockEntity;
import com.fittingroom.client.garment.GarmentModel;
import com.fittingroom.client.garment.GarmentModels;
import com.fittingroom.economy.Money;
import com.fittingroom.wardrobe.ClientWardrobeStore;
import com.fittingroom.wardrobe.ClothingCatalog;
import com.fittingroom.wardrobe.Looks;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.network.chat.Component;
import org.joml.Matrix4f;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Draws the mannequin: a player model (wide arms) with the ivory mannequin texture, and on top of it the same
 * 3D garments that players wear. The stand (plate and rod) is an ordinary block model.
 */
public class MannequinRenderer implements BlockEntityRenderer<MannequinBlockEntity> {
    private static final ResourceLocation TEXTURE =
            ResourceLocation.fromNamespaceAndPath(FittingRoomMod.MOD_ID, "textures/entity/mannequin.png");

    /**
     * Size of the figure compared with a player (1.0 = a player). A shop mannequin is a little taller than a
     * person, so the clothes are easy to see. Change this one number to make it bigger or smaller.
     */
    private static final float SCALE = 1.15F;

    private final PlayerModel<AbstractClientPlayer> model;
    private final Font font;

    public MannequinRenderer(BlockEntityRendererProvider.Context context) {
        this.font = context.getFont();
        this.model = new PlayerModel<>(context.bakeLayer(ModelLayers.PLAYER), false);
    }

    @Override
    public void render(MannequinBlockEntity mannequin, float partialTick, PoseStack poseStack,
                       MultiBufferSource buffer, int light, int overlay) {
        BlockState state = mannequin.getBlockState();
        if (!state.hasProperty(MannequinBlock.FACING)) {
            return;
        }
        Direction facing = state.getValue(MannequinBlock.FACING);

        poseStack.pushPose();
        // stand on top of the marble plate (1/16 block), then do what the player renderer does
        poseStack.translate(0.5, 1.0 / 16.0, 0.5);
        poseStack.scale(SCALE, SCALE, SCALE);
        poseStack.mulPose(Axis.YP.rotationDegrees(180.0F - facing.toYRot()));
        poseStack.scale(-1.0F, -1.0F, 1.0F);
        poseStack.translate(0.0F, -1.501F, 0.0F);

        // relaxed pose: arms a little away from the body, no overlay layers
        model.setAllVisible(true);
        model.hat.visible = false;
        model.jacket.visible = false;
        model.leftSleeve.visible = false;
        model.rightSleeve.visible = false;
        model.leftPants.visible = false;
        model.rightPants.visible = false;
        model.rightArm.zRot = 0.07F;
        model.leftArm.zRot = -0.07F;

        VertexConsumer body = buffer.getBuffer(RenderType.entityCutoutNoCull(TEXTURE));
        model.renderToBuffer(poseStack, body, light, overlay, -1);

        for (ClothingCatalog.Item item : ClothingCatalog.forRender(mannequin.outfit())) {
            GarmentModel garment = GarmentModels.get(item.id(), false);
            if (garment != null) {
                garment.render(model, poseStack, buffer, light, overlay);
            }
        }
        poseStack.popPose();
        renderTag(mannequin, poseStack, buffer, light);
    }

    /** A small floating tag: the name of the look and its price today (sales included). */
    private void renderTag(MannequinBlockEntity mannequin, PoseStack poseStack, MultiBufferSource buffer, int light) {
        Looks.Look look = Looks.byId(mannequin.look());
        Minecraft mc = Minecraft.getInstance();
        if (look == null || mc.player == null) {
            return;
        }
        double dx = mannequin.getBlockPos().getX() + 0.5 - mc.player.getX();
        double dz = mannequin.getBlockPos().getZ() + 0.5 - mc.player.getZ();
        if (dx * dx + dz * dz > 14 * 14) {
            return;
        }
        Component text = Component.translatable("gui.fittingroom.look_tag",
                Component.translatable("look.fittingroom." + look.id()),
                Money.format(Looks.price(look, ClientWardrobeStore.saleDate())));
        poseStack.pushPose();
        poseStack.translate(0.5, 2.0 * SCALE + 0.3, 0.5);
        poseStack.mulPose(mc.getEntityRenderDispatcher().cameraOrientation());
        poseStack.scale(-0.025F, -0.025F, 0.025F);
        Matrix4f matrix = poseStack.last().pose();
        float x = -font.width(text) / 2.0F;
        font.drawInBatch(text, x, 0, 0xFFFFFFFF, false, matrix, buffer, Font.DisplayMode.NORMAL, 0x60000000, light);
        poseStack.popPose();
    }

    @Override
    public boolean shouldRenderOffScreen(MannequinBlockEntity mannequin) {
        return true;
    }
}
