package com.fittingroom.client.render;

import com.fittingroom.FittingRoomMod;
import com.fittingroom.seller.SellerEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.ChatFormatting;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;

/** The seller: a player-shaped model with one of three skins and a speech bubble above the name. */
public class SellerRenderer extends HumanoidMobRenderer<SellerEntity, PlayerModel<SellerEntity>> {
    private static final ResourceLocation[] SKINS = {
            ResourceLocation.fromNamespaceAndPath(FittingRoomMod.MOD_ID, "textures/entity/seller_0.png"),
            ResourceLocation.fromNamespaceAndPath(FittingRoomMod.MOD_ID, "textures/entity/seller_1.png"),
            ResourceLocation.fromNamespaceAndPath(FittingRoomMod.MOD_ID, "textures/entity/seller_2.png")
    };

    public SellerRenderer(EntityRendererProvider.Context context) {
        super(context, new PlayerModel<>(context.bakeLayer(ModelLayers.PLAYER), false), 0.45F);
    }

    @Override
    public ResourceLocation getTextureLocation(SellerEntity entity) {
        return SKINS[entity.variant()];
    }

    @Override
    protected void renderNameTag(SellerEntity entity, Component name, PoseStack pose,
                                 MultiBufferSource buffer, int light, float partialTick) {
        String key = entity.bubbleKey();
        if (!key.isEmpty()) {
            pose.pushPose();
            pose.translate(0.0F, 0.32F, 0.0F);
            Component bubble = Component.literal("♥ ")
                    .append(Component.translatable(key, entity.bubbleArg()))
                    .withStyle(ChatFormatting.LIGHT_PURPLE);
            super.renderNameTag(entity, bubble, pose, buffer, light, partialTick);
            pose.popPose();
        }
        super.renderNameTag(entity, name, pose, buffer, light, partialTick);
    }
}
