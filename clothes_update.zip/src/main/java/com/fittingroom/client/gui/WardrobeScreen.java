package com.fittingroom.client.gui;

import com.fittingroom.FittingSounds;
import com.fittingroom.economy.Money;
import com.fittingroom.network.SaveSlotPayload;
import com.fittingroom.network.SetOutfitPayload;
import com.fittingroom.wardrobe.Category;
import com.fittingroom.seller.ClientSellerState;
import com.fittingroom.seller.Loyalty;
import com.fittingroom.wardrobe.ClientWardrobeStore;
import com.fittingroom.wardrobe.ClothingCatalog;
import com.fittingroom.wardrobe.OutfitSlotsData;
import com.fittingroom.wardrobe.Sales;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.resources.language.I18n;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.neoforged.neoforge.network.PacketDistributor;
import net.neoforged.neoforge.registries.DeferredHolder;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * The fitting room screen. The window art comes from textures/gui/fitting_room.png, see {@link GuiLayout}.
 * Picking a garment shows it on the player immediately (preview); "Wear" sends it to the server,
 * closing the screen any other way throws the preview away.
 * <p>
 * Clothes cost money: the ones you do not own yet are dimmed and marked with "$", the tooltip shows the price
 * (with the running sale, marked with "%"), and when the outfit contains something unpaid the button says "Buy"
 * and charges your bank account (the server does the payment, see {@code Shop}).
 * <p>
 * Under the window: a wallet strip, then a row with a search box (searches all tabs), a filter (all / owned /
 * not owned / on sale) and "Undress", and a row with five outfit slots, the sale banner and "Gift".
 * All texts go through {@link GuiText}, so they always fit.
 */
public class WardrobeScreen extends Screen {
    private static final int TEXT = 0xFF5E3E36;
    private static final int TEXT_DISABLED = 0xFFA09482;
    private static final int PRICE_GOLD = 0xFFFFD34D;
    private static final int PRICE_RED = 0xFFFF6B6B;
    private static final int SALE_RED = 0xFFFF5C7A;
    private static final int OUTLINE = 0xFF765448;
    private static final int PINK = 0xFFF8C8CC;
    private static final int PINK_HOVER = 0xFFFFDEE0;
    private static final int PINK_LIGHT = 0xFFFFE8E8;
    private static final int GREY = 0xFFE8DED0;
    private static final int GOLD_EDGE = 0xFFF0BE46;
    private static final int STRIP = 0xAA000000;
    private static final int[] TAB_ICON_U = {
            GuiLayout.ICON_HAT_U, GuiLayout.ICON_SHIRT_U, GuiLayout.ICON_PANTS_U,
            GuiLayout.ICON_SHOES_U, GuiLayout.ICON_ACCESSORY_U};
    private static final Map<String, ResourceLocation> ICONS = new HashMap<>();

    /** What the item grid shows. */
    private enum Filter {
        ALL("all"), OWNED("owned"), UNOWNED("unowned"), SALE("sale");

        final String key;

        Filter(String key) {
            this.key = key;
        }

        Filter next() {
            return values()[(ordinal() + 1) % values().length];
        }

        Filter previous() {
            return values()[(ordinal() + values().length - 1) % values().length];
        }

        Component label() {
            return Component.translatable("gui.fittingroom.filter." + key);
        }
    }

    private final AbstractClientPlayer player;
    private final List<String> original;
    /** The server's date: sale prices are worked out with it. */
    private final LocalDate day = ClientWardrobeStore.saleDate();
    /** slot -> id of the worn item (one per slot; the Accessories tab has two slots: accessory and neck). */
    private final Map<String, String> selection = new LinkedHashMap<>();

    private Category tab = Category.HAT;
    private Filter filter = Filter.ALL;
    private EditBox search;
    private List<ClothingCatalog.Item> visible = List.of();
    private boolean visibleDirty = true;
    private int scrollRow = 0;
    private float rotation = 20.0F;
    private int heldRotate = 0;
    private boolean applied = false;
    /** Set while the gift screen is open: the preview must survive it. */
    private boolean keepPreview = false;
    private boolean greeted = false;
    private int left;
    private int top;

    public WardrobeScreen(AbstractClientPlayer player) {
        super(Component.translatable("gui.fittingroom.title"));
        this.player = player;
        this.original = List.copyOf(ClientWardrobeStore.get(player.getUUID()));
        for (String id : original) {
            ClothingCatalog.Item item = ClothingCatalog.byId(id);
            if (item != null && item.isAvailable()) {
                selection.put(item.slot(), item.id());
            }
        }
    }

    @Override
    protected void init() {
        this.left = (this.width - GuiLayout.WIDTH) / 2;
        this.top = Math.max(4, (this.height - GuiLayout.TOTAL_H) / 2);
        this.keepPreview = false;

        String old = search == null ? "" : search.getValue();
        search = new EditBox(this.font, left + GuiLayout.SEARCH_X, top + GuiLayout.ROW1_Y + 2,
                GuiLayout.SEARCH_W, GuiLayout.SEARCH_H, Component.translatable("gui.fittingroom.search"));
        search.setMaxLength(24);
        search.setHint(Component.translatable("gui.fittingroom.search").withStyle(ChatFormatting.GRAY));
        search.setValue(old);
        search.setResponder(text -> {
            visibleDirty = true;
            scrollRow = 0;
        });
        // not addRenderableWidget: the screen draws its background after super.render(), the box is drawn by hand
        this.addWidget(search);
        // the box has the keyboard from the start, so typing works at once without clicking it first
        // (Escape leaves the box, then closes the screen; a click outside the box also leaves it)
        this.setInitialFocus(search);
        search.setFocused(true);
        visibleDirty = true;

        if (!greeted) {
            greeted = true;
            Sales.Offer head = Sales.headline(day);
            if (head != null && head.percent() >= 25) {
                sfx(FittingSounds.SALE, 1.0F, 0.5F);
            }
        }
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    // ------------------------------------------------------------------ state

    private List<String> currentList() {
        return new ArrayList<>(selection.values());
    }

    private void pushPreview() {
        ClientWardrobeStore.set(player.getUUID(), currentList());
    }

    private boolean hasTabSelection() {
        for (String id : selection.values()) {
            ClothingCatalog.Item item = ClothingCatalog.byId(id);
            if (item != null && item.category() == tab) {
                return true;
            }
        }
        return false;
    }

    /** "Take off" takes off everything worn from the current tab. */
    private void clearTab() {
        selection.values().removeIf(id -> {
            ClothingCatalog.Item item = ClothingCatalog.byId(id);
            return item != null && item.category() == tab;
        });
    }

    /** "Undress" takes off everything (press Wear to confirm). */
    private void undress() {
        if (selection.isEmpty()) {
            return;
        }
        selection.clear();
        pushPreview();
        sfx(FittingSounds.UNDRESS, 1.0F, 0.7F);
    }

    private void toggle(ClothingCatalog.Item item) {
        if (item.id().equals(selection.get(item.slot()))) {
            selection.remove(item.slot());
        } else {
            selection.put(item.slot(), item.id());
        }
        pushPreview();
        sfx(FittingSounds.RUSTLE, 0.9F + player.getRandom().nextFloat() * 0.3F, 0.45F);
    }

    /** Price of everything in the current outfit that the player has not bought yet, in cents (sale applied). */
    private long cartTotal() {
        long total = 0;
        for (String id : selection.values()) {
            ClothingCatalog.Item item = ClothingCatalog.byId(id);
            if (item != null && !ClientWardrobeStore.owns(id)) {
                total += Sales.price(item, day);
            }
        }
        return ClientSellerState.discounted(total);
    }

    /** Unowned clothes only go to the cart here, so applying is always possible; paying happens at the seller. */
    private boolean canAfford() {
        return true;
    }

    private void apply() {
        if (!canAfford()) {
            sfx(FittingSounds.ERROR, 1.0F, 0.7F);
            return;
        }
        PacketDistributor.sendToServer(new SetOutfitPayload(currentList()));
        applied = true;
        onClose();
    }

    // ---- outfit slots

    private boolean sameOutfit(List<String> content) {
        if (content.isEmpty()) {
            return false;
        }
        return new HashSet<>(content).equals(new HashSet<>(selection.values()));
    }

    private void loadSlot(int index) {
        List<String> content = ClientWardrobeStore.slot(index);
        selection.clear();
        for (String id : content) {
            ClothingCatalog.Item item = ClothingCatalog.byId(id);
            if (item != null && item.isAvailable()) {
                selection.put(item.slot(), item.id());
            }
        }
        pushPreview();
        sfx(FittingSounds.RUSTLE, 1.0F, 0.6F);
    }

    /** Saves what is selected now (nothing selected = clears the slot). The server plays the "saved" sound. */
    private void saveSlot(int index) {
        List<String> list = currentList();
        ClientWardrobeStore.setSlot(index, list);
        PacketDistributor.sendToServer(new SaveSlotPayload(index, list));
    }

    // ---- what the grid shows

    private static String normalize(String text) {
        return text.trim().toLowerCase(Locale.ROOT).replace('\u0451', '\u0435');
    }

    /** The items in the grid: the current tab, or every tab while something is typed in the search box. */
    private List<ClothingCatalog.Item> visible() {
        if (visibleDirty) {
            String query = search == null ? "" : normalize(search.getValue());
            List<ClothingCatalog.Item> base = new ArrayList<>();
            if (query.isEmpty()) {
                base.addAll(ClothingCatalog.inCategory(tab));
            } else {
                for (Category category : Category.values()) {
                    base.addAll(ClothingCatalog.inCategory(category));
                }
            }
            List<ClothingCatalog.Item> out = new ArrayList<>();
            for (ClothingCatalog.Item item : base) {
                if (!query.isEmpty() && !normalize(I18n.get(item.translationKey())).contains(query)
                        && !item.id().contains(query)) {
                    continue;
                }
                if (!accepts(item)) {
                    continue;
                }
                out.add(item);
            }
            visible = out;
            visibleDirty = false;
        }
        return visible;
    }

    private boolean accepts(ClothingCatalog.Item item) {
        return switch (filter) {
            case ALL -> true;
            case OWNED -> ClientWardrobeStore.owns(item.id());
            case UNOWNED -> !ClientWardrobeStore.owns(item.id());
            case SALE -> Sales.percentOff(item, day) > 0;
        };
    }

    private boolean searching() {
        return search != null && !search.getValue().trim().isEmpty();
    }

    private int maxScroll() {
        int items = visible().size();
        int rows = (items + GuiLayout.COLS - 1) / GuiLayout.COLS;
        return Math.max(0, rows - GuiLayout.ROWS);
    }

    private void refresh() {
        visibleDirty = true;
        scrollRow = 0;
    }

    @Override
    public void removed() {
        if (!applied && !keepPreview) {
            ClientWardrobeStore.set(player.getUUID(), original);
        }
        super.removed();
    }

    @Override
    public void tick() {
        if (heldRotate != 0) {
            rotation += heldRotate * 6.0F;
        }
    }

    private void sfx(DeferredHolder<SoundEvent, SoundEvent> sound, float pitch, float volume) {
        if (this.minecraft != null) {
            this.minecraft.getSoundManager().play(SimpleSoundInstance.forUI(sound.get(), pitch, volume));
        }
    }

    private void click() {
        if (this.minecraft != null) {
            this.minecraft.getSoundManager().play(SimpleSoundInstance.forUI(
                    net.minecraft.sounds.SoundEvents.UI_BUTTON_CLICK, 1.0F));
        }
    }

    // ------------------------------------------------------------------ gifts

    private boolean giftEnabled() {
        return !selection.isEmpty() && !GiftScreen.recipients().isEmpty();
    }

    private void openGift() {
        keepPreview = true;
        if (this.minecraft != null) {
            this.minecraft.setScreen(new GiftScreen(this, currentList(), day));
        }
    }

    // ------------------------------------------------------------------ geometry helpers

    private static boolean in(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    private int slotX(int col) {
        return left + GuiLayout.GRID_X + GuiLayout.SLOT_PITCH * col;
    }

    private int slotY(int row) {
        return top + GuiLayout.GRID_Y + GuiLayout.SLOT_PITCH * row;
    }

    private static ResourceLocation icon(String id) {
        return ICONS.computeIfAbsent(id,
                k -> ResourceLocation.fromNamespaceAndPath("fittingroom", "textures/gui/clothes/" + k + ".png"));
    }

    private ClothingCatalog.Item slotItemAt(double mx, double my) {
        List<ClothingCatalog.Item> items = visible();
        int first = scrollRow * GuiLayout.COLS;
        for (int idx = first; idx < items.size() && idx < first + GuiLayout.COLS * GuiLayout.ROWS; idx++) {
            int rel = idx - first;
            int col = rel % GuiLayout.COLS;
            int row = rel / GuiLayout.COLS;
            if (in(mx, my, slotX(col), slotY(row), GuiLayout.SLOT_SIZE, GuiLayout.SLOT_SIZE)) {
                return items.get(idx);
            }
        }
        return null;
    }

    private boolean overRotateLeft(double mx, double my) {
        return in(mx, my, left + GuiLayout.ROT_LEFT_X, top + GuiLayout.ROT_Y, GuiLayout.ARROW_SIZE, GuiLayout.ARROW_SIZE);
    }

    private boolean overRotateRight(double mx, double my) {
        return in(mx, my, left + GuiLayout.ROT_RIGHT_X, top + GuiLayout.ROT_Y, GuiLayout.ARROW_SIZE, GuiLayout.ARROW_SIZE);
    }

    private boolean overApply(double mx, double my) {
        return in(mx, my, left + GuiLayout.BTN_LEFT_X, top + GuiLayout.BTN_Y, GuiLayout.BTN_W, GuiLayout.BTN_H);
    }

    private boolean overRemove(double mx, double my) {
        return in(mx, my, left + GuiLayout.BTN_RIGHT_X, top + GuiLayout.BTN_Y, GuiLayout.BTN_W, GuiLayout.BTN_H);
    }

    private boolean overPreview(double mx, double my) {
        return in(mx, my, left + GuiLayout.PREVIEW_X, top + GuiLayout.PREVIEW_Y, GuiLayout.PREVIEW_W, GuiLayout.PREVIEW_H);
    }

    private boolean overFilter(double mx, double my) {
        return in(mx, my, left + GuiLayout.FILTER_X, top + GuiLayout.ROW1_Y + 1, GuiLayout.BTN_W, GuiLayout.BTN_H);
    }

    private boolean overUndress(double mx, double my) {
        return in(mx, my, left + GuiLayout.UNDRESS_X, top + GuiLayout.ROW1_Y + 1, GuiLayout.BTN_W, GuiLayout.BTN_H);
    }

    private boolean overGift(double mx, double my) {
        return in(mx, my, left + GuiLayout.GIFT_X, top + GuiLayout.ROW2_Y + 1, GuiLayout.BTN_W, GuiLayout.BTN_H);
    }

    private boolean overBanner(double mx, double my) {
        return in(mx, my, left + GuiLayout.BANNER_X, top + GuiLayout.ROW2_Y, GuiLayout.BANNER_W, GuiLayout.ROW_H);
    }

    private int outfitX(int index) {
        return left + GuiLayout.OUTFIT_X + GuiLayout.OUTFIT_PITCH * index;
    }

    private int outfitY() {
        return top + GuiLayout.ROW2_Y + 1;
    }

    /** Index of the outfit slot under the mouse, or -1. */
    private int outfitAt(double mx, double my) {
        for (int i = 0; i < GuiLayout.OUTFIT_COUNT; i++) {
            if (in(mx, my, outfitX(i), outfitY(), GuiLayout.OUTFIT_SIZE, GuiLayout.OUTFIT_SIZE)) {
                return i;
            }
        }
        return -1;
    }

    private int tabAt(double mx, double my) {
        Category[] categories = Category.values();
        for (int i = 0; i < categories.length; i++) {
            if (in(mx, my, left + GuiLayout.TAB_X + GuiLayout.TAB_W * i, top + GuiLayout.TAB_Y,
                    GuiLayout.TAB_W, GuiLayout.TAB_H)) {
                return i;
            }
        }
        return -1;
    }

    // ------------------------------------------------------------------ sales text

    static Component offerName(Sales.Offer offer) {
        return switch (offer.kind()) {
            case DAILY -> Component.translatable("gui.fittingroom.sale.daily",
                    Component.translatable("gui.fittingroom.category." + offer.category().id()), offer.percent());
            case WEEKEND -> Component.translatable("gui.fittingroom.sale.weekend", offer.percent());
            case BLACK_FRIDAY -> Component.translatable("gui.fittingroom.sale.black_friday", offer.percent());
            case NEW_YEAR -> Component.translatable("gui.fittingroom.sale.new_year", offer.percent());
            case SCHOOL -> Component.translatable("gui.fittingroom.sale.school", offer.percent());
        };
    }

    // ------------------------------------------------------------------ rendering

    @Override
    public void render(GuiGraphics g, int mx, int my, float partialTick) {
        super.render(g, mx, my, partialTick);

        g.blit(GuiLayout.TEXTURE, left, top, 0, 0, GuiLayout.WIDTH, GuiLayout.HEIGHT, GuiLayout.TEX_W, GuiLayout.TEX_H);
        GuiText.centered(g, this.font, this.title, left + GuiLayout.TITLE_CENTER_X, top + GuiLayout.TITLE_Y, 130,
                TEXT, false);

        drawPlayer(g);
        drawTabs(g);
        drawSlots(g, mx, my);
        drawScrollbar(g);
        drawRotateButtons(g, mx, my);
        drawButtons(g, mx, my);
        drawWalletBar(g);
        drawSellerStrip(g);
        drawToolRows(g, mx, my);
        drawTooltips(g, mx, my);
    }

    private void drawWideButton(GuiGraphics g, int x, int y, Component label, boolean enabled, boolean hovered) {
        int u = !enabled ? GuiLayout.BTN_DISABLED_U : (hovered ? GuiLayout.BTN_HOVER_U : GuiLayout.BTN_U);
        g.blit(GuiLayout.TEXTURE, x, y, u, GuiLayout.BTN_V, GuiLayout.BTN_W, GuiLayout.BTN_H,
                GuiLayout.TEX_W, GuiLayout.TEX_H);
        GuiText.centered(g, this.font, label, x + GuiLayout.BTN_W / 2, y + 5, GuiLayout.BTN_W - 8,
                enabled ? TEXT : TEXT_DISABLED, false);
    }

    private void drawSmallButton(GuiGraphics g, int x, int y, int size, int edge, int fill) {
        g.fill(x, y, x + size, y + size, edge);
        g.fill(x + 1, y + 1, x + size - 1, y + size - 1, fill);
    }

    /** A strip above the window: the loyalty card and the discount, or a hint that a seller is needed. */
    private void drawSellerStrip(GuiGraphics g) {
        int y = top - GuiLayout.BAR_H - GuiLayout.BAR_GAP;
        if (y < 2) {
            return;
        }
        g.fill(left, y, left + GuiLayout.WIDTH, y + GuiLayout.BAR_H, STRIP);
        int avail = GuiLayout.WIDTH - 12;
        if (!ClientSellerState.near()) {
            GuiText.left(g, this.font, Component.translatable("gui.fittingroom.cart_hint",
                    ClientSellerState.cart().size()), left + 6, y + 3, avail, PRICE_GOLD, true);
            return;
        }
        int tier = ClientSellerState.tier();
        Component card = Component.translatable("gui.fittingroom.loyalty",
                Component.translatable("seller.fittingroom.tier." + Loyalty.IDS[tier]), ClientSellerState.percent());
        long next = Loyalty.nextThreshold(ClientSellerState.spent());
        Component hint = next < 0 ? Component.translatable("gui.fittingroom.loyalty_max")
                : Component.translatable("gui.fittingroom.loyalty_next", Money.format(next - ClientSellerState.spent()));
        int hintWidth = Math.min(this.font.width(hint.getString()), avail / 2);
        GuiText.right(g, this.font, hint, left + GuiLayout.WIDTH - 6, y + 3, hintWidth, 0xFFCCCCCC, true);
        GuiText.left(g, this.font, card, left + 6, y + 3, avail - hintWidth - 8, PRICE_GOLD, true);
    }

    /** A strip under the window: money on the account and the price of the current outfit. */
    private void drawWalletBar(GuiGraphics g) {
        int y = top + GuiLayout.HEIGHT + GuiLayout.BAR_GAP;
        g.fill(left, y, left + GuiLayout.WIDTH, y + GuiLayout.BAR_H, STRIP);
        int avail = GuiLayout.WIDTH - 12;
        Component balance = Component.translatable("gui.fittingroom.balance", Money.format(ClientWardrobeStore.balance()));
        long total = cartTotal();
        if (total > 0) {
            Component cart = Component.translatable("gui.fittingroom.total", Money.format(total));
            int cartWidth = Math.min(this.font.width(cart.getString()), avail / 2);
            GuiText.right(g, this.font, cart, left + GuiLayout.WIDTH - 6, y + 3, cartWidth,
                    canAfford() ? PRICE_GOLD : PRICE_RED, true);
            GuiText.left(g, this.font, balance, left + 6, y + 3, avail - cartWidth - 8, 0xFFFFFFFF, true);
        } else {
            GuiText.left(g, this.font, balance, left + 6, y + 3, avail, 0xFFFFFFFF, true);
        }
    }

    /** Row 1 (search, filter, undress) and row 2 (outfit slots, sale banner, gift). */
    private void drawToolRows(GuiGraphics g, int mx, int my) {
        int y1 = top + GuiLayout.ROW1_Y;
        int y2 = top + GuiLayout.ROW2_Y;
        g.fill(left, y1, left + GuiLayout.WIDTH, y1 + GuiLayout.ROW_H, STRIP);
        g.fill(left, y2, left + GuiLayout.WIDTH, y2 + GuiLayout.ROW_H, STRIP);

        search.render(g, mx, my, 0.0F);

        drawWideButton(g, left + GuiLayout.FILTER_X, y1 + 1, filter.label(), true, overFilter(mx, my));
        boolean canUndress = !selection.isEmpty();
        drawWideButton(g, left + GuiLayout.UNDRESS_X, y1 + 1, Component.translatable("gui.fittingroom.undress"),
                canUndress, canUndress && overUndress(mx, my));

        for (int i = 0; i < GuiLayout.OUTFIT_COUNT; i++) {
            List<String> content = ClientWardrobeStore.slot(i);
            boolean filled = !content.isEmpty();
            boolean active = sameOutfit(content);
            boolean hovered = outfitAt(mx, my) == i;
            int fill = !filled ? GREY : (active ? PINK_LIGHT : (hovered ? PINK_HOVER : PINK));
            int x = outfitX(i);
            drawSmallButton(g, x, outfitY(), GuiLayout.OUTFIT_SIZE, active ? GOLD_EDGE : OUTLINE, fill);
            String number = String.valueOf(i + 1);
            g.drawString(this.font, number, x + (GuiLayout.OUTFIT_SIZE - this.font.width(number)) / 2, outfitY() + 5,
                    filled ? TEXT : TEXT_DISABLED, false);
        }

        Sales.Offer head = Sales.headline(day);
        if (head != null) {
            GuiText.centered(g, this.font, Component.translatable("gui.fittingroom.sale.badge", head.percent()),
                    left + GuiLayout.BANNER_X + GuiLayout.BANNER_W / 2, y2 + 6, GuiLayout.BANNER_W - 4, PRICE_GOLD, true);
        }

        boolean canGift = giftEnabled();
        drawWideButton(g, left + GuiLayout.GIFT_X, y2 + 1, Component.translatable("gui.fittingroom.gift"),
                canGift, canGift && overGift(mx, my));
    }

    private void drawPlayer(GuiGraphics g) {
        int x1 = left + GuiLayout.PREVIEW_X;
        int y1 = top + GuiLayout.PREVIEW_Y;
        g.enableScissor(x1, y1, x1 + GuiLayout.PREVIEW_W, y1 + GuiLayout.PREVIEW_H);

        AbstractClientPlayer p = this.player;
        int scale = 38;
        float centerX = left + GuiLayout.PLAYER_FEET_X;
        float centerY = top + GuiLayout.PLAYER_FEET_Y - p.getBbHeight() / 2.0F * scale;
        Vector3f translate = new Vector3f(0.0F, p.getBbHeight() / 2.0F, 0.0F);
        Quaternionf pose = new Quaternionf().rotateZ((float) Math.PI);
        Quaternionf camera = new Quaternionf().rotateX(0.1F);
        pose.mul(camera);

        float yaw = 180.0F + rotation;
        float bodyRot = p.yBodyRot;
        float yRot = p.getYRot();
        float xRot = p.getXRot();
        float headRotO = p.yHeadRotO;
        float headRot = p.yHeadRot;
        p.yBodyRot = yaw;
        p.setYRot(yaw);
        p.setXRot(0.0F);
        p.yHeadRot = yaw;
        p.yHeadRotO = yaw;

        InventoryScreen.renderEntityInInventory(g, centerX, centerY, scale, translate, pose, camera, p);

        p.yBodyRot = bodyRot;
        p.setYRot(yRot);
        p.setXRot(xRot);
        p.yHeadRotO = headRotO;
        p.yHeadRot = headRot;

        g.disableScissor();
    }

    private void drawTabs(GuiGraphics g) {
        Category[] categories = Category.values();
        boolean all = searching(); // while searching every tab is searched, so none is shown as selected
        for (int i = 0; i < categories.length; i++) {
            int x = left + GuiLayout.TAB_X + GuiLayout.TAB_W * i;
            int y = top + GuiLayout.TAB_Y;
            boolean selected = !all && categories[i] == tab;
            if (selected) {
                g.blit(GuiLayout.TEXTURE, x, y, GuiLayout.TAB_SEL_U, GuiLayout.TAB_SEL_V,
                        GuiLayout.TAB_W, GuiLayout.TAB_SEL_H, GuiLayout.TEX_W, GuiLayout.TEX_H);
            } else {
                g.blit(GuiLayout.TEXTURE, x, y, GuiLayout.TAB_U, GuiLayout.TAB_V,
                        GuiLayout.TAB_W, GuiLayout.TAB_H, GuiLayout.TEX_W, GuiLayout.TEX_H);
            }
            g.blit(GuiLayout.TEXTURE, x + GuiLayout.TAB_ICON_DX,
                    y + (selected ? GuiLayout.TAB_ICON_SEL_DY : GuiLayout.TAB_ICON_DY),
                    TAB_ICON_U[i], GuiLayout.ICON_V, GuiLayout.ICON_SIZE, GuiLayout.ICON_SIZE,
                    GuiLayout.TEX_W, GuiLayout.TEX_H);
        }
    }

    private void drawSlots(GuiGraphics g, int mx, int my) {
        List<ClothingCatalog.Item> items = visible();
        if (items.isEmpty()) {
            int width = GuiLayout.COLS * GuiLayout.SLOT_PITCH - 6;
            int y = top + GuiLayout.GRID_Y + 30;
            for (String line : GuiText.wrap(this.font, I18n.get("gui.fittingroom.nothing"), width)) {
                GuiText.centered(g, this.font, Component.literal(line), left + GuiLayout.GRID_X + width / 2 + 2, y,
                        width, TEXT_DISABLED, false);
                y += 10;
            }
            return;
        }
        int first = scrollRow * GuiLayout.COLS;
        for (int idx = first; idx < items.size() && idx < first + GuiLayout.COLS * GuiLayout.ROWS; idx++) {
            int rel = idx - first;
            int sx = slotX(rel % GuiLayout.COLS);
            int sy = slotY(rel / GuiLayout.COLS);
            ClothingCatalog.Item item = items.get(idx);

            boolean owned = ClientWardrobeStore.owns(item.id());
            if (!owned) {
                g.setColor(0.55F, 0.55F, 0.55F, 1.0F);
            }
            g.blit(icon(item.id()), sx + GuiLayout.ITEM_ICON_OFFSET, sy + GuiLayout.ITEM_ICON_OFFSET,
                    0, 0, 16, 16, 16, 16);
            if (!owned) {
                g.setColor(1.0F, 1.0F, 1.0F, 1.0F);
                g.drawString(this.font, "$", sx + GuiLayout.SLOT_SIZE - 7, sy + GuiLayout.SLOT_SIZE - 9, PRICE_GOLD, true);
                if (Sales.percentOff(item, day) > 0) {
                    g.drawString(this.font, "%", sx + GuiLayout.SLOT_SIZE - 7, sy + 2, SALE_RED, true);
                }
            }
            if (in(mx, my, sx, sy, GuiLayout.SLOT_SIZE, GuiLayout.SLOT_SIZE)) {
                g.blit(GuiLayout.TEXTURE, sx, sy, GuiLayout.SLOT_HOVER_U, GuiLayout.SLOT_HOVER_V,
                        GuiLayout.SLOT_SIZE, GuiLayout.SLOT_SIZE, GuiLayout.TEX_W, GuiLayout.TEX_H);
            }
            if (item.id().equals(selection.get(item.slot()))) {
                g.blit(GuiLayout.TEXTURE, sx - 1, sy - 1, GuiLayout.SLOT_SELECTED_U, GuiLayout.SLOT_SELECTED_V,
                        GuiLayout.SLOT_SELECTED_SIZE, GuiLayout.SLOT_SELECTED_SIZE, GuiLayout.TEX_W, GuiLayout.TEX_H);
            }
        }
    }

    private void drawScrollbar(GuiGraphics g) {
        int max = maxScroll();
        int x = left + GuiLayout.SCROLL_X;
        int y = top + GuiLayout.SCROLL_Y;
        if (max <= 0) {
            g.blit(GuiLayout.TEXTURE, x, y, GuiLayout.THUMB_DISABLED_U, GuiLayout.THUMB_V,
                    GuiLayout.SCROLL_W, GuiLayout.THUMB_H, GuiLayout.TEX_W, GuiLayout.TEX_H);
        } else {
            int travel = GuiLayout.SCROLL_H - GuiLayout.THUMB_H;
            g.blit(GuiLayout.TEXTURE, x, y + travel * Math.min(scrollRow, max) / max, GuiLayout.THUMB_U, GuiLayout.THUMB_V,
                    GuiLayout.SCROLL_W, GuiLayout.THUMB_H, GuiLayout.TEX_W, GuiLayout.TEX_H);
        }
    }

    private void drawRotateButtons(GuiGraphics g, int mx, int my) {
        int ly = top + GuiLayout.ROT_Y;
        g.blit(GuiLayout.TEXTURE, left + GuiLayout.ROT_LEFT_X, ly,
                overRotateLeft(mx, my) ? GuiLayout.ARROW_LEFT_HOVER_U : GuiLayout.ARROW_LEFT_U, GuiLayout.ARROW_V,
                GuiLayout.ARROW_SIZE, GuiLayout.ARROW_SIZE, GuiLayout.TEX_W, GuiLayout.TEX_H);
        g.blit(GuiLayout.TEXTURE, left + GuiLayout.ROT_RIGHT_X, ly,
                overRotateRight(mx, my) ? GuiLayout.ARROW_RIGHT_HOVER_U : GuiLayout.ARROW_RIGHT_U, GuiLayout.ARROW_V,
                GuiLayout.ARROW_SIZE, GuiLayout.ARROW_SIZE, GuiLayout.TEX_W, GuiLayout.TEX_H);
    }

    private void drawButtons(GuiGraphics g, int mx, int my) {
        int by = top + GuiLayout.BTN_Y;
        boolean canApply = canAfford();
        Component apply = Component.translatable(cartTotal() > 0 ? "gui.fittingroom.buy" : "gui.fittingroom.apply");
        drawWideButton(g, left + GuiLayout.BTN_LEFT_X, by, apply, canApply, canApply && overApply(mx, my));

        boolean canRemove = hasTabSelection();
        drawWideButton(g, left + GuiLayout.BTN_RIGHT_X, by, Component.translatable("gui.fittingroom.remove"),
                canRemove, canRemove && overRemove(mx, my));
    }

    private void drawTooltips(GuiGraphics g, int mx, int my) {
        List<Component> lines = new ArrayList<>();

        ClothingCatalog.Item hovered = slotItemAt(mx, my);
        int outfit = outfitAt(mx, my);
        int tab = tabAt(mx, my);
        if (hovered != null) {
            lines.add(Component.translatable(hovered.translationKey()));
            if (ClientWardrobeStore.owns(hovered.id())) {
                lines.add(Component.translatable("gui.fittingroom.owned").withStyle(ChatFormatting.GREEN));
            } else {
                Sales.Offer offer = Sales.bestFor(hovered, day);
                if (offer == null) {
                    lines.add(Component.translatable("gui.fittingroom.price", Money.format(hovered.priceCents()))
                            .withStyle(ChatFormatting.GOLD));
                } else {
                    lines.add(Component.translatable("gui.fittingroom.price", Money.format(hovered.priceCents()))
                            .withStyle(ChatFormatting.GRAY, ChatFormatting.STRIKETHROUGH));
                    lines.add(Component.translatable("gui.fittingroom.sale_price",
                            Money.format(Sales.price(hovered, day)), offer.percent()).withStyle(ChatFormatting.GREEN));
                    lines.add(offerName(offer).copy().withStyle(ChatFormatting.LIGHT_PURPLE));
                }
            }
        } else if (overApply(mx, my) && !canAfford()) {
            lines.add(Component.translatable(ClientSellerState.near()
                    ? "gui.fittingroom.not_enough" : "gui.fittingroom.need_seller"));
        } else if (tab >= 0) {
            lines.add(Component.translatable("gui.fittingroom.category." + Category.values()[tab].id()));
        } else if (overFilter(mx, my)) {
            lines.add(Component.translatable("gui.fittingroom.filter.tooltip", filter.label()));
            lines.add(Component.translatable("gui.fittingroom.filter.hint").withStyle(ChatFormatting.GRAY));
        } else if (overUndress(mx, my)) {
            lines.add(Component.translatable("gui.fittingroom.undress.tooltip"));
        } else if (overGift(mx, my)) {
            lines.add(Component.translatable("gui.fittingroom.gift.tooltip"));
            if (selection.isEmpty()) {
                lines.add(Component.translatable("gui.fittingroom.gift.select_first").withStyle(ChatFormatting.RED));
            } else if (GiftScreen.recipients().isEmpty()) {
                lines.add(Component.translatable("gui.fittingroom.gift.nobody").withStyle(ChatFormatting.RED));
            }
        } else if (outfit >= 0) {
            List<String> content = ClientWardrobeStore.slot(outfit);
            lines.add(Component.translatable("gui.fittingroom.outfit", outfit + 1));
            if (content.isEmpty()) {
                lines.add(Component.translatable("gui.fittingroom.outfit.empty").withStyle(ChatFormatting.GRAY));
                lines.add(Component.translatable("gui.fittingroom.outfit.save_hint").withStyle(ChatFormatting.GRAY));
            } else {
                for (String id : content) {
                    ClothingCatalog.Item item = ClothingCatalog.byId(id);
                    if (item != null) {
                        lines.add(Component.literal("- ").append(Component.translatable(item.translationKey()))
                                .withStyle(ChatFormatting.WHITE));
                    }
                }
                lines.add(Component.translatable("gui.fittingroom.outfit.load_hint").withStyle(ChatFormatting.GRAY));
                lines.add(Component.translatable("gui.fittingroom.outfit.save_over_hint").withStyle(ChatFormatting.GRAY));
            }
        } else if (overBanner(mx, my)) {
            List<Sales.Offer> offers = Sales.active(day);
            lines.add(Component.translatable("gui.fittingroom.sale.title"));
            for (Sales.Offer offer : offers) {
                lines.add(offerName(offer).copy().withStyle(ChatFormatting.GOLD));
            }
        }
        if (!lines.isEmpty()) {
            GuiText.tooltip(g, this.font, lines, mx, my, this.width);
        }
    }

    // ------------------------------------------------------------------ input

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        // the search box takes the click (and loses the focus when the click is somewhere else)
        if (search.mouseClicked(mx, my, button)) {
            return true;
        }
        if (button == 1) {
            if (overFilter(mx, my)) {
                filter = filter.previous();
                refresh();
                click();
                return true;
            }
            int outfit = outfitAt(mx, my);
            if (outfit >= 0) {
                saveSlot(outfit);
                click();
                return true;
            }
        }
        if (button == 0) {
            int tabIndex = tabAt(mx, my);
            if (tabIndex >= 0) {
                tab = Category.values()[tabIndex];
                search.setValue("");
                refresh();
                click();
                return true;
            }
            ClothingCatalog.Item item = slotItemAt(mx, my);
            if (item != null) {
                toggle(item);
                return true;
            }
            if (overRotateLeft(mx, my)) {
                rotation -= 25.0F;
                heldRotate = -1;
                click();
                return true;
            }
            if (overRotateRight(mx, my)) {
                rotation += 25.0F;
                heldRotate = 1;
                click();
                return true;
            }
            if (overApply(mx, my)) {
                click();
                apply();
                return true;
            }
            if (overRemove(mx, my) && hasTabSelection()) {
                clearTab();
                pushPreview();
                click();
                return true;
            }
            if (overFilter(mx, my)) {
                filter = filter.next();
                refresh();
                click();
                return true;
            }
            if (overUndress(mx, my) && !selection.isEmpty()) {
                undress();
                return true;
            }
            if (overGift(mx, my) && giftEnabled()) {
                click();
                openGift();
                return true;
            }
            int outfit = outfitAt(mx, my);
            if (outfit >= 0) {
                boolean filled = !ClientWardrobeStore.slot(outfit).isEmpty();
                if (filled && !hasShiftDown()) {
                    loadSlot(outfit);
                } else if (!selection.isEmpty() || filled) {
                    saveSlot(outfit);
                }
                click();
                return true;
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        heldRotate = 0;
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dragX, double dragY) {
        if (button == 0 && overPreview(mx, my)) {
            rotation += (float) dragX * 1.2F;
            return true;
        }
        return super.mouseDragged(mx, my, button, dragX, dragY);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double scrollX, double scrollY) {
        int max = maxScroll();
        if (max > 0) {
            scrollRow = Math.max(0, Math.min(max, scrollRow - (int) Math.signum(scrollY)));
            return true;
        }
        return super.mouseScrolled(mx, my, scrollX, scrollY);
    }

    @Override
    public boolean charTyped(char codePoint, int modifiers) {
        if (search.isFocused() && search.charTyped(codePoint, modifiers)) {
            return true;
        }
        return super.charTyped(codePoint, modifiers);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (search.isFocused()) {
            if (keyCode == 256) { // Escape: first leave the search box
                search.setFocused(false);
                return true;
            }
            search.keyPressed(keyCode, scanCode, modifiers);
            return true; // typing "e" in the box must not close the screen
        }
        if (this.minecraft != null && this.minecraft.options.keyInventory.matches(keyCode, scanCode)) {
            this.onClose();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }
}
