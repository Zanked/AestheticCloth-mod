package com.fittingroom.client.gui;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * Text that always fits: too wide text is first shrunk (down to {@link #MIN_SCALE}) and, if that is not
 * enough, cut with an ellipsis. Long tooltips are wrapped into several lines.
 */
final class GuiText {
    private GuiText() {}

    static final float MIN_SCALE = 0.65F;
    private static final String ELLIPSIS = "...";

    /** The text to draw and the scale to draw it with, so that it fits in {@code maxWidth}. */
    record Fit(String text, float scale, float width) {}

    static Fit fit(Font font, String text, int maxWidth) {
        int w = font.width(text);
        if (w <= maxWidth) {
            return new Fit(text, 1.0F, w);
        }
        float scale = Math.max(MIN_SCALE, maxWidth / (float) w);
        if (w * scale <= maxWidth + 0.01F) {
            return new Fit(text, scale, w * scale);
        }
        int room = Math.max(1, (int) (maxWidth / scale) - font.width(ELLIPSIS));
        String cut = font.plainSubstrByWidth(text, room) + ELLIPSIS;
        return new Fit(cut, scale, font.width(cut) * scale);
    }

    private static void draw(GuiGraphics g, Font font, Fit fit, float x, int y, int color, boolean shadow) {
        float dy = 8.0F * (1.0F - fit.scale()) / 2.0F; // keep a shrunk line vertically centered
        g.pose().pushPose();
        g.pose().translate(x, y + dy, 0.0F);
        g.pose().scale(fit.scale(), fit.scale(), 1.0F);
        g.drawString(font, fit.text(), 0, 0, color, shadow);
        g.pose().popPose();
    }

    /** Left-aligned at x. */
    static void left(GuiGraphics g, Font font, Component text, int x, int y, int maxWidth, int color, boolean shadow) {
        draw(g, font, fit(font, text.getString(), maxWidth), x, y, color, shadow);
    }

    /** Right edge at rightX. */
    static void right(GuiGraphics g, Font font, Component text, int rightX, int y, int maxWidth, int color,
                      boolean shadow) {
        Fit fit = fit(font, text.getString(), maxWidth);
        draw(g, font, fit, rightX - fit.width(), y, color, shadow);
    }

    /** Centered on centerX. */
    static void centered(GuiGraphics g, Font font, Component text, int centerX, int y, int maxWidth, int color,
                         boolean shadow) {
        Fit fit = fit(font, text.getString(), maxWidth);
        draw(g, font, fit, centerX - fit.width() / 2.0F, y, color, shadow);
    }

    /** Word wrap into lines no wider than maxWidth (a single very long word is cut). */
    static List<String> wrap(Font font, String text, int maxWidth) {
        List<String> lines = new ArrayList<>();
        StringBuilder line = new StringBuilder();
        for (String word : text.split(" ")) {
            while (font.width(word) > maxWidth) {
                String head = font.plainSubstrByWidth(word, maxWidth);
                if (head.isEmpty()) {
                    break;
                }
                if (line.length() > 0) {
                    lines.add(line.toString());
                    line.setLength(0);
                }
                lines.add(head);
                word = word.substring(head.length());
            }
            String candidate = line.length() == 0 ? word : line + " " + word;
            if (font.width(candidate) <= maxWidth) {
                line.setLength(0);
                line.append(candidate);
            } else {
                lines.add(line.toString());
                line.setLength(0);
                line.append(word);
            }
        }
        if (line.length() > 0) {
            lines.add(line.toString());
        }
        return lines;
    }

    /** A tooltip that never runs off the screen: long lines are wrapped, the style of each line is kept. */
    static void tooltip(GuiGraphics g, Font font, List<Component> lines, int mx, int my, int screenWidth) {
        int maxWidth = Math.max(80, Math.min(190, screenWidth / 2 - 20));
        List<Component> out = new ArrayList<>();
        for (Component line : lines) {
            String text = line.getString();
            if (font.width(text) <= maxWidth) {
                out.add(line);
                continue;
            }
            for (String piece : wrap(font, text, maxWidth)) {
                out.add(Component.literal(piece).setStyle(line.getStyle()));
            }
        }
        g.renderComponentTooltip(font, out, mx, my);
    }
}
