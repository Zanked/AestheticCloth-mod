package com.fittingroom.client.gui;

import net.minecraft.resources.ResourceLocation;

/**
 * Coordinates of everything in textures/gui/fitting_room.png (256x256 atlas).
 * Screen coordinates are relative to the top-left corner of the window (WIDTH x HEIGHT).
 * Draw with: graphics.blit(TEXTURE, x, y, u, v, w, h) (atlas is 256x256).
 */
public final class GuiLayout {
    private GuiLayout() {}

    public static final ResourceLocation TEXTURE =
            ResourceLocation.fromNamespaceAndPath("fittingroom", "textures/gui/fitting_room.png");
    public static final int TEX_W = 256, TEX_H = 256;

    // ---- window background: atlas (0,0) ----
    public static final int WIDTH = 248, HEIGHT = 166;

    // ---- title: centered text in the ribbon, y ~ 6..16 ----
    public static final int TITLE_CENTER_X = 124, TITLE_Y = 7;

    // ---- player preview "stage" (inner scene area) ----
    public static final int PREVIEW_X = 13, PREVIEW_Y = 25, PREVIEW_W = 86, PREVIEW_H = 116;
    /** Where the player's feet should stand (on the rug). */
    public static final int PLAYER_FEET_X = 56, PLAYER_FEET_Y = 125;

    // ---- rotate buttons (14x14) ----
    public static final int ROT_LEFT_X = 34, ROT_RIGHT_X = 64, ROT_Y = 147, ARROW_SIZE = 14;
    public static final int ARROW_LEFT_U = 110, ARROW_LEFT_HOVER_U = 124;
    public static final int ARROW_RIGHT_U = 138, ARROW_RIGHT_HOVER_U = 152, ARROW_V = 168;

    // ---- category tabs: 5 tabs side by side ----
    public static final int TAB_X = 114, TAB_Y = 22, TAB_W = 24, TAB_H = 22, TAB_COUNT = 5;
    public static final int TAB_U = 0, TAB_V = 168;                       // normal 24x22
    public static final int TAB_SEL_U = 24, TAB_SEL_V = 168, TAB_SEL_H = 24; // selected 24x24
    public static final int TAB_ICON_DX = 4, TAB_ICON_DY = 3, TAB_ICON_SEL_DY = 4;

    // ---- item grid (5 columns x 4 rows of 20x20 slots) ----
    public static final int GRID_X = 114, GRID_Y = 49, SLOT_SIZE = 20, SLOT_PITCH = 22, COLS = 5, ROWS = 4;
    public static final int SLOT_SELECTED_U = 48, SLOT_SELECTED_V = 168, SLOT_SELECTED_SIZE = 22; // draw at slot - 1
    public static final int SLOT_HOVER_U = 70, SLOT_HOVER_V = 168;                                 // 20x20 overlay
    public static final int ITEM_ICON_OFFSET = 2; // 16x16 icon inside a slot

    // ---- scrollbar ----
    public static final int SCROLL_X = 227, SCROLL_Y = 49, SCROLL_W = 8, SCROLL_H = 86;
    public static final int THUMB_U = 92, THUMB_DISABLED_U = 100, THUMB_V = 168, THUMB_H = 15;

    // ---- wide buttons (56x18): normal / hover / disabled ----
    public static final int BTN_W = 56, BTN_H = 18, BTN_V = 192;
    public static final int BTN_U = 0, BTN_HOVER_U = 56, BTN_DISABLED_U = 112;
    public static final int BTN_LEFT_X = 114, BTN_RIGHT_X = 178, BTN_Y = 143;

    // ---- 16x16 icons, row v=212 ----
    public static final int ICON_V = 212, ICON_SIZE = 16;
    public static final int ICON_HAT_U = 0, ICON_SHIRT_U = 16, ICON_PANTS_U = 32,
            ICON_SHOES_U = 48, ICON_ACCESSORY_U = 64, ICON_CLEAR_U = 80;

    // ---- under the window: wallet strip, then two rows of controls (all as wide as the window) ----
    public static final int BAR_GAP = 3, BAR_H = 14;
    public static final int ROW_H = 20;
    /** Row 1: search box, filter button, "undress" button. */
    public static final int ROW1_Y = HEIGHT + BAR_GAP + BAR_H + 2;
    /** Row 2: outfit slots, sale banner, "gift" button. */
    public static final int ROW2_Y = ROW1_Y + ROW_H + 2;
    /** Window plus everything under it: this block is centered on the screen. */
    public static final int TOTAL_H = ROW2_Y + ROW_H;

    public static final int SEARCH_X = 3, SEARCH_W = 118, SEARCH_H = 16;
    public static final int FILTER_X = 125, UNDRESS_X = 185, GIFT_X = 185;
    public static final int OUTFIT_COUNT = 5, OUTFIT_X = 3, OUTFIT_PITCH = 20, OUTFIT_SIZE = 18;
    public static final int BANNER_X = 106, BANNER_W = 76;
}
