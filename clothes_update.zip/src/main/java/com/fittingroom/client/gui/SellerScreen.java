package com.fittingroom.client.gui;

import com.fittingroom.FittingRoomMod;
import com.fittingroom.client.FittingRoomClient;
import com.fittingroom.economy.Money;
import com.fittingroom.network.SellerActionPayload;
import com.fittingroom.seller.ClientSellerState;
import com.fittingroom.seller.Loyalty;
import com.fittingroom.wardrobe.ClientWardrobeStore;
import com.fittingroom.wardrobe.ClothingCatalog;
import com.fittingroom.wardrobe.Sales;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * The seller's counter: a pastel window with her portrait, a speech bubble that types out her lines, the cart
 * with the clothes picked in the fitting room, the discount (loyalty card + haggle) and the pay button.
 * All money is still decided by the server; this screen only shows and asks.
 */
public class SellerScreen extends Screen {
    // pastel palette (ARGB)
    private static final int CREAM = 0xFFFFF8EE;
    private static final int PINK = 0xFFF8C8CC;
    private static final int PINK_L = 0xFFFFE3E6;
    private static final int PINK_D = 0xFFE59BA9;
    private static final int MINT = 0xFFC9E8DF;
    private static final int MINT_D = 0xFF8FC5B7;
    private static final int LILAC = 0xFFDCCBF0;
    private static final int LILAC_D = 0xFFB59AD8;
    private static final int GOLD = 0xFFF0BE46;
    private static final int GOLD_L = 0xFFFFE9A0;
    private static final int GOLD_D = 0xFFC8942A;
    private static final int TEXT = 0xFF5E3E36;
    private static final int TEXT_SOFT = 0xFF9A8076;
    private static final int PRICE = 0xFFB8860B;
    private static final int RED = 0xFFD94A4A;
    private static final int GREEN = 0xFF4E9A78;

    private static final int W = 264, H = 238;
    private static final int ROWS = 3, ROW_H = 20, LIST_Y = 126;
    private static final int BTN_Y = 214, BTN_H = 18, BTN_W = 58, BTN_GAP = 4;
    private static final int TALK = 6;

    private final String name;
    private final int variant;
    private final ResourceLocation skin;
    private final Random random = new Random();

    private String line;
    private int lineAge;
    private int lastTalk = -1;
    private int scroll;
    private int left;
    private int top;
    private int tickCount;
    private int lastHaggle = ClientSellerState.haggle();
    private int cartBefore;
    private final List<Float[]> hearts = new ArrayList<>(); // x, y, speed, drift, life

    public SellerScreen(String name, int variant, String key, String arg) {
        super(Component.literal(name));
        this.name = name;
        this.variant = Math.floorMod(variant, 3);
        this.skin = ResourceLocation.fromNamespaceAndPath(FittingRoomMod.MOD_ID,
                "textures/entity/seller_" + this.variant + ".png");
        this.line = Component.translatable(key, arg).getString();
        this.cartBefore = unownedCart().size();
    }

    /** A new line from the seller (a server answer or a click on Chat). */
    public void say(String key, String arg) {
        this.line = Component.translatable(key, arg).getString();
        this.lineAge = 0;
        if (key.endsWith("thanks") || key.endsWith("tier_up") || key.endsWith("haggle_win")) {
            burst();
        }
    }

    @Override
    protected void init() {
        this.left = (this.width - W) / 2;
        this.top = Math.max(2, (this.height - H) / 2);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void tick() {
        tickCount++;
        lineAge++;
        Float[][] copy = hearts.toArray(new Float[0][]);
        hearts.clear();
        for (Float[] h : copy) {
            h[1] -= h[2];
            h[0] += (float) Math.sin((h[4] + h[3]) * 0.3) * 0.4F;
            h[4] -= 1F;
            if (h[4] > 0) {
                hearts.add(h);
            }
        }
        // after a payment the cart empties: celebrate
        int now = unownedCart().size();
        if (cartBefore > 0 && now == 0) {
            burst();
        }
        cartBefore = now;
        scroll = Math.min(scroll, maxScroll(now));
        lastHaggle = ClientSellerState.haggle();
    }

    private void burst() {
        for (int i = 0; i < 14; i++) {
            hearts.add(new Float[]{left + 20F + random.nextInt(56), top + 80F, 0.6F + random.nextFloat() * 1.0F,
                    random.nextFloat() * 6F, 30F + random.nextInt(25)});
        }
    }

    // ---------------------------------------------------------------- cart maths
    private List<ClothingCatalog.Item> unownedCart() {
        List<ClothingCatalog.Item> out = new ArrayList<>();
        for (String id : ClientSellerState.cart()) {
            ClothingCatalog.Item item = ClothingCatalog.byId(id);
            if (item != null && !ClientWardrobeStore.owns(id)) {
                out.add(item);
            }
        }
        return out;
    }

    private long subtotal(List<ClothingCatalog.Item> items) {
        long sum = 0;
        for (ClothingCatalog.Item item : items) {
            sum += Sales.price(item, ClientWardrobeStore.saleDate());
        }
        return sum;
    }

    private int maxScroll(int size) {
        return Math.max(0, size - ROWS);
    }

    // ---------------------------------------------------------------- hit boxes
    private static boolean in(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    private int btnX(int i) {
        return left + 10 + i * (BTN_W + BTN_GAP);
    }

    private int btnAt(double mx, double my) {
        for (int i = 0; i < 4; i++) {
            if (in(mx, my, btnX(i), top + BTN_Y, BTN_W, BTN_H)) {
                return i;
            }
        }
        return -1;
    }

    private int removeAt(double mx, double my, int count) {
        for (int i = 0; i < ROWS; i++) {
            int idx = scroll + i;
            if (idx < count && in(mx, my, left + W - 28, top + LIST_Y + i * ROW_H + 3, 14, 14)) {
                return idx;
            }
        }
        return -1;
    }

    private boolean overClear(double mx, double my) {
        return in(mx, my, left + W - 70, top + LIST_Y - 12, 60, 10);
    }

    // ---------------------------------------------------------------- drawing helpers
    /** A rectangle with the four corner pixels cut off: the soft "pixel-rounded" look of the mod. */
    private static void soft(GuiGraphics g, int x, int y, int w, int h, int fill) {
        g.fill(x + 1, y, x + w - 1, y + h, fill);
        g.fill(x, y + 1, x + w, y + h - 1, fill);
    }

    private static void framed(GuiGraphics g, int x, int y, int w, int h, int edge, int fill) {
        soft(g, x, y, w, h, edge);
        soft(g, x + 1, y + 1, w - 2, h - 2, fill);
    }

    private void button(GuiGraphics g, int x, int y, int w, int h, Component label, int color, int dark,
                        boolean enabled, boolean hover) {
        int yy = hover && enabled ? y - 1 : y;
        int fill = enabled ? (hover ? lighten(color) : color) : 0xFFE6DED6;
        int edge = enabled ? dark : 0xFFBFB2A6;
        soft(g, x, yy + 1, w, h, edge);                // the lower rim gives a little depth
        soft(g, x, yy, w, h, edge);
        soft(g, x + 1, yy + 1, w - 2, h - 2, fill);
        g.fill(x + 2, yy + 1, x + w - 2, yy + 2, 0x66FFFFFF); // light edge on the top
        txtC(g, this.font, label, x + w / 2, yy + (h - 8) / 2 + 1, w - 6,
                enabled ? TEXT : TEXT_SOFT, false);
    }

    private static int lighten(int c) {
        int r = Math.min(255, ((c >> 16) & 255) + 16);
        int gr = Math.min(255, ((c >> 8) & 255) + 16);
        int b = Math.min(255, (c & 255) + 16);
        return 0xFF000000 | r << 16 | gr << 8 | b;
    }

    private void scallops(GuiGraphics g, int x, int y, int w) {
        for (int cx = x; cx + 8 <= x + w; cx += 8) {
            int c = ((cx - x) / 8) % 2 == 0 ? PINK : MINT;
            g.fill(cx + 1, y, cx + 7, y + 2, c);
            g.fill(cx + 2, y + 2, cx + 6, y + 4, c);
            g.fill(cx + 3, y + 4, cx + 5, y + 5, c);
        }
    }

    // ---------------------------------------------------------------- text (one size everywhere)
    private String clip(Component c, int maxW) {
        String text = c.getString();
        if (this.font.width(text) <= maxW) {
            return text;
        }
        int dots = this.font.width("...");
        return this.font.plainSubstrByWidth(text, Math.max(0, maxW - dots)) + "...";
    }

    private void txtL(GuiGraphics g, Font f, Component c, int x, int y, int maxW, int color, boolean shadow) {
        g.drawString(f, clip(c, maxW), x, y, color, shadow);
    }

    private void txtR(GuiGraphics g, Font f, Component c, int rightX, int y, int maxW, int color, boolean shadow) {
        String t = clip(c, maxW);
        g.drawString(f, t, rightX - f.width(t), y, color, shadow);
    }

    private void txtC(GuiGraphics g, Font f, Component c, int cx, int y, int maxW, int color, boolean shadow) {
        String t = clip(c, maxW);
        g.drawString(f, t, cx - f.width(t) / 2, y, color, shadow);
    }

    // ---------------------------------------------------------------- render
    @Override
    public void render(GuiGraphics g, int mx, int my, float partialTick) {
        super.render(g, mx, my, partialTick); // dims / blurs the world behind; must come before the panel
        List<ClothingCatalog.Item> cart = unownedCart();

        // window: gold frame, cream paper with a soft pink-to-cream wash
        framed(g, left, top, W, H, GOLD_D, GOLD);
        framed(g, left + 2, top + 2, W - 4, H - 4, CREAM, CREAM);
        g.fillGradient(left + 3, top + 3, left + W - 3, top + 90, PINK_L, CREAM);
        // ribbon with the shop sign
        g.fill(left + 3, top + 3, left + W - 3, top + 21, PINK);
        g.fill(left + 3, top + 21, left + W - 3, top + 22, PINK_D);
        scallops(g, left + 3, top + 22, W - 6);
        txtC(g, this.font, Component.translatable("gui.fittingroom.shop.title"), left + W / 2, top + 8,
                W - 40, TEXT, false);
        g.drawString(this.font, "♥", left + 10, top + 8, PINK_D, false);
        g.drawString(this.font, "♥", left + W - 18, top + 8, PINK_D, false);

        drawSeller(g, mx, my);
        drawCart(g, mx, my, cart);
        drawTotals(g, cart);
        drawButtons(g, mx, my, cart);
        drawHearts(g);
        drawTooltips(g, mx, my, cart);
    }

    private void drawSeller(GuiGraphics g, int mx, int my) {
        // portrait window
        int px = left + 10, py = top + 32, ps = 60;
        framed(g, px, py, ps, ps, GOLD, MINT);
        g.fillGradient(px + 2, py + 2, px + ps - 2, py + ps - 2, 0xFFE3F5EF, MINT);
        // sparkles
        for (int i = 0; i < 5; i++) {
            int sx = px + 6 + (i * 13 + 5) % (ps - 14);
            int sy = py + 5 + (i * 17) % (ps - 14);
            if ((tickCount / 6 + i) % 4 != 0) {
                g.fill(sx, sy, sx + 1, sy + 1, 0xFFFFFFFF);
                g.fill(sx - 1, sy, sx + 2, sy + 1, 0x88FFFFFF);
                g.fill(sx, sy - 1, sx + 1, sy + 2, 0x88FFFFFF);
            }
        }
        // the face (head + hat layer) breathes a little
        int bob = (int) Math.round(Math.sin(tickCount * 0.12) * 1.0);
        int fs = 44;
        int fx = px + (ps - fs) / 2, fy = py + 10 + bob;
        g.blit(skin, fx, fy, fs, fs, 16, 16, 16, 16, 128, 128);
        g.blit(skin, fx - 2, fy - 2, fs + 4, fs + 4, 80, 16, 16, 16, 128, 128);
        // name plate
        int ny = py + ps + 3;
        framed(g, px - 1, ny, ps + 2, 14, GOLD_D, GOLD_L);
        txtC(g, this.font, Component.literal(name), px + ps / 2, ny + 3, ps - 6, TEXT, false);
        // speech bubble with a tail
        int bx = left + 80, by = top + 32, bw = W - 90, bh = 60;
        for (int i = 0; i < 5; i++) {
            g.fill(bx - 5 + i, by + 26 + i, bx - 4 + i, by + 41 - i, GOLD);
        }
        framed(g, bx, by, bw, bh, GOLD, 0xFFFFFFFF);
        for (int i = 0; i < 4; i++) {
            g.fill(bx - 3 + i, by + 28 + i, bx + 1, by + 39 - i, 0xFFFFFFFF);
        }
        // loyalty card under the bubble
        int tier = ClientSellerState.tier();
        int[] tierColor = {0xFFE8DED4, 0xFFE0A878, 0xFFD6D9E0, 0xFFF4D060, 0xFFCDEBF5};
        framed(g, bx, ny, bw, 14, GOLD_D, tierColor[tier]);
        txtC(g, this.font, Component.translatable("gui.fittingroom.shop.card",
                Component.translatable("seller.fittingroom.tier." + Loyalty.IDS[tier]), ClientSellerState.percent()),
                bx + bw / 2, ny + 3, bw - 8, TEXT, false);

        int shown = Math.min(line.length(), lineAge * 2);
        List<String> wrapped = GuiText.wrap(this.font, line.substring(0, shown), bw - 14);
        int maxLines = (bh - 10) / 10;
        int startLine = Math.max(0, wrapped.size() - maxLines);
        for (int i = startLine; i < wrapped.size(); i++) {
            txtL(g, this.font, Component.literal(wrapped.get(i)), bx + 7, by + 7 + (i - startLine) * 10,
                    bw - 14, TEXT, false);
        }
        if (shown >= line.length() && (tickCount / 10) % 2 == 0) {
            g.drawString(this.font, "▼", bx + bw - 13, by + bh - 12, PINK_D, false);
        }
    }

    private void drawCart(GuiGraphics g, int mx, int my, List<ClothingCatalog.Item> cart) {
        txtL(g, this.font, Component.translatable("gui.fittingroom.shop.cart", cart.size()),
                left + 12, top + LIST_Y - 11, W - 90, TEXT, false);
        if (!cart.isEmpty()) {
            boolean over = overClear(mx, my);
            txtR(g, this.font, Component.translatable("gui.fittingroom.shop.clear"), left + W - 12,
                    top + LIST_Y - 11, 60, over ? RED : TEXT_SOFT, false);
        }
        int lx = left + 8, lw = W - 16;
        framed(g, lx, top + LIST_Y - 1, lw, ROWS * ROW_H + 2, PINK, 0xFFFFFFFF);
        if (cart.isEmpty()) {
            txtC(g, this.font, Component.translatable("gui.fittingroom.shop.empty"), left + W / 2,
                    top + LIST_Y + 20, lw - 16, TEXT_SOFT, false);
            txtC(g, this.font, Component.translatable("gui.fittingroom.shop.empty2"), left + W / 2,
                    top + LIST_Y + 32, lw - 16, TEXT_SOFT, false);
            return;
        }
        int pct = ClientSellerState.percent();
        for (int i = 0; i < ROWS; i++) {
            int idx = scroll + i;
            if (idx >= cart.size()) {
                break;
            }
            ClothingCatalog.Item item = cart.get(idx);
            int y = top + LIST_Y + i * ROW_H;
            if (i % 2 == 0) {
                g.fill(lx + 2, y, lx + lw - 2, y + ROW_H, PINK_L);
            }
            g.blit(ResourceLocation.fromNamespaceAndPath("fittingroom", "textures/gui/clothes/" + item.id() + ".png"),
                    lx + 5, y + 2, 0, 0, 16, 16, 16, 16);
            long shelf = item.priceCents();
            long price = Sales.price(item, ClientWardrobeStore.saleDate());
            txtL(g, this.font, Component.translatable(item.translationKey()), lx + 25, y + 3, lw - 100, TEXT, false);
            String priceText = Money.format(Loyalty.apply(price, pct));
            txtR(g, this.font, Component.literal(priceText), lx + lw - 24, y + 3, 56, PRICE, false);
            if (price < shelf) {
                txtL(g, this.font, Component.translatable("gui.fittingroom.shop.sale"), lx + 25, y + 11, 40, GREEN, false);
            }
            boolean overX = removeAt(mx, my, cart.size()) == idx;
            g.drawString(this.font, "×", lx + lw - 18, y + 6, overX ? RED : TEXT_SOFT, false);
        }
        if (maxScroll(cart.size()) > 0) {
            int trackH = ROWS * ROW_H - 2;
            int thumbH = Math.max(8, trackH * ROWS / cart.size());
            int thumbY = top + LIST_Y + (trackH - thumbH) * scroll / maxScroll(cart.size());
            g.fill(left + W - 12, thumbY, left + W - 10, thumbY + thumbH, GOLD);
        }
    }

    private void drawTotals(GuiGraphics g, List<ClothingCatalog.Item> cart) {
        long sub = subtotal(cart);
        long total = ClientSellerState.discounted(sub);
        int y = top + LIST_Y + ROWS * ROW_H + 5;
        long balance = ClientWardrobeStore.balance();
        boolean poor = total > balance;
        txtL(g, this.font, Component.translatable("gui.fittingroom.balance", Money.format(balance)),
                left + 12, y, 100, TEXT, false);
        int pct = ClientSellerState.percent();
        if (pct > 0 && sub > 0) {
            txtR(g, this.font, Component.translatable("gui.fittingroom.shop.discount", pct,
                    Money.format(sub - total)), left + W - 12, y, 110, GREEN, false);
        }
        Component totalText = Component.translatable("gui.fittingroom.total", Money.format(total));
        txtR(g, this.font, totalText, left + W - 12, y + 10, 130, poor ? RED : PRICE, false);
        if (ClientSellerState.haggle() > 0) {
            txtL(g, this.font, Component.translatable("gui.fittingroom.shop.haggled", ClientSellerState.haggle()),
                    left + 12, y + 10, 100, GREEN, false);
        }
    }

    private void drawButtons(GuiGraphics g, int mx, int my, List<ClothingCatalog.Item> cart) {
        long total = ClientSellerState.discounted(subtotal(cart));
        boolean canPay = !cart.isEmpty() && ClientSellerState.near() && ClientWardrobeStore.balance() >= total;
        int hover = btnAt(mx, my);
        int y = top + BTN_Y;
        button(g, btnX(0), y, BTN_W, BTN_H, Component.translatable("gui.fittingroom.shop.pay"), MINT, MINT_D, canPay, hover == 0);
        button(g, btnX(1), y, BTN_W, BTN_H, Component.translatable("gui.fittingroom.shop.haggle"), PINK, PINK_D, true, hover == 1);
        button(g, btnX(2), y, BTN_W, BTN_H, Component.translatable("gui.fittingroom.shop.chat"), LILAC, LILAC_D, true, hover == 2);
        button(g, btnX(3), y, BTN_W, BTN_H, Component.translatable("gui.fittingroom.shop.tryon"), GOLD_L, GOLD_D, true, hover == 3);
    }

    private void drawHearts(GuiGraphics g) {
        for (Float[] h : hearts) {
            int alpha = (int) Math.min(255, h[4] * 10);
            g.drawString(this.font, "♥", Math.round(h[0]), Math.round(h[1]),
                    (alpha << 24) | (PINK_D & 0xFFFFFF), false);
        }
    }

    private void drawTooltips(GuiGraphics g, int mx, int my, List<ClothingCatalog.Item> cart) {
        int b = btnAt(mx, my);
        if (b == 0 && (cart.isEmpty() || !ClientSellerState.near()
                || ClientWardrobeStore.balance() < ClientSellerState.discounted(subtotal(cart)))) {
            String key = cart.isEmpty() ? "gui.fittingroom.shop.tip.empty"
                    : !ClientSellerState.near() ? "gui.fittingroom.need_seller" : "gui.fittingroom.not_enough";
            GuiText.tooltip(g, this.font, List.of(Component.translatable(key)), mx, my, this.width);
        } else if (b == 1) {
            GuiText.tooltip(g, this.font, List.of(Component.translatable("gui.fittingroom.shop.tip.haggle")), mx, my, this.width);
        } else if (b == 3) {
            GuiText.tooltip(g, this.font, List.of(Component.translatable("gui.fittingroom.shop.tip.tryon")), mx, my, this.width);
        }
    }

    // ---------------------------------------------------------------- input
    private void click() {
        if (this.minecraft != null) {
            this.minecraft.getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.UI_BUTTON_CLICK, 1.2F));
        }
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button == 0) {
            List<ClothingCatalog.Item> cart = unownedCart();
            int b = btnAt(mx, my);
            if (b == 0) {
                long total = ClientSellerState.discounted(subtotal(cart));
                if (!cart.isEmpty() && ClientSellerState.near() && ClientWardrobeStore.balance() >= total) {
                    click();
                    PacketDistributor.sendToServer(new SellerActionPayload(SellerActionPayload.CHECKOUT, ""));
                } else if (this.minecraft != null) {
                    this.minecraft.getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.NOTE_BLOCK_BASS, 0.7F));
                }
                return true;
            }
            if (b == 1) {
                click();
                PacketDistributor.sendToServer(new SellerActionPayload(SellerActionPayload.HAGGLE, ""));
                return true;
            }
            if (b == 2) {
                click();
                int next;
                do {
                    next = random.nextInt(TALK);
                } while (next == lastTalk);
                lastTalk = next;
                say("seller.fittingroom.talk" + next, "");
                return true;
            }
            if (b == 3) {
                click();
                FittingRoomClient.openWardrobe();
                return true;
            }
            int rem = removeAt(mx, my, cart.size());
            if (rem >= 0) {
                click();
                PacketDistributor.sendToServer(new SellerActionPayload(SellerActionPayload.REMOVE, cart.get(rem).id()));
                return true;
            }
            if (!cart.isEmpty() && overClear(mx, my)) {
                click();
                PacketDistributor.sendToServer(new SellerActionPayload(SellerActionPayload.CLEAR, ""));
                return true;
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double scrollX, double scrollY) {
        int max = maxScroll(unownedCart().size());
        if (max > 0) {
            scroll = Math.max(0, Math.min(max, scroll - (int) Math.signum(scrollY)));
            return true;
        }
        return super.mouseScrolled(mx, my, scrollX, scrollY);
    }
}
