package com.fittingroom.client;

import com.fittingroom.FittingRoomMod;
import com.fittingroom.seller.ClientSellerState;
import com.fittingroom.wardrobe.ClientWardrobeStore;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;

/** Game-bus events (client only). */
@EventBusSubscriber(modid = FittingRoomMod.MOD_ID, value = Dist.CLIENT)
public final class ClientGameEvents {
    private ClientGameEvents() {}

    @SubscribeEvent
    public static void onLogout(ClientPlayerNetworkEvent.LoggingOut event) {
        ClientWardrobeStore.clear();
        ClientSellerState.clear();
    }
}
