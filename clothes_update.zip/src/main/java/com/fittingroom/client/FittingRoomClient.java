package com.fittingroom.client;

import com.fittingroom.client.gui.SellerScreen;
import com.fittingroom.client.gui.WardrobeScreen;
import net.minecraft.client.Minecraft;

/** Client-only entry points. Only ever called from code that runs on the client. */
public final class FittingRoomClient {
    private FittingRoomClient() {}

    public static void openWardrobe() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) {
            mc.setScreen(new WardrobeScreen(mc.player));
        }
    }

    /** The seller speaks: opens her screen (open) or updates the line if it is already open. */
    public static void seller(String name, int variant, String key, String arg, boolean open) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.screen instanceof SellerScreen screen) {
            screen.say(key, arg);
        } else if (open && mc.player != null) {
            mc.setScreen(new SellerScreen(name, variant, key, arg));
        }
    }
}
