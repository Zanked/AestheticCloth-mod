package com.fittingroom;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

/**
 * The mod's own sounds (assets/fittingroom/sounds/*.ogg, listed in sounds.json). They are made by
 * tools/gen_sounds.py. Safe to use on both sides: no client classes in here.
 */
public final class FittingSounds {
    private FittingSounds() {}

    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(Registries.SOUND_EVENT, FittingRoomMod.MOD_ID);

    private static DeferredHolder<SoundEvent, SoundEvent> register(String name) {
        return SOUNDS.register(name, () -> SoundEvent.createVariableRangeEvent(
                ResourceLocation.fromNamespaceAndPath(FittingRoomMod.MOD_ID, name)));
    }

    /** Putting clothes on. */
    public static final DeferredHolder<SoundEvent, SoundEvent> RUSTLE = register("rustle");
    /** Taking everything off. */
    public static final DeferredHolder<SoundEvent, SoundEvent> UNDRESS = register("undress");
    /** Paid for clothes. */
    public static final DeferredHolder<SoundEvent, SoundEvent> PURCHASE = register("purchase");
    /** A gift was sent or received. */
    public static final DeferredHolder<SoundEvent, SoundEvent> GIFT = register("gift");
    /** Not enough money / refused. */
    public static final DeferredHolder<SoundEvent, SoundEvent> ERROR = register("error");
    /** An outfit was saved to a slot. */
    public static final DeferredHolder<SoundEvent, SoundEvent> SLOT_SAVE = register("slot_save");
    /** A big sale is running. */
    public static final DeferredHolder<SoundEvent, SoundEvent> SALE = register("sale");

    /** Plays the sound in the world at the player (everybody close by hears it), with a little random pitch. */
    public static void play(ServerPlayer player, DeferredHolder<SoundEvent, SoundEvent> sound, float volume) {
        float pitch = 0.95F + player.getRandom().nextFloat() * 0.1F;
        player.level().playSound(null, player.getX(), player.getY(), player.getZ(), sound.get(),
                SoundSource.PLAYERS, volume, pitch);
    }
}
