package com.fittingroom.seller;

import java.util.List;

/** Client copy of the seller state (plain Java, safe to touch from the network handler). */
public final class ClientSellerState {
    private ClientSellerState() {}

    private static volatile boolean near;
    private static volatile int haggle;
    private static volatile long spent;
    private static volatile List<String> cart = List.of();

    public static void set(boolean nearSeller, int haggleToday, long totalSpent, List<String> cartIds) {
        cart = List.copyOf(cartIds);
        near = nearSeller;
        haggle = haggleToday;
        spent = totalSpent;
    }

    public static void clear() {
        set(false, 0, 0L, List.of());
    }

    public static boolean near() {
        return near;
    }

    public static List<String> cart() {
        return cart;
    }

    public static int tier() {
        return Loyalty.tier(spent);
    }

    public static int haggle() {
        return haggle;
    }

    public static int percent() {
        return Loyalty.total(spent, haggle);
    }

    public static long spent() {
        return spent;
    }

    public static long discounted(long cents) {
        return Loyalty.apply(cents, percent());
    }
}
