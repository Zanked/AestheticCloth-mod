package com.fittingroom.seller;

import com.mojang.serialization.Codec;

/** How much the player has spent at the seller, in cents. Saved on the player, kept after death. */
public record LoyaltyData(long spent) {
    public static final LoyaltyData EMPTY = new LoyaltyData(0L);
    public static final Codec<LoyaltyData> CODEC = Codec.LONG.xmap(LoyaltyData::new, LoyaltyData::spent);

    public LoyaltyData plus(long cents) {
        return new LoyaltyData(spent + Math.max(0L, cents));
    }
}
