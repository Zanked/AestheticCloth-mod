package com.fittingroom.seller;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.phys.Vec3;
import com.fittingroom.FittingRoomMod;

/** Use on a block to hire a seller who stands there. The owner earns a commission from every sale. */
public class SellerContractItem extends Item {
    public SellerContractItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult useOn(UseOnContext context) {
        if (!(context.getLevel() instanceof ServerLevel level)) {
            return InteractionResult.SUCCESS;
        }
        Player player = context.getPlayer();
        Vec3 spot = Vec3.atBottomCenterOf(context.getClickedPos().relative(context.getClickedFace()));
        SellerEntity seller = FittingRoomMod.SELLER.get().create(level);
        if (seller == null) {
            return InteractionResult.FAIL;
        }
        float yaw = player != null ? player.getYRot() + 180.0F : 0.0F;
        seller.moveTo(spot.x, spot.y, spot.z, yaw, 0.0F);
        seller.yHeadRot = yaw;
        seller.yBodyRot = yaw;
        if (!level.noCollision(seller)) {
            if (player != null) {
                player.displayClientMessage(Component.translatable("message.fittingroom.seller_no_room"), true);
            }
            return InteractionResult.FAIL;
        }
        seller.setup(player != null ? player.getUUID() : null);
        level.addFreshEntity(seller);
        seller.say("seller.fittingroom.bubble.hired");
        if (player != null) {
            context.getItemInHand().consume(1, player);
        }
        return InteractionResult.CONSUME;
    }
}
