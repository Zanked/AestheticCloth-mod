package com.fittingroom.seller;

import com.mojang.serialization.Codec;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/** The shopping cart: clothes picked in the fitting room that wait to be paid at the seller. Kept after death. */
public record CartData(List<String> items) {
    public static final CartData EMPTY = new CartData(List.of());
    public static final Codec<CartData> CODEC = Codec.STRING.listOf().xmap(CartData::new, CartData::items);
    public static final int MAX = 40;

    public CartData with(Iterable<String> ids) {
        Set<String> all = new LinkedHashSet<>(items);
        for (String id : ids) {
            if (all.size() < MAX) {
                all.add(id);
            }
        }
        return new CartData(new ArrayList<>(all));
    }

    public CartData without(String id) {
        List<String> copy = new ArrayList<>(items);
        copy.remove(id);
        return new CartData(copy);
    }
}
