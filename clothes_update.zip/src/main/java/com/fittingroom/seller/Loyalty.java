package com.fittingroom.seller;

/**
 * The loyalty card: the more a player has spent at the seller in total, the bigger the permanent discount.
 * Plain Java, shared by the server (which charges) and the client (which only shows the same number).
 */
public final class Loyalty {
    private Loyalty() {}

    /** Total spent (cents) at which each tier starts. */
    public static final long[] THRESHOLDS = {0L, 10_000L, 50_000L, 150_000L, 400_000L};
    public static final int[] PERCENT = {0, 3, 5, 8, 10};
    public static final String[] IDS = {"none", "bronze", "silver", "gold", "platinum"};
    /** Loyalty and haggling together never go above this. */
    public static final int MAX_PERCENT = 30;

    public static int tier(long spent) {
        int tier = 0;
        for (int i = 0; i < THRESHOLDS.length; i++) {
            if (spent >= THRESHOLDS[i]) {
                tier = i;
            }
        }
        return tier;
    }

    public static int percent(long spent) {
        return PERCENT[tier(spent)];
    }

    /** Amount at which the next tier starts, or -1 at the top. */
    public static long nextThreshold(long spent) {
        int tier = tier(spent);
        return tier + 1 < THRESHOLDS.length ? THRESHOLDS[tier + 1] : -1L;
    }

    public static int total(long spent, int haggle) {
        return Math.min(MAX_PERCENT, percent(spent) + Math.max(0, haggle));
    }

    /** The price after the discount; the same arithmetic on both sides. */
    public static long apply(long cents, int percent) {
        return cents * (100 - Math.max(0, Math.min(MAX_PERCENT, percent))) / 100;
    }
}
