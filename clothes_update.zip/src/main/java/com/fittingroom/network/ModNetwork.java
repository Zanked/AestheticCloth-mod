package com.fittingroom.network;

import com.fittingroom.FittingRoomMod;
import com.fittingroom.FittingSounds;
import com.fittingroom.seller.CartData;
import com.fittingroom.seller.ClientSellerState;
import com.fittingroom.seller.Sellers;
import com.fittingroom.wardrobe.OutfitSlotsData;
import com.fittingroom.wardrobe.ClientWardrobeStore;
import com.fittingroom.wardrobe.ClothingCatalog;
import com.fittingroom.wardrobe.ServerEvents;
import com.fittingroom.wardrobe.Shop;
import com.fittingroom.wardrobe.WardrobeData;
import com.fittingroom.client.FittingRoomClient;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.handling.IPayloadContext;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;

import java.util.ArrayList;
import java.util.List;

public final class ModNetwork {
    private ModNetwork() {}

    public static void register(RegisterPayloadHandlersEvent event) {
        PayloadRegistrar registrar = event.registrar("5");
        registrar.playToServer(SetOutfitPayload.TYPE, SetOutfitPayload.STREAM_CODEC, ModNetwork::handleSetOutfit);
        registrar.playToServer(GiftPayload.TYPE, GiftPayload.STREAM_CODEC, ModNetwork::handleGift);
        registrar.playToServer(SaveSlotPayload.TYPE, SaveSlotPayload.STREAM_CODEC, ModNetwork::handleSaveSlot);
        registrar.playToServer(SellerActionPayload.TYPE, SellerActionPayload.STREAM_CODEC, ModNetwork::handleSellerAction);
        registrar.playToClient(OpenSellerPayload.TYPE, OpenSellerPayload.STREAM_CODEC, ModNetwork::handleOpenSeller);
        registrar.playToClient(SyncOutfitPayload.TYPE, SyncOutfitPayload.STREAM_CODEC, ModNetwork::handleSync);
        registrar.playToClient(WalletPayload.TYPE, WalletPayload.STREAM_CODEC, ModNetwork::handleWallet);
        registrar.playToClient(SellerStatePayload.TYPE, SellerStatePayload.STREAM_CODEC, ModNetwork::handleSellerState);
    }

    /** Runs on the server: validate, pay for new clothes from the bank, save on the player, tell everybody. */
    private static void handleSetOutfit(SetOutfitPayload payload, IPayloadContext context) {
        if (!(context.player() instanceof ServerPlayer player)) {
            return;
        }
        // clothes can only be changed next to a fitting room
        if (!canUseWardrobe(player)) {
            return;
        }
        List<String> clean = ClothingCatalog.sanitize(payload.items());
        List<String> before = player.getData(FittingRoomMod.WARDROBE).items();
        // owned clothes are worn at once, the rest goes to the cart and is paid at the seller
        List<String> wear = new ArrayList<>();
        List<String> toCart = new ArrayList<>();
        for (String id : clean) {
            (Shop.owned(player).owns(id) ? wear : toCart).add(id);
        }
        Shop.addToCart(player, toCart);
        player.setData(FittingRoomMod.WARDROBE, new WardrobeData(wear));
        if (!wear.equals(before)) {
            FittingSounds.play(player, wear.isEmpty() ? FittingSounds.UNDRESS : FittingSounds.RUSTLE, 0.8F);
        }
        // Always answer: the client already shows the new outfit as a preview, and if the purchase was refused
        // this puts the old outfit back. It also refreshes what the player owns and the balance.
        ServerEvents.syncToTrackers(player);
        ServerEvents.sendWallet(player, false);
    }

    /** Runs on the server: buy clothes for another player. */
    private static void handleGift(GiftPayload payload, IPayloadContext context) {
        if (!(context.player() instanceof ServerPlayer player) || !canUseWardrobe(player)) {
            return;
        }
        ServerPlayer recipient = player.server.getPlayerList().getPlayer(payload.recipient());
        if (recipient == null) {
            player.sendSystemMessage(Component.translatable("message.fittingroom.gift_no_player"));
        } else {
            Shop.gift(player, recipient, ClothingCatalog.sanitize(payload.items()));
            ServerEvents.sendWallet(recipient, false);
        }
        ServerEvents.sendWallet(player, false);
    }

    /** Runs on the server: remember an outfit in one of the slots. */
    private static void handleSaveSlot(SaveSlotPayload payload, IPayloadContext context) {
        if (!(context.player() instanceof ServerPlayer player) || !canUseWardrobe(player)) {
            return;
        }
        if (payload.slot() < 0 || payload.slot() >= OutfitSlotsData.COUNT) {
            return;
        }
        List<String> clean = ClothingCatalog.sanitize(payload.items());
        player.setData(FittingRoomMod.SLOTS, player.getData(FittingRoomMod.SLOTS).with(payload.slot(), clean));
        FittingSounds.play(player, FittingSounds.SLOT_SAVE, 0.6F);
        ServerEvents.sendWallet(player, false);
    }

    /** Runs on the client (no client-only classes are touched here). */
    private static void handleSync(SyncOutfitPayload payload, IPayloadContext context) {
        ClientWardrobeStore.set(payload.player(), payload.items());
    }

    /** Runs on the client. Opens the fitting room when the server asks for it. */
    private static void handleWallet(WalletPayload payload, IPayloadContext context) {
        context.enqueueWork(() -> {
            ClientWardrobeStore.setWallet(payload.owned(), payload.balanceCents(), payload.saleDay(), payload.slots());
            if (payload.open()) {
                FittingRoomClient.openWardrobe();
            }
        });
    }

    /** Runs on the server: a button of the seller screen. */
    private static void handleSellerAction(SellerActionPayload payload, IPayloadContext context) {
        if (!(context.player() instanceof ServerPlayer player)) {
            return;
        }
        switch (payload.action()) {
            case SellerActionPayload.CHECKOUT -> {
                Shop.checkout(player);
                ServerEvents.sendWallet(player, false);
            }
            case SellerActionPayload.HAGGLE -> {
                var seller = Sellers.nearest(player, Sellers.RANGE);
                if (seller != null) {
                    Sellers.haggle(player, seller);
                }
            }
            case SellerActionPayload.REMOVE -> {
                player.setData(FittingRoomMod.CART, player.getData(FittingRoomMod.CART).without(payload.arg()));
                Sellers.sendState(player);
            }
            case SellerActionPayload.CLEAR -> {
                player.setData(FittingRoomMod.CART, CartData.EMPTY);
                Sellers.sendState(player);
            }
            default -> {
            }
        }
    }

    /** Runs on the client: opens the seller screen or shows a line in it. */
    private static void handleOpenSeller(OpenSellerPayload payload, IPayloadContext context) {
        context.enqueueWork(() -> FittingRoomClient.seller(payload.name(), payload.variant(), payload.key(),
                payload.arg(), payload.open()));
    }

    /** Runs on the client. */
    private static void handleSellerState(SellerStatePayload payload, IPayloadContext context) {
        context.enqueueWork(() -> ClientSellerState.set(payload.near(), payload.haggle(), payload.spent(), payload.cart()));
    }

    /** Clothes can be changed next to a fitting room or next to a seller (but only a seller takes payment). */
    private static boolean canUseWardrobe(ServerPlayer player) {
        return isNearFittingRoom(player) || Sellers.nearSeller(player);
    }

    private static boolean isNearFittingRoom(ServerPlayer player) {
        BlockPos center = player.blockPosition();
        for (BlockPos pos : BlockPos.betweenClosed(center.offset(-4, -3, -4), center.offset(4, 3, 4))) {
            if (player.level().getBlockState(pos).is(FittingRoomMod.FITTING_ROOM.get())) {
                return true;
            }
        }
        return false;
    }
}
