package com.fittingroom.network;

import com.fittingroom.FittingRoomMod;
import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/**
 * Server -> client: the seller says something (translation key + one argument). With {@code open} the seller
 * screen opens, otherwise the line only appears if that screen is already open.
 */
public record OpenSellerPayload(String name, int variant, String key, String arg, boolean open) implements CustomPacketPayload {
    public static final CustomPacketPayload.Type<OpenSellerPayload> TYPE =
            new CustomPacketPayload.Type<>(ResourceLocation.fromNamespaceAndPath(FittingRoomMod.MOD_ID, "open_seller"));

    public static final StreamCodec<ByteBuf, OpenSellerPayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.stringUtf8(64), OpenSellerPayload::name,
            ByteBufCodecs.VAR_INT, OpenSellerPayload::variant,
            ByteBufCodecs.stringUtf8(128), OpenSellerPayload::key,
            ByteBufCodecs.stringUtf8(64), OpenSellerPayload::arg,
            ByteBufCodecs.BOOL, OpenSellerPayload::open,
            OpenSellerPayload::new);

    @Override
    public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
