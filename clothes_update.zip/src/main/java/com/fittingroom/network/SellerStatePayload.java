package com.fittingroom.network;

import com.fittingroom.FittingRoomMod;
import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

import java.util.List;

/** Server -> client: is a seller close enough to pay, today's haggle discount, total spent and the cart. */
public record SellerStatePayload(boolean near, int haggle, long spent, List<String> cart) implements CustomPacketPayload {
    public static final CustomPacketPayload.Type<SellerStatePayload> TYPE =
            new CustomPacketPayload.Type<>(ResourceLocation.fromNamespaceAndPath(FittingRoomMod.MOD_ID, "seller_state"));

    public static final StreamCodec<ByteBuf, SellerStatePayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.BOOL, SellerStatePayload::near,
            ByteBufCodecs.VAR_INT, SellerStatePayload::haggle,
            ByteBufCodecs.VAR_LONG, SellerStatePayload::spent,
            ByteBufCodecs.stringUtf8(64).apply(ByteBufCodecs.list(64)), SellerStatePayload::cart,
            SellerStatePayload::new);

    @Override
    public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
