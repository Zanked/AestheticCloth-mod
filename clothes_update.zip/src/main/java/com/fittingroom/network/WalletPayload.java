package com.fittingroom.network;

import com.fittingroom.FittingRoomMod;
import com.fittingroom.wardrobe.OutfitSlotsData;
import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

import java.util.List;

/**
 * Server -> client: what the player has bought, how much money is on their bank account, the server's date
 * (as an epoch day, so that sale prices are the same on both sides) and the saved outfits.
 * With {@code open} set the client also opens the fitting room screen (so it always shows a fresh balance).
 */
public record WalletPayload(List<String> owned, long balanceCents, boolean open, long saleDay,
                            List<List<String>> slots) implements CustomPacketPayload {
    public static final CustomPacketPayload.Type<WalletPayload> TYPE =
            new CustomPacketPayload.Type<>(ResourceLocation.fromNamespaceAndPath(FittingRoomMod.MOD_ID, "wallet"));

    public static final StreamCodec<ByteBuf, WalletPayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.stringUtf8(64).apply(ByteBufCodecs.list(1024)), WalletPayload::owned,
            ByteBufCodecs.VAR_LONG, WalletPayload::balanceCents,
            ByteBufCodecs.BOOL, WalletPayload::open,
            ByteBufCodecs.VAR_LONG, WalletPayload::saleDay,
            ByteBufCodecs.stringUtf8(64).apply(ByteBufCodecs.list(8)).apply(ByteBufCodecs.list(OutfitSlotsData.COUNT)),
            WalletPayload::slots,
            WalletPayload::new);

    @Override
    public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
