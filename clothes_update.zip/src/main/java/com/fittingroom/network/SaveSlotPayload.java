package com.fittingroom.network;

import com.fittingroom.FittingRoomMod;
import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

import java.util.List;

/** Client -> server: "save this outfit in slot N" (an empty list clears the slot). */
public record SaveSlotPayload(int slot, List<String> items) implements CustomPacketPayload {
    public static final CustomPacketPayload.Type<SaveSlotPayload> TYPE =
            new CustomPacketPayload.Type<>(ResourceLocation.fromNamespaceAndPath(FittingRoomMod.MOD_ID, "save_slot"));

    public static final StreamCodec<ByteBuf, SaveSlotPayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.VAR_INT, SaveSlotPayload::slot,
            ByteBufCodecs.stringUtf8(64).apply(ByteBufCodecs.list(8)), SaveSlotPayload::items,
            SaveSlotPayload::new);

    @Override
    public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
