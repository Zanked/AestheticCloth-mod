package com.fittingroom.network;

import com.fittingroom.FittingRoomMod;
import io.netty.buffer.ByteBuf;
import net.minecraft.core.UUIDUtil;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

import java.util.List;
import java.util.UUID;

/** Client -> server: "buy these clothes as a gift for that player". */
public record GiftPayload(UUID recipient, List<String> items) implements CustomPacketPayload {
    public static final CustomPacketPayload.Type<GiftPayload> TYPE =
            new CustomPacketPayload.Type<>(ResourceLocation.fromNamespaceAndPath(FittingRoomMod.MOD_ID, "gift"));

    public static final StreamCodec<ByteBuf, GiftPayload> STREAM_CODEC = StreamCodec.composite(
            UUIDUtil.STREAM_CODEC, GiftPayload::recipient,
            ByteBufCodecs.stringUtf8(64).apply(ByteBufCodecs.list(8)), GiftPayload::items,
            GiftPayload::new);

    @Override
    public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
