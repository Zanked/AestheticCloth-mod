package com.fittingroom.network;

import com.fittingroom.FittingRoomMod;
import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/** Client -> server: a button of the seller screen. */
public record SellerActionPayload(int action, String arg) implements CustomPacketPayload {
    public static final int CHECKOUT = 0, HAGGLE = 1, REMOVE = 2, CLEAR = 3;

    public static final CustomPacketPayload.Type<SellerActionPayload> TYPE =
            new CustomPacketPayload.Type<>(ResourceLocation.fromNamespaceAndPath(FittingRoomMod.MOD_ID, "seller_action"));

    public static final StreamCodec<ByteBuf, SellerActionPayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.VAR_INT, SellerActionPayload::action,
            ByteBufCodecs.stringUtf8(64), SellerActionPayload::arg,
            SellerActionPayload::new);

    @Override
    public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
