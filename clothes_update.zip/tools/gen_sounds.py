"""Generates the shop sounds (assets/fittingroom/sounds/*.ogg). Needs numpy, scipy and ffmpeg (libvorbis).
Run from the project root: python3 tools/gen_sounds.py"""
import os, subprocess, tempfile
import numpy as np
from scipy.io import wavfile
from scipy.signal import butter, lfilter

SR = 44100
OUT = "src/main/resources/assets/fittingroom/sounds"
rng = np.random.default_rng(7)


def t(d):
    return np.arange(int(SR * d)) / SR


def env(n, a=0.005, r=0.1):
    e = np.ones(n)
    na, nr = max(1, int(SR * a)), max(1, int(SR * r))
    e[:na] = np.linspace(0, 1, na)
    e[-nr:] *= np.linspace(1, 0, nr)
    return e


def bell(freq, d, decay=6.0, partials=((1, 1.0), (2.76, 0.35), (5.4, 0.12))):
    x = t(d)
    y = sum(a * np.sin(2 * np.pi * freq * k * x) for k, a in partials)
    return y * np.exp(-decay * x) * env(len(x), 0.002, 0.02)


def band_noise(d, lo, hi, order=3):
    n = rng.standard_normal(int(SR * d))
    b, a = butter(order, [lo / (SR / 2), hi / (SR / 2)], btype="band")
    return lfilter(b, a, n)


def place(parts):
    """parts: list of (start_seconds, signal)"""
    total = max(int(s * SR) + len(x) for s, x in parts)
    out = np.zeros(total)
    for s, x in parts:
        i = int(s * SR)
        out[i:i + len(x)] += x
    return out


def save(name, sig, gain=0.8):
    sig = sig / (np.max(np.abs(sig)) + 1e-9) * gain
    with tempfile.TemporaryDirectory() as tmp:
        wav = os.path.join(tmp, name + ".wav")
        wavfile.write(wav, SR, (sig * 32767).astype(np.int16))
        os.makedirs(OUT, exist_ok=True)
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", wav, "-ac", "1", "-c:a", "libvorbis",
                        "-q:a", "4", os.path.join(OUT, name + ".ogg")], check=True)


# cloth rustle: two swishes of filtered noise with a soft rise and fall
def rustle(d, lo, hi):
    n = band_noise(d, lo, hi)
    x = t(d)
    shape = np.sin(np.pi * x / d) ** 1.5 * (0.7 + 0.3 * np.sin(2 * np.pi * 14 * x))
    return n * shape

save("rustle", place([(0.0, rustle(0.22, 900, 5200)), (0.17, 0.8 * rustle(0.2, 1400, 6500))]))
# undress: a longer, lower swish
save("undress", place([(0.0, rustle(0.45, 500, 3800)), (0.25, 0.6 * rustle(0.3, 800, 4800))]))
# purchase: little cash register: tick, then two bright bells
tick = band_noise(0.04, 2500, 9000) * np.exp(-90 * t(0.04))
save("purchase", place([(0.0, 0.5 * tick), (0.04, bell(1318, 0.9, 5.0)), (0.13, bell(1976, 1.1, 4.2))]))
# gift: rising chime arpeggio
save("gift", place([(0.0, bell(784, 0.6, 6)), (0.09, bell(988, 0.6, 6)), (0.18, bell(1318, 0.7, 5.5)),
                    (0.30, bell(1568, 1.0, 4.5))]))
# error: soft low double blip
def blip(f, d):
    x = t(d)
    return np.sin(2 * np.pi * f * x) * env(len(x), 0.004, 0.05) * np.exp(-8 * x)
save("error", place([(0.0, blip(196, 0.14)), (0.13, blip(165, 0.2))]), 0.7)
# slot saved: short pop with a high ping
x = t(0.12)
pop = np.sin(2 * np.pi * (380 + 900 * np.exp(-40 * x)) * x) * np.exp(-35 * x)
save("slot_save", place([(0.0, pop), (0.03, 0.5 * bell(1760, 0.3, 14))]))
# sale: a light "ding-ding" shown when the daily sale starts the screen
save("sale", place([(0.0, bell(1568, 0.5, 8)), (0.12, bell(2093, 0.7, 7))]), 0.6)
print("ok")
