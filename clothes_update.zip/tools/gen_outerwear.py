#!/usr/bin/env python3
"""
Generates the dresses, windbreakers, trench coats, coats, sweaters, kimono / yukata and pajamas of the fitting room.
  dress_*        (top)    floral, yellow sundress, evening gown, polka dot (the skirt part hangs on the body bone)
  windbreaker_*  (top)    colour-block zip windbreakers: blue, pink, yellow
  trench_*       (top)    double-breasted trench coats with a belt: beige, black
  coat_*         (top)    long coats: camel, grey double-breasted, red with a round collar
  sweater_*      (top)    cable knit, nordic, pink oversize, striped
  kimono_*, yukata_* (top) kimono with long hanging sleeves and an obi with a bow, lighter yukata
  pajama_*_top / _pants   three pyjama sets: stars, hearts, stripes
Models, 32x textures, 16x16 GUI icons and (idempotently) the entries in clothes.json, the lang files,
ClothingCatalog.java and ClothingPrices.java. Same smooth painter as gen_dino.py.

Run from the project root:  python3 tools/gen_outerwear.py
"""
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from gen_dino import blk, build, grad, mix  # noqa: E402
from gen_accessories import ASSETS, Cube, Icon, shade  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent
WHITE = (250, 248, 244)
GOLD = (232, 190, 84)
GOLD_D = (178, 132, 52)
SILVER = (206, 212, 224)


# ---------------------------------------------------------------- helpers
def tw(side, n):
    return None if side == "r" else n + "_r"


def sd(f):
    return f not in ("top", "bottom")


def keep(center):
    """pivot/rot for an arm cube that must keep its authored X offset on slim arms (see docs/clothes-models.md)."""
    return dict(pivot=center, rot=(0, 0, 0.01))


def tile_col(layers, x, y):
    """Colour of the first motif layer that covers the pixel. A layer: pat (rows of text), cols {char: colour},
    gx/gy spacing, ox/oy offset, shift (odd rows move by half a step)."""
    for L in layers:
        pat, gx, gy = L["pat"], L["gx"], L["gy"]
        row = (y - L.get("oy", 0)) // gy
        sx = gx // 2 if L.get("shift", True) and row % 2 else 0
        cx, cy = (x - L.get("ox", 0) - sx) % gx, (y - L.get("oy", 0)) % gy
        if cy < len(pat) and cx < len(pat[0]):
            ch = pat[cy][cx]
            if ch in L["cols"]:
                return L["cols"][ch]
    return None


def weave(col, light, x, y):
    return mix(col, light, 0.16) if (x + y) % 4 == 0 else col


def fold(col, x, n=4, k=0.10):
    return tuple(max(0, int(v * (1 - k))) for v in col) if x % n == n - 1 else col


def hem_band(col, y, h, trim, rows=2):
    if y >= h - rows:
        return trim
    if y == h - rows - 1:
        return mix(col, trim, 0.5)
    return col


def btn(x, y, bx, by, col):
    if bx <= x < bx + 2 and by <= y < by + 2:
        return shade(col, 1.25) if (x, y) == (bx, by) else col
    return None


SHOULDER_TOP = -2.3  # the skin arm starts at y = -2; a sleeve that starts lower lets the skin's shoulder peek out above it


def arm_pair(cubes, n, cy, dims, base, deco, ox=1.0, off=0.0, offcentre=False):
    top, bottom = cy - dims[1] / 2, cy + dims[1] / 2
    if SHOULDER_TOP < top < -0.5:  # a sleeve (or puff) that should start at the shoulder: pull its top up over the skin arm
        dims = (dims[0], bottom - SHOULDER_TOP, dims[2])
        cy = (bottom + SHOULDER_TOP) / 2
    for side, sx in (("r", -1), ("l", 1)):
        bone = "right_arm" if side == "r" else "left_arm"
        center = (sx * (ox + off), cy, 0)
        kw = keep(center) if offcentre else {}
        cubes.append(Cube(f"{n}_{side}", bone, center, dims, base, deco, twin_of=tw(side, n), mirror=side == "l", **kw))


def leg_pair(cubes, n, cy, dims, base, deco):
    for side, sx in (("r", -1), ("l", 1)):
        bone = "right_leg" if side == "r" else "left_leg"
        cubes.append(Cube(f"{n}_{side}", bone, (sx * 0.1, cy, 0), dims, base, deco, twin_of=tw(side, n), mirror=side == "l"))


# ---------------------------------------------------------------- motifs
DAISY = ["  P  ", " PPP ", "PPCPP", " PPP ", "  P  "]
STAR = ["  X  ", "XXXXX", " XXX ", " X X "]
MOON = [" XX", "XX ", "XX ", " XX"]
HEARTS = [" X X ", "XXXXX", " XXX ", "  X  "]
DOT = ["XX", "XX"]
SAKURA = [" P P ", "PPPPP", " PCP ", "PPPPP", " P P "]
FIRE = ["X  X  X", " X X X ", "  XXX  ", "XXXXXXX", "  XXX  ", " X X X ", "X  X  X"]
RING = [" XXX ", "X   X", "X   X", "X   X", " XXX "]
DIAMOND = ["  X  ", " XXX ", "XXXXX", " XXX ", "  X  "]
BIG_HEART = ["  XX   XX  ", " XXXX XXXX ", "XXXXXXXXXXX", "XXXXXXXXXXX", " XXXXXXXXX ", "  XXXXXXX  ", "   XXXXX   ", "    XXX    ", "     X     "]


# ====================================================================== DRESSES
DRESSES = {
    "floral": dict(kind="floral", base=(252, 240, 218), light=(255, 252, 240), trim=(236, 122, 148), gem=None,
                   layers=[dict(pat=DAISY, cols={"P": (240, 122, 150), "C": (252, 208, 96)}, gx=11, gy=11, ox=1, oy=1),
                           dict(pat=DOT, cols={"X": (120, 176, 108)}, gx=11, gy=11, ox=6, oy=7)],
                   ru="Цветочное платье", en="Floral Dress", price=4999),
    "sundress": dict(kind="sundress", base=(252, 214, 84), light=(255, 238, 150), trim=(255, 250, 240), gem=None,
                     layers=[dict(pat=DOT, cols={"X": (255, 246, 190)}, gx=9, gy=9, ox=1, oy=2)],
                     ru="Жёлтый сарафан", en="Yellow Sundress", price=3999),
    "evening": dict(kind="evening", base=(150, 30, 56), light=(200, 70, 96), trim=GOLD, gem=(90, 200, 240),
                    layers=[dict(pat=["X"], cols={"X": (238, 190, 200)}, gx=7, gy=5, ox=2, oy=1)],
                    ru="Вечернее платье", en="Evening Gown", price=12999),
    "polka": dict(kind="polka", base=(78, 124, 200), light=(120, 164, 232), trim=WHITE, gem=None,
                  layers=[dict(pat=DOT, cols={"X": (250, 250, 255)}, gx=8, gy=8, ox=1, oy=1)],
                  ru="Платье в горошек", en="Polka Dot Dress", price=4499),
}


def dress(name, p):
    kind, base, trim = p["kind"], p["base"], p["trim"]
    strap = kind in ("sundress", "evening")
    midi = kind == "evening"

    def fab(f, x, y, w, h):
        if not sd(f):
            return mix(base, p["light"], 0.2)
        col = tile_col(p["layers"], x, y) or weave(base, p["light"], x, y)
        return fold(col, x, 4, 0.09) if midi else col

    def bodice(f, x, y, w, h):
        if not sd(f):
            return "clear" if strap else mix(base, p["light"], 0.2)
        if strap:
            cut = 7 if midi else 6
            if y < cut:
                if f in ("front", "back") and not midi and (3 <= x <= 5 or w - 6 <= x <= w - 4):
                    return base
                return "clear"
            if y == cut:
                return trim
        if kind == "floral" and f == "front" and y < 4 and abs(x - w // 2) < 4:
            return mix(base, trim, 0.35)
        if kind == "polka" and f == "front" and abs(x - w // 2) < 1 and y > 3:
            return btn(x, y, w // 2 - 1, 7 + (y - 7) // 6 * 6, WHITE) or fab(f, x, y, w, h)
        return fab(f, x, y, w, h)

    cubes = [Cube("bodice", "body", (0, 5.1, 0), (9.6, 10.4, 5.6), base, bodice)]
    band = lambda f, x, y, w, h: None if not sd(f) else (shade(trim, 1.1) if y == 0 else trim)
    cubes.append(Cube("waist", "body", (0, 10.4, 0), (9.9, 1.4, 5.9), trim if kind != "polka" else (200, 52, 70), band))

    tiers = [("sk1", 12.5, 3.2, 10.8, 7.0), ("sk2", 15.5, 3.2, 12.2, 8.4)]
    if midi:
        tiers.append(("sk3", 18.3, 2.8, 13.2, 9.4))
    for i, (n, cy, ch, cw, cd) in enumerate(tiers):
        last = i == len(tiers) - 1

        def skirt(f, x, y, w, h, last=last):
            col = fab(f, x, y, w, h)
            if last and sd(f):
                return hem_band(col, y, h, trim, 2)
            return col
        cubes.append(Cube(n, "body", (0, cy, 0), (cw, ch, cd), base, skirt))

    if kind == "floral":
        puff = lambda f, x, y, w, h: fab(f, x, y, w, h)
        arm_pair(cubes, "puff", 0.6, (6.0, 4.4, 5.8), base, puff)
        arm_pair(cubes, "ribbon", 3.1, (5.5, 0.9, 5.5), trim, lambda f, x, y, w, h: None if not sd(f) else trim)
        cubes.append(Cube("collar", "body", (0, 0.2, 0), (10.0, 1.2, 6.0), WHITE,
                          lambda f, x, y, w, h: None if not sd(f) else (trim if y == h - 1 and x % 2 == 0 else WHITE)))
    if kind == "polka":
        arm_pair(cubes, "sleeve", 2.7, (5.4, 7.4, 5.4), base, fab)
        arm_pair(cubes, "cuff", 6.9, (5.6, 1.6, 5.6), WHITE, lambda f, x, y, w, h: None if not sd(f) else WHITE)
        cubes.append(Cube("collar", "body", (0, 0.4, 0), (10.2, 1.6, 6.2), WHITE,
                          lambda f, x, y, w, h: None if not sd(f) else (mix(WHITE, (190, 200, 224), 0.5) if y == h - 1 else WHITE)))
        cubes.append(Cube("tie", "body", (0, 1.2, -3.2), (2.6, 1.6, 0.8), (200, 52, 70), None))
    if kind in ("floral", "polka"):
        cubes.append(Cube("bow", "body", (0, 10.3, 3.5), (4.6, 2.6, 1.4), trim if kind == "floral" else (200, 52, 70), None))
        for sx in (-1, 1):
            cubes.append(Cube(f"bow_tail{'l' if sx > 0 else 'r'}", "body", (sx * 1.1, 12.6, 3.9), (1.4, 3.8, 0.8),
                              trim if kind == "floral" else (200, 52, 70), None))
    if kind == "sundress":
        cubes.append(Cube("bow", "body", (0, 10.4, -3.25), (4.2, 2.4, 1.0), (255, 250, 240), None))
        cubes.append(Cube("bow_knot", "body", (0, 10.4, -3.8), (1.4, 1.4, 0.8), (230, 190, 70), None))
    if kind == "evening":
        cubes.append(Cube("gem", "body", (0, 10.4, -3.35), (1.8, 1.8, 0.7), p["gem"], grad(shade(p["gem"], 1.2), shade(p["gem"], 0.8))))
    return build(name, cubes)


def icon_dress(name, p):
    i = Icon()
    base, kind = p["base"], p["kind"]
    hi, lo = mix(base, p["light"], 0.5), shade(base, 0.82)
    if kind in ("floral", "polka"):
        blk(i, 2, 3, 4, 5, base)
        blk(i, 11, 3, 13, 5, base)
    if kind == "polka":
        i.rect(2, 5, 4, 5, WHITE); i.rect(11, 5, 13, 5, WHITE)
    for y in range(3, 15):
        if y < 9:
            x0, x1 = 5, 10
        else:
            grow = (y - 8) // 2 + 1 if kind != "evening" else (y - 8) // 3 + 1
            x0, x1 = max(1, 5 - grow), min(14, 10 + grow)
        for x in range(x0, x1 + 1):
            col = base
            if x == x0:
                col = hi
            elif x == x1:
                col = lo
            i.put(x, y, col)
    if kind in ("sundress", "evening"):
        i.rect(6, 3, 9, 4, (0, 0, 0)); [i.px.pop((x, y), None) for x in range(6, 10) for y in (3, 4)]
        i.rect(5, 3, 5, 3, base); i.rect(10, 3, 10, 3, base)
    i.rect(5, 9, 10, 9, p["trim"] if kind != "polka" else (200, 52, 70))
    i.rect(max(1, 2 if kind != "evening" else 1), 14, 14 if kind != "evening" else 14, 14, p["trim"] if kind in ("sundress", "evening", "floral") else WHITE)
    dots = {"floral": (240, 122, 150), "sundress": (255, 246, 190), "evening": (238, 190, 200), "polka": WHITE}[kind]
    for x, y in ((6, 6), (8, 7), (4, 11), (7, 12), (10, 11), (12, 13), (3, 13)):
        if (x, y) in i.px and y != 14:
            i.put(x, y, dots)
    if kind == "polka":
        i.rect(6, 3, 9, 3, WHITE); i.put(7, 4, (200, 52, 70)); i.put(8, 4, (200, 52, 70))
    if kind == "evening":
        i.put(7, 9, p["gem"]); i.put(8, 9, p["gem"])
    i.save(name)


# ====================================================================== WINDBREAKERS
WIND = {
    "blue": dict(base=(70, 128, 214), panel=(250, 250, 255), stripe=(250, 250, 255), dark=(46, 90, 168), zip=SILVER,
                 ru="Синяя ветровка", en="Blue Windbreaker"),
    "pink": dict(base=(248, 160, 196), panel=(255, 244, 248), stripe=(255, 244, 248), dark=(212, 112, 152), zip=SILVER,
                 ru="Розовая ветровка", en="Pink Windbreaker"),
    "yellow": dict(base=(252, 206, 70), panel=(46, 62, 112), stripe=(46, 62, 112), dark=(206, 154, 36), zip=SILVER,
                   ru="Жёлтая ветровка", en="Yellow Windbreaker"),
}


def windbreaker(name, p):
    base, panel, dark = p["base"], p["panel"], p["dark"]

    def body(f, x, y, w, h):
        if not sd(f):
            return None
        col = weave(base, mix(base, WHITE, 0.4), x, y)
        if y < 9 and f in ("front", "back") or (y < 9 and f in ("left", "right")):
            col = weave(panel, mix(panel, base, 0.15), x, y)
        if y == 9:
            col = p["stripe"] if f in ("front", "back", "left", "right") else col
        if y >= h - 3:
            col = dark if x % 2 == 0 else mix(dark, base, 0.4)
        if f == "front":
            c = w // 2
            if c - 1 <= x <= c:
                return p["zip"] if y % 2 == 0 else shade(p["zip"], 0.7)
            if 14 <= y <= 17 and (x in (3, 4) or x in (w - 5, w - 4)):
                return dark
            if y == 3 and c + 2 <= x <= c + 4:
                return p["stripe"]
        return col
    cubes = [Cube("body", "body", (0, 6.0, 0), (9.9, 12.4, 5.9), base, body),
             Cube("collar", "body", (0, -0.2, 0), (10.1, 2.0, 6.1), panel,
                  lambda f, x, y, w, h: None if not sd(f) else (p["zip"] if f == "front" and x in (w // 2 - 1, w // 2) else
                                                              mix(panel, base, 0.25) if y == h - 1 else panel)),
             Cube("hood", "body", (0, 0.2, 2.9), (7.6, 3.6, 2.6), base,
                  lambda f, x, y, w, h: None if not sd(f) else (dark if y == 0 else weave(base, mix(base, WHITE, 0.4), x, y)))]

    def sleeve(f, x, y, w, h):
        if not sd(f):
            return None
        if f in ("left", "right") and w // 2 - 1 <= x <= w // 2:
            return p["stripe"]
        return weave(base, mix(base, WHITE, 0.4), x, y)
    arm_pair(cubes, "sleeve", 3.9, (5.4, 11.4, 5.4), base, sleeve)
    arm_pair(cubes, "cuff", 9.0, (5.6, 2.0, 5.6), dark, lambda f, x, y, w, h: None if not sd(f) else (dark if x % 2 == 0 else mix(dark, base, 0.4)))
    return build(name, cubes)


def icon_windbreaker(name, p):
    i = Icon()
    base, panel = p["base"], p["panel"]
    blk(i, 1, 4, 3, 12, base); blk(i, 12, 4, 14, 12, base)
    i.rect(1, 11, 3, 12, p["dark"]); i.rect(12, 11, 14, 12, p["dark"])
    blk(i, 4, 3, 11, 14, base)
    i.rect(4, 3, 11, 7, panel); i.rect(1, 4, 3, 6, panel); i.rect(12, 4, 14, 6, panel)
    i.rect(4, 8, 11, 8, p["stripe"]); i.rect(4, 14, 11, 14, p["dark"])
    for y in range(3, 14):
        i.put(7, y, p["zip"] if y % 2 else shade(p["zip"], 0.7))
    i.rect(6, 2, 9, 2, panel)
    i.rect(5, 10, 6, 10, p["dark"]); i.rect(9, 10, 10, 10, p["dark"])
    i.save(name)


# ====================================================================== TRENCH COATS AND COATS
LONG = {
    "trench_beige": dict(base=(214, 180, 128), light=(236, 208, 160), dark=(158, 120, 76), btn=(120, 78, 44), lapel=(226, 194, 142),
                         style="trench", belt=(166, 126, 80), ru="Бежевый тренч", en="Beige Trench Coat", price=12999),
    "trench_black": dict(base=(52, 52, 62), light=(86, 86, 102), dark=(30, 30, 38), btn=(168, 172, 186), lapel=(64, 64, 76),
                         style="trench", belt=(34, 34, 42), ru="Чёрный тренч", en="Black Trench Coat", price=12999),
    "coat_camel": dict(base=(196, 148, 90), light=(224, 182, 124), dark=(146, 102, 58), btn=(86, 56, 34), lapel=(210, 164, 106),
                       style="lapel", belt=None, ru="Пальто цвета кэмел", en="Camel Coat", price=14999),
    "coat_gray": dict(base=(126, 130, 144), light=(168, 172, 186), dark=(86, 90, 104), btn=(40, 40, 50), lapel=(144, 148, 162),
                      style="double", belt=None, ru="Серое двубортное пальто", en="Grey Double-breasted Coat", price=14999),
    "coat_red": dict(base=(196, 46, 62), light=(228, 92, 104), dark=(136, 28, 44), btn=GOLD, lapel=(212, 70, 84),
                     style="round", belt=None, ru="Красное пальто с круглым воротником", en="Red Coat with Round Collar", price=15999),
}


def long_coat(name, p):
    base, dark, style = p["base"], p["dark"], p["style"]
    double = style in ("trench", "double")
    flare = style == "round"
    length = 2 if style != "lapel" else 2

    def front(f, x, y, w, h, part):
        """part: body / sk1 / sk2"""
        if not sd(f):
            return None
        col = weave(base, p["light"], x, y)
        if style == "double" or style == "round":
            col = fold(col, x, 6, 0.04)
        c = w // 2
        if part != "body" and y >= h - 2:
            col = mix(col, dark, 0.5)
        if f == "front":
            if double:
                if x == c + 3 and (part != "body" or y > 6):
                    col = dark
            elif x == c - 1 or x == c:
                col = mix(col, dark, 0.55)
            by = {"body": (8, 14, 20), "sk1": (3,), "sk2": ()}[part] if not double else {"body": (7, 13, 19), "sk1": (3,), "sk2": ()}[part]
            for yy in by:
                for bx in ((c - 5, c + 3) if double else (c - 1,)):
                    b = btn(x, y, bx, yy, p["btn"])
                    if b:
                        return b
            if part == "body":
                if style == "round":
                    pass
                else:
                    d = abs(x - c)
                    edge = 8 - y * 0.55
                    if y < 13 and 1 <= d <= edge:
                        return mix(p["lapel"], dark, 0.35) if edge - d < 1.0 else p["lapel"]
                if y in (20, 21) and (4 <= x <= 9 or w - 10 <= x <= w - 5) and style != "round":
                    return dark if y == 20 else mix(col, dark, 0.4)
            elif part == "sk1" and style == "trench" and x in (c - 6, c + 5):
                return dark
        if f == "back" and part == "body" and style == "trench" and y == 7:
            return dark
        if f == "back" and part != "body" and x == w // 2:
            return mix(col, dark, 0.5)
        return col
    body_len = 12.6
    cubes = [Cube("body", "body", (0, 6.1, 0), (9.9, body_len, 5.9), base, lambda f, x, y, w, h: front(f, x, y, w, h, "body"))]
    sk = [("sk1", 14.0, 4.6, 10.9, 6.9), ("sk2", 18.3, 4.2, 11.7 if not flare else 12.8, 7.4 if not flare else 8.2)]
    for n, cy, ch, cw, cd in sk:
        cubes.append(Cube(n, "body", (0, cy, 0), (cw, ch, cd), base, lambda f, x, y, w, h, n=n: front(f, x, y, w, h, n)))

    def collar(f, x, y, w, h):
        if not sd(f):
            return None
        if style == "round":
            return WHITE if y > 0 else (230, 224, 220)
        return mix(p["lapel"], dark, 0.3) if y == h - 1 else p["lapel"]
    if style == "round":
        cubes.append(Cube("collar", "body", (0, 0.2, 0), (10.9, 1.8, 6.9), WHITE, collar))
    else:
        cubes.append(Cube("collar", "body", (0, -0.2, 0), (10.5, 2.4, 6.5), p["lapel"], collar))
    if style == "trench":
        cubes.append(Cube("belt", "body", (0, 9.6, 0), (10.4, 1.6, 6.3), p["belt"],
                          lambda f, x, y, w, h: None if not sd(f) else (shade(p["belt"], 1.15) if y == 0 else p["belt"])))
        cubes.append(Cube("buckle", "body", (1.0, 9.6, -3.2), (1.8, 1.8, 0.5), SILVER, None))
        cubes.append(Cube("belt_tail", "body", (-2.2, 10.7, -3.2), (2.4, 1.0, 0.4), p["belt"], None))

    def sleeve(f, x, y, w, h):
        if not sd(f):
            return None
        col = weave(base, p["light"], x, y)
        if style == "trench" and y == 12 and f in ("front", "back"):
            return dark
        return col
    arm_pair(cubes, "sleeve", 3.9, (5.5, 11.4, 5.5), base, sleeve)
    if style == "trench":
        arm_pair(cubes, "cuff", 8.6, (5.7, 1.4, 5.7), p["belt"], lambda f, x, y, w, h: None if not sd(f) else (p["btn"] if f == "front" and x in (w // 2, w // 2 - 1) and y < 2 else p["belt"]))
        arm_pair(cubes, "strap", -2.0, (5.6, 0.5, 3.0), dark, None)
    else:
        arm_pair(cubes, "cuff", 9.0, (5.7, 2.0, 5.7), dark if style != "round" else WHITE,
                 lambda f, x, y, w, h: None if not sd(f) else (mix(dark, base, 0.3) if style != "round" else WHITE))
    return build(name, cubes)


def icon_long(name, p):
    i = Icon()
    base, dark, style = p["base"], p["dark"], p["style"]
    blk(i, 1, 3, 3, 12, base); blk(i, 12, 3, 14, 12, base)
    i.rect(1, 11, 3, 12, dark if style != "round" else WHITE); i.rect(12, 11, 14, 12, dark if style != "round" else WHITE)
    blk(i, 4, 2, 11, 14, base)
    i.rect(3, 12, 12, 14, base); i.rect(3, 14, 12, 14, shade(base, 0.74))
    if style == "round":
        i.rect(4, 2, 11, 3, WHITE); i.rect(6, 3, 9, 4, WHITE)
    else:
        for k in range(4):
            i.put(6 - k // 2 + 0, 3 + k, p["lapel"]); i.put(9 + k // 2, 3 + k, p["lapel"])
        i.rect(4, 2, 11, 2, p["lapel"])
    i.rect(7, 3, 8, 14, mix(base, dark, 0.55))
    cols = (5, 10) if style in ("trench", "double", "round") else (7,)
    for y in (6, 9, 12):
        for x in cols:
            i.put(x, y, p["btn"])
    if style == "trench":
        i.rect(4, 8, 11, 8, p["belt"]); i.put(8, 8, SILVER)
    i.save(name)


# ====================================================================== SWEATERS
SWEATERS = {
    "cable": dict(kind="cable", base=(240, 228, 204), dark=(190, 170, 134), light=(254, 248, 232), rib=(214, 196, 160),
                  ru="Вязаный свитер с косами", en="Cable Knit Sweater", price=5999),
    "nordic": dict(kind="nordic", base=(48, 70, 124), dark=(30, 44, 86), light=(80, 106, 164), rib=(236, 232, 224),
                   ru="Скандинавский свитер", en="Nordic Sweater", price=6499),
    "pink": dict(kind="pink", base=(248, 178, 204), dark=(214, 130, 164), light=(255, 214, 230), rib=(238, 150, 184),
                 ru="Розовый свитер оверсайз", en="Pink Oversize Sweater", price=4999),
    "stripe": dict(kind="stripe", base=(86, 160, 118), dark=(54, 118, 84), light=(240, 236, 218), rib=(240, 236, 218),
                   ru="Полосатый свитер", en="Striped Sweater", price=4499),
}


def sweater_deco(p, part):
    kind, base, dark, light = p["kind"], p["base"], p["dark"], p["light"]

    def d(f, x, y, w, h):
        if not sd(f):
            return None
        if part == "rib":
            return p["rib"] if x % 2 == 0 else mix(p["rib"], dark, 0.35)
        col = weave(base, light, x, y) if kind != "stripe" else base
        if kind == "cable":
            m = x % 12
            if 2 <= m <= 7:
                t = (y + (m - 2)) % 8
                return light if t < 3 else (mix(base, dark, 0.5) if t == 7 else base)
            return mix(base, dark, 0.3) if x % 2 == 0 else base
        if kind == "nordic":
            if part == "body" and f in ("front", "back", "left", "right"):
                if y in (4, 5, 16, 17):
                    return p["rib"]
                if 6 <= y <= 15:
                    c = tile_col([dict(pat=DIAMOND, cols={"X": p["rib"]}, gx=6, gy=10, ox=0, oy=6, shift=False),
                                  dict(pat=["X"], cols={"X": (206, 60, 70)}, gx=6, gy=10, ox=2, oy=8, shift=False)], x, y)
                    return c or (mix(base, dark, 0.35) if y in (6, 15) else base)
                if y > 22:
                    return mix(base, dark, 0.25) if x % 4 < 2 else base
            if part == "sleeve" and y % 10 in (4, 5):
                return p["rib"]
            return col
        if kind == "pink":
            if part == "body" and f == "front":
                c = tile_col([dict(pat=BIG_HEART, cols={"X": (255, 250, 252)}, gx=99, gy=99, ox=(w - 11) // 2, oy=7, shift=False)], x, y)
                if c:
                    return c
            return col
        if kind == "stripe":
            return light if (y // 4) % 2 == 1 else (weave(base, mix(base, WHITE, 0.3), x, y))
        return col
    return d


def sweater(name, p):
    kind = p["kind"]
    big = kind == "pink"
    bw, bh, bd = (10.8, 13.2, 6.5) if big else (9.9, 12.4, 5.9)
    cubes = [Cube("body", "body", (0, 5.9 + (0.5 if big else 0), 0), (bw, bh, bd), p["base"], sweater_deco(p, "body")),
             Cube("hem", "body", (0, 5.9 + (0.5 if big else 0) + bh / 2 - 0.9, 0), (bw + 0.2, 1.8, bd + 0.2), p["rib"], sweater_deco(p, "rib"))]
    if kind in ("cable", "nordic"):
        cubes.append(Cube("collar", "body", (0, -0.1, 0), (10.1, 2.8, 6.1), p["rib"], sweater_deco(p, "rib")))
    elif kind == "pink":
        cubes.append(Cube("collar", "body", (0, 0.0, 0), (10.9, 1.8, 7.0), p["rib"], sweater_deco(p, "rib")))
    else:
        cubes.append(Cube("collar", "body", (0, 0.1, 0), (10.2, 1.6, 6.2), p["light"], sweater_deco(p, "rib")))
    sw = 5.9 if big else 5.4
    arm_pair(cubes, "sleeve", 4.2 if big else 3.9, (sw, 12.0 if big else 11.4, sw), p["base"], sweater_deco(p, "sleeve"))
    arm_pair(cubes, "cuff", 9.2 if big else 9.0, (sw + 0.2, 2.2, sw + 0.2), p["rib"], sweater_deco(p, "rib"))
    return build(name, cubes)


def icon_sweater(name, p):
    i = Icon()
    kind, base = p["kind"], p["base"]
    blk(i, 1, 4, 3, 12, base); blk(i, 12, 4, 14, 12, base)
    i.rect(1, 11, 3, 12, p["rib"]); i.rect(12, 11, 14, 12, p["rib"])
    blk(i, 4, 3, 11, 14, base)
    i.rect(4, 14, 11, 14, p["rib"]); i.rect(5, 3, 10, 3, p["rib"])
    if kind == "cable":
        for x in (6, 9):
            for y in range(5, 13):
                i.put(x, y, p["light"] if y % 3 else p["dark"])
    if kind == "nordic":
        i.rect(4, 6, 11, 6, p["rib"]); i.rect(4, 10, 11, 10, p["rib"])
        for x in (5, 7, 9):
            i.put(x, 8, p["rib"]); i.put(x + 1, 8, (206, 60, 70))
    if kind == "pink":
        for dy, row in enumerate([" X X ", "XXXXX", " XXX ", "  X  "]):
            for dx, ch in enumerate(row):
                if ch == "X":
                    i.put(5 + dx + 0, 6 + dy, (255, 250, 252))
    if kind == "stripe":
        for y in (6, 8, 10, 12):
            i.rect(4, y, 11, y, p["light"])
        for y in (6, 8):
            i.rect(1, y, 3, y, p["light"]); i.rect(12, y, 14, y, p["light"])
    i.save(name)


# ====================================================================== KIMONO AND YUKATA
KIMONO = {
    "kimono_sakura": dict(base=(248, 184, 208), light=(255, 222, 234), dark=(214, 128, 164), inner=WHITE, obi=(190, 40, 60), obi2=GOLD,
                          layers=[dict(pat=SAKURA, cols={"P": (255, 246, 250), "C": (226, 96, 140)}, gx=12, gy=10, ox=1, oy=2)],
                          sleeve_len=9.0, ru="Кимоно с сакурой", en="Sakura Kimono", price=17999),
    "kimono_red": dict(base=(178, 28, 48), light=(214, 70, 86), dark=(120, 16, 34), inner=WHITE, obi=(30, 28, 38), obi2=GOLD,
                       layers=[dict(pat=RING, cols={"X": GOLD}, gx=9, gy=9, ox=1, oy=1)],
                       sleeve_len=9.0, ru="Красное кимоно с золотом", en="Red Gold Kimono", price=19999),
    "yukata_indigo": dict(base=(40, 56, 112), light=(70, 90, 156), dark=(26, 36, 80), inner=WHITE, obi=(246, 168, 70), obi2=(255, 222, 150),
                          layers=[dict(pat=FIRE, cols={"X": (240, 244, 255)}, gx=14, gy=12, ox=2, oy=2)],
                          sleeve_len=6.0, ru="Тёмная юката с фейерверками", en="Indigo Fireworks Yukata", price=8999),
    "yukata_light": dict(base=(236, 244, 252), light=(252, 254, 255), dark=(176, 196, 226), inner=WHITE, obi=(240, 140, 176), obi2=(255, 220, 232),
                         layers=[dict(pat=DAISY, cols={"P": (110, 160, 226), "C": (252, 224, 120)}, gx=12, gy=11, ox=1, oy=1),
                                 dict(pat=DOT, cols={"X": (130, 190, 140)}, gx=12, gy=11, ox=7, oy=7)],
                         sleeve_len=6.0, ru="Светлая юката с цветами", en="Light Flower Yukata", price=8999),
}


def kimono(name, p):
    base, dark, sl = p["base"], p["dark"], p["sleeve_len"]

    def fab(f, x, y, w, h):
        if not sd(f):
            return mix(base, dark, 0.2)
        return tile_col(p["layers"], x, y) or weave(base, p["light"], x, y)

    def body(f, x, y, w, h):
        if f == "front":
            c = w // 2
            edge = 8 - y * 0.5
            d = abs(x - c)
            if y < 15 and d <= edge:
                if edge - d < 1.2:
                    return p["inner"]
                return mix(p["inner"], dark, 0.28) if d < edge - 1 else None
            if y < 15 and edge - d < 2.6 and d > edge:
                return mix(base, dark, 0.28)
        return fab(f, x, y, w, h)

    cubes = [Cube("body", "body", (0, 6.1, 0), (9.9, 12.6, 5.9), base, body),
             Cube("collar", "body", (0, -0.1, 0), (10.1, 1.6, 6.1), p["inner"],
                  lambda f, x, y, w, h: None if not sd(f) else (mix(p["inner"], dark, 0.3) if y == h - 1 else p["inner"]))]
    for n, cy, ch, cw, cd in (("sk1", 13.6, 4.2, 10.6, 6.7), ("sk2", 17.5, 4.4, 10.9, 6.9)):
        def skirt(f, x, y, w, h, n=n):
            col = fab(f, x, y, w, h)
            if n == "sk2" and sd(f):
                return hem_band(col, y, h, dark, 2)
            return col
        cubes.append(Cube(n, "body", (0, cy, 0), (cw, ch, cd), base, skirt))
    # obi: wide sash with a gold pattern and a big bow at the back
    obi = lambda f, x, y, w, h: None if not sd(f) else (p["obi2"] if y in (1, h - 2) else (mix(p["obi"], p["obi2"], 0.35) if (x + y) % 6 == 0 else p["obi"]))
    cubes.append(Cube("obi", "body", (0, 9.0, 0), (10.4, 4.4, 6.4), p["obi"], obi))
    cubes.append(Cube("bow", "body", (0, 8.8, 3.9), (8.2, 5.2, 2.0), p["obi"], obi))
    cubes.append(Cube("knot", "body", (0, 8.8, 3.6), (2.4, 3.0, 2.6), shade(p["obi"], 0.85), None))
    for sx in (-1, 1):
        cubes.append(Cube(f"tail{'l' if sx > 0 else 'r'}", "body", (sx * 1.8, 13.4, 4.6), (2.2, 5.8, 0.9), p["obi"], obi))

    def sleeve(f, x, y, w, h):
        return fab(f, x, y, w, h)
    arm_pair(cubes, "sleeve", 3.9, (5.5, 11.4, 5.5), base, sleeve)
    arm_pair(cubes, "cuff", 9.0, (5.6, 1.4, 5.6), p["inner"], lambda f, x, y, w, h: None if not sd(f) else p["inner"])
    # long hanging sleeve: a wide box centred on the arm (so slim arms squeeze it like the sleeve and it never floats away from the
    # arm); the inner half is hidden inside the torso, the outer half hangs out as the furisode panel. It is a hair deeper than the sleeve.
    arm_pair(cubes, "hang", 0.4 + sl / 2, (9.6, sl, 5.7), base,
             lambda f, x, y, w, h: hem_band(fab(f, x, y, w, h), y, h, dark, 2) if sd(f) else mix(base, dark, 0.2))
    return build(name, cubes)


def icon_kimono(name, p):
    i = Icon()
    base, dark = p["base"], p["dark"]
    blk(i, 0, 4, 2, 13, base); blk(i, 13, 4, 15, 13, base)
    blk(i, 3, 2, 12, 14, base)
    i.rect(2, 3, 3, 12, base); i.rect(12, 3, 13, 12, base)
    for k in range(6):
        i.put(4 + k, 2 + k, p["inner"]); i.put(11 - k, 2 + k, p["inner"])
    i.rect(5, 7, 10, 7, base)
    i.rect(3, 7, 12, 9, p["obi"]); i.rect(3, 8, 12, 8, p["obi2"])
    i.rect(0, 13, 2, 13, dark); i.rect(13, 13, 15, 13, dark); i.rect(3, 14, 12, 14, dark)
    dot = p["layers"][0]["cols"].get("X") or p["layers"][0]["cols"].get("P")
    for x, y in ((5, 11), (8, 12), (10, 10), (1, 8), (14, 10), (6, 5), (11, 5), (2, 11)):
        i.put(x, y, dot)
    i.save(name)


# ====================================================================== PAJAMAS
PAJAMAS = {
    "stars": dict(base=(54, 72, 140), light=(86, 108, 176), pipe=(250, 246, 232), dark=(34, 46, 98),
                  layers=[dict(pat=STAR, cols={"X": (252, 220, 100)}, gx=10, gy=9, ox=1, oy=1),
                          dict(pat=MOON, cols={"X": (252, 232, 150)}, gx=20, gy=18, ox=7, oy=6)],
                  ru="со звёздами", en="Star", price=(3499, 2999)),
    "hearts": dict(base=(250, 188, 210), light=(255, 224, 236), pipe=(255, 252, 252), dark=(222, 138, 170),
                   layers=[dict(pat=HEARTS, cols={"X": (255, 252, 252)}, gx=10, gy=8, ox=1, oy=1)],
                   ru="с сердечками", en="Heart", price=(3499, 2999)),
    "stripe": dict(base=(140, 182, 230), light=(176, 208, 244), pipe=(252, 252, 255), dark=(96, 140, 196),
                   layers=[], stripes=True,
                   ru="в полоску", en="Striped", price=(3299, 2799)),
}


def pj_fab(p):
    def d(f, x, y, w, h):
        if not sd(f):
            return None
        if p.get("stripes"):
            return p["pipe"] if (x // 4) % 2 == 1 else weave(p["base"], p["light"], x, y)
        return tile_col(p["layers"], x, y) or weave(p["base"], p["light"], x, y)
    return d


def pajama_top(name, p):
    fab = pj_fab(p)

    def body(f, x, y, w, h):
        if f == "front":
            c = w // 2
            if c - 1 <= x <= c:
                b = btn(x, y, c - 1, 5 + (y - 5) // 6 * 6, p["pipe"]) if y >= 5 else None
                return b or p["pipe"]
            if 4 <= x <= 9 and 10 <= y <= 15:
                return p["pipe"] if (y == 10 or x in (4, 9)) else mix(p["base"], p["dark"], 0.2)
        if sd(f) and y >= h - 2:
            return p["pipe"]
        return fab(f, x, y, w, h)
    cubes = [Cube("body", "body", (0, 6.1, 0), (9.6, 12.4, 5.6), p["base"], body),
             Cube("collar", "body", (0, -0.1, 0), (9.9, 1.4, 5.9), p["pipe"],
                  lambda f, x, y, w, h: None if not sd(f) else (mix(p["pipe"], p["dark"], 0.3) if y == h - 1 else p["pipe"]))]
    arm_pair(cubes, "sleeve", 3.9, (5.3, 11.4, 5.3), p["base"], fab)
    arm_pair(cubes, "cuff", 9.0, (5.5, 1.8, 5.5), p["pipe"], lambda f, x, y, w, h: None if not sd(f) else p["pipe"])
    return build(name, cubes)


def pajama_pants(name, p):
    fab = pj_fab(p)
    cubes = [Cube("belt", "body", (0, 11.3, 0), (8.9, 1.6, 4.9), p["pipe"],
                  lambda f, x, y, w, h: None if not sd(f) else (p["dark"] if f == "front" and x in (w // 2 - 2, w // 2 + 1) and y > 1 else p["pipe"]))]
    leg_pair(cubes, "leg", 5.9, (5.0, 11.8, 5.0), p["base"], fab)
    leg_pair(cubes, "cuff", 11.0, (5.2, 1.8, 5.2), p["pipe"], lambda f, x, y, w, h: None if not sd(f) else p["pipe"])
    return build(name, cubes)


def icon_pj_top(name, p):
    i = Icon()
    base, pipe = p["base"], p["pipe"]
    blk(i, 1, 4, 3, 12, base); blk(i, 12, 4, 14, 12, base)
    i.rect(1, 11, 3, 12, pipe); i.rect(12, 11, 14, 12, pipe)
    blk(i, 4, 3, 11, 14, base)
    i.rect(4, 14, 11, 14, pipe); i.rect(5, 3, 10, 3, pipe); i.rect(7, 4, 8, 13, pipe)
    for y in (6, 9, 12):
        i.put(7, y, mix(pipe, p["dark"], 0.5))
    if p.get("stripes"):
        for x in (5, 9, 13):
            i.rect(x - 1 if x > 5 else x, 5, x, 13, pipe) if x < 12 else None
        i.rect(5, 5, 5, 13, pipe); i.rect(10, 5, 10, 13, pipe); i.rect(2, 5, 2, 10, pipe); i.rect(13, 5, 13, 10, pipe)
    else:
        dot = p["layers"][0]["cols"]["X"]
        for x, y in ((5, 6), (10, 7), (5, 10), (10, 11), (2, 7), (13, 8)):
            i.put(x, y, dot)
    i.save(name)


def icon_pj_pants(name, p):
    i = Icon()
    base, pipe = p["base"], p["pipe"]
    blk(i, 3, 3, 12, 4, pipe)
    blk(i, 3, 5, 7, 13, base); blk(i, 8, 5, 12, 13, base)
    i.rect(7, 5, 8, 9, p["dark"])
    i.rect(3, 12, 7, 13, pipe); i.rect(8, 12, 12, 13, pipe)
    if p.get("stripes"):
        for x in (4, 6, 9, 11):
            i.rect(x, 5, x, 11, pipe)
    else:
        dot = p["layers"][0]["cols"]["X"]
        for x, y in ((4, 7), (6, 10), (9, 8), (11, 10)):
            i.put(x, y, dot)
    i.save(name)


# ====================================================================== run + registration
CATEGORY = {"top": "TOP", "bottom": "BOTTOM"}


def entries():
    out = []
    for k, p in DRESSES.items():
        out.append(dict(id=f"dress_{k}", category="top", ru=p["ru"], en=p["en"], price=p["price"],
                        build=lambda n=f"dress_{k}", p=p: dress(n, p), icon=lambda n=f"dress_{k}", p=p: icon_dress(n, p)))
    for k, p in WIND.items():
        out.append(dict(id=f"windbreaker_{k}", category="top", ru=p["ru"], en=p["en"], price=5499,
                        build=lambda n=f"windbreaker_{k}", p=p: windbreaker(n, p),
                        icon=lambda n=f"windbreaker_{k}", p=p: icon_windbreaker(n, p)))
    for k, p in LONG.items():
        out.append(dict(id=k, category="top", ru=p["ru"], en=p["en"], price=p["price"],
                        build=lambda n=k, p=p: long_coat(n, p), icon=lambda n=k, p=p: icon_long(n, p)))
    for k, p in SWEATERS.items():
        out.append(dict(id=f"sweater_{k}", category="top", ru=p["ru"], en=p["en"], price=p["price"],
                        build=lambda n=f"sweater_{k}", p=p: sweater(n, p), icon=lambda n=f"sweater_{k}", p=p: icon_sweater(n, p)))
    for k, p in KIMONO.items():
        out.append(dict(id=k, category="top", ru=p["ru"], en=p["en"], price=p["price"],
                        build=lambda n=k, p=p: kimono(n, p), icon=lambda n=k, p=p: icon_kimono(n, p)))
    for k, p in PAJAMAS.items():
        out.append(dict(id=f"pajama_{k}_top", category="top", ru=f"Пижамная кофта {p['ru']}", en=f"{p['en']} Pajama Top",
                        price=p["price"][0], build=lambda n=f"pajama_{k}_top", p=p: pajama_top(n, p),
                        icon=lambda n=f"pajama_{k}_top", p=p: icon_pj_top(n, p)))
        out.append(dict(id=f"pajama_{k}_pants", category="bottom", ru=f"Пижамные штаны {p['ru']}", en=f"{p['en']} Pajama Pants",
                        price=p["price"][1], build=lambda n=f"pajama_{k}_pants", p=p: pajama_pants(n, p),
                        icon=lambda n=f"pajama_{k}_pants", p=p: icon_pj_pants(n, p)))
    return out


def register(items):
    res = ROOT / "src/main/resources/assets/fittingroom"
    cj = json.loads((res / "clothes.json").read_text(encoding="utf-8"))
    have = {it["id"] for it in cj["items"]}
    for e in items:
        if e["id"] in have:
            continue
        cj["items"].append({
            "id": e["id"], "category": e["category"], "name": {"ru_ru": e["ru"], "en_us": e["en"]},
            "model": f"fittingroom:clothes_models/{e['id']}.json",
            "texture": f"fittingroom:textures/clothes/{e['id']}.png",
            "icon": f"fittingroom:textures/gui/clothes/{e['id']}.png"})
    (res / "clothes.json").write_text(json.dumps(cj, ensure_ascii=False) + "\n", encoding="utf-8")
    for lang, key in (("ru_ru", "ru"), ("en_us", "en")):
        path = res / f"lang/{lang}.json"
        data = json.loads(path.read_text(encoding="utf-8"))
        for e in items:
            data.setdefault(f"clothes.fittingroom.{e['id']}", e[key])
        path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    java = ROOT / "src/main/java/com/fittingroom/wardrobe/ClothingCatalog.java"
    text = java.read_text(encoding="utf-8")
    anchor = '            new Item("casual_sneakers", Category.SHOES),\n'
    add = "".join(f'            new Item("{e["id"]}", Category.{CATEGORY[e["category"]]}),\n' for e in items if f'"{e["id"]}"' not in text)
    if add:
        assert anchor in text, "anchor for the catalog not found"
        java.write_text(text.replace(anchor, anchor + add), encoding="utf-8")
    prices = ROOT / "src/main/java/com/fittingroom/wardrobe/ClothingPrices.java"
    text = prices.read_text(encoding="utf-8")
    anchor = '        p("casual_backpack", 4999);\n'
    add = "".join(f'        p("{e["id"]}", {e["price"]});\n' for e in items if f'"{e["id"]}"' not in text)
    if add:
        assert anchor in text, "anchor for the prices not found"
        prices.write_text(text.replace(anchor, anchor + add), encoding="utf-8")


if __name__ == "__main__":
    items = entries()
    for e in items:
        e["build"]()
        e["icon"]()
    register(items)
    print("outerwear set generated:", len(items), "items")
