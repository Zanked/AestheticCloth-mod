#!/usr/bin/env python3
"""
Generates more accessories of the fitting room:
  bag_*       (slot "bag")      crossbody shoulder bags: brown satchel, pink heart purse, black quilted bag on a gold chain
  umbrella_*  (main accessory)  open umbrellas held in the right hand: pink with dots, rainbow, black
  wings_*     (main accessory)  wings on the back: angel, butterfly, bat
  mask_*      (slot "mask")     sleep masks with closed eyes: pink, black, lavender
  earring_*   (slot "earrings") pearl studs, gold square hoops, star drops, heart drops
Models, 32x textures and 16x16 GUI icons, and (idempotently) the entries in clothes.json, the lang files,
ClothingCatalog.java (new slots BAG, MASK, EARRINGS) and ClothingPrices.java. Same smooth painter as gen_dino.py.

Run from the project root:  python3 tools/gen_accessories2.py
"""
import json
import math
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from gen_dino import blk, build, mix  # noqa: E402
from gen_accessories import Cube, Icon, shade  # noqa: E402
from gen_jewelry import GOLD, GOLD_D, GOLD_L, SILVER, SILVER_D, SILVER_L, in_heart, in_star, shaped  # noqa: E402
from gen_outerwear import keep, sd, tile_col, tw, weave  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent
WHITE = (252, 250, 246)
DOT = ["XX", "XX"]


def clear_side(f, x, y, w, h, col):
    return col


# ====================================================================== SHOULDER BAGS (body bone, slot "bag")
BAGS = {
    "brown": dict(kind="satchel", base=(150, 98, 56), dark=(104, 64, 34), light=(186, 134, 86), strap=(122, 80, 46), metal=GOLD,
                  ru="Коричневая сумка через плечо", en="Brown Crossbody Bag", price=5999),
    "pink": dict(kind="heart", base=(248, 170, 198), dark=(214, 124, 158), light=(255, 214, 230), strap=(232, 138, 172), metal=SILVER,
                 ru="Розовая сумочка с сердечком", en="Pink Heart Purse", price=4499),
    "black": dict(kind="quilt", base=(42, 40, 50), dark=(24, 22, 30), light=(92, 90, 108), strap=GOLD, metal=GOLD,
                  ru="Чёрная стёганая сумка на цепочке", en="Black Quilted Chain Bag", price=8999),
}


def bag_deco(p):
    kind, base, dark, light = p["kind"], p["base"], p["dark"], p["light"]

    def d(f, x, y, w, h):
        if not sd(f):
            return mix(base, dark, 0.25) if f == "bottom" else mix(base, light, 0.2)
        col = weave(base, light, x, y)
        if y == 0 or x == 0 or x == w - 1:
            col = mix(col, dark, 0.35)
        if kind == "quilt" and f in ("front", "back"):
            if (x + y) % 6 == 0 or (x - y) % 6 == 0:
                col = mix(base, light, 0.55)
            return col
        if kind == "heart" and f == "front":
            hw = 9
            cx, cy = w // 2, h // 2 + 1
            u, v = (x - (cx - hw // 2)) / hw, (y - (cy - hw // 2)) / hw
            if 0 <= u <= 1 and 0 <= v <= 1 and in_heart(u, v):
                return mix(light, WHITE, 0.5) if (x + y) % 5 == 0 else light
        if kind == "satchel" and f == "front":
            if y == 3:
                return dark
            if y == h - 3 and x % 3 != 2:
                return mix(base, light, 0.5)
        return col
    return d


def strap_deco(p):
    chain = p["kind"] in ("quilt",) or p["strap"] in (GOLD, SILVER)

    def d(f, x, y, w, h):
        if not sd(f):
            return None
        if chain:
            return p["metal"] if (y // 2) % 2 == 0 else mix(p["metal"], (60, 50, 30), 0.35)
        return mix(p["strap"], p["light"], 0.3) if x == 0 else (shade(p["strap"], 0.8) if x == w - 1 else p["strap"])
    return d


def bag(name, p):
    base = p["base"]
    ang = -36.5
    cubes = [Cube("bag", "body", (3.5, 10.6, -3.95), (6.6, 4.8, 2.8), base, bag_deco(p)),
             Cube("flap", "body", (3.5, 8.7, -4.05), (6.8, 2.2, 3.0), mix(base, p["dark"], 0.18),
                  lambda f, x, y, w, h: bag_deco(p)(f, x, y, w, h) if f != "front" or y < h - 1 else p["dark"]),
             Cube("clasp", "body", (3.5, 9.9, -5.55), (1.4, 1.4, 0.5), p["metal"],
                  lambda f, x, y, w, h: shade(p["metal"], 1.2) if (x, y) == (0, 0) else None)]
    cubes.append(Cube("strap_f", "body", (0.0, 3.4, -3.6), (0.9, 12.0, 0.5), p["strap"], strap_deco(p), pivot=(0.0, 3.4, -3.6), rot=(0, 0, ang)))
    cubes.append(Cube("strap_b", "body", (0.6, 4.3, 3.6), (0.9, 13.6, 0.5), p["strap"], strap_deco(p), pivot=(0.6, 4.3, 3.6), rot=(0, 0, ang)))
    cubes.append(Cube("strap_top", "body", (-3.7, -0.3, 0.0), (1.0, 0.5, 7.4), p["strap"], strap_deco(p)))
    return build(name, cubes)


def icon_bag(name, p):
    i = Icon()
    base, dark, light = p["base"], p["dark"], p["light"]
    for k in range(9):
        i.put(2 + k, 1 + k, p["strap"] if p["kind"] != "quilt" else GOLD)
        i.put(3 + k, 1 + k, p["strap"] if p["kind"] != "quilt" else GOLD_D)
    blk(i, 5, 8, 14, 14, base)
    i.rect(5, 8, 14, 10, mix(base, dark, 0.2))
    i.rect(5, 10, 14, 10, dark)
    i.rect(9, 10, 10, 11, p["metal"])
    if p["kind"] == "heart":
        for x, y in ((7, 12), (8, 12), (11, 12), (12, 12), (7, 13), (8, 13), (9, 13), (10, 13), (11, 13), (12, 13), (9, 14), (10, 14)):
            pass
        for x, y in ((8, 12), (11, 12), (7, 13), (9, 13), (10, 13), (12, 13)):
            i.put(x, y, light)
    if p["kind"] == "quilt":
        for x in (7, 9, 11, 13):
            for y in (12, 14):
                i.put(x, y, light)
    i.save(name)


# ====================================================================== UMBRELLAS (right arm bone)
RAINBOW = [(236, 84, 96), (248, 160, 70), (250, 216, 84), (110, 196, 120), (90, 160, 236)]
UMBRELLAS = {
    "pink": dict(layers=[(247, 170, 200)] * 4, dots=WHITE, dark=(206, 120, 156), rim=(255, 240, 246), wood=(176, 122, 80),
                 ru="Розовый зонтик в горошек", en="Pink Polka Dot Umbrella", price=2499),
    "rainbow": dict(layers=RAINBOW[:4], dots=None, dark=(120, 80, 100), rim=WHITE, wood=(176, 122, 80),
                    ru="Радужный зонтик", en="Rainbow Umbrella", price=2799),
    "black": dict(layers=[(46, 44, 56)] * 4, dots=None, dark=(24, 22, 30), rim=(90, 88, 104), wood=(110, 70, 44),
                  ru="Классический чёрный зонт", en="Classic Black Umbrella", price=2999),
}


def umbrella(name, p):
    z = -3.2
    lay = [(13.2, -12.7, 0.9), (11.2, -13.7, 1.1), (8.6, -14.8, 1.1), (5.6, -15.8, 1.0)]
    cx = -4.6
    cubes = []
    # handle: grip, hook, tip, pole (tilted a little towards the head)
    cubes.append(Cube("grip", "right_arm", (-1.0, 10.0, z), (1.0, 3.2, 1.0), p["wood"], None, **keep((-1.0, 10.0, z))))
    cubes.append(Cube("hook", "right_arm", (-0.1, 12.1, z), (2.6, 0.9, 0.9), p["wood"], None, **keep((-0.1, 12.1, z))))
    cubes.append(Cube("hook_tip", "right_arm", (0.9, 12.9, z), (0.9, 1.6, 0.9), p["wood"], None, **keep((0.9, 12.9, z))))
    pole_c = (-2.9, -2.2, z + 1.5)
    cubes.append(Cube("pole", "right_arm", pole_c, (0.7, 22.0, 0.7), SILVER_D, None, pivot=pole_c, rot=(-8.0, 0, -9.6)))
    for n, (s, y, h) in enumerate(lay):
        col = p["layers"][n]

        def top(f, x, y_, w, h_, col=col, n=n):
            if f == "bottom":
                return mix(p["dark"], col, 0.3) if (x // 2 + y_ // 2) % 4 else p["dark"]
            if f == "top":
                c = weave(col, mix(col, WHITE, 0.4), x, y_)
                if p["dots"] and (x // 3 + y_ // 3) % 3 == 0 and x % 3 < 2 and y_ % 3 < 2:
                    return p["dots"]
                return c
            c = col
            if p["dots"] and (x // 3) % 2 == 0 and y_ % 4 < 2:
                c = p["dots"]
            if n == 0 and y_ >= h_ - 2:
                return p["rim"] if (x // 2) % 2 == 0 else mix(p["rim"], col, 0.5)
            return c
        centre = (cx, y, 0.0)
        cubes.append(Cube(f"canopy{n}_a", "right_arm", centre, (s, h, s), col, top, **keep(centre)))
        c2 = (cx, y + 0.04, 0.0)
        cubes.append(Cube(f"canopy{n}_b", "right_arm", c2, (s, h, s), col, top, pivot=c2, rot=(0, 45, 0.01)))
    tip = (cx, -17.1, 0.0)
    cubes.append(Cube("tip", "right_arm", tip, (0.9, 1.4, 0.9), GOLD, None, **keep(tip)))
    return build(name, cubes)


def icon_umbrella(name, p):
    i = Icon()
    cols = p["layers"]
    rows = [(2, 6, 9, 0), (3, 4, 11, 1), (4, 2, 13, 2), (5, 1, 14, 3)]
    for y, x0, x1, k in rows:
        for x in range(x0, x1 + 1):
            col = cols[min(k, len(cols) - 1)] if len(set(cols)) > 1 else cols[0]
            if p["dots"] and (x + y) % 3 == 0:
                col = p["dots"]
            if x == x0:
                col = mix(col, WHITE, 0.3)
            elif x == x1:
                col = shade(col, 0.82)
            i.put(x, y, col)
    for x in range(1, 15, 2):
        i.put(x, 6, p["rim"] if len(set(cols)) == 1 and p["dots"] else shade(cols[-1], 0.85))
    for y in range(7, 13):
        i.put(8, y, SILVER_D)
    i.rect(8, 13, 9, 13, p["wood"]); i.rect(9, 13, 10, 14, p["wood"]) if False else None
    i.put(9, 13, p["wood"]); i.put(10, 13, p["wood"]); i.put(10, 14, p["wood"])
    i.put(8, 1, GOLD)
    i.save(name)


# ====================================================================== WINGS (body bone, back)
WINGS = {
    "angel": dict(rows=[(5.0, -1.2, 2.6), (9.5, 1.3, 2.8), (12.5, 4.0, 2.8), (12.0, 6.8, 2.8), (10.0, 9.5, 2.8), (7.5, 12.0, 2.6)],
                  c1=(255, 253, 248), c2=(224, 232, 248), edge=(244, 214, 120), rib=(206, 214, 232), cut=2, spots=None,
                  ru="Крылья ангела", en="Angel Wings", price=6999),
    "butterfly": dict(rows=[(8.0, -1.5, 2.8), (13.0, 1.3, 2.8), (14.0, 4.1, 2.8), (10.0, 6.9, 2.8), (9.0, 9.6, 2.8), (6.0, 12.1, 2.6)],
                      c1=(250, 150, 196), c2=(172, 122, 238), edge=(70, 34, 92), rib=(236, 120, 176), cut=1, spots=WHITE,
                      ru="Крылья бабочки", en="Butterfly Wings", price=7999),
    "bat": dict(rows=[(6.0, -1.3, 2.6), (11.0, 1.3, 2.8), (14.0, 4.0, 2.8), (12.0, 6.8, 2.8), (9.5, 9.5, 2.8), (6.0, 12.0, 2.6)],
                c1=(86, 44, 112), c2=(40, 20, 62), edge=(150, 40, 70), rib=(130, 80, 164), cut=3, spots=None,
                ru="Крылья летучей мыши", en="Bat Wings", price=6999),
}


def wing_deco(p, k, n):
    c1, c2 = p["c1"], p["c2"]
    base = mix(c1, c2, k / max(1, n - 1))

    def d(f, x, y, w, h):
        if not sd(f):
            return base if f == "top" else mix(base, c2, 0.4)
        dd = x if f == "back" else w - 1 - x
        cut = p["cut"] * ((y // 3) % 2) + (3 if (y < 2 or y >= h - 2) else 0)
        if dd >= w - cut:
            return "clear"
        col = mix(base, c1, 0.5 * (1 - dd / max(1, w))) if True else base
        if dd >= w - 2 - (p["cut"] if (y // 3) % 2 == 0 else 0):
            return p["edge"]
        if k == 0 and y < 2:
            return p["edge"]
        if k == n - 1 and y >= h - 2:
            return p["edge"]
        if y == h // 2 and dd % 4 != 3:
            return mix(col, p["rib"], 0.7)
        if dd % 5 == 2 and y % 3 != 1:
            return mix(col, p["rib"], 0.35)
        if p["spots"] and dd > w // 2 and (dd // 3) % 2 == 0 and y == h // 2 - 1:
            return p["spots"]
        return col
    return d


def wings(name, p):
    cubes = [Cube("harness", "body", (0.0, 4.6, 3.3), (3.6, 9.0, 1.0), shade(p["c2"], 0.8), None)]
    n = len(p["rows"])
    for k, (w, yc, h) in enumerate(p["rows"]):
        for side, sx in (("r", -1), ("l", 1)):
            c = (sx * (1.5 + w / 2), yc, 3.9)
            cubes.append(Cube(f"w{k}_{side}", "body", c, (w, h, 0.7), p["c1"], wing_deco(p, k, n) if side == "r" else None,
                              pivot=(sx * 1.5, yc, 3.9), rot=(0, -26 * sx, 0), mirror=side == "l", twin_of=tw(side, f"w{k}")))
    return build(name, cubes)


def icon_wings(name, p):
    i = Icon()
    rows = [(2, 3), (3, 5), (4, 7), (5, 7), (6, 6), (7, 5), (8, 4), (9, 2)]
    n = len(rows)
    for k, (y, wd) in enumerate(rows):
        col = mix(p["c1"], p["c2"], k / (n - 1))
        for sx in (-1, 1):
            for dx in range(wd):
                x = 6 - dx if sx < 0 else 9 + dx
                c = p["edge"] if dx == wd - 1 else (mix(col, p["rib"], 0.5) if dx % 3 == 1 and y % 2 else col)
                i.put(x, y, c)
    i.rect(7, 3, 8, 11, shade(p["c2"], 0.8))
    if p["spots"]:
        for x, y in ((2, 5), (13, 5), (3, 7), (12, 7)):
            i.put(x, y, p["spots"])
    i.save(name)


# ====================================================================== SLEEP MASKS (head bone, slot "mask")
MASKS = {
    "pink": dict(base=(248, 170, 200), dark=(214, 124, 158), eye=(124, 60, 92), trim=(255, 240, 246),
                 ru="Розовая маска для сна", en="Pink Sleep Mask", price=1499),
    "black": dict(base=(40, 38, 50), dark=(22, 20, 30), eye=(240, 200, 96), trim=(240, 200, 96),
                  ru="Чёрная шёлковая маска для сна", en="Black Silk Sleep Mask", price=1799),
    "lavender": dict(base=(196, 176, 238), dark=(150, 126, 204), eye=(255, 252, 252), trim=(255, 252, 252),
                     ru="Лавандовая маска для сна", en="Lavender Sleep Mask", price=1499),
}

EYE = ["  XXXXX  ", " X     X ", "X       X", "X  X X  X"]


def mask(name, p):
    def patch(f, x, y, w, h):
        if not sd(f):
            return mix(p["base"], WHITE, 0.2) if f == "top" else p["dark"]
        col = weave(p["base"], mix(p["base"], WHITE, 0.4), x, y)
        if f == "front":
            if y == 0 or y == h - 1 or x == 0 or x == w - 1:
                return p["trim"] if (x + y) % 2 == 0 else mix(p["trim"], p["base"], 0.4)
            for cx in (w // 4 + 1, 3 * w // 4 - 1):
                dx = x - cx
                if y == 3 and abs(dx) <= 2:
                    return p["eye"]
                if y == 4 and abs(dx) in (3,):
                    return p["eye"]
                if y == 5 and abs(dx) in (1, 3) and abs(dx) <= 3 and abs(dx) != 2:
                    return p["eye"] if abs(dx) == 3 else None
        return col
    band = lambda f, x, y, w, h: None if not sd(f) else (p["trim"] if y == 0 and x % 2 == 0 else (p["dark"] if y == h - 1 else p["base"]))
    cubes = [Cube("band", "head", (0, -3.0, 0), (9.2, 1.2, 9.2), p["base"], band),
             Cube("patch", "head", (0, -3.0, -4.95), (7.8, 3.2, 0.9), p["base"], patch)]
    return build(name, cubes)


def icon_mask(name, p):
    i = Icon()
    for y, x0, x1 in ((5, 2, 13), (6, 1, 14), (7, 1, 14), (8, 1, 14), (9, 2, 13), (10, 3, 12)):
        for x in range(x0, x1 + 1):
            col = p["base"] if y < 9 else p["dark"]
            if y == 5 or x == x0:
                col = mix(p["base"], WHITE, 0.35)
            i.put(x, y, col)
    for cx in (5, 10):
        i.rect(cx - 1, 7, cx + 1, 7, p["eye"]); i.put(cx - 2, 8, p["eye"]); i.put(cx + 2, 8, p["eye"])
    i.rect(0, 7, 0, 8, p["dark"]); i.rect(15, 7, 15, 8, p["dark"])
    i.save(name)


# ====================================================================== EARRINGS (head bone, slot "earrings")
EARRINGS = {
    "pearl": dict(kind="pearl", ru="Жемчужные серьги-гвоздики", en="Pearl Studs", price=3499),
    "hoop": dict(kind="hoop", ru="Золотые серьги-кольца", en="Gold Hoop Earrings", price=4999),
    "star": dict(kind="star", ru="Серьги со звёздочками", en="Star Drop Earrings", price=2999),
    "heart": dict(kind="heart", ru="Серьги с сердечками", en="Heart Drop Earrings", price=2999),
}
EX, EY, EZ = 4.95, -1.6, 0.6


def earring(name, p):
    kind = p["kind"]
    cubes = []

    def pair(n, c, dims, base, deco=None):
        cubes.append(Cube(f"{n}_r", "head", (-c[0], c[1], c[2]), dims, base, deco, twin_of=None))
        cubes.append(Cube(f"{n}_l", "head", (c[0], c[1], c[2]), dims, base, deco, mirror=True, twin_of=f"{n}_r"))

    glint = lambda f, x, y, w, h, c=None: None
    if kind == "pearl":
        pair("pearl", (EX, EY, EZ), (1.6, 1.6, 1.6), (250, 246, 240),
             lambda f, x, y, w, h: (255, 255, 255) if (x, y) == (0, 0) else (mix((250, 246, 240), (206, 206, 226), 0.5) if f == "bottom" else None))
        pair("post", (EX - 0.7, EY, EZ), (0.8, 0.6, 0.6), SILVER, None)
    elif kind == "hoop":
        g = lambda f, x, y, w, h: GOLD_L if (f == "top" and y == 0) else (GOLD_D if f == "bottom" else None)
        pair("top", (EX, 0.0, EZ), (0.6, 0.6, 3.4), GOLD, g)
        pair("bot", (EX, 3.0, EZ), (0.6, 0.6, 3.4), GOLD_D, None)
        pair("front", (EX, 1.5, EZ - 1.4), (0.6, 3.0, 0.6), GOLD, None)
        pair("back", (EX, 1.5, EZ + 1.4), (0.6, 3.0, 0.6), GOLD_D, None)
    else:
        mask_fn, col, hi, edge = (in_star, (252, 214, 84), GOLD_L, GOLD_D) if kind == "star" else (in_heart, (244, 98, 138), (255, 190, 210), (170, 40, 80))
        pair("stud", (EX, EY, EZ), (0.8, 0.8, 0.8), GOLD, None)
        pair("chain", (EX, EY + 1.5, EZ), (0.4, 2.2, 0.4), SILVER if kind == "heart" else GOLD, None)
        pair("charm", (EX, EY + 4.0, EZ), (0.6, 3.0, 3.0), col, shaped(mask_fn, col, hi, edge, edge, faces=("left", "right")))
    return build(name, cubes)


def icon_earring(name, p):
    i = Icon()
    kind = p["kind"]
    for cx in (4, 11):
        if kind == "pearl":
            blk(i, cx - 1, 5, cx + 1, 7, (250, 246, 240))
            i.put(cx - 1, 5, WHITE); i.put(cx, 8, SILVER)
        elif kind == "hoop":
            i.rect(cx - 2, 3, cx + 2, 3, GOLD); i.rect(cx - 2, 9, cx + 2, 9, GOLD_D)
            i.rect(cx - 2, 3, cx - 2, 9, GOLD); i.rect(cx + 2, 3, cx + 2, 9, GOLD_D)
        else:
            i.put(cx, 2, GOLD)
            for y in (3, 4):
                i.put(cx, y, GOLD if kind == "star" else SILVER)
            if kind == "star":
                shape = ["  X  ", "XXXXX", " XXX ", " X X ", "X   X"]
                col, edge = (252, 214, 84), GOLD_D
            else:
                shape = [" X X ", "XXXXX", "XXXXX", " XXX ", "  X  "]
                col, edge = (244, 98, 138), (170, 40, 80)
            for dy, row in enumerate(shape):
                for dx, ch in enumerate(row):
                    if ch == "X":
                        i.put(cx - 2 + dx, 5 + dy, col if dx + dy > 1 else mix(col, WHITE, 0.4))
    i.save(name)


# ====================================================================== run + registration
SETS = [("bag_", "bag", BAGS, bag, icon_bag), ("umbrella_", None, UMBRELLAS, umbrella, icon_umbrella),
        ("wings_", None, WINGS, wings, icon_wings), ("mask_", "mask", MASKS, mask, icon_mask),
        ("earring_", "earrings", EARRINGS, earring, icon_earring)]
CONST = {"bag": "BAG", "mask": "MASK", "earrings": "EARRINGS"}

DOC_MARK = "## Bags, umbrellas, wings, sleep masks and earrings"
DOC_TEXT = """
## Bags, umbrellas, wings, sleep masks and earrings
`python3 tools/gen_accessories2.py` regenerates 16 accessories and registers them (also adds the slots `BAG`, `MASK` and `EARRINGS`
to `ClothingCatalog`, so a bag, a mask and earrings can be worn together with each other and with the other jewelry).
- `bag_brown/pink/black` (slot `bag`): a bag on the left hip, a strap that crosses the chest and the back from the right shoulder
  (two flat boxes turned 36.5 degrees, plus a piece over the shoulder). Satchel with a flap and a clasp, heart purse, quilted bag on a gold chain.
- `umbrella_pink/rainbow/black` (main accessory slot): an open umbrella in the right hand, the pole leans a little outwards and back
  so the canopy floats beside the head. Each canopy layer is two boxes, one turned 45 degrees, so it looks round (like the balloons).
  Handle, hook and pole are `right_arm` cubes (`keep()` so slim arms do not squeeze them).
- `wings_angel/butterfly/bat` (main accessory slot): six feather rows per wing on the `body` bone, swept back 26 degrees around the
  root; the left wing is the mirrored twin of the right one. The tips are cut out with transparent pixels.
- `mask_pink/black/lavender` (slot `mask`): elastic band round the head and a patch over the eyes with closed lashes painted on it.
- `earring_pearl/hoop/star/heart` (slot `earrings`): on both sides of the head, below the hat layer; the charms are cut out of a flat box.
"""


def register(items):
    res = ROOT / "src/main/resources/assets/fittingroom"
    cj = json.loads((res / "clothes.json").read_text(encoding="utf-8"))
    have = {it["id"] for it in cj["items"]}
    for e in items:
        if e["id"] in have:
            continue
        item = {"id": e["id"], "category": "accessory"}
        if e["slot"]:
            item["slot"] = e["slot"]
        item.update({"name": {"ru_ru": e["ru"], "en_us": e["en"]},
                     "model": f"fittingroom:clothes_models/{e['id']}.json",
                     "texture": f"fittingroom:textures/clothes/{e['id']}.png",
                     "icon": f"fittingroom:textures/gui/clothes/{e['id']}.png"})
        cj["items"].append(item)
    (res / "clothes.json").write_text(json.dumps(cj, ensure_ascii=False) + "\n", encoding="utf-8")
    for lang, key in (("ru_ru", "ru"), ("en_us", "en")):
        path = res / f"lang/{lang}.json"
        data = json.loads(path.read_text(encoding="utf-8"))
        for e in items:
            data.setdefault(f"clothes.fittingroom.{e['id']}", e[key])
        path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    java = ROOT / "src/main/java/com/fittingroom/wardrobe/ClothingCatalog.java"
    text = java.read_text(encoding="utf-8")
    if "EARRINGS" not in text:
        old = '    public static final String WRIST = "wrist";\n'
        assert old in text
        text = text.replace(old, old + '    /** More accessory slots: a shoulder bag, a sleep mask and earrings can be worn with everything else. */\n'
                            '    public static final String BAG = "bag";\n'
                            '    public static final String MASK = "mask";\n'
                            '    public static final String EARRINGS = "earrings";\n')
        old = "                    : slot.equals(WRIST) ? 7 : 0;"
        assert old in text
        text = text.replace(old, "                    : slot.equals(WRIST) ? 7\n"
                            "                    : slot.equals(BAG) ? 4\n"
                            "                    : slot.equals(MASK) ? 8\n"
                            "                    : slot.equals(EARRINGS) ? 9 : 0;")
    close = "\n    );\n\n    private static final Map<String, Item> BY_ID"
    lines = []
    for e in items:
        if f'"{e["id"]}"' in text:
            continue
        lines.append(f'            jewel("{e["id"]}", {CONST[e["slot"]]})' if e["slot"]
                     else f'            new Item("{e["id"]}", Category.ACCESSORY)')
    if lines:
        assert close in text, "end of the item list not found"
        text = text.replace(close, ",\n" + ",\n".join(lines) + close)
    java.write_text(text, encoding="utf-8")

    prices = ROOT / "src/main/java/com/fittingroom/wardrobe/ClothingPrices.java"
    text = prices.read_text(encoding="utf-8")
    anchor = "        // ---- scarves ----\n"
    assert anchor in text, "anchor for the prices not found"
    add = "".join(f'        p("{e["id"]}", {e["price"]});\n' for e in items if f'"{e["id"]}"' not in text)
    if add:
        prices.write_text(text.replace(anchor, "        // ---- bags, umbrellas, wings, masks, earrings ----\n" + add + "\n" + anchor, 1), encoding="utf-8")

    doc = ROOT / "docs/clothes-models.md"
    text = doc.read_text(encoding="utf-8")
    if DOC_MARK not in text:
        doc.write_text(text.rstrip("\n") + "\n" + DOC_TEXT, encoding="utf-8")


if __name__ == "__main__":
    items = []
    for prefix, slot, palettes, model_fn, icon_fn in SETS:
        for key, p in palettes.items():
            name = prefix + key
            model_fn(name, p)
            icon_fn(name, p)
            items.append(dict(id=name, slot=slot, ru=p["ru"], en=p["en"], price=p["price"]))
    register(items)
    print("accessories generated:", len(items))
