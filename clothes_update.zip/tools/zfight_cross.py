#!/usr/bin/env python3
"""
Cross-garment z-fight detector and fixer. Two faces of two DIFFERENT garments that can be worn at the same time (different category /
accessory slot) flicker when they lie in the same plane, look the same way and overlap (the check inside one garment and against the
player's skin is tools/zfight.py).

The fix never touches textures or UV: the garment that is drawn on top (bottom < shoes < top < hat < accessory; the same rank: the one
whose id comes later) gets the clashing cube made a hair bigger with `grow` on the axis of the face, so that its face is MIN_GAP in
front of the other one. Running it twice changes nothing. Run it after the generators (and tools/zfight.py after it; the two tools
are repeated by `--all` until both are quiet):

    python3 tools/zfight_cross.py --check   # only report, exit code 1 if anything flickers
    python3 tools/zfight_cross.py           # fix the models in place
    python3 tools/zfight_cross.py --all     # fix with zfight.py and this tool, repeated until nothing changes
    python3 tools/zfight_cross.py --all --only=joseph_   # the same, but only for the garments whose id starts with the prefix:
                                            # old garments are never touched; where an old garment would win, the new one is made a hair smaller
"""
import json
import sys
from collections import defaultdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import zfight  # noqa: E402
from zfight import ASSETS, DETECT, MIN_AREA, MIN_GAP, MODELS, cube_box, faces, overlap  # noqa: E402

RANK = {"bottom": 0, "shoes": 1, "top": 2, "hat": 3, "accessory": 4}


SHOULDER_TOP = -2.3  # the skin arm starts at y = -2; a sleeve that starts lower lets the skin's shoulder peek out above it


def lift_sleeves(models):
    """Sleeves (arm cubes at least 4.5 wide and 3 tall, not rotated) that start below the top of the skin arm get `grow` on y until
    their top is at SHOULDER_TOP (the skin used to show on the shoulders). Returns the set of changed items."""
    changed = set()
    for name, model in models.items():
        for c in model["cubes"]:
            rot = c.get("rot")
            if c["bone"] not in ("right_arm", "left_arm") or (rot and any(abs(r) > 1e-6 for r in rot)):
                continue
            if c["size"][0] + 2 * c["grow"][0] < 4.5 or c["size"][1] < 3:
                continue
            top = c["pos"][1] - c["grow"][1]
            if SHOULDER_TOP < top < -0.5:
                c["grow"][1] = round(c["pos"][1] - SHOULDER_TOP + 0.0005, 4)
                changed.add(name)
    return changed


def load_slots():
    data = json.loads((ASSETS / "clothes.json").read_text(encoding="utf-8"))
    return {it["id"]: (it["category"], it.get("slot") if it["category"] == "accessory" else None) for it in data["items"]}


def find(models, slots, slim):
    """Return {(item, cube_index, axis): needed_extra_grow} and a set of readable clashes."""
    buckets = defaultdict(list)
    for name, model in models.items():
        for idx, c in enumerate(model["cubes"]):
            box = cube_box(c, slim)
            if box is None:
                continue
            for axis, sign, plane, ru, rv in faces(box):
                buckets[(c["bone"], axis, sign, round(plane / DETECT))].append((name, idx, plane, ru, rv))
    needs, texts = {}, set()
    unders = {}                                                 # winner key -> {(loser item, loser cube index)}
    for (bone, axis, sign, k), lst in buckets.items():
        near = list(lst)
        for dk in (-1, 1):
            near += buckets.get((bone, axis, sign, k + dk), [])
        for a in lst:
            for b in near:
                if a[0] >= b[0] or slots[a[0]] == slots[b[0]]:
                    continue
                if abs(a[2] - b[2]) >= DETECT or overlap(a[3], b[3]) * overlap(a[4], b[4]) <= MIN_AREA:
                    continue
                ra, rb = RANK[slots[a[0]][0]], RANK[slots[b[0]][0]]
                top, under = (a, b) if (ra, a[0]) > (rb, b[0]) else (b, a)
                need = MIN_GAP - (top[2] - under[2]) * sign
                key = (top[0], top[1], axis)
                needs[key] = max(needs.get(key, 0.0), need)
                unders.setdefault(key, set()).add((under[0], under[1]))
                texts.add(f"{a[0]} + {b[0]} ({models[a[0]]['cubes'][a[1]]['name']}/{models[b[0]]['cubes'][b[1]]['name']} on {bone} {'xyz'[axis]})")
    find.unders = unders
    return needs, texts


def run(fix, only=None):
    slots = load_slots()
    models = {p.stem: json.loads(p.read_text()) for p in sorted(MODELS.glob("*.json")) if p.stem in slots}
    changed, found = set(), set()
    shrunk = set()                                              # --only: every cube is made smaller at most once per axis, so the tool always ends
    if fix:
        lifted = lift_sleeves(models)
        changed |= {i for i in lifted if not only or i.startswith(only)}
    for _ in range(30):
        any_change = False
        for slim in (False, True):
            needs, texts = find(models, slots, slim)
            if only:                                            # report only clashes that involve the garments of this prefix
                texts = {t for t in texts if any(part.startswith(only) for part in t.split(" (")[0].split(" + "))}
            found |= texts
            for (item, idx, axis), need in needs.items():
                if need <= 0 or not fix:
                    continue
                if not only or item.startswith(only):
                    cube = models[item]["cubes"][idx]
                    cube["grow"][axis] = round(cube["grow"][axis] + need + 0.0005, 4)         # the garment on top grows
                    changed.add(item)
                    any_change = True
                else:                                           # an old garment wins: it stays untouched, the new one gets a hair smaller
                    for uitem, uidx in find.unders.get((item, idx, axis), ()):
                        if uitem.startswith(only) and (uitem, uidx, axis) not in shrunk:
                            shrunk.add((uitem, uidx, axis))
                            cube = models[uitem]["cubes"][uidx]
                            cube["grow"][axis] = round(cube["grow"][axis] - need - 0.0005, 4)
                            changed.add(uitem)
                            any_change = True
        if not any_change:
            break
    if fix:
        for item in changed:
            (MODELS / f"{item}.json").write_text(json.dumps(models[item], indent=1) + "\n")
    return found, changed


def main():
    only = next((a.split("=", 1)[1] for a in sys.argv if a.startswith("--only=")), None)
    if "--all" in sys.argv:
        for _ in range(10):
            fixed = 0
            for path in sorted(MODELS.glob("*.json")):
                if only and not path.stem.startswith(only):
                    continue
                model = json.loads(path.read_text())
                if zfight.fix_model(model):
                    path.write_text(json.dumps(model, indent=1) + "\n")
                    fixed += 1
            _, changed = run(True, only)
            print(f"round: {fixed} model(s) fixed inside, {len(changed)} across garments")
            if not fixed and not changed:
                break
        found, _ = run(False, only)
        print("clean" if not found else f"{len(found)} clash(es) left")
        sys.exit(1 if found else 0)
    check = "--check" in sys.argv
    found, changed = run(not check, only)
    if check:
        for t in sorted(found)[:60]:
            print(t)
        print("no cross-garment flicker" if not found else f"{len(found)} clash(es)")
        sys.exit(1 if found else 0)
    print(f"fixed {len(changed)} model(s)")


if __name__ == "__main__":
    main()
