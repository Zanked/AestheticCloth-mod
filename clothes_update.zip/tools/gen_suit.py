#!/usr/bin/env python3
"""
Generates a three-piece "dandy" suit set of the fitting room in two colours (blue and white):

    suit_<colour>_jacket  (top)      open single-breasted jacket with painted notch lapels, two gold buttons, pocket flaps,
                                     three gold buttons on each cuff, a centre back seam, and a green striped button-down
                                     shirt underneath (the shirt is part of the top: only one top can be worn at a time)
    suit_<colour>_pants   (bottom)   straight trousers with a pressed crease, a black belt and a silver buckle
    tie_skull             (accessory, own slot "tie")   dark purple tie with a gold diamond lattice and skulls

The tie lives in its own slot, so it can be worn with a backpack, glasses, jewelry etc. (one tie at a time).
Colours are the PALETTES dict below: a new colour is one more entry plus the items in the lang files.

Run from the project root:  python3 tools/gen_suit.py            (models, textures, icons, registration)
                            python3 tools/gen_suit.py --preview   (also writes front-view previews to /tmp/suit_preview)
Same smooth painter as gen_dino.py / gen_school_boy.py.
"""
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from gen_dino import blk, build, grad, mix  # noqa: E402
from gen_accessories import ASSETS, PX, Cube, Icon, shade  # noqa: E402
from gen_outerwear import arm_pair, leg_pair, sd  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent

GOLD = (238, 200, 94)
GOLD_D = (180, 136, 54)
SILVER = (206, 210, 224)
BELT = (24, 24, 30)

# shirt: green with thin white stripes (as on the reference picture)
SHIRT = (150, 214, 120)
SHIRT_D = (104, 172, 92)
SHIRT_W = (244, 252, 238)

# tie: violet with a navy diamond lattice, tan outlines and skulls
T_BG = (98, 66, 152)
T_NAVY = (40, 30, 88)
T_TAN = (222, 182, 120)
T_SKULL = (240, 206, 150)

PALETTES = {
    "blue": dict(base=(112, 172, 234), light=(158, 204, 250), dark=(72, 124, 188), lapel=(134, 190, 244),
                 ru_jacket="Голубой пиджак с рубашкой", en_jacket="Blue Suit Jacket & Shirt",
                 ru_pants="Голубые брюки", en_pants="Blue Suit Trousers",
                 ru_look="Голубой костюм", en_look="Blue Suit"),
    "white": dict(base=(238, 238, 246), light=(255, 255, 255), dark=(192, 194, 210), lapel=(250, 250, 255),
                  ru_jacket="Белый пиджак с рубашкой", en_jacket="White Suit Jacket & Shirt",
                  ru_pants="Белые брюки", en_pants="White Suit Trousers",
                  ru_look="Белый костюм", en_look="White Suit"),
}


# ====================================================================== JACKET + SHIRT
def shirt_deco(f, x, y, w, h):
    if not sd(f):
        return SHIRT_D
    col = mix(SHIRT, SHIRT_D, y / max(1, h - 1) * 0.55)  # the green gets darker towards the belt
    return SHIRT_W if x % 4 == 1 else col


def shirt_collar_deco(f, x, y, w, h):
    if not sd(f):
        return mix(SHIRT, SHIRT_W, 0.3)
    if y == h - 1:
        return SHIRT_D
    return SHIRT_W if x % 4 == 1 else mix(SHIRT, SHIRT_W, 0.2)


def back_deco(p):
    def d(f, x, y, w, h):
        if f == "back":
            if x in (w // 2 - 1, w // 2):
                return mix(p["base"], p["dark"], 0.55)  # centre seam
            if y > h - 9 and x in (w // 2 + 1, w // 2 - 2):
                return mix(p["base"], p["dark"], 0.25)  # vent
            if y == h - 1:
                return mix(p["base"], p["dark"], 0.5)
        return None
    return d


def panel_deco(p, side):
    """Front panel of the jacket. side 'r' = wearer's right (seen on the left), 'l' = wearer's left.
    Pixel 0 of the front face is the viewer's left, so the inner (opening) edge is x = w-1 for 'r' and x = 0 for 'l'."""
    base, dark, lapel = p["base"], p["dark"], p["lapel"]

    def d(f, x, y, w, h):
        if not sd(f):
            return None
        if f != "front":
            return None
        di = (w - 1 - x) if side == "r" else x   # distance from the inner edge
        do = w - 1 - di                           # distance from the outer edge
        if y == h - 1:
            return mix(base, dark, 0.5)           # hem
        # --- notch lapel: wide at the shoulder, narrowing down to the first button
        lw = round(w - 1 - 0.30 * y) if y < 17 else 0
        if y < 17 and di < lw:
            if y in (6, 7) and lw - 4 <= di < lw - 1:
                return mix(base, dark, 0.7)       # the notch between collar and lapel
            if di == lw - 1 or y == 0:
                return mix(lapel, dark, 0.45)     # lapel edge
            return lapel
        if di == 0:
            return mix(base, dark, 0.6)           # front edge of the opening
        # --- buttons on the right panel, buttonholes on the left one
        for by in (17, 23):
            if side == "r" and by <= y <= by + 1 and 1 <= di <= 2:
                return mix(GOLD, (255, 255, 255), 0.45) if (di, y) == (2, by) else (GOLD_D if y == by + 1 else GOLD)
            if side == "l" and y == by and 1 <= di <= 3:
                return mix(base, dark, 0.75)
        # --- pocket flaps on the hips, a welt pocket on the left breast
        if 19 <= y <= 21 and 1 <= do <= w - 3:
            return mix(base, dark, 0.65) if y == 21 else mix(base, p["light"], 0.12) if y == 19 else base
        if side == "l" and y in (10, 11) and 1 <= do <= 4:
            return mix(base, dark, 0.7) if y == 10 else mix(base, p["light"], 0.3)
        return None
    return d


def sleeve_deco(p):
    base, dark = p["base"], p["dark"]

    def d(f, x, y, w, h):
        if not sd(f):
            return None
        if y == h - 1:
            return mix(base, dark, 0.5)
        if y == h - 13:
            return mix(base, dark, 0.3)          # cuff seam
        if f in ("right", "left"):
            for k in range(3):                    # three gold buttons on each cuff
                by = h - 11 + k * 3
                if by <= y <= by + 1 and w // 2 - 1 <= x <= w // 2:
                    return mix(GOLD, (255, 255, 255), 0.45) if (x, y) == (w // 2 - 1, by) else (GOLD_D if y == by + 1 else GOLD)
        return None
    return d


def jacket(key, p):
    cubes = [
        Cube("shirt", "body", (0, 6.1, 0), (9.0, 12.2, 5.2), SHIRT, shirt_deco),
        Cube("shirt_collar", "body", (0, -0.2, 0), (8.6, 1.8, 4.8), SHIRT, shirt_collar_deco),
        Cube("back", "body", (0, 6.2, 1.1), (9.9, 13.2, 3.7), p["base"], back_deco(p)),
        Cube("panel_r", "body", (-3.25, 6.2, -1.85), (3.4, 13.2, 2.2), p["base"], panel_deco(p, "r")),
        Cube("panel_l", "body", (3.25, 6.2, -1.85), (3.4, 13.2, 2.2), p["base"], panel_deco(p, "l")),
        Cube("collar", "body", (0, -0.3, 1.0), (10.3, 1.8, 4.5), p["lapel"],
             lambda f, x, y, w, h: mix(p["lapel"], p["dark"], 0.35) if (sd(f) and y == h - 1) else None),
    ]
    arm_pair(cubes, "sleeve", 4.0, (5.5, 12.6, 5.5), p["base"], sleeve_deco(p))
    return build(f"suit_{key}_jacket", cubes)


# ====================================================================== TROUSERS
def waist_deco(p):
    def d(f, x, y, w, h):
        if f == "front" and x in (w // 2 - 1, w // 2) and y > 5:
            return mix(p["base"], p["dark"], 0.45)    # fly
        if f == "front" and y == 0:
            return mix(p["base"], p["dark"], 0.6)
        return None
    return d


def belt_deco(f, x, y, w, h):
    if f == "front" and w // 2 - 2 <= x <= w // 2 + 1 and 1 <= y <= h - 2:
        return SILVER if x not in (w // 2 - 2, w // 2 + 1) else mix(SILVER, BELT, 0.5)
    return None


def pants(key, p):
    base, dark, light = p["base"], p["dark"], p["light"]

    def leg(f, x, y, w, h):
        if f in ("top", "bottom"):
            return None
        col = mix(light, base, min(1.0, y / max(1, h - 1) * 0.9))
        if f in ("front", "back") and x == w // 2 - 1:
            return mix(col, dark, 0.5)                # pressed crease
        if f in ("front", "back") and y == h - 1:
            return mix(col, dark, 0.35)               # hem
        return col

    cubes = [
        Cube("waist", "body", (0, 11.4, 0), (9.5, 3.2, 5.5), base, waist_deco(p)),
        Cube("belt", "body", (0, 10.9, 0), (9.7, 0.9, 5.7), BELT, belt_deco),
    ]
    leg_pair(cubes, "leg", 5.6, (4.8, 11.8, 4.8), base, leg)
    return build(f"suit_{key}_pants", cubes)


# ====================================================================== SKULL TIE
SKULL = ["TTTT",
         "TDDT",
         ".TT."]
PERIOD = 6


def tie_px(u, gy):
    """Colour of the tie at column u (0 = just right of the centre line) and row gy (from the top of the blade)."""
    cell = gy % PERIOD
    uc = u + 0.5
    m = abs(uc) / 3.0 + abs(cell - 2.5) / 3.0
    sx, sy = u + 2, cell - 1                      # skull is 4 wide, 3 tall, rows 1..3 of the cell
    if 0 <= sx < 4 and 0 <= sy < len(SKULL):
        ch = SKULL[sy][sx]
        if ch == "T":
            return T_SKULL
        if ch == "D":
            return T_NAVY
    if m < 1.0:
        return T_NAVY
    if m < 1.25:
        return mix(T_TAN, T_NAVY, 0.4)
    return T_BG


TIE_SEGS = [  # name, top y, bottom y, width (units); the blade is nearly straight and gets a little wider downwards
    ("s0", 2.0, 4.0, 1.8),
    ("s1", 4.0, 6.0, 2.2),
    ("s2", 6.0, 8.0, 2.5),
    ("s3", 8.0, 9.6, 2.7),
]
TIP = ("tip", 9.6, 11.2, 2.7)
TZ = -3.05  # in front of the shirt and of the jacket panels, but behind the gold buttons' plane of thick tops


def tie_deco(y0, tip=False):
    gy0 = int(round((y0 - 2.0) * PX))

    def d(f, x, y, w, h):
        if f in ("front", "back"):
            u = x - w // 2
            if tip:
                half = max(1.0, (w / 2.0) * (1.0 - y / float(h)) + 0.4)
                if abs(x + 0.5 - w / 2.0) > half:
                    return "clear"
            return tie_px(u, gy0 + y)
        if tip:
            return "clear"
        return T_NAVY
    return d


def knot_deco(f, x, y, w, h):
    if f == "front":
        return mix(T_NAVY, T_BG, 0.45) if y < 2 else (mix(T_NAVY, T_BG, 0.2) if x % 4 in (1, 2) else T_NAVY)
    return T_NAVY


def tie():
    cubes = [Cube("knot", "body", (0, 1.5, TZ - 0.05), (2.2, 1.3, 0.9), T_NAVY, knot_deco)]
    for name, y0, y1, w in TIE_SEGS:
        cubes.append(Cube(name, "body", (0, (y0 + y1) / 2, TZ), (w, y1 - y0, 0.5), T_NAVY, tie_deco(y0)))
    name, y0, y1, w = TIP
    cubes.append(Cube(name, "body", (0, (y0 + y1) / 2, TZ), (w, y1 - y0, 0.5), T_NAVY, tie_deco(y0, tip=True)))
    return build("tie_skull", cubes)


# ====================================================================== ICONS
def icon_jacket(key, p):
    base, dark, lap = p["base"], p["dark"], p["lapel"]
    i = Icon()
    blk(i, 1, 4, 3, 13, base)
    blk(i, 12, 4, 14, 13, base)
    i.rect(1, 11, 3, 11, dark); i.rect(12, 11, 14, 11, dark)
    i.put(2, 9, GOLD); i.put(13, 9, GOLD)
    blk(i, 4, 3, 5, 14, base)
    blk(i, 10, 3, 11, 14, base)
    for y in range(3, 14):                       # green striped shirt between the panels
        for x in (6, 7, 8, 9):
            i.put(x, y, SHIRT_W if x == 7 else (SHIRT if y < 9 else SHIRT_D))
    for k in range(4):                           # lapels
        i.put(5 - (k // 3), 3 + k, lap); i.put(10 + (k // 3), 3 + k, lap)
    i.rect(4, 3, 5, 3, lap); i.rect(10, 3, 11, 3, lap)
    i.put(5, 5, mix(lap, dark, 0.5)); i.put(10, 5, mix(lap, dark, 0.5))
    i.put(5, 9, GOLD); i.put(5, 12, GOLD)        # buttons
    i.rect(6, 13, 9, 14, BELT); i.put(7, 14, SILVER)
    i.save(f"suit_{key}_jacket")


def icon_pants(key, p):
    base, dark, light = p["base"], p["dark"], p["light"]
    i = Icon()
    blk(i, 3, 2, 12, 4, base)
    i.rect(3, 3, 12, 3, BELT); i.rect(7, 3, 8, 3, SILVER)
    blk(i, 3, 5, 7, 14, base)
    blk(i, 8, 5, 12, 14, base)
    i.rect(5, 6, 5, 14, light); i.rect(10, 6, 10, 14, light)
    i.rect(7, 5, 8, 14, dark)
    i.save(f"suit_{key}_pants")


def icon_tie():
    i = Icon()
    i.rect(6, 1, 9, 3, T_NAVY)                    # knot
    i.rect(6, 1, 9, 1, mix(T_NAVY, T_BG, 0.5))
    i.rect(5, 4, 10, 11, T_BG)
    i.rect(6, 4, 9, 11, T_NAVY)
    i.rect(5, 4, 5, 11, mix(T_BG, (255, 255, 255), 0.15))
    i.rect(10, 4, 10, 11, mix(T_BG, (0, 0, 0), 0.2))
    i.rect(7, 12, 8, 13, T_NAVY)
    i.put(5, 12, T_BG); i.put(10, 12, T_BG)
    i.rect(6, 12, 9, 12, T_NAVY)
    for y in (5, 9):                              # skulls
        i.rect(6, y, 9, y, T_SKULL)
        i.rect(6, y + 1, 9, y + 1, T_SKULL)
        i.put(7, y + 1, T_NAVY); i.put(8, y + 1, T_NAVY)
    i.put(7, 7, T_SKULL); i.put(8, 7, T_SKULL)
    i.put(7, 11, T_TAN); i.put(8, 11, T_TAN)
    i.save("tie_skull")


# ====================================================================== REGISTRATION
PRICE = {"jacket": 12999, "pants": 5999, "tie": 1999}


def entries():
    out = []
    for key, p in PALETTES.items():
        out.append(dict(id=f"suit_{key}_jacket", category="top", slot=None, ru=p["ru_jacket"], en=p["en_jacket"],
                        price=PRICE["jacket"], build=lambda k=key, p=p: jacket(k, p), icon=lambda k=key, p=p: icon_jacket(k, p)))
        out.append(dict(id=f"suit_{key}_pants", category="bottom", slot=None, ru=p["ru_pants"], en=p["en_pants"],
                        price=PRICE["pants"], build=lambda k=key, p=p: pants(k, p), icon=lambda k=key, p=p: icon_pants(k, p)))
    out.append(dict(id="tie_skull", category="accessory", slot="tie", ru="Галстук с черепами", en="Skull Tie",
                    price=PRICE["tie"], build=tie, icon=icon_tie))
    return out


CATEGORY = {"top": "TOP", "bottom": "BOTTOM", "accessory": "ACCESSORY"}
DOC_MARK = "## Suits and the skull tie"
DOC_TEXT = """
## Suits and the skull tie
`python3 tools/gen_suit.py` regenerates the models, textures, icons and (idempotently) the entries in `clothes.json`, the lang files,
`ClothingCatalog`, `ClothingPrices` and `Looks`. Two colours, blue and white (`PALETTES` at the top of the script).
- `suit_<colour>_jacket` (top): an open single-breasted jacket on the `body` bone. It is built of a back piece and two front panels with
  a gap between them, and the green striped button-down shirt (`shirt` + `shirt_collar`) shows in that gap, so the shirt is part of the top
  (only one top can be worn at a time). The notch lapels, two gold buttons / buttonholes, pocket flaps and the welt pocket are painted into
  the panel textures; the sleeves carry three gold buttons on each cuff.
- `suit_<colour>_pants` (bottom): straight trousers with a fly, a pressed crease, a black belt and a silver buckle. The belt shows through
  the gap of the jacket. Shoes are not part of the set (`boy_shoes` or any other go with it).
- `tie_skull` (accessory in its own slot `tie`, `ClothingCatalog.TIE`): violet tie with a navy diamond lattice, tan outlines and skulls.
  A knot and a blade made of four stacked boxes that get wider downwards, plus a pointed tip: the tip is cut out of the texture with
  transparent pixels. It sits in the gap of the jacket in front of the shirt (z = -3.05), so it also goes over other tops.
- Looks `suit_blue` and `suit_white` (jacket, trousers, tie, black shoes) are in `Looks.java`.
"""


def register(items):
    res = ROOT / "src/main/resources/assets/fittingroom"
    cj = json.loads((res / "clothes.json").read_text(encoding="utf-8"))
    have = {it["id"] for it in cj["items"]}
    for e in items:
        if e["id"] in have:
            continue
        item = {"id": e["id"], "category": e["category"]}
        if e["slot"]:
            item["slot"] = e["slot"]
        item.update({"name": {"ru_ru": e["ru"], "en_us": e["en"]},
                     "model": f"fittingroom:clothes_models/{e['id']}.json",
                     "texture": f"fittingroom:textures/clothes/{e['id']}.png",
                     "icon": f"fittingroom:textures/gui/clothes/{e['id']}.png"})
        cj["items"].append(item)
    (res / "clothes.json").write_text(json.dumps(cj, ensure_ascii=False) + "\n", encoding="utf-8")

    look_names = {}
    for key, p in PALETTES.items():
        look_names[f"look.fittingroom.suit_{key}"] = (p["ru_look"], p["en_look"])
    for lang, idx, key in (("ru_ru", 0, "ru"), ("en_us", 1, "en")):
        path = res / f"lang/{lang}.json"
        data = json.loads(path.read_text(encoding="utf-8"))
        for e in items:
            data.setdefault(f"clothes.fittingroom.{e['id']}", e[key])
        for k, names in look_names.items():
            data.setdefault(k, names[idx])
        path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    java = ROOT / "src/main/java/com/fittingroom/wardrobe/ClothingCatalog.java"
    text = java.read_text(encoding="utf-8")
    if "String TIE" not in text:
        old = '    public static final String EARRINGS = "earrings";\n'
        assert old in text, "EARRINGS constant not found"
        text = text.replace(old, old + '    /** A tie: worn together with the other accessories (one tie at a time). */\n'
                            '    public static final String TIE = "tie";\n')
        old = "slot.equals(CHOKER) || slot.equals(NECKLACE) ? 6"
        assert old in text, "render order of the jewelry not found"
        text = text.replace(old, "slot.equals(CHOKER) || slot.equals(NECKLACE) || slot.equals(TIE) ? 6")
    close = "\n    );\n\n    private static final Map<String, Item> BY_ID"
    lines = []
    for e in items:
        if f'"{e["id"]}"' in text:
            continue
        if e["slot"]:
            lines.append(f'            jewel("{e["id"]}", {e["slot"].upper()})')
        else:
            lines.append(f'            new Item("{e["id"]}", Category.{CATEGORY[e["category"]]})')
    if lines:
        assert close in text, "end of the item list not found"
        text = text.replace(close, ",\n" + ",\n".join(lines) + close)
    java.write_text(text, encoding="utf-8")

    prices = ROOT / "src/main/java/com/fittingroom/wardrobe/ClothingPrices.java"
    text = prices.read_text(encoding="utf-8")
    anchor = "        // ---- scarves ----\n"
    assert anchor in text, "anchor for the prices not found"
    add = "".join(f'        p("{e["id"]}", {e["price"]});\n' for e in items if f'"{e["id"]}"' not in text)
    if add:
        prices.write_text(text.replace(anchor, "        // ---- suits (blue and white cost the same) and the skull tie ----\n" + add + "\n" + anchor, 1),
                          encoding="utf-8")

    looks = ROOT / "src/main/java/com/fittingroom/wardrobe/Looks.java"
    text = looks.read_text(encoding="utf-8")
    start = text.index("public static final List<Look> ALL = List.of(")
    end = text.index("\n    );", start)
    add = ""
    for key in PALETTES:
        if f'"suit_{key}"' not in text:
            add += (f',\n            new Look("suit_{key}", List.of("suit_{key}_jacket", "suit_{key}_pants", '
                    f'"tie_skull", "boy_shoes"))')
    if add:
        looks.write_text(text[:end] + add + text[end:], encoding="utf-8")

    doc = ROOT / "docs/clothes-models.md"
    text = doc.read_text(encoding="utf-8")
    if DOC_MARK not in text:
        doc.write_text(text.rstrip("\n") + "\n" + DOC_TEXT, encoding="utf-8")


# ====================================================================== front-view preview (no game needed)
def preview(items):
    from PIL import Image, ImageDraw
    out = Path("/tmp/suit_preview")
    out.mkdir(parents=True, exist_ok=True)
    S = 16
    pivots = {"body": (0, 0), "head": (0, 0), "right_arm": (-5, 2), "left_arm": (5, 2),
              "right_leg": (-1.9, 12), "left_leg": (1.9, 12)}

    def render(ids, name):
        W, H = 26 * S, 36 * S
        img = Image.new("RGBA", (W, H), (60, 62, 74, 255))
        dr = ImageDraw.Draw(img)

        def X(v):
            return int(round((v + 13) * S))

        def Y(v):
            return int(round((v + 9) * S))
        skin, shirt, pant = (226, 178, 140), (120, 120, 130), (70, 70, 120)
        for (x0, y0, x1, y1, c) in ((-4, -8, 4, 0, skin), (-4, 0, 4, 12, shirt), (-8, 0, -4, 12, skin), (4, 0, 8, 12, skin),
                                    (-3.9, 12, 0, 24, pant), (0, 12, 3.9, 24, pant)):
            dr.rectangle([X(x0), Y(y0), X(x1), Y(y1)], fill=c)
        cubes = []
        for i in ids:
            m = json.loads((ASSETS / f"clothes_models/{i}.json").read_text())
            tex = Image.open(ASSETS / f"textures/clothes/{i}.png").convert("RGBA")
            for c in m["cubes"]:
                cubes.append((c, tex))

        def zf(ct):
            c = ct[0]
            return c["pos"][2] - c["grow"][2]
        cubes.sort(key=zf, reverse=True)
        for c, tex in cubes:
            px, py = pivots[c["bone"]]
            w, h, d = c["size"]
            g = c["grow"]
            x0 = px + c["pos"][0] - g[0]
            y0 = py + c["pos"][1] - g[1]
            x1 = px + c["pos"][0] + w + g[0]
            y1 = py + c["pos"][1] + h + g[1]
            u, v = c["uv"]
            face = tex.crop(((u + d) * PX, (v + d) * PX, (u + d + w) * PX, (v + d + h) * PX))
            if c.get("mirror"):
                face = face.transpose(Image.FLIP_LEFT_RIGHT)
            tw_, th_ = max(1, X(x1) - X(x0)), max(1, Y(y1) - Y(y0))
            face = face.resize((tw_, th_), Image.NEAREST)
            img.alpha_composite(face, (X(x0), Y(y0)))
        img.convert("RGB").save(out / f"{name}.png")

    for key in PALETTES:
        render([f"suit_{key}_jacket", f"suit_{key}_pants", "tie_skull"], f"suit_{key}_front")
    render(["tie_skull"], "tie_only")
    print("previews in", out)


if __name__ == "__main__":
    items = entries()
    for e in items:
        e["build"]()
        e["icon"]()
    register(items)
    print("suits generated:", ", ".join(e["id"] for e in items))
    if "--preview" in sys.argv:
        preview(items)
