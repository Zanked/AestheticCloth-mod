#!/usr/bin/env python3
"""
Generates the textures of the seller NPC and of the seller contract item.

    textures/entity/seller_0.png  mint apron, brown bob, pink bow
    textures/entity/seller_1.png  pink apron, black hair with long back, ribbon
    textures/entity/seller_2.png  lilac apron, blond hair with a side tail, flower pin
    textures/item/seller_contract.png

Skins are 128x128 (the vanilla 64x64 layout at 2 px per unit, like the garments and the mannequin).
Run from the project root:  python3 tools/gen_seller.py
"""
import math
import sys
from pathlib import Path

from PIL import Image, ImageDraw

sys.path.insert(0, str(Path(__file__).resolve().parent))
from gen_showcase import GOLD, GOLD_D, GOLD_L, GOLD_LL, clamp, light, mix, noise, paint_box, S  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent
ASSETS = ROOT / "src/main/resources/assets/fittingroom/textures"

SKIN = (255, 226, 207)
SKIN_L = (255, 240, 227)
SKIN_D = (234, 190, 170)
CREAM = (255, 249, 238)
CREAM_D = (230, 218, 200)
BLUSH = (255, 178, 184)
LIP = (214, 106, 118)
LASH = (74, 48, 58)
WHITE = (255, 255, 255)

VARIANTS = [
    dict(name="mint", hair=(112, 74, 56), hair_l=(150, 104, 78), hair_d=(84, 54, 42), eye=(94, 150, 120),
         apron=(151, 197, 187), apron_l=(178, 218, 207), apron_d=(120, 170, 160), trim=(246, 170, 184),
         hair_style="bob", accent=(246, 170, 184)),
    dict(name="pink", hair=(52, 40, 52), hair_l=(88, 70, 88), hair_d=(34, 26, 36), eye=(120, 92, 150),
         apron=(246, 186, 200), apron_l=(252, 210, 220), apron_d=(222, 150, 170), trim=(255, 249, 238),
         hair_style="long", accent=(151, 197, 187)),
    dict(name="lilac", hair=(244, 208, 120), hair_l=(255, 232, 160), hair_d=(214, 170, 84), eye=(100, 150, 200),
         apron=(206, 190, 236), apron_l=(228, 216, 250), apron_d=(176, 158, 214), trim=(255, 233, 157),
         hair_style="tail", accent=(255, 255, 255)),
]


def shade(c, name, x, y, W, H, seed, strength=0.07):
    u = (x + 0.5) / W * 2 - 1
    if name in ("front", "back"):
        f = 1.0 - strength * u * u
    elif name in ("left", "right"):
        f = 0.94 + 0.03 * (1 - abs(u))
    elif name == "top":
        f = 1.03
    else:
        f = 0.82
    return light(light(c, f), 1 + noise(x, y, seed) * 0.012)


# ---------------------------------------------------------------- head
def hair_depth_front(x, style):
    """How many pixel rows of the 16x16 front are covered by hair at column x."""
    if x in (0, 1, 14, 15):
        return 10                                    # side locks
    if x in (2, 13):
        return 6
    if x in (7, 8):
        return 3                                     # parting
    return 4 + (1 if x % 4 in (3, 0) else 0)


def hair_pixel(v, x, y, seed):
    c = v["hair"]
    if (x * 3 + y * 2) % 7 == 0:
        c = v["hair_l"]
    elif (x + y * 3) % 9 == 0:
        c = v["hair_d"]
    return light(c, 1 + noise(x, y, seed) * 0.03)


def head_painter(v, overlay):
    style = v["hair_style"]

    def paint(name, x, y, W, H):
        seed = 3
        if overlay:
            # hat layer: only hair, a bit bigger than the head
            if name == "top":
                return hair_pixel(v, x, y, seed)
            if name == "front":
                return hair_pixel(v, x, y, seed) if y < hair_depth_front(x, style) - 1 and y < 4 else None
            if name in ("left", "right"):
                limit = 9 if style == "bob" else 11
                return hair_pixel(v, x, y, seed) if y < limit and x > 3 else None
            if name == "back":
                limit = {"bob": 11, "long": 16, "tail": 12}[style]
                return hair_pixel(v, x, y, seed) if y < limit else None
            return None
        base = shade(SKIN, name, x, y, W, H, seed)
        if name == "front":
            return head_front(v, x, y, base)
        if name in ("left", "right"):
            return head_side(v, name, x, y, base)
        if name == "back":
            limit = {"bob": 10, "long": 16, "tail": 11}[style]
            return hair_pixel(v, x, y, seed) if y < limit else base
        if name == "top":
            if x in (7, 8) and False:
                return v["hair_d"]
            return hair_pixel(v, x, y, seed)
        return base
    return paint


def head_front(v, x, y, base):
    style = v["hair_style"]
    if y < hair_depth_front(x, style):
        return hair_pixel(v, x, y, 5)
    c = base
    # blush
    for cx in (2.5, 13.5):
        d = math.hypot(x - cx, y - 11.5)
        if d < 2.2:
            c = mix(c, BLUSH, (1 - d / 2.2) * 0.7)
    # eyes: x 3..5 and 10..12, rows 8..10
    for x0 in (3, 10):
        if x0 <= x <= x0 + 2:
            dx = x - x0
            if y == 7:
                return LASH if dx != 1 or True else c
            if y == 8:
                return WHITE if dx == 0 else mix(v["eye"], (40, 30, 50), 0.35)
            if y == 9:
                return mix(v["eye"], WHITE, 0.15) if dx != 0 else WHITE
            if y == 10:
                return mix(v["eye"], (255, 255, 255), 0.4) if dx == 1 else mix(v["eye"], (40, 30, 50), 0.2)
    # little highlight in each eye
    # brows
    if y == 6 and (3 <= x <= 5 or 10 <= x <= 12):
        return mix(v["hair_d"], SKIN, 0.2)
    # nose
    if y == 11 and x == 8:
        return mix(c, SKIN_D, 0.7)
    # mouth: a small smile
    if y == 13 and x in (7, 8):
        return LIP
    if y == 12 and x in (6, 9):
        return mix(c, LIP, 0.55)
    if y == 14 and x in (7, 8):
        return mix(c, LIP, 0.35)
    return c


def head_side(v, name, x, y, base):
    style = v["hair_style"]
    front_edge = x >= 12 if name == "right" else x <= 3   # the front of the head, next to the face
    hair_rows = 11 if style == "bob" else 14
    if y < 6:
        return hair_pixel(v, x, y, 7)
    if (not front_edge) and y < hair_rows:
        return hair_pixel(v, x, y, 7)
    # ear
    if 6 <= x <= 9 and 8 <= y <= 11 and style == "bob":
        return mix(base, SKIN_D, 0.35)
    return base


# ---------------------------------------------------------------- body
def apron_edge(c1, c2):
    return c1 if True else c2


def body_painter(v, overlay):
    apron, apron_l, apron_d, trim = v["apron"], v["apron_l"], v["apron_d"], v["trim"]

    def blouse(name, x, y, W, H):
        return shade(CREAM, name, x, y, W, H, 11)

    def paint(name, x, y, W, H):
        if overlay:
            # jacket layer = the flared skirt of the apron, rows 14..23 (the lower 5 units of the torso)
            if y < 14 or name in ("top", "bottom"):
                return None
            c = shade(apron, name, x, y, W, H, 12)
            if (x + y) % 5 == 0:
                c = light(c, 1.04)
            if y >= 22:                                      # scalloped hem
                return trim if (x // 2 + y) % 2 == 0 else mix(trim, c, 0.35)
            if y == 14:
                return apron_d
            return c
        if name in ("top", "bottom"):
            return shade(CREAM, name, x, y, W, H, 11)
        if name == "front":
            return body_front(v, x, y, W, H, blouse(name, x, y, W, H))
        if name == "back":
            return body_back(v, x, y, W, H, blouse(name, x, y, W, H))
        # sides: blouse with the edge of the apron
        c = blouse(name, x, y, W, H)
        if y >= 8:
            c = shade(apron, name, x, y, W, H, 13)
        return c
    return paint


def body_front(v, x, y, W, H, base):
    apron, apron_l, apron_d, trim, accent = v["apron"], v["apron_l"], v["apron_d"], v["trim"], v["accent"]
    # collar and bow tie
    if y <= 2 and (x < 5 or x > 10):
        return mix(CREAM, CREAM_D, 0.25) if y == 2 else base
    # bow tie (x 5..10, y 2..5)
    if 5 <= x <= 10 and 2 <= y <= 5:
        if x in (7, 8):
            return GOLD if y in (3, 4) else accent
        return accent if (x + y) % 2 == 0 else mix(accent, WHITE, 0.3)
    # apron straps from the shoulders
    if y <= 7 and (x in (4, 5) or x in (10, 11)):
        return apron_l if x in (4, 10) else apron
    # bib
    if 6 <= y <= 9 and 4 <= x <= 11:
        if y == 6 or x in (4, 11):
            return trim
        c = apron_l if (x + y) % 2 == 0 else apron
        # gold name badge with a tiny heart
        if (x, y) in ((5, 7), (6, 7)):
            return GOLD_L if (x, y) == (5, 7) else GOLD
        if (x, y) == (5, 8) or (x, y) == (6, 8):
            return GOLD_D if (x, y) == (6, 8) else GOLD
        return c
    # apron body
    if y >= 10 and 3 <= x <= 12:
        if x in (3, 12):
            return trim
        c = apron if (x // 2 + y // 2) % 2 == 0 else apron_l
        c = light(c, 1 - 0.015 * (y - 10))
        # pocket
        if 15 <= y <= 19 and 5 <= x <= 10:
            if y == 15 or x in (5, 10) or y == 19:
                return trim
            if (x, y) == (7, 17) or (x, y) == (8, 17):
                return accent
            return apron_l
        return c
    return base


def body_back(v, x, y, W, H, base):
    apron, apron_l, apron_d, trim, accent = v["apron"], v["apron_l"], v["apron_d"], v["trim"], v["accent"]
    # straps crossing on the back
    if y <= 9:
        for a, b in ((4, 11), (11, 4)):
            xx = round(a + (b - a) * min(y, 9) / 9)
            if abs(x - xx) <= 0:
                return apron_l
            if abs(x - xx) == 1:
                return apron
    if y >= 10 and 3 <= x <= 12:
        if x in (3, 12):
            return trim
        # big bow at the waist
        if 11 <= y <= 15 and 4 <= x <= 11:
            if x in (7, 8) and 12 <= y <= 14:
                return GOLD
            return accent if (x + y) % 2 == 0 else mix(accent, WHITE, 0.3)
        return apron if (x // 2 + y // 2) % 2 == 0 else apron_l
    return base


# ---------------------------------------------------------------- arms and legs
def arm_painter(v, overlay):
    trim = v["trim"]

    def paint(name, x, y, W, H):
        if overlay:
            # puffed sleeve: rows 0..10
            if name in ("top", "bottom"):
                return shade(CREAM, name, x, y, W, H, 21) if name == "top" else None
            if y > 10:
                return None
            if y >= 9:
                return trim if (x + y) % 2 == 0 else mix(trim, CREAM, 0.4)
            return shade(CREAM, name, x, y, W, H, 21)
        c = shade(SKIN, name, x, y, W, H, 22)
        if name in ("top", "bottom"):
            return c
        if y <= 8:
            return shade(CREAM, name, x, y, W, H, 21)
        # hand: a little darker at the fingertips
        if y >= 21:
            c = mix(c, SKIN_D, 0.25)
        return c
    return paint


def leg_painter(v, overlay):
    trim = v["trim"]

    def paint(name, x, y, W, H):
        if overlay:
            # the skirt flares over the upper legs, rows 0..5
            if name in ("top", "bottom") or y > 5:
                return None
            c = shade(v["apron"], name, x, y, W, H, 31)
            if y >= 5:
                return trim if (x // 2 + y) % 2 == 0 else mix(trim, c, 0.35)
            return c
        if name in ("top", "bottom"):
            return shade(SKIN, name, x, y, W, H, 32)
        # knee socks (rows 11..19), shoes (rows 20..23)
        if y >= 20:
            c = shade(mix(v["trim"], v["apron_d"], 0.25) if v["name"] != "pink" else (190, 120, 140), name, x, y, W, H, 33)
            if y == 20:
                c = light(c, 0.85)
            if name == "front" and y == 21 and x in (W // 2 - 1, W // 2):
                c = GOLD                                    # buckle
            return c
        if y >= 11:
            c = shade(CREAM, name, x, y, W, H, 34)
            if y in (11, 12):
                return mix(trim, CREAM, 0.35)               # sock cuff
            return c
        return shade(SKIN, name, x, y, W, H, 32)
    return paint


def skin(v):
    img = Image.new("RGBA", (64 * S, 64 * S), (0, 0, 0, 0))
    paint_box(img, 0, 0, 8, 8, 8, head_painter(v, False))
    paint_box(img, 32, 0, 8, 8, 8, head_painter(v, True))
    paint_box(img, 16, 16, 8, 12, 4, body_painter(v, False))
    paint_box(img, 16, 32, 8, 12, 4, body_painter(v, True))
    paint_box(img, 40, 16, 4, 12, 4, arm_painter(v, False))
    paint_box(img, 40, 32, 4, 12, 4, arm_painter(v, True))
    paint_box(img, 32, 48, 4, 12, 4, arm_painter(v, False))
    paint_box(img, 48, 48, 4, 12, 4, arm_painter(v, True))
    paint_box(img, 0, 16, 4, 12, 4, leg_painter(v, False))
    paint_box(img, 0, 32, 4, 12, 4, leg_painter(v, True))
    paint_box(img, 16, 48, 4, 12, 4, leg_painter(v, False))
    paint_box(img, 0, 48, 4, 12, 4, leg_painter(v, True))
    add_accessory(img, v)
    return img


def add_accessory(img, v):
    """A bow / ribbon / flower pin on the hat layer, at the right side of the head front (x 10..14, y 1..4)."""
    px = img.load()
    ox, oy = (32 + 8) * S, (0 + 8) * S           # front face of the hat layer
    name = v["name"]
    acc = v["accent"]
    pts = []
    if name == "mint":     # pink bow
        pts = [(10, 2, acc), (11, 1, acc), (12, 2, GOLD), (13, 1, acc), (14, 2, acc), (11, 3, acc), (13, 3, acc),
               (10, 1, mix(acc, WHITE, 0.4)), (14, 1, mix(acc, WHITE, 0.4))]
    elif name == "pink":   # mint ribbon
        pts = [(2, 2, acc), (3, 1, acc), (4, 2, GOLD), (5, 1, acc), (6, 2, acc), (3, 3, acc), (5, 3, acc)]
    else:                  # flower pin
        pts = [(12, 2, (255, 214, 120)), (11, 2, WHITE), (13, 2, WHITE), (12, 1, WHITE), (12, 3, WHITE),
               (11, 1, mix(WHITE, (230, 220, 255), 0.5)), (13, 3, mix(WHITE, (230, 220, 255), 0.5))]
    for x, y, c in pts:
        px[ox + x, oy + y] = c + (255,)


# ---------------------------------------------------------------- contract item (32x32)
def contract_icon():
    K = 8
    big = Image.new("RGBA", (32 * K, 32 * K), (0, 0, 0, 0))
    d = ImageDraw.Draw(big)

    def rect(box, fill):
        d.rectangle([v * K for v in box], fill=fill)

    def ell(box, fill):
        d.ellipse([v * K for v in box], fill=fill)

    paper, paper_d = (255, 249, 238, 255), (232, 218, 196, 255)
    # sheet
    rect((7, 6, 25, 26), paper)
    rect((7, 6, 9, 26), paper_d)
    # rolled top and bottom
    ell((5, 3.6, 27, 8.6), paper_d)
    ell((5.6, 4.0, 26.4, 8.0), paper)
    ell((5, 23.6, 27, 28.6), paper_d)
    ell((5.6, 24.0, 26.4, 28.0), paper)
    # text lines
    for i, w in enumerate((14, 12, 14, 9)):
        rect((9.5, 10 + i * 2.6, 9.5 + w, 10.9 + i * 2.6), (196, 172, 160, 255))
    # pink ribbon
    rect((14, 3.2, 17.6, 28.8), (246, 170, 184, 255))
    rect((14, 3.2, 14.9, 28.8), (252, 196, 204, 255))
    # gold seal with a heart
    ell((12.2, 17.4, 21.6, 26.4), GOLD_D + (255,))
    ell((12.2, 16.8, 21.4, 25.6), GOLD + (255,))
    ell((13.4, 17.6, 17.2, 21.2), GOLD_L + (255,))
    ell((15.0, 20.0, 16.6, 21.6), (214, 120, 140, 255))
    ell((16.7, 20.0, 18.3, 21.6), (214, 120, 140, 255))
    d.polygon([(15.0 * K, 21.2 * K), (18.3 * K, 21.2 * K), (16.65 * K, 23.6 * K)], fill=(214, 120, 140, 255))
    small = big.resize((32, 32), Image.LANCZOS)
    px = small.load()
    base = {}
    for y in range(32):
        for x in range(32):
            r, g, b, a = px[x, y]
            if a > 110:
                base[(x, y)] = (r, g, b)
    out = Image.new("RGBA", (32, 32), (0, 0, 0, 0))
    op = out.load()
    for (x, y), c in base.items():
        op[x, y] = c + (255,)
    for (x, y) in list(base):
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            n = (x + dx, y + dy)
            if 0 <= n[0] < 32 and 0 <= n[1] < 32 and n not in base:
                op[n] = (160, 128, 112, 255)
    for (x, y) in ((20, 19), (15, 14)):
        if (x, y) in base:
            op[x, y] = GOLD_LL + (255,)
    return out


def main():
    (ASSETS / "entity").mkdir(parents=True, exist_ok=True)
    (ASSETS / "item").mkdir(parents=True, exist_ok=True)
    for i, v in enumerate(VARIANTS):
        skin(v).save(ASSETS / f"entity/seller_{i}.png")
    contract_icon().save(ASSETS / "item/seller_contract.png")
    print("seller generated")


if __name__ == "__main__":
    main()
