#!/usr/bin/env python3
"""
Generates the bare-torso costume with the black net and tattoos (after the figure picture; no hairstyle):

  diavolo_top    (top)     a skin-coloured, tight body layer: black net over the chest and shoulders, a chevron of straps down to the
                           middle, outlined abs, a spine line on the back, net on the upper arms and swirl tattoos on the forearms,
                           green wide wristbands
  diavolo_pants  (bottom)  glossy purple leather trousers: a green belt with a buckle, gold studs down the outer seams and round the
                           ankles, knee wrinkles, flared cuffs with a slit on the outer side
  diavolo_boots  (shoes)   purple ankle boots with a long pointed toe

Run from the project root:  python3 tools/gen_diavolo.py            (models, textures, icons, registration)
                            python3 tools/gen_diavolo.py --preview   (also writes previews to /tmp/diavolo_preview)
Same smooth painter as gen_suit.py / gen_giorno.py.
"""
import json
import math
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import gen_giorno as G  # noqa: E402
from gen_dino import blk, build, grad, mix  # noqa: E402
from gen_accessories import Cube, Icon, shade  # noqa: E402
from gen_outerwear import arm_pair, leg_pair, sd  # noqa: E402

SK = (234, 176, 134)
SK_L = (247, 198, 154)
SK_D = (204, 144, 106)
LINE = (34, 26, 30)
GREEN = (92, 176, 70)
GREEN_L = (136, 210, 104)
GREEN_D = (58, 124, 44)
PURPLE = (110, 62, 158)
PURPLE_L = (156, 106, 206)
PURPLE_D = (66, 34, 104)
STUD = (240, 200, 98)
STUD_D = (170, 124, 48)
BUCKLE = (176, 178, 190)


# ---------------------------------------------------------------- top
def skin(x, y, w, h):
    e = abs(x - (w - 1) / 2) / max(1.0, (w - 1) / 2)
    return mix(mix(SK_L, SK, min(1.0, y / max(1, h - 1) * 1.2)), SK_D, e ** 3 * 0.55)


def unroll(f, x, W, D):
    """x along the whole unwrapped strip [right | front | left | back] of a box (W wide, D deep, in texture pixels), so a pattern can
    run on round the corner from one face to the next without a break."""
    return {"right": x, "front": D + x, "left": D + W + x, "back": 2 * D + W + x}[f]


def net(u, y, period):
    """Two pixel thick diagonal lines in both directions: a connected lattice. `period` must divide the strip length (2W + 2D)."""
    return (u + y) % period < 2 or (u - y) % period < 2


def torso_deco(f, x, y, w, h):
    if f in ("top", "bottom"):
        return SK
    if f in ("right", "left") and y <= 11 and net(unroll(f, x, 18, 10), y, 7):
        return LINE                                                 # the net goes round the sides without a break
    if f in ("front", "back"):
        cx = abs(x - (w - 1) / 2)
        if y <= 11 and cx >= 2.4 and net(unroll(f, x, 18, 10), y, 7):
            return LINE                                             # the net over the chest / shoulder blades
        if y <= 10 and abs(cx - (7.2 - 0.65 * y)) <= 0.8:
            return LINE                                             # chevron of straps towards the middle
        if f == "front":
            if y >= 11 and x in (w // 2 - 1, w // 2) and y <= h - 3:
                return LINE                                         # line down the middle of the abs
            if y in (12, 15, 18, 21) and 5 <= x <= 12 and x not in (w // 2 - 1, w // 2):
                return LINE                                         # outlines of the abs
            if x in (5, 12) and 12 <= y <= 21:
                return LINE
        else:
            if x in (w // 2 - 1, w // 2) and y > 4:
                return LINE if y % 3 else skin(x, y, w, h)          # spine
    return skin(x, y, w, h)


def arm_deco(f, x, y, w, h):
    if f in ("top", "bottom"):
        return SK
    if y <= 9 and net(unroll(f, x, 10, 10), y, 8):
        return LINE                                                 # net over the upper arm, continuous round the arm
    if 10 <= y <= h - 8:                                            # swirl tattoos on the forearm
        for k, off in enumerate((0.0, 3.2)):
            if x == int(round((w - 1) / 2 + 1.9 * math.sin((y - 10) * 0.7 + off) - 1.2 + 1.2 * k)):
                return LINE
        if (y - 10) % 5 == 0 and x in (1, w - 2):
            return LINE
    return skin(x, y, w, h)


def wrist_deco(f, x, y, w, h):
    if f in ("top", "bottom"):
        return GREEN_D
    if y == 0:
        return GREEN_L
    if y >= h - 1:
        return GREEN_D
    return mix(GREEN, GREEN_D, y / max(1, h - 1) * 0.5)


def top():
    cubes = [Cube("torso", "body", (0, 6.0, 0), (8.2, 12.2, 4.2), SK, torso_deco)]
    arm_pair(cubes, "sleeve", 4.0, (4.2, 12.2, 4.2), SK, arm_deco)
    arm_pair(cubes, "wrist", 7.9, (4.7, 2.2, 4.7), GREEN, wrist_deco)
    return build("diavolo_top", cubes)


# ---------------------------------------------------------------- trousers
def stud_rows(h, start=2, step=3):
    return set(range(start, h - 1, step))


def thigh_deco(f, x, y, w, h):
    if f in ("top", "bottom"):
        return None
    col = mix(PURPLE_L, PURPLE, min(1.0, y / max(1, h - 1) * 0.8))
    if f in ("front", "back") and x in (1, 2):
        col = mix(col, PURPLE_L, 0.45)                              # glossy highlight
    if f == "right" and x == w // 2 and y in stud_rows(h):
        return STUD                                                 # studs along the outer seam
    if y == h - 1:
        return mix(col, PURPLE_D, 0.3)
    return col


def shin_deco(f, x, y, w, h):
    if f in ("top", "bottom"):
        return None
    col = mix(PURPLE_L, PURPLE, 0.55)
    if f in ("front", "back") and x in (1, 2):
        col = mix(col, PURPLE_L, 0.4)
    if f == "front" and y in (1, 3, 4) and 2 <= x <= w - 3:
        return mix(col, PURPLE_D, 0.55)                             # wrinkles at the knee
    if f == "right" and x == w // 2 and y in stud_rows(h, 1):
        return STUD
    return col


def cuff_deco(f, x, y, w, h):
    if f in ("top", "bottom"):
        return None
    col = mix(PURPLE, PURPLE_D, 0.2)
    if f == "right":                                                # the slit on the outer side with studs on its edges
        if x == w // 2 or x == w // 2 - 1:
            return PURPLE_D if y < h - 1 else None
        if x in (w // 2 - 2, w // 2 + 1) and y in (1, 3, 5):
            return STUD
    if f in ("front", "back") and y in (2, 5) and x in (1, w - 2):
        return STUD
    if y == h - 1:
        return mix(col, PURPLE_D, 0.5)
    if y == 0:
        return mix(col, PURPLE_L, 0.3)
    return col


def belt_deco(f, x, y, w, h):
    if f in ("top", "bottom"):
        return GREEN_D
    if y == 0:
        return GREEN_L
    if f == "front" and w // 2 - 2 <= x <= w // 2 + 1 and 0 <= y <= h - 1:
        return BUCKLE if (x in (w // 2 - 2, w // 2 + 1) or y in (0, h - 1)) else mix(BUCKLE, GREEN_D, 0.6)
    return GREEN if y < h - 1 else GREEN_D


def waist_deco(f, x, y, w, h):
    if f == "right" and x == w // 2 and y in (3, 7):
        return STUD
    return mix(PURPLE_L, PURPLE, 0.5)


def pants():
    cubes = [
        Cube("waist", "body", (0, 11.5, 0), (8.2, 3.2, 4.5), PURPLE, waist_deco),
        Cube("belt", "body", (0, 10.7, 0), (8.6, 1.8, 4.8), GREEN, belt_deco),
    ]
    leg_pair(cubes, "thigh", 2.9, (4.5, 6.2, 4.5), PURPLE, thigh_deco)
    leg_pair(cubes, "shin", 7.2, (4.2, 6.2, 4.2), PURPLE, shin_deco)
    leg_pair(cubes, "cuff", 10.4, (4.9, 3.2, 4.9), PURPLE, cuff_deco)
    return build("diavolo_pants", cubes)


# ---------------------------------------------------------------- boots
def d_shaft(f, x, y, w, h):
    if f in ("top", "bottom"):
        return None
    if y == 0:
        return PURPLE_L
    return None


def boots():
    cubes = []
    for side, sx in (("r", -1), ("l", 1)):
        m = side == "l"
        ox = sx * 0.1
        bone = "right_leg" if side == "r" else "left_leg"

        def tw(n):
            return None if side == "r" else n + "_r"
        cubes += [
            Cube(f"shaft_{side}", bone, (ox, 10.4, 0.2), (4.5, 3.2, 4.3), PURPLE, grad(PURPLE_L, PURPLE), twin_of=tw("shaft"), mirror=m),
            Cube(f"toe_{side}", bone, (ox, 11.1, -3.1), (3.8, 1.8, 3.2), PURPLE, grad(PURPLE_L, PURPLE), twin_of=tw("toe"), mirror=m),
            Cube(f"tip_{side}", bone, (ox, 11.3, -5.0), (2.6, 1.4, 1.4), PURPLE, None, twin_of=tw("tip"), mirror=m),
            Cube(f"sole_{side}", bone, (ox, 11.85, -1.7), (4.3, 0.6, 8.0), PURPLE_D, None, twin_of=tw("sole"), mirror=m),
        ]
    return build("diavolo_boots", cubes)


# ---------------------------------------------------------------- icons
def icon_top():
    i = Icon()
    blk(i, 1, 4, 3, 12, SK)                        # arms
    blk(i, 12, 4, 14, 12, SK)
    i.rect(1, 10, 3, 11, GREEN); i.rect(12, 10, 14, 11, GREEN)
    i.rect(1, 10, 3, 10, GREEN_L); i.rect(12, 10, 14, 10, GREEN_L)
    blk(i, 3, 2, 12, 14, SK)                       # torso
    for x in range(1, 4):
        for y in range(4, 9):
            if (x + y) % 3 == 0:
                i.put(x, y, LINE); i.put(15 - x, y, LINE)
    for x, y in ((3, 3), (4, 4), (5, 5), (6, 6), (7, 7), (12, 3), (11, 4), (10, 5), (9, 6), (8, 7)):
        i.put(x, y, LINE)
    for y in (9, 11, 13):
        i.rect(5, y, 10, y, LINE)
    i.rect(7, 8, 8, 14, LINE)
    i.rect(3, 14, 12, 14, shade(SK, 0.8))
    i.save("diavolo_top")


def icon_pants():
    i = Icon()
    blk(i, 3, 2, 12, 4, PURPLE)
    blk(i, 3, 5, 7, 14, PURPLE)
    blk(i, 8, 5, 12, 14, PURPLE)
    i.rect(3, 2, 12, 3, GREEN); i.rect(3, 2, 12, 2, GREEN_L)
    i.rect(7, 2, 8, 3, BUCKLE)
    i.rect(7, 5, 8, 14, PURPLE_D)
    i.rect(4, 6, 4, 12, PURPLE_L); i.rect(11, 6, 11, 12, PURPLE_L)
    for y in (6, 9, 12):
        i.put(3, y, STUD); i.put(12, y, STUD)
    i.rect(3, 13, 7, 14, PURPLE_D if False else shade(PURPLE, 0.8)); i.rect(8, 13, 12, 14, shade(PURPLE, 0.8))
    i.save("diavolo_pants")


def icon_boots():
    i = Icon()
    for x0 in (1, 8):
        blk(i, x0 + 1, 5, x0 + 5, 10, PURPLE)
        blk(i, x0, 9, x0 + 6, 12, PURPLE)
        i.rect(x0 + 1, 5, x0 + 4, 6, PURPLE_L)
        i.put(x0 + 6, 11, PURPLE); i.put(x0 + 7, 12, PURPLE)
        i.rect(x0, 13, x0 + 7, 13, PURPLE_D)
    i.save("diavolo_boots")


# ---------------------------------------------------------------- registration
ITEMS = [
    dict(id="diavolo_top", category="top", ru="Сетчатый торс с татуировками", en="Net and Tattoo Torso", price=8999,
         build=top, icon=icon_top),
    dict(id="diavolo_pants", category="bottom", ru="Фиолетовые брюки с заклёпками", en="Purple Studded Pants", price=9999,
         build=pants, icon=icon_pants),
    dict(id="diavolo_boots", category="shoes", ru="Фиолетовые остроносые ботинки", en="Purple Pointed Boots", price=6499,
         build=boots, icon=icon_boots),
]
DOC_MARK = "## Net and tattoo torso with purple studded pants"
DOC_TEXT = """
## Net and tattoo torso with purple studded pants
`python3 tools/gen_diavolo.py` regenerates the models, textures, icons and (idempotently) the entries in `clothes.json`, the lang files,
`ClothingCatalog`, `ClothingPrices` and `Looks` (look `diavolo`: top, trousers, boots). No hairstyle.
- `diavolo_top` (top): a skin-coloured tight layer (8.2 x 4.2 torso, 4.2 sleeves, only 0.1 wider than the skin), painted with the black
  net (a connected 2 px thick diagonal lattice that wraps round the body and the arms), a chevron of straps, outlined abs, a spine line and swirl tattoos on the forearms. The wide green
  wristbands are separate boxes (`wrist`) on the arm bones.
- `diavolo_pants` (bottom): three boxes per leg (thigh, shin, flared cuff), a waist and a green belt with a buckle. Gold studs are painted on
  the `right` face of every leg piece, which is the OUTER face for both legs (the left leg is a mirrored twin). The cuffs have a slit.
- `diavolo_boots` (shoes): shaft, toe, a stepped tip for the pointed toe, sole.
"""


def register():
    res = G.ROOT / "src/main/resources/assets/fittingroom"
    cj = json.loads((res / "clothes.json").read_text(encoding="utf-8"))
    have = {it["id"] for it in cj["items"]}
    for e in ITEMS:
        if e["id"] in have:
            continue
        cj["items"].append({"id": e["id"], "category": e["category"],
                            "name": {"ru_ru": e["ru"], "en_us": e["en"]},
                            "model": f"fittingroom:clothes_models/{e['id']}.json",
                            "texture": f"fittingroom:textures/clothes/{e['id']}.png",
                            "icon": f"fittingroom:textures/gui/clothes/{e['id']}.png"})
    (res / "clothes.json").write_text(json.dumps(cj, ensure_ascii=False) + "\n", encoding="utf-8")

    for lang, key, look in (("ru_ru", "ru", "Диаволо"), ("en_us", "en", "Diavolo")):
        path = res / f"lang/{lang}.json"
        data = json.loads(path.read_text(encoding="utf-8"))
        for e in ITEMS:
            data.setdefault(f"clothes.fittingroom.{e['id']}", e[key])
        data.setdefault("look.fittingroom.diavolo", look)
        path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    java = G.ROOT / "src/main/java/com/fittingroom/wardrobe/ClothingCatalog.java"
    text = java.read_text(encoding="utf-8")
    close = "\n    );\n\n    private static final Map<String, Item> BY_ID"
    cat = {"top": "TOP", "bottom": "BOTTOM", "shoes": "SHOES"}
    lines = [f'            new Item("{e["id"]}", Category.{cat[e["category"]]})' for e in ITEMS if f'"{e["id"]}"' not in text]
    if lines:
        assert close in text, "end of the item list not found"
        java.write_text(text.replace(close, ",\n" + ",\n".join(lines) + close), encoding="utf-8")

    prices = G.ROOT / "src/main/java/com/fittingroom/wardrobe/ClothingPrices.java"
    text = prices.read_text(encoding="utf-8")
    anchor = "        // ---- scarves ----\n"
    assert anchor in text, "anchor for the prices not found"
    add = "".join(f'        p("{e["id"]}", {e["price"]});\n' for e in ITEMS if f'"{e["id"]}"' not in text)
    if add:
        prices.write_text(text.replace(anchor, "        // ---- net and tattoo torso with purple studded pants ----\n" + add + "\n" + anchor, 1), encoding="utf-8")

    looks = G.ROOT / "src/main/java/com/fittingroom/wardrobe/Looks.java"
    text = looks.read_text(encoding="utf-8")
    if '"diavolo"' not in text:
        end = text.index("\n    );", text.index("public static final List<Look> ALL = List.of("))
        add = ',\n            new Look("diavolo", List.of("diavolo_top", "diavolo_pants", "diavolo_boots"))'
        looks.write_text(text[:end] + add + text[end:], encoding="utf-8")

    doc = G.ROOT / "docs/clothes-models.md"
    text = doc.read_text(encoding="utf-8")
    if DOC_MARK not in text:
        doc.write_text(text.rstrip("\n") + "\n" + DOC_TEXT, encoding="utf-8")


if __name__ == "__main__":
    for e in ITEMS:
        e["build"]()
        e["icon"]()
    register()
    print("generated:", ", ".join(e["id"] for e in ITEMS))
    if "--preview" in sys.argv:
        G.preview([e["id"] for e in ITEMS], ITEMS, "diavolo")
