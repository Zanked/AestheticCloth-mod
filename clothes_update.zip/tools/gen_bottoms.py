#!/usr/bin/env python3
"""
Generates more lower-body clothes of the fitting room:
  pants_*      (bottom)  ripped jeans, flared jeans, white jeans, black trousers with a crease, beige chinos, khaki cargo pants,
                         gray and black sweatpants with side stripes, black and pink leggings
  skirt_*      (bottom)  long floral maxi skirt, long pleated satin skirt, white tennis skirt with stripes
  overalls_*   (top)     denim and corduroy dungarees with a tee underneath (top slot: they sit over the other bottoms)
Models, 32x textures and 16x16 GUI icons, and (idempotently) the entries in clothes.json, the lang files,
ClothingCatalog.java and ClothingPrices.java. Same smooth painter as gen_dino.py.

Run from the project root:  python3 tools/gen_bottoms.py
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from gen_dino import blk, build, grad, mix  # noqa: E402
from gen_accessories import Cube, Icon, shade  # noqa: E402
import gen_outerwear  # noqa: E402
from gen_outerwear import DAISY, arm_pair, fold, hem_band, sd, tile_col, tw, weave  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent
WHITE = (252, 250, 246)
SILVER = (206, 212, 224)
GOLD = (232, 190, 84)


def legs(cubes, n, cy, dims, base, deco, ox=0.1):
    for side, sx in (("r", -1), ("l", 1)):
        bone = "right_leg" if side == "r" else "left_leg"
        cubes.append(Cube(f"{n}_{side}", bone, (sx * ox, cy, 0), dims, base, deco, twin_of=tw(side, n), mirror=side == "l"))


# ====================================================================== PANTS
PANTS = {
    "jeans_ripped": dict(kind="denim", base=(112, 156, 214), dark=(76, 114, 176), light=(160, 196, 238), stitch=(232, 190, 96), belt=(92, 66, 44),
                         rips=True, ru="Рваные джинсы", en="Ripped Jeans", price=4499),
    "jeans_flared": dict(kind="denim", base=(54, 80, 142), dark=(34, 52, 100), light=(90, 120, 182), stitch=(232, 190, 96), belt=(60, 44, 36),
                         flare=True, ru="Тёмные джинсы-клёш", en="Flared Jeans", price=4499),
    "jeans_white": dict(kind="denim", base=(246, 244, 238), dark=(212, 208, 198), light=(255, 255, 252), stitch=(190, 184, 168), belt=(170, 120, 80),
                        ru="Белые джинсы", en="White Jeans", price=4299),
    "trousers_black": dict(kind="suit", base=(44, 42, 52), dark=(26, 24, 34), light=(86, 84, 104), stitch=(150, 150, 170), belt=(20, 18, 24),
                           ru="Чёрные классические брюки", en="Black Trousers", price=4999),
    "chino_beige": dict(kind="suit", base=(212, 186, 144), dark=(170, 144, 102), light=(240, 222, 184), stitch=(240, 226, 180), belt=(110, 74, 46),
                        ru="Бежевые чиносы", en="Beige Chinos", price=4299),
    "cargo_khaki": dict(kind="cargo", base=(92, 106, 64), dark=(60, 72, 42), light=(132, 148, 98), stitch=(190, 200, 140), belt=(54, 50, 40),
                        ru="Штаны карго цвета хаки", en="Khaki Cargo Pants", price=4799),
    "sweat_gray": dict(kind="sweat", base=(152, 156, 168), dark=(110, 114, 128), light=(192, 196, 208), stripe=WHITE, belt=(110, 114, 128),
                       ru="Серые спортивные штаны", en="Gray Sweatpants", price=3499),
    "sweat_black": dict(kind="sweat", base=(36, 36, 46), dark=(20, 20, 28), light=(80, 80, 98), stripe=WHITE, belt=(20, 20, 28),
                        ru="Чёрные спортивные штаны с полосками", en="Black Track Pants", price=3499),
    "leggings_black": dict(kind="legging", base=(34, 32, 42), dark=(20, 18, 28), light=(96, 94, 116), stripe=None, belt=(20, 18, 28),
                           ru="Чёрные лосины", en="Black Leggings", price=2999),
    "leggings_pink": dict(kind="legging", base=(246, 152, 192), dark=(208, 106, 148), light=(255, 214, 232), stripe=WHITE, belt=(208, 106, 148),
                          ru="Розовые лосины с полоской", en="Pink Leggings", price=2999),
}


def pant_leg(p):
    kind = p["kind"]

    def d(f, x, y, w, h):
        if f == "top":
            return p["dark"]
        if f == "bottom":
            return None
        col = weave(p["base"], p["light"], x, y)
        if kind == "denim":
            if f == "back" and 2 <= x <= 7 and 2 <= y <= 7 and (x in (2, 7) or y in (2, 7)):
                return p["stitch"]
            if f == "front":
                if x in (w - 3,) and 1 <= y <= 5 and y % 2 == 1:
                    return p["stitch"]
                if p.get("rips") and 7 <= y <= 12 and 2 <= x <= w - 4:
                    if 8 <= y <= 11 and 3 <= x <= w - 5:
                        return "clear"
                    return WHITE if (x + y) % 2 == 0 else mix(col, WHITE, 0.5)
            if f in ("left", "right") and x == w // 2:
                col = mix(col, p["dark"], 0.35)
        elif kind == "suit":
            if f in ("front", "back") and x == w // 2 - (0 if f == "front" else 1):
                col = mix(col, p["light"], 0.5)
            if f == "front" and y in (2, 3) and x in (1, 2):
                col = p["dark"]
        elif kind == "cargo":
            if f == "front" and y == 10 and x % 3 == 0:
                col = p["stitch"]
        elif kind == "sweat":
            if f in ("left", "right") and w // 2 - 1 <= x <= w // 2:
                return p["stripe"]
        elif kind == "legging":
            col = mix(p["base"], p["light"], 0.5) if (f == "front" and x in (2, 3) and 3 < y < h - 3) else p["base"]
            if p["stripe"] and f in ("left", "right") and x == w // 2:
                return p["stripe"]
        if y >= h - 1:
            col = mix(col, p["dark"], 0.4)
        return col
    return d


def pants(name, p):
    kind = p["kind"]
    tight = kind == "legging"
    wd = 4.4 if tight else (5.4 if kind in ("sweat", "cargo") else 4.9)
    belt_col = p["belt"]
    belt_deco = lambda f, x, y, w, h: None if not sd(f) else (
        (p["light"] if kind == "sweat" and f == "front" and x in (w // 2 - 2, w // 2 + 1) and y > 1 else belt_col) if y else mix(belt_col, WHITE, 0.2))
    cubes = [Cube("belt", "body", (0, 11.3, 0), (8.9, 1.6, 4.9), belt_col, belt_deco)]
    if kind in ("denim", "suit", "cargo"):
        cubes.append(Cube("buckle", "body", (0, 11.3, -2.55), (1.6, 1.1, 0.4), SILVER if kind != "suit" else (206, 212, 224), None))
    legs(cubes, "leg", 5.2, (wd, 10.4, wd), p["base"], pant_leg(p))
    if p.get("flare"):
        legs(cubes, "flare", 9.7, (5.9, 2.6, 5.9), p["base"],
             lambda f, x, y, w, h: None if f in ("top", "bottom") else (p["stitch"] if y == h - 2 and x % 2 == 0 else
                                                                         (p["dark"] if y == h - 1 else weave(p["base"], p["light"], x, y))))
    elif kind == "denim":
        legs(cubes, "cuff", 9.9, (wd + 0.3, 1.2, wd + 0.3), p["light"],
             lambda f, x, y, w, h: None if f in ("top", "bottom") else (p["stitch"] if y == 0 and x % 2 == 0 else mix(p["light"], p["base"], 0.3)))
    elif kind == "sweat":
        legs(cubes, "cuff", 9.9, (wd - 0.5, 1.2, wd - 0.5), p["dark"],
             lambda f, x, y, w, h: None if f in ("top", "bottom") else (p["dark"] if x % 2 == 0 else mix(p["dark"], p["base"], 0.4)))
    elif kind == "cargo":
        for side, sx in (("r", -1), ("l", 1)):
            bone = "right_leg" if side == "r" else "left_leg"
            cubes.append(Cube(f"pocket_{side}", bone, (sx * (0.1 + wd / 2 + 0.45), 4.2, 0.0), (0.9, 3.6, 3.8), p["dark"],
                              lambda f, x, y, w, h, c=p: None if f in ("top", "bottom") else
                              (c["stitch"] if y == 2 and f in ("front", "back", "left", "right") else mix(c["base"], c["dark"], 0.5)),
                              twin_of=tw(side, "pocket"), mirror=side == "l"))
    return build(name, cubes)


def icon_pants(name, p):
    i = Icon()
    kind = p["kind"]
    base, dark, light = p["base"], p["dark"], p["light"]
    blk(i, 3, 2, 12, 3, p["belt"])
    i.rect(3, 2, 12, 2, mix(p["belt"], WHITE, 0.25))
    if kind in ("denim", "suit", "cargo"):
        i.rect(7, 2, 8, 3, SILVER)
    lx = (3, 7) if not kind == "legging" else (4, 7)
    rx = (8, 12) if not kind == "legging" else (8, 11)
    for x0, x1 in (lx, rx):
        for y in range(4, 14):
            xa, xb = x0, x1
            if p.get("flare") and y >= 11:
                xa, xb = x0 - 1, x1 + 1
            if kind == "sweat":
                xa, xb = x0, x1
            for x in range(xa, xb + 1):
                if y >= 9 and x in (7, 8):
                    continue
                col = base
                if x == xa:
                    col = mix(base, light, 0.5)
                elif x == xb:
                    col = shade(base, 0.82)
                i.put(x, y, col)
    i.rect(7, 4, 8, 8, dark)
    if kind == "denim":
        i.rect(3, 12, 7, 12, light); i.rect(8, 12, 12, 12, light)
        if p.get("rips"):
            for x, y in ((4, 7), (5, 8), (4, 8), (10, 8), (11, 9), (10, 9)):
                i.put(x, y, WHITE)
            for x, y in ((5, 7), (11, 8)):
                i.put(x, y, (236, 226, 214))
    if kind == "suit":
        for x in (5, 10):
            i.rect(x, 5, x, 12, mix(base, light, 0.6))
    if kind == "cargo":
        for x0 in (3, 11):
            i.rect(x0, 8, x0 + 1, 10, dark); i.rect(x0, 8, x0 + 1, 8, p["stitch"])
    if kind == "sweat":
        for x in (3, 12):
            i.rect(x, 4, x, 13, p["stripe"])
        i.rect(3, 13, 7, 13, dark); i.rect(8, 13, 12, 13, dark)
    if kind == "legging" and p["stripe"]:
        i.rect(4, 5, 4, 13, p["stripe"]); i.rect(11, 5, 11, 13, p["stripe"])
    i.save(name)


# ====================================================================== SKIRTS
SKIRTS = {
    "maxi_floral": dict(mode="floral", base=(62, 112, 96), dark=(40, 78, 66), light=(100, 152, 134), band=(40, 78, 66),
                        layers=[dict(pat=DAISY, cols={"P": (250, 186, 206), "C": (252, 220, 110)}, gx=12, gy=12, ox=1, oy=1),
                                dict(pat=["XX"], cols={"X": (252, 244, 226)}, gx=12, gy=12, ox=7, oy=7)],
                        tiers=3, ru="Длинная юбка в цветочек", en="Floral Maxi Skirt", price=4999),
    "maxi_satin": dict(mode="satin", base=(172, 200, 176), dark=(124, 156, 132), light=(222, 240, 222), band=(124, 156, 132),
                       layers=[], tiers=3, ru="Длинная плиссированная юбка", en="Pleated Satin Skirt", price=5499),
    "tennis": dict(mode="tennis", base=(248, 248, 252), dark=(196, 200, 216), light=WHITE, band=(40, 60, 130),
                   layers=[], tiers=2, ru="Белая теннисная юбка", en="Tennis Skirt", price=3999),
}


def skirt_fab(p):
    def d(f, x, y, w, h):
        if f in ("top", "bottom"):
            return mix(p["base"], p["dark"], 0.3)
        col = tile_col(p["layers"], x, y) or weave(p["base"], p["light"], x, y)
        if p["mode"] in ("satin", "tennis"):
            col = fold(col, x, 4, 0.12)
            if p["mode"] == "satin" and (x + y * 2) % 11 == 0:
                col = mix(col, p["light"], 0.6)
        elif p["mode"] == "floral":
            col = fold(col, x, 6, 0.05)
        return col
    return d


def skirt(name, p):
    long = p["tiers"] == 3
    band = lambda f, x, y, w, h: None if not sd(f) else (mix(p["band"], WHITE, 0.25) if y == 0 else p["band"])
    cubes = [Cube("band", "body", (0, 11.3, 0), (9.9, 1.6, 5.9), p["band"], band)]
    spec = ([("sk1", 12.7, 3.4, 10.6, 6.8), ("sk2", 15.8, 3.4, 11.8, 7.8), ("sk3", 19.0, 3.2, 12.8, 8.6)] if long
            else [("sk1", 12.6, 2.6, 10.0, 6.2), ("sk2", 14.8, 2.4, 11.0, 7.2)])
    for k, (n, cy, ch, cw, cd) in enumerate(spec):
        last = k == len(spec) - 1

        def deco(f, x, y, w, h, last=last):
            col = skirt_fab(p)(f, x, y, w, h)
            if not sd(f):
                return col
            if p["mode"] == "tennis" and last:
                if y == h - 2 and x % 1 == 0:
                    return p["band"]
                if y == h - 4:
                    return (200, 50, 60)
            if last:
                return hem_band(col, y, h, p["dark"] if p["mode"] != "tennis" else p["band"], 1)
            return col
        cubes.append(Cube(n, "body", (0, cy, 0), (cw, ch, cd), p["base"], deco))
    return build(name, cubes)


def icon_skirt(name, p):
    i = Icon()
    long = p["tiers"] == 3
    blk(i, 5, 2, 10, 3, p["band"])
    rows = ({4: (5, 10), 5: (5, 10), 6: (4, 11), 7: (4, 11), 8: (3, 12), 9: (3, 12), 10: (2, 13), 11: (2, 13), 12: (1, 14), 13: (1, 14), 14: (1, 14)}
            if long else {4: (5, 10), 5: (4, 11), 6: (4, 11), 7: (3, 12), 8: (3, 12), 9: (2, 13), 10: (2, 13)})
    for y, (x0, x1) in rows.items():
        for x in range(x0, x1 + 1):
            col = p["base"]
            if p["mode"] == "floral" and (x * 3 + y * 5) % 7 == 0:
                col = (250, 186, 206)
            if p["mode"] in ("satin", "tennis") and x % 3 == 2:
                col = shade(col, 0.88)
            if p["mode"] == "satin" and (x + y * 2) % 7 == 0:
                col = p["light"]
            if x == x0:
                col = mix(col, p["light"], 0.4)
            i.put(x, y, col)
    last = max(rows)
    x0, x1 = rows[last]
    i.rect(x0, last, x1, last, p["dark"] if p["mode"] != "tennis" else p["band"])
    if p["mode"] == "tennis":
        i.rect(x0, last - 2, x1, last - 2, (200, 50, 60))
    i.save(name)


# ====================================================================== OVERALLS (top slot)
OVERALLS = {
    "denim": dict(base=(82, 124, 196), dark=(54, 88, 148), light=(126, 166, 226), stitch=(232, 190, 96), tee=WHITE, tee_dark=(214, 210, 204),
                  stripes=False, ru="Джинсовый комбинезон с футболкой", en="Denim Overalls", price=5999),
    "cord": dict(base=(150, 98, 62), dark=(106, 66, 40), light=(190, 136, 96), stitch=(240, 214, 170), tee=(250, 236, 214), tee_dark=(206, 190, 164),
                 stripes=True, ru="Вельветовый комбинезон с полосатой футболкой", en="Corduroy Overalls", price=5999),
}


def overalls(name, p):
    def cloth(f, x, y, w, h):
        if f in ("top", "bottom"):
            return p["dark"]
        col = mix(p["base"], p["light"], 0.14) if (x + y) % 5 == 0 else p["base"]
        if p["stripes"] and x % 3 == 0:
            col = mix(col, p["dark"], 0.35)
        if y >= h - 1:
            col = mix(col, p["dark"], 0.35)
        return col

    def tee(f, x, y, w, h):
        if not sd(f):
            return None
        if p["stripes"] and (y // 3) % 2 == 1:
            return (214, 70, 80) if True else p["tee"]
        return p["tee"] if (x + y) % 6 else p["tee_dark"]

    def bib(f, x, y, w, h):
        col = cloth(f, x, y, w, h)
        if f == "front" and 3 <= x <= w - 4 and 4 <= y <= 9 and (x in (3, w - 4) or y in (4, 9)):
            return p["stitch"]
        if f == "front" and (x, y) in ((1, 1), (w - 2, 1)):
            return GOLD
        return col
    cubes = [Cube("tee", "body", (0, 5.0, 0), (9.6, 10.4, 5.6), p["tee"], tee),
             Cube("hip", "body", (0, 10.6, 0), (9.9, 3.6, 5.9), p["base"],
                  lambda f, x, y, w, h: p["stitch"] if f == "back" and 2 <= x <= 7 and y in (3, 6) else cloth(f, x, y, w, h)),
             Cube("bib", "body", (0, 8.0, -3.15), (6.8, 5.6, 0.7), p["base"], bib),
             Cube("strap_fl", "body", (-2.3, 2.7, -3.0), (1.5, 5.2, 0.6), p["base"], cloth),
             Cube("strap_fr", "body", (2.3, 2.7, -3.0), (1.5, 5.2, 0.6), p["base"], cloth),
             Cube("strap_bl", "body", (-2.3, 2.7, 3.0), (1.5, 5.6, 0.6), p["base"], cloth),
             Cube("strap_br", "body", (2.3, 2.7, 3.0), (1.5, 5.6, 0.6), p["base"], cloth),
             Cube("strap_tl", "body", (-2.3, -0.4, 0.0), (1.5, 0.6, 6.4), p["base"], cloth),
             Cube("strap_tr", "body", (2.3, -0.4, 0.0), (1.5, 0.6, 6.4), p["base"], cloth),
             Cube("button_l", "body", (-2.3, 5.5, -3.4), (1.1, 1.1, 0.3), GOLD, None),
             Cube("button_r", "body", (2.3, 5.5, -3.4), (1.1, 1.1, 0.3), GOLD, None)]
    arm_pair(cubes, "sleeve", 0.7, (5.0, 5.4, 5.0), p["tee"], tee)
    legs(cubes, "leg", 5.2, (4.9, 10.4, 4.9), p["base"],
         lambda f, x, y, w, h: p["stitch"] if f == "back" and 2 <= x <= 6 and y == 3 else cloth(f, x, y, w, h))
    legs(cubes, "cuff", 9.9, (5.2, 1.2, 5.2), p["light"],
         lambda f, x, y, w, h: None if f in ("top", "bottom") else (p["stitch"] if y == 0 and x % 2 == 0 else mix(p["light"], p["base"], 0.3)))
    return build(name, cubes)


def icon_overalls(name, p):
    i = Icon()
    blk(i, 2, 3, 4, 6, p["tee"]); blk(i, 11, 3, 13, 6, p["tee"])
    blk(i, 4, 2, 11, 8, p["tee"])
    if p["stripes"]:
        for y in (3, 6):
            i.rect(2, y, 13, y, (214, 70, 80))
    blk(i, 6, 5, 9, 9, p["base"])
    i.rect(6, 6, 9, 6, p["stitch"]) if False else None
    i.rect(4, 2, 5, 5, p["base"]); i.rect(10, 2, 11, 5, p["base"])
    i.rect(4, 5, 5, 5, GOLD); i.rect(10, 5, 11, 5, GOLD)
    blk(i, 4, 9, 11, 10, p["base"])
    blk(i, 4, 10, 7, 14, p["base"]); blk(i, 8, 10, 11, 14, p["base"])
    i.rect(7, 10, 8, 13, p["dark"])
    i.rect(4, 14, 7, 14, p["light"]); i.rect(8, 14, 11, 14, p["light"])
    i.rect(7, 6, 8, 7, p["dark"])
    i.save(name)


# ====================================================================== run
CATEGORY_OF = {"pants_": "bottom", "skirt_": "bottom", "overalls_": "top"}
SETS = [("pants_", PANTS, pants, icon_pants), ("skirt_", SKIRTS, skirt, icon_skirt), ("overalls_", OVERALLS, overalls, icon_overalls)]

DOC_MARK = "## More trousers, leggings, long skirts and overalls"
DOC_TEXT = """
## More trousers, leggings, long skirts and overalls
`python3 tools/gen_bottoms.py` regenerates fifteen lower-body items (models, textures, icons) and registers them.
- `pants_*` (bottom): ankle-length trousers made of two leg cubes (10.4 units, so shoes and ankles show below), a belt on the body bone and
  a kind-specific detail: ripped jeans have transparent holes at the knees (skin shows), `jeans_flared` a wide flared hem, trousers a crease,
  cargo pants two side pocket boxes, sweatpants side stripes and ribbed cuffs, leggings a tighter fit (4.4 units).
- `skirt_maxi_floral`, `skirt_maxi_satin` (three flared tiers down to y = 20.6) and `skirt_tennis` (two short pleated tiers with stripes):
  hang on the body bone, so they do not swing with the legs, like the other skirts.
- `overalls_denim`, `overalls_cord` (**top** slot, because tops are drawn over bottoms): tee + hip part + bib + straps (flat boxes in front,
  behind and over the shoulders) + trousers legs; wear them with any shoes, but not with another top.
"""

if __name__ == "__main__":
    gen_outerwear.CATEGORY["shoes"] = "SHOES"
    items = []
    for prefix, palettes, model_fn, icon_fn in SETS:
        for key, p in palettes.items():
            name = prefix + key
            model_fn(name, p)
            icon_fn(name, p)
            items.append(dict(id=name, category=CATEGORY_OF[prefix], ru=p["ru"], en=p["en"], price=p["price"]))
    gen_outerwear.register(items)
    doc = ROOT / "docs/clothes-models.md"
    text = doc.read_text(encoding="utf-8")
    if DOC_MARK not in text:
        doc.write_text(text.rstrip("\n") + "\n" + DOC_TEXT, encoding="utf-8")
    print("bottoms generated:", len(items))
