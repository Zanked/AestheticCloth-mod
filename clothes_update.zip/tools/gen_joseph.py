#!/usr/bin/env python3
"""
Generates two outfits of the fitting room after the pictures of Joseph (no hairstyle):

  YOUNG (Battle Tendency)
    joseph_young_scarf   (accessory, slot neck)  green scarf with yellow edge stripes: two rings, a knot, a tail in front and two on the back
    joseph_young_top     (top)     olive sleeveless crop top, the sides of the hem are cut out so the bare waist shows
    joseph_young_gloves  (accessory)  black fingerless gloves with a long wrist guard and a gold ring on each wrist
    joseph_young_jeans   (bottom)  blue jeans, high-rise, brown belt with a gold buckle, back pockets
    joseph_young_boots   (shoes)   tall black boots with a folded grey cuff (jeans go inside)
  OLD (Stardust Crusaders)
    joseph_old_hat       (hat)     tan fedora: wide tilted brim, dark band, pinched crown
    joseph_old_shirt     (top)     olive polo with an open collar that shows a cream undershirt, short sleeves
    joseph_old_gloves    (accessory)  white gloves with dark wristbands
    joseph_old_pants     (bottom)  khaki trousers, dark brown belt with a silver buckle
    joseph_old_boots     (shoes)   brown laced boots

Run from the project root:  python3 tools/gen_joseph.py            (models, textures, icons, registration)
                            python3 tools/gen_joseph.py --preview   (also writes previews to /tmp/joseph_preview)
                            python3 tools/zfight_cross.py --all     (afterwards, like after every generator)
Same smooth painter as gen_josuke.py / gen_jotaro.py.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import gen_giorno as G  # noqa: E402
from gen_dino import blk, build, mix  # noqa: E402
from gen_accessories import Cube, Icon, shade  # noqa: E402
from gen_outerwear import arm_pair, leg_pair, sd  # noqa: E402

GOLD, GOLD_D, GOLD_L = G.GOLD, G.GOLD_D, G.GOLD_L
SILVER, SILVER_D = (206, 208, 218), (146, 150, 164)

# ---- young
OLIVE, OLIVE_L, OLIVE_D = (84, 94, 58), (116, 128, 84), (56, 64, 38)
SC_G, SC_GD, SC_Y = (104, 164, 84), (66, 118, 58), (240, 204, 80)
JEAN, JEAN_L, JEAN_D = (52, 94, 140), (84, 130, 176), (32, 62, 102)
THREAD = (226, 176, 96)
BELT, BELT_D, BELT_L = (116, 70, 44), (78, 46, 28), (148, 96, 62)
BLACK, BLACK_L, BLACK_D = (36, 34, 40), (78, 76, 90), (18, 16, 22)
CUFF, CUFF_L = (92, 86, 88), (132, 124, 122)

# ---- old
HAT, HAT_L, HAT_D = (184, 166, 98), (214, 198, 130), (136, 120, 66)
BAND, BAND_L = (92, 62, 38), (128, 90, 58)
POLO, POLO_L, POLO_D = (192, 178, 98), (226, 214, 142), (146, 132, 70)
TEE, TEE_D = (240, 232, 198), (200, 190, 152)
KHAKI, KHAKI_L, KHAKI_D = (156, 122, 72), (186, 152, 98), (112, 84, 46)
BELT_O, BELT_OD = (70, 44, 30), (44, 28, 18)
WHITE, WHITE_D = (244, 244, 242), (186, 188, 196)
WRIST, WRIST_L = (44, 44, 58), (82, 82, 100)
BROWN, BROWN_L, BROWN_D = (112, 76, 46), (150, 106, 68), (72, 46, 28)


def ellipse(x, y, cx, cy, rx, ry):
    return ((x + 0.5 - cx) / rx) ** 2 + ((y + 0.5 - cy) / ry) ** 2 < 1.0


# ====================================================================== YOUNG: SCARF
def scarf_ring(yline):
    def d(f, x, y, w, h):
        if f in ("top", "bottom"):
            return None
        if y == yline:
            return SC_Y
        return mix(SC_G, SC_GD, 0.25) if y == h - 1 else None
    return d


def scarf_tail(f, x, y, w, h):
    if f in ("top", "bottom"):
        return None
    if f in ("front", "back"):
        if x in (1, w - 2):
            return SC_Y                                         # yellow stripes along both edges
        if y >= h - 2:
            return mix(SC_G, SC_GD, 0.5)
        return mix(SC_G, SC_GD, 0.2) if x in (0, w - 1) else None
    return SC_GD


def scarf():
    cubes = [
        Cube("wrap_a", "body", (0, -0.7, 0), (9.8, 1.8, 9.4), SC_G, scarf_ring(1)),
        Cube("wrap_b", "body", (0, 1.1, 0), (11.0, 2.0, 9.8), SC_G, scarf_ring(2)),
        Cube("knot", "body", (2.0, 1.6, -5.5), (3.0, 2.6, 1.6), shade(SC_G, 0.92), scarf_ring(2)),
        # tail on the chest, tilted 12 degrees towards the body
        Cube("tail_front", "body", (1.3, 2.6 + 3.7, -5.3), (2.2, 7.4, 0.9), SC_G, scarf_tail, pivot=(1.3, 2.6, -5.3), rot=(12, 0, 0)),
        # two tails on the back, tilted towards the body the other way (they never go into the body)
        Cube("tail_back_a", "body", (-1.6, 1.7 + 4.5, 5.05), (2.4, 9.0, 0.9), SC_G, scarf_tail, pivot=(-1.6, 1.7, 5.05), rot=(-10, 0, 0)),
        Cube("tail_back_b", "body", (1.4, 1.7 + 3.4, 5.05), (2.4, 6.8, 0.9), SC_G, scarf_tail, pivot=(1.4, 1.7, 5.05), rot=(-10, 0, 0)),
    ]
    return build("joseph_young_scarf", cubes)


# ====================================================================== YOUNG: CROP TOP
def top_young_deco(f, x, y, w, h):
    if f == "top":
        return None
    if f == "bottom":
        return OLIVE_D
    if f in ("front", "back"):
        for cx in (0, w):                                       # the lower corners are cut out: bare waist on both sides
            if ellipse(x, y, cx, h, 3.6, 5.0):
                return "clear"
    elif y >= h - 5:
        return "clear"
    col = mix(OLIVE_L, OLIVE, min(1.0, y / max(1, h - 1) * 1.1))
    if f == "front":
        for cx in (w * 0.27, w * 0.73):                         # chest muscles
            if ellipse(x, y, cx, 5.0, 4.4, 3.4):
                col = mix(col, OLIVE_L, 0.35)
        if x in (w // 2 - 1, w // 2) and 3 <= y <= h - 3:
            col = mix(col, OLIVE_D, 0.45)                       # middle seam
        if y == 9 and 2 < x < w - 3:
            col = mix(col, OLIVE_D, 0.3)                        # under the chest
    if f == "back" and x in (w // 2 - 1, w // 2) and y > 2:
        col = mix(col, OLIVE_D, 0.35)
    if y <= 1:
        col = mix(col, OLIVE_D, 0.4)                            # neckline
    if y == h - 2:
        col = mix(col, OLIVE_D, 0.45)                           # hem stitching
    return col


def top_young():
    cubes = [Cube("tank", "body", (0, 3.3, 0), (8.5, 7.0, 4.5), OLIVE, top_young_deco)]
    return build("joseph_young_top", cubes)


# ====================================================================== YOUNG: GLOVES (fingerless, gold rings)
def glove_black(f, x, y, w, h):
    if f in ("top", "bottom"):
        return BLACK_L if f == "top" else BLACK_D
    col = mix(BLACK_L, BLACK, min(1.0, y / max(1, h - 1)))
    if f in ("front", "back") and y >= 1 and x in (3, 5, 7, 9, 11) and h >= 3:
        col = mix(col, BLACK_D, 0.6)                            # knuckle seams
    if y == h - 1:
        col = mix(col, BLACK_D, 0.5)                            # cut-off fingers
    return col


def guard_black(f, x, y, w, h):
    if f in ("top", "bottom"):
        return BLACK_L if f == "top" else BLACK_D
    if y in (2, h - 3):
        return mix(BLACK, BLACK_L, 0.5)                         # stitched seams
    return mix(BLACK_L, BLACK, y / max(1, h - 1))


def bangle(f, x, y, w, h):
    if f in ("top", "bottom"):
        return GOLD_L if f == "top" else GOLD_D
    return GOLD_L if y == 0 else GOLD_D if y == h - 1 else GOLD


def gloves_young():
    cubes = []
    for side, sx, bone in (("r", -1, "right_arm"), ("l", 1, "left_arm")):
        m = side == "l"
        cubes.append(Cube(f"guard_{side}", bone, (sx * 1, 5.6, 0), (4.7, 2.8, 4.7), BLACK, guard_black,
                          twin_of="guard_r" if m else None, mirror=m))
        cubes.append(Cube(f"ring_{side}", bone, (sx * 1, 7.2, 0), (5.1, 1.0, 5.1), GOLD, bangle,
                          twin_of="ring_r" if m else None, mirror=m))
        cubes.append(Cube(f"hand_{side}", bone, (sx * 1, 8.5, 0), (4.6, 1.4, 4.6), BLACK, glove_black,
                          twin_of="hand_r" if m else None, mirror=m))
    return build("joseph_young_gloves", cubes)


# ====================================================================== belts
def belt_young(f, x, y, w, h):
    if f in ("top", "bottom"):
        return BELT_L if f == "top" else BELT_D
    col = mix(BELT_L, BELT, y / max(1, h - 1))
    if f == "front" and 7 <= x <= 10 and y <= h - 1:             # gold buckle with a hole
        if 8 <= x <= 9 and 1 <= y <= h - 2:
            return BELT_D
        return GOLD_L if (x in (7, 10) or y == 0) else GOLD
    if f in ("front", "back") and x in (3, 14):
        return BELT_D                                           # belt loops
    return col


def belt_old(f, x, y, w, h):
    if f in ("top", "bottom"):
        return BELT_O
    col = mix(BELT_O, BELT_OD, y / max(1, h - 1) * 0.6)
    if f == "front" and 7 <= x <= 10:
        if 8 <= x <= 9 and 1 <= y <= h - 2:
            return BELT_OD
        return SILVER if (x in (7, 10) or y in (0, h - 1)) else mix(SILVER, SILVER_D, 0.3)
    if f in ("front", "back") and x in (3, 14):
        return BELT_OD
    return col


# ====================================================================== JEANS / TROUSERS (shared builder)
def jeans():
    def leg(f, x, y, w, h):
        if f in ("top", "bottom"):
            return None
        col = mix(JEAN_L, JEAN, min(1.0, y / max(1, h - 1) * 0.9))
        if f in ("front", "back"):
            if x in (w // 2 - 3, w // 2 - 2) and 4 < y < h - 4:
                col = mix(col, JEAN_L, 0.25)                    # light thigh
            if y in (11, 12, 13) and (x + y) % 3 != 0:
                col = mix(col, JEAN_D, 0.28)                    # knee wrinkles
            if y >= h - 3:
                col = mix(col, JEAN_D, 0.3)                     # hem
        if f in ("right", "left") and x == 0:
            return THREAD                                       # outer seam
        return col

    def waist(f, x, y, w, h):
        if f in ("top", "bottom"):
            return None
        col = mix(JEAN_L, JEAN, 0.3)
        if f == "front":
            if x in (w // 2 - 1, w // 2) and y > 1:
                col = mix(col, JEAN_D, 0.5)                     # fly
            if y == 2 and (x in (2, 3, 4) or x in (w - 5, w - 4, w - 3)):
                col = THREAD                                    # front pockets
        if f == "back":
            for x0 in (2, 10):                                  # back pockets
                if x0 <= x <= x0 + 5 and 1 <= y <= 6:
                    if x in (x0, x0 + 5) or y in (1, 6):
                        col = THREAD
                    else:
                        col = mix(col, JEAN_L, 0.15)
        if y == h - 1:
            col = mix(col, JEAN_D, 0.3)
        return col

    cubes = [
        Cube("waist", "body", (0, 11.4, 0), (8.5, 3.2, 4.544), JEAN, waist),
        Cube("belt", "body", (0, 9.6, 0), (8.8, 1.4, 4.8), BELT, belt_young),
    ]
    leg_pair(cubes, "leg", 5.6, (4.34, 11.8, 4.34), JEAN, leg)
    return build("joseph_young_jeans", cubes)


# ====================================================================== BOOTS (shared builder)
def boots(model_id, base, light, dark, cuff=None, cuff_l=None, laces=None, shaft_top=6.2):
    def shaft(f, x, y, w, h):
        if f in ("top", "bottom"):
            return None
        col = mix(light, base, min(1.0, y / max(1, h - 1) * 1.1))
        if f == "front" and x in (w // 2 - 2, w // 2 - 1) and y < h - 3:
            col = mix(col, light, 0.35)                         # glossy front
        if laces and f == "front" and y % 3 == 1 and 2 <= x <= w - 3:
            col = laces                                         # laces
        if f in ("right", "left") and y in (h - 4, h - 3):
            col = mix(col, dark, 0.3)                           # ankle crease
        return col

    def rim(f, x, y, w, h):
        if f == "top":
            return cuff_l
        if f == "bottom":
            return dark
        return mix(cuff_l, cuff, min(1.0, y / max(1, h - 1) * 1.6)) if y < h - 1 else mix(cuff, dark, 0.4)

    def toe(f, x, y, w, h):
        if f in ("top", "bottom"):
            return mix(light, base, 0.4) if f == "top" else dark
        col = mix(light, base, 0.5 + y / max(1, h - 1) * 0.5)
        return mix(col, dark, 0.3) if f == "front" and y >= h - 2 else col

    cubes = []
    for side, sx in (("r", -1), ("l", 1)):
        m = side == "l"
        ox = sx * 0.1
        bone = "right_leg" if side == "r" else "left_leg"

        def tw(n):
            return None if side == "r" else n + "_r"
        cubes.append(Cube(f"shaft_{side}", bone, (ox, (shaft_top + 11.6) / 2, 0.1), (4.9, 11.6 - shaft_top, 4.9), base, shaft,
                          twin_of=tw("shaft"), mirror=m))
        if cuff:
            cubes.append(Cube(f"cuff_{side}", bone, (ox, shaft_top - 0.5, 0.1), (5.3, 2.0, 5.38), cuff, rim,
                              twin_of=tw("cuff"), mirror=m))
        cubes.append(Cube(f"toe_{side}", bone, (ox, 11.0, -3.15), (4.5, 1.5, 3.4), base, toe, twin_of=tw("toe"), mirror=m))
        cubes.append(Cube(f"sole_{side}", bone, (ox, 11.9, -1.7), (4.9, 0.6, 8.4), dark, None, twin_of=tw("sole"), mirror=m))
    return build(model_id, cubes)


def boots_young():
    return boots("joseph_young_boots", BLACK, BLACK_L, BLACK_D, cuff=CUFF, cuff_l=CUFF_L, shaft_top=6.4)


def boots_old():
    return boots("joseph_old_boots", BROWN, BROWN_L, BROWN_D, laces=(222, 204, 160), shaft_top=8.4)


# ====================================================================== OLD: FEDORA
def d_brim(f, x, y, w, h):
    if f == "top":
        edge = min(x, y, w - 1 - x, h - 1 - y)
        return HAT_L if edge == 0 else mix(HAT_L, HAT, min(1.0, edge / 8.0)) if edge < 8 else HAT
    if f == "bottom":
        return mix(HAT_D, BAND, 0.5)
    return BAND                                                 # binding round the edge


def d_band(f, x, y, w, h):
    if f in ("top", "bottom"):
        return BAND
    if y == 0:
        return BAND_L
    return mix(BAND_L, BAND, 0.6) if y < h - 1 else BAND


def d_crown(f, x, y, w, h):
    if f in ("top", "bottom"):
        return None
    col = mix(HAT_L, HAT, min(1.0, y / max(1, h - 1) * 1.1))
    if f == "front" and x in (w // 2 - 1, w // 2) and y < h - 2:
        col = mix(col, HAT_D, 0.35)                             # the front crease
    if f in ("right", "left") and y < 3:
        col = mix(col, HAT_D, 0.18)
    return col


def d_plate(f, x, y, w, h):
    if f == "top":
        if abs(x - (w - 1) / 2.0) < 1.6:
            return HAT_D                                        # the groove along the crown
        return HAT_L if min(x, y, w - 1 - x, h - 1 - y) == 0 else None
    return None if f != "bottom" else HAT_D


def fedora():
    cubes = [
        Cube("brim", "head", (0, -7.3, 0), (12.6, 0.6, 12.6), HAT, d_brim, pivot=(0, -7.3, 0), rot=(4, 0, 0)),
        Cube("band", "head", (0, -8.0, 0), (9.6, 1.9, 9.6), BAND, d_band),
        Cube("crown", "head", (0, -9.9, 0), (9.2, 2.8, 9.2), HAT, d_crown),
        Cube("plate", "head", (0, -11.5, 0), (7.8, 0.6, 8.4), HAT, d_plate),
    ]
    return build("joseph_old_hat", cubes)


# ====================================================================== OLD: POLO SHIRT
def vhalf(y):
    return max(0.0, 5.0 - y * 0.5)


def polo_front(f, x, y, w, h):
    if f in ("top", "bottom"):
        return None if f == "top" else POLO_D
    col = mix(POLO_L, POLO, min(1.0, y / max(1, h - 1) * 1.1))
    if f == "front":
        dx = abs(x + 0.5 - w / 2.0)
        vh = vhalf(y)
        if y < 9 and dx < vh:
            return mix(TEE, TEE_D, 0.35) if y == 8 or dx > vh - 1 else TEE      # undershirt in the open collar
        if y < 8 and dx < vh + 3.2:
            return POLO_D if dx < vh + 1.0 else mix(POLO_L, POLO, 0.2)          # collar wings with an edge
        for cx in (w * 0.27, w * 0.73):
            if 9 <= y <= 15 and ellipse(x, y, cx, 11.5, 4.4, 3.6):
                col = mix(col, POLO_L, 0.3)                                       # chest muscles
        if x in (w // 2 - 1, w // 2) and y >= 9:
            col = mix(col, POLO_D, 0.5)                                           # placket
            if y in (11, 12, 15, 16):
                col = TEE_D                                                       # buttons
        if y == 17:
            col = mix(col, POLO_D, 0.18)
    if f == "back":
        if y <= 1:
            col = POLO_D                                                          # collar
        if x in (w // 2 - 1, w // 2) and y > 2:
            col = mix(col, POLO_D, 0.2)
    if y >= h - 2:
        col = mix(col, POLO_D, 0.4)                                               # hem
    return col


def sleeve_old(f, x, y, w, h):
    if f == "top":
        return None
    col = mix(POLO_L, POLO, min(1.0, y / max(1, h - 1)))
    if y >= h - 3:
        col = mix(col, POLO_D, 0.28 + 0.1 * (y - (h - 3)))      # cuff band
    if y == h - 4:
        col = mix(POLO_L, POLO, 0.4)
    return col


def shirt_old():
    cubes = [Cube("shirt", "body", (0, 4.5, 0), (8.7, 9.2, 4.7), POLO, polo_front)]
    arm_pair(cubes, "sleeve", 0.6, (4.5, 5.4, 4.5), POLO, sleeve_old)
    return build("joseph_old_shirt", cubes)


# ====================================================================== OLD: GLOVES AND TROUSERS
def glove_white(f, x, y, w, h):
    if f in ("top", "bottom"):
        return WHITE if f == "top" else WHITE_D
    col = mix(WHITE, WHITE_D, y / max(1, h - 1) * 0.5)
    if f in ("front", "back") and y >= 3 and x in (3, 5, 7, 9, 11):
        col = mix(col, WHITE_D, 0.8)                            # fingers
    return col


def wristband(f, x, y, w, h):
    if f in ("top", "bottom"):
        return WRIST_L if f == "top" else WRIST
    if y in (0, h - 1):
        return mix(WRIST, WRIST_L, 0.5)
    return mix(WRIST_L, WRIST, y / max(1, h - 1))


def gloves_old():
    cubes = []
    for side, sx, bone in (("r", -1, "right_arm"), ("l", 1, "left_arm")):
        m = side == "l"
        cubes.append(Cube(f"band_{side}", bone, (sx * 1, 5.4, 0), (4.8, 3.4, 4.8), WRIST, wristband,
                          twin_of="band_r" if m else None, mirror=m))
        cubes.append(Cube(f"hand_{side}", bone, (sx * 1, 8.7, 0), (4.6, 3.0, 4.6), WHITE, glove_white,
                          twin_of="hand_r" if m else None, mirror=m))
    return build("joseph_old_gloves", cubes)


def pants_old():
    def leg(f, x, y, w, h):
        if f in ("top", "bottom"):
            return None
        col = mix(KHAKI_L, KHAKI, min(1.0, y / max(1, h - 1) * 0.9))
        if f in ("front", "back") and x == w // 2 - 1 and y > 2:
            col = mix(col, KHAKI_D, 0.4)                        # crease
        if y >= h - 3:
            col = mix(col, KHAKI_D, 0.3)                        # hem
        return col

    def waist(f, x, y, w, h):
        if f in ("top", "bottom"):
            return None
        col = mix(KHAKI_L, KHAKI, 0.3)
        if f == "front":
            if x in (w // 2 - 1, w // 2) and y > 1:
                col = mix(col, KHAKI_D, 0.5)                    # fly
            for sx in (3, w - 4):                               # slanted front pockets
                if x in (sx, sx + 1) and y >= 2:
                    col = mix(col, KHAKI_D, 0.4)
        if f == "back":
            for x0 in (2, 10):
                if x0 <= x <= x0 + 5 and 1 <= y <= 5 and (x in (x0, x0 + 5) or y in (1, 5)):
                    col = mix(col, KHAKI_D, 0.5)
        return col

    cubes = [
        Cube("waist", "body", (0, 11.4, 0), (8.5, 3.2, 4.544), KHAKI, waist),
        Cube("belt", "body", (0, 9.7, 0), (8.6, 1.4, 4.544), BELT_O, belt_old),
    ]
    leg_pair(cubes, "leg", 5.6, (4.44, 11.8, 4.44), KHAKI, leg)
    return build("joseph_old_pants", cubes)


# ====================================================================== ICONS
def icon_scarf():
    i = Icon()
    i.rect(3, 3, 12, 3, mix(SC_G, (255, 255, 255), 0.25))
    i.rect(2, 4, 13, 5, SC_G)
    i.rect(2, 5, 13, 5, SC_Y)
    i.rect(3, 6, 12, 6, shade(SC_G, 0.84))
    i.rect(8, 5, 11, 8, shade(SC_G, 0.9))
    for y in range(8, 14):
        for x in (8, 9, 10):
            i.put(x, y, SC_Y if x in (8, 10) else SC_G)
    for y in range(8, 12):
        for x in (11, 12, 13):
            i.put(x, y, SC_Y if x in (11, 13) else SC_G)
    i.save("joseph_young_scarf")


def icon_top_young():
    i = Icon()
    blk(i, 3, 2, 12, 9, OLIVE)
    i.rect(3, 2, 4, 3, OLIVE_L); i.rect(11, 2, 12, 3, OLIVE_L)
    i.rect(6, 2, 9, 3, (226, 178, 140))                     # neckline
    for x, y in ((3, 9), (4, 9), (3, 8), (12, 9), (11, 9), (12, 8)):
        i.px.pop((x, y), None)                              # cut-out corners
    i.rect(7, 5, 8, 8, OLIVE_D)
    i.rect(5, 4, 6, 5, OLIVE_L); i.rect(9, 4, 10, 5, OLIVE_L)
    i.rect(4, 10, 11, 12, (226, 178, 140))                  # bare waist
    i.save("joseph_young_top")


def icon_gloves_young():
    i = Icon()
    blk(i, 4, 3, 11, 6, BLACK)
    i.rect(4, 7, 11, 8, GOLD); i.rect(4, 7, 11, 7, GOLD_L)
    blk(i, 3, 9, 12, 12, BLACK)
    for x in (5, 7, 9):
        i.rect(x, 10, x, 11, BLACK_D)
    i.rect(4, 13, 5, 13, (226, 178, 140)); i.rect(7, 13, 8, 13, (226, 178, 140)); i.rect(10, 13, 11, 13, (226, 178, 140))
    i.save("joseph_young_gloves")


def icon_jeans():
    i = Icon()
    blk(i, 2, 4, 13, 5, JEAN)
    i.rect(2, 2, 13, 3, BELT); i.rect(7, 2, 8, 3, GOLD)
    blk(i, 2, 6, 7, 14, JEAN); blk(i, 8, 6, 13, 14, JEAN)
    i.rect(7, 6, 8, 14, JEAN_D)
    i.rect(3, 9, 6, 9, JEAN_D); i.rect(9, 9, 12, 9, JEAN_D)
    i.rect(2, 13, 7, 14, JEAN_D); i.rect(8, 13, 13, 14, JEAN_D)
    i.save("joseph_young_jeans")


def icon_boots(name, base, light, dark, cuff=None, cuff_l=None):
    i = Icon()
    for x0 in (2, 9):
        blk(i, x0, 3, x0 + 4, 11, base)
        i.rect(x0 + 1, 3, x0 + 1, 10, light)
        if cuff:
            blk(i, x0 - 1, 3, x0 + 5, 5, cuff)
            i.rect(x0 - 1, 3, x0 + 5, 3, cuff_l)
        blk(i, x0, 12, x0 + 5, 13, base)
        i.rect(x0, 14, x0 + 5, 14, dark)
    i.save(name)


def icon_fedora():
    i = Icon()
    blk(i, 4, 3, 11, 9, HAT)
    i.rect(6, 3, 9, 3, HAT_D)
    i.rect(4, 8, 11, 9, BAND)
    blk(i, 1, 10, 14, 12, HAT)
    i.rect(1, 12, 14, 12, mix(HAT_D, BAND, 0.5))
    i.save("joseph_old_hat")


def icon_polo():
    i = Icon()
    blk(i, 1, 4, 3, 8, POLO); blk(i, 12, 4, 14, 8, POLO)
    blk(i, 3, 2, 12, 14, POLO)
    for y in range(2, 6):
        for x in range(6 + (y - 2) // 2, 10 - (y - 2) // 2):
            i.put(x, y, TEE)
    for x, y in ((4, 2), (5, 2), (4, 3), (5, 3), (6, 3), (5, 4), (6, 4), (10, 2), (11, 2), (10, 3), (11, 3), (9, 3), (10, 4), (9, 4)):
        i.put(x, y, POLO_L if (x, y) not in ((6, 4), (9, 4)) else POLO_D)
    i.rect(7, 6, 8, 12, POLO_D)
    i.put(7, 8, TEE_D); i.put(7, 11, TEE_D)
    i.rect(3, 14, 12, 14, shade(POLO, 0.8))
    i.save("joseph_old_shirt")


def icon_gloves_old():
    i = Icon()
    blk(i, 4, 3, 11, 7, WRIST)
    blk(i, 3, 8, 12, 12, WHITE)
    for x in (5, 7, 9):
        i.rect(x, 9, x, 12, WHITE_D)
    blk(i, 1, 9, 3, 10, WHITE)
    i.save("joseph_old_gloves")


def icon_pants_old():
    i = Icon()
    blk(i, 2, 4, 13, 5, KHAKI)
    i.rect(2, 2, 13, 3, BELT_O); i.rect(7, 2, 8, 3, SILVER)
    blk(i, 2, 6, 7, 14, KHAKI); blk(i, 8, 6, 13, 14, KHAKI)
    i.rect(7, 6, 8, 14, KHAKI_D)
    i.rect(2, 13, 7, 14, KHAKI_D); i.rect(8, 13, 13, 14, KHAKI_D)
    i.save("joseph_old_pants")


# ====================================================================== REGISTRATION
ITEMS = [
    dict(id="joseph_young_scarf", category="accessory", slot="neck", ru="Зелёный шарф с жёлтыми полосами", en="Green Striped Scarf",
         price=2999, build=scarf, icon=icon_scarf),
    dict(id="joseph_young_top", category="top", ru="Оливковый топ с вырезами по бокам", en="Olive Crop Top with Side Cutouts",
         price=6999, build=top_young, icon=icon_top_young),
    dict(id="joseph_young_gloves", category="accessory", slot=None, ru="Чёрные перчатки без пальцев с золотыми кольцами",
         en="Black Fingerless Gloves with Gold Rings", price=3499, build=gloves_young, icon=icon_gloves_young),
    dict(id="joseph_young_jeans", category="bottom", ru="Синие джинсы с коричневым ремнём", en="Blue Jeans with Brown Belt",
         price=5999, build=jeans, icon=icon_jeans),
    dict(id="joseph_young_boots", category="shoes", ru="Чёрные сапоги с отворотами", en="Black Folded-Cuff Boots",
         price=7499, build=boots_young,
         icon=lambda: icon_boots("joseph_young_boots", BLACK, BLACK_L, BLACK_D, CUFF, CUFF_L)),
    dict(id="joseph_old_hat", category="hat", ru="Коричневая федора", en="Tan Fedora", price=4499, build=fedora, icon=icon_fedora),
    dict(id="joseph_old_shirt", category="top", ru="Оливковая рубашка-поло", en="Olive Polo Shirt", price=6999, build=shirt_old,
         icon=icon_polo),
    dict(id="joseph_old_gloves", category="accessory", slot=None, ru="Белые перчатки с тёмными напульсниками",
         en="White Gloves with Dark Wristbands", price=3299, build=gloves_old, icon=icon_gloves_old),
    dict(id="joseph_old_pants", category="bottom", ru="Брюки цвета хаки с ремнём", en="Khaki Trousers with Belt", price=5499,
         build=pants_old, icon=icon_pants_old),
    dict(id="joseph_old_boots", category="shoes", ru="Коричневые ботинки на шнуровке", en="Brown Laced Boots", price=6499,
         build=boots_old, icon=lambda: icon_boots("joseph_old_boots", BROWN, BROWN_L, BROWN_D)),
]
LOOKS = [
    ("joseph_young", "Джозеф (молодой)", "Joseph (Young)",
     ["joseph_young_top", "joseph_young_jeans", "joseph_young_boots", "joseph_young_scarf", "joseph_young_gloves"]),
    ("joseph_old", "Джозеф (старый)", "Joseph (Old)",
     ["joseph_old_hat", "joseph_old_shirt", "joseph_old_pants", "joseph_old_boots", "joseph_old_gloves"]),
]
DOC_MARK = "## Joseph, young and old"
DOC_TEXT = """
## Joseph, young and old
`python3 tools/gen_joseph.py` regenerates the models, textures, icons and (idempotently) the entries in `clothes.json`, the lang files,
`ClothingCatalog`, `ClothingPrices` and `Looks` (looks `joseph_young` and `joseph_old`; no hairstyle). Run `python3 tools/zfight_cross.py --all` after it.
- Young: `joseph_young_top` (top: ONE box on the `body` bone; its two lower corners are cut out with transparent pixels on the front, back
  and sides, so the bare waist shows; the skin's own jacket layer is hidden while a top is worn), `joseph_young_jeans` (bottom: high waist,
  belt with a gold buckle, back pockets, straight legs), `joseph_young_boots` (shoes: tall boots, a folded grey cuff 0.2 units wider than the
  shaft, so the jeans go inside), `joseph_young_scarf` (accessory, slot `neck`: two rings, a knot, a tail on the chest and two tails on the
  back tilted towards the body so they never go into it) and `joseph_young_gloves` (accessory: black wrist guard, gold ring, a short glove
  that leaves the fingers bare).
- Old: `joseph_old_hat` (fedora: tilted brim 4 degrees, band, crown with a groove painted on the top plate), `joseph_old_shirt` (top: polo with a
  V opening painted as the cream undershirt, collar wings, a placket with buttons, short sleeves), `joseph_old_pants` (bottom: khaki, belt with a
  silver buckle), `joseph_old_boots` (shoes) and `joseph_old_gloves` (accessory: white hand, dark wristband).
- Gloves are in the main accessory slot (like `gloves_*`), so they replace a backpack; the scarf is in its own slot and goes together with them.
"""


def register():
    import json
    res = G.ROOT / "src/main/resources/assets/fittingroom"
    cj = json.loads((res / "clothes.json").read_text(encoding="utf-8"))
    have = {it["id"] for it in cj["items"]}
    for e in ITEMS:
        if e["id"] in have:
            continue
        item = {"id": e["id"], "category": e["category"]}
        if e.get("slot"):
            item["slot"] = e["slot"]
        item.update({"name": {"ru_ru": e["ru"], "en_us": e["en"]},
                     "model": f"fittingroom:clothes_models/{e['id']}.json",
                     "texture": f"fittingroom:textures/clothes/{e['id']}.png",
                     "icon": f"fittingroom:textures/gui/clothes/{e['id']}.png"})
        cj["items"].append(item)
    (res / "clothes.json").write_text(json.dumps(cj, ensure_ascii=False) + "\n", encoding="utf-8")

    for lang, key, idx in (("ru_ru", "ru", 1), ("en_us", "en", 2)):
        path = res / f"lang/{lang}.json"
        data = json.loads(path.read_text(encoding="utf-8"))
        for e in ITEMS:
            data.setdefault(f"clothes.fittingroom.{e['id']}", e[key])
        for lk in LOOKS:
            data.setdefault(f"look.fittingroom.{lk[0]}", lk[idx])
        path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    java = G.ROOT / "src/main/java/com/fittingroom/wardrobe/ClothingCatalog.java"
    text = java.read_text(encoding="utf-8")
    close = "\n    );\n\n    private static final Map<String, Item> BY_ID"
    cat = {"top": "TOP", "bottom": "BOTTOM", "hat": "HAT", "shoes": "SHOES", "accessory": "ACCESSORY"}
    lines = []
    for e in ITEMS:
        if f'"{e["id"]}"' in text:
            continue
        if e.get("slot") == "neck":
            lines.append(f'            scarf("{e["id"]}")')
        elif e.get("slot") in ("tie", "wrist"):
            lines.append(f'            jewel("{e["id"]}", {e["slot"].upper()})')
        else:
            lines.append(f'            new Item("{e["id"]}", Category.{cat[e["category"]]})')
    if lines:
        assert close in text, "end of the item list not found"
        java.write_text(text.replace(close, ",\n" + ",\n".join(lines) + close), encoding="utf-8")

    prices = G.ROOT / "src/main/java/com/fittingroom/wardrobe/ClothingPrices.java"
    text = prices.read_text(encoding="utf-8")
    anchor = "        // ---- scarves ----\n"
    assert anchor in text, "anchor for the prices not found"
    add = "".join(f'        p("{e["id"]}", {e["price"]});\n' for e in ITEMS if f'"{e["id"]}"' not in text)
    if add:
        prices.write_text(text.replace(anchor, "        // ---- Joseph, young and old ----\n" + add + "\n" + anchor, 1), encoding="utf-8")

    looks = G.ROOT / "src/main/java/com/fittingroom/wardrobe/Looks.java"
    text = looks.read_text(encoding="utf-8")
    for lid, _ru, _en, ids in LOOKS:
        if f'"{lid}"' in text:
            continue
        end = text.index("\n    );", text.index("public static final List<Look> ALL = List.of("))
        add = f',\n            new Look("{lid}", List.of(' + ", ".join(f'"{i}"' for i in ids) + "))"
        text = text[:end] + add + text[end:]
    looks.write_text(text, encoding="utf-8")

    doc = G.ROOT / "docs/clothes-models.md"
    text = doc.read_text(encoding="utf-8")
    if DOC_MARK not in text:
        doc.write_text(text.rstrip("\n") + "\n" + DOC_TEXT, encoding="utf-8")


if __name__ == "__main__":
    for e in ITEMS:
        e["build"]()
        e["icon"]()
    register()
    print("generated:", ", ".join(e["id"] for e in ITEMS))
    if "--preview" in sys.argv:
        G.preview([e["id"] for e in ITEMS if e["id"].startswith("joseph_young")], ITEMS, "joseph_young")
        G.preview([e["id"] for e in ITEMS if e["id"].startswith("joseph_old")], ITEMS, "joseph_old")
