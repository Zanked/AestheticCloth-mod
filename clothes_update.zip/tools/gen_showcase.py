#!/usr/bin/env python3
"""
Generates the mannequin (textures 32x32 per block face, models, blockstates, loot, recipes).

    mannequin     two blocks tall, drawn by a block entity renderer on top of a stand (rod + marble plate).
                  The figure is a normal player model with the texture textures/entity/mannequin.png
                  (128x128 = the vanilla 64x64 layout at 2 px per unit, like the garments).
                  Up to three garment icons stand inside, with their price on the front.

Run from the project root:  python3 tools/gen_showcase.py
The palette is the one of the fitting room (mint, pink, cream, gold).
"""
import json
import math
from pathlib import Path

from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parent.parent
ASSETS = ROOT / "src/main/resources/assets/fittingroom"
DATA = ROOT / "src/main/resources/data/fittingroom"
BLOCK_TEX = ASSETS / "textures/block"
ENTITY_TEX = ASSETS / "textures/entity"
ITEM_TEX = ASSETS / "textures/item"
MODELS = ASSETS / "models"

# ------------------------------------------------------------------ palette
GOLD = (243, 199, 87)
GOLD_L = (255, 233, 157)
GOLD_D = (214, 160, 54)
GOLD_LL = (255, 247, 214)
MINT = (151, 197, 187)
MINT_L = (168, 209, 197)
MINT_D = (126, 174, 164)
CREAM = (255, 251, 240)
PINK = (246, 170, 184)
PINK_L = (252, 196, 204)
PINK_D = (214, 120, 140)
LEAF = (110, 170, 140)
IVORY = (243, 230, 211)
IVORY_L = (253, 246, 233)
IVORY_D = (213, 192, 170)
SEAM = (196, 172, 146)


def clamp(v):
    return max(0, min(255, int(round(v))))


def mix(a, b, t):
    return tuple(clamp(a[i] + (b[i] - a[i]) * t) for i in range(3))


def light(c, f):
    return tuple(clamp(v * f) for v in c)


def noise(x, y, seed=0):
    """Deterministic value in -1..1 for a pixel."""
    n = (x * 374761393 + y * 668265263 + seed * 2147483647) & 0xFFFFFFFF
    n = (n ^ (n >> 13)) * 1274126177 & 0xFFFFFFFF
    n ^= n >> 16
    return (n & 0xFFFF) / 32767.5 - 1.0


def smooth_noise(x, y, cell, seed=0):
    """Soft value noise (bilinear between random cell corners)."""
    gx, gy = x / cell, y / cell
    x0, y0 = int(math.floor(gx)), int(math.floor(gy))
    fx, fy = gx - x0, gy - y0
    fx = fx * fx * (3 - 2 * fx)
    fy = fy * fy * (3 - 2 * fy)
    a = noise(x0, y0, seed)
    b = noise(x0 + 1, y0, seed)
    c = noise(x0, y0 + 1, seed)
    d = noise(x0 + 1, y0 + 1, seed)
    return (a * (1 - fx) + b * fx) * (1 - fy) + (c * (1 - fx) + d * fx) * fy


def write_json(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")


# ================================================================== block textures (32x32)
def tex_marble():
    im = Image.new("RGB", (32, 32))
    px = im.load()
    for y in range(32):
        for x in range(32):
            c = (249, 241, 231)
            cloud = smooth_noise(x, y, 8, 3)
            c = mix(c, (236, 222, 214), max(0.0, cloud) * 0.55)
            # veins: thin bands along a wobbling diagonal
            v = math.sin((x * 0.42 + y * 0.77) + smooth_noise(x, y, 6, 9) * 3.2)
            if abs(v) < 0.09:
                c = mix(c, (205, 184, 184), 0.75)
            elif abs(v) < 0.2:
                c = mix(c, (225, 207, 204), 0.35)
            c = light(c, 1 + noise(x, y, 5) * 0.012)
            if x == 0 or y == 0:
                c = mix(c, (255, 255, 252), 0.65)
            if x == 31 or y == 31:
                c = mix(c, (214, 196, 186), 0.6)
            px[x, y] = c
    return im


def rose(px, cx, cy):
    """A small 7x7 pixel rose with two leaves (same flower as on the fitting room wallpaper, a bit bigger)."""
    leaf = [(-4, 1), (-3, 2), (-3, 1), (-2, 2), (4, 1), (3, 2), (3, 1), (2, 2)]
    for dx, dy in leaf:
        px[cx + dx, cy + dy] = LEAF if (dx + dy) % 2 else mix(LEAF, (80, 140, 112), 0.5)
    petals = {
        (-1, -3): PINK_L, (0, -3): PINK_L, (1, -3): PINK,
        (-2, -2): PINK_L, (-1, -2): PINK, (0, -2): PINK, (1, -2): PINK, (2, -2): PINK,
        (-3, -1): PINK, (-2, -1): PINK, (-1, -1): PINK_D, (0, -1): PINK, (1, -1): PINK_D, (2, -1): PINK, (3, -1): PINK_D,
        (-3, 0): PINK, (-2, 0): PINK_D, (-1, 0): PINK, (0, 0): PINK_D, (1, 0): PINK, (2, 0): PINK_D, (3, 0): PINK,
        (-3, 1): PINK_D, (-2, 1): PINK, (-1, 1): PINK_D, (0, 1): PINK, (1, 1): PINK_D, (2, 1): PINK, (3, 1): PINK_D,
        (-2, 2): PINK_D, (-1, 2): PINK, (0, 2): PINK_D, (1, 2): PINK, (2, 2): PINK_D,
        (-1, 3): PINK_D, (0, 3): PINK_D, (1, 3): PINK_D,
    }
    for (dx, dy), c in petals.items():
        px[cx + dx, cy + dy] = c
    px[cx, cy] = (200, 96, 120)


def tex_cabinet_panel():
    im = Image.new("RGB", (32, 32))
    px = im.load()
    for y in range(32):
        for x in range(32):
            edge = min(x, y, 31 - x, 31 - y)
            n = noise(x, y, 11) * 3
            if edge < 3:                      # frame: slightly darker, lit from the top left
                c = MINT if (x + y) % 2 == 0 else mix(MINT, MINT_L, 0.5)
                c = light(c, 0.97 + (0.05 if (y < 3 or x < 3) and edge < 1 else 0))
            else:                             # inset panel: soft vertical gradient
                c = mix(MINT_L, MINT, (y - 3) / 40.0)
                if (x + y) % 2 == 0:
                    c = mix(c, MINT_L, 0.25)
            px[x, y] = tuple(clamp(v + n) for v in c)
    # shadow just inside the frame (top and left), highlight at the bottom and right: the panel looks sunken
    for i in range(3, 29):
        px[i, 3] = mix(MINT_D, MINT, 0.3)
        px[3, i] = mix(MINT_D, MINT, 0.3)
        px[i, 28] = mix(MINT_L, CREAM, 0.6)
        px[28, i] = mix(MINT_L, CREAM, 0.6)
    # thin gold inlay around the panel
    for i in range(4, 28):
        for (x, y) in ((i, 4), (i, 27), (4, i), (27, i)):
            px[x, y] = GOLD if (i % 6) else GOLD_L
    for (x, y) in ((4, 4), (27, 4), (4, 27), (27, 27)):
        px[x, y] = GOLD_LL
    # gold corner dots
    for (x, y) in ((6, 6), (25, 6), (6, 25), (25, 25)):
        px[x, y] = GOLD_D
        px[x + 1, y] = GOLD
        px[x, y + 1] = GOLD
        px[x + 1, y + 1] = GOLD_L
    rose(px, 15, 15)
    # sparkles
    for (x, y) in ((9, 11), (22, 9), (21, 22), (10, 21)):
        px[x, y] = CREAM
    return im


def tex_velvet():
    im = Image.new("RGB", (32, 32))
    px = im.load()
    for y in range(32):
        for x in range(32):
            t = (x + y) / 62.0
            c = mix((248, 202, 214), (222, 150, 172), t)
            c = light(c, 1 + noise(x, y, 21) * 0.025)
            # quilted diamonds
            d1 = (x + y) % 16
            d2 = (x - y) % 16
            if d1 == 0 or d2 == 0:
                c = light(c, 0.9)
            elif d1 == 1 or d2 == 1:
                c = light(c, 1.04)
            px[x, y] = c
    # tufting buttons at the crossings
    for gx in (8, 24):
        for gy in (8, 24):
            px[gx, gy] = (176, 98, 124)
            px[gx - 1, gy - 1] = (255, 226, 232)
    # stitched gold border
    for i in range(2, 30):
        if i % 3 != 2:
            for (x, y) in ((i, 2), (i, 29), (2, i), (29, i)):
                px[x, y] = GOLD
    return im


def tex_glass():
    im = Image.new("RGBA", (32, 32))
    px = im.load()
    for y in range(32):
        for x in range(32):
            c = (214, 238, 248, 40)
            s = (x + y) % 32
            if 7 <= s < 10:
                c = (245, 252, 255, 105)
            elif 15 <= s < 17:
                c = (245, 252, 255, 64)
            edge = min(x, y, 31 - x, 31 - y)
            if edge == 0:
                c = (236, 248, 255, 125)
            elif edge == 1:
                c = (226, 244, 252, 66)
            px[x, y] = c
    for (x, y) in ((6, 5), (24, 12), (13, 24), (27, 27)):
        px[x, y] = (255, 255, 255, 215)
    return im


# ================================================================== mannequin skin (128x128, vanilla layout x2)
S = 2


def paint_box(img, u, v, w, h, d, painter):
    faces = {
        "top": (u + d, v, w, d),
        "bottom": (u + d + w, v, w, d),
        "right": (u, v + d, d, h),
        "front": (u + d, v + d, w, h),
        "left": (u + d + w, v + d, d, h),
        "back": (u + d + w + d, v + d, w, h),
    }
    px = img.load()
    for name, (fx, fy, fw, fh) in faces.items():
        W, H = fw * S, fh * S
        for py in range(H):
            for pxl in range(W):
                c = painter(name, pxl, py, W, H)
                if c is not None:
                    px[fx * S + pxl, fy * S + py] = c + (255,)


def body_colour(name, x, y, W, H, seed):
    """Soft ivory with a gentle cylinder shading."""
    u = (x + 0.5) / W * 2 - 1
    if name in ("front", "back"):
        f = 1.0 - 0.085 * u * u
    elif name in ("left", "right"):
        f = 0.93 + 0.04 * (1 - abs(u))
    elif name == "top":
        f = 1.03
    else:
        f = 0.82
    t = y / max(1, H - 1)
    c = mix(IVORY_L, IVORY, min(1.0, t * 1.6)) if name not in ("top", "bottom") else IVORY
    c = mix(c, IVORY_D, max(0.0, t - 0.6) * 0.45) if name not in ("top", "bottom") else c
    c = light(c, f)
    return light(c, 1 + noise(x, y, seed) * 0.012)


def ring(c_y0, c_y1):
    """Gold ring across rows c_y0..c_y1 (inclusive): dark edge, gold, highlight."""
    def paint(name, x, y, W, H, base):
        if name in ("top", "bottom"):
            return base
        if y == c_y0:
            return GOLD_D
        if y == c_y1:
            return mix(GOLD, GOLD_L, 0.4) if (x // 2) % 3 else GOLD_LL
        if c_y0 < y < c_y1:
            return GOLD if (x // 3) % 4 else GOLD_L
        return base
    return paint


def seam(row):
    def paint(name, x, y, W, H, base):
        if name in ("top", "bottom"):
            return base
        if y == row:
            return SEAM
        if y == row + 1:
            return mix(base, IVORY_L, 0.5)
        return base
    return paint


def make_painter(seed, layers):
    def painter(name, x, y, W, H):
        c = body_colour(name, x, y, W, H, seed)
        for layer in layers:
            c = layer(name, x, y, W, H, c)
        return c
    return painter


def face_layer(name, x, y, W, H, base):
    """Faceless face: sunken eye line, a nose, a hint of lips and cheeks. W = H = 16 px."""
    if name != "front":
        return base
    c = base
    # cheeks
    for cx in (3.5, 12.5):
        d = math.hypot(x - cx, y - 10.5)
        if d < 2.6:
            c = mix(c, (250, 205, 200), (1 - d / 2.6) * 0.55)
    # eye hollows (soft)
    for cx in (4.5, 11.5):
        d = math.hypot((x - cx) * 0.8, y - 7.0)
        if d < 2.4:
            c = mix(c, IVORY_D, (1 - d / 2.4) * 0.8)
    # nose: highlight with shadow on the right
    if x in (7, 8) and 7 <= y <= 10:
        c = mix(c, IVORY_L, 0.75) if x == 7 else mix(c, IVORY_D, 0.5)
    if y == 11 and x in (7, 8):
        c = mix(c, IVORY_D, 0.45)
    # lips
    if y == 13 and 6 <= x <= 9:
        c = mix(c, (232, 160, 168), 0.7)
    if y == 14 and 7 <= x <= 8:
        c = mix(c, (240, 186, 190), 0.55)
    return c


def head_layers():
    neck = ring(13, 15)

    def top_seam(name, x, y, W, H, base):
        if name == "top" and x in (7, 8):
            return SEAM if x == 7 else mix(base, IVORY_L, 0.5)
        if name == "back" and x in (7, 8) and y < 13:
            return SEAM if x == 7 else mix(base, IVORY_L, 0.5)
        return base
    return [face_layer, top_seam, neck]


def tex_mannequin_skin():
    img = Image.new("RGBA", (64 * S, 64 * S), (0, 0, 0, 0))
    # head 8x8x8 -> faces 16 px
    paint_box(img, 0, 0, 8, 8, 8, make_painter(1, head_layers()))
    # body 8x12x4: shoulder seam, waist ring, hip seam
    body = [seam(1), ring(14, 16), seam(21)]
    paint_box(img, 16, 16, 8, 12, 4, make_painter(2, body))
    # arms 4x12x4: shoulder seam, elbow seam, gold wrist ring
    arm = [seam(1), seam(13), ring(20, 22)]
    paint_box(img, 40, 16, 4, 12, 4, make_painter(3, arm))
    paint_box(img, 32, 48, 4, 12, 4, make_painter(4, arm))
    # legs 4x12x4: hip seam, knee seam, gold ankle ring
    leg = [seam(1), seam(13), ring(20, 22)]
    paint_box(img, 0, 16, 4, 12, 4, make_painter(5, leg))
    paint_box(img, 16, 48, 4, 12, 4, make_painter(6, leg))
    return img


# ================================================================== item icon (32x32)
def tex_item_mannequin():
    K = 8
    big = Image.new("RGBA", (32 * K, 32 * K), (0, 0, 0, 0))
    d = ImageDraw.Draw(big)

    def e(box, fill):
        d.ellipse([v * K for v in box], fill=fill)

    def poly(points, fill):
        flat = list(points[0]) if len(points) == 1 else [v for pt in points for v in pt]
        d.polygon([(flat[i] * K, flat[i + 1] * K) for i in range(0, len(flat), 2)], fill=fill)

    def rect(box, fill):
        d.rectangle([v * K for v in box], fill=fill)

    # plate: gold rim + marble top
    e((6, 26.2, 26, 30.6), GOLD_D + (255,))
    e((6, 25.2, 26, 29.6), GOLD + (255,))
    e((7.4, 25.6, 24.6, 28.6), (249, 241, 231, 255))
    # rod
    rect((15.2, 19, 16.8, 27), GOLD + (255,))
    rect((15.2, 19, 15.8, 27), GOLD_L + (255,))
    # legs
    poly([(12.3, 18, 15.7, 18, 15.2, 26.3, 13.0, 26.3)], IVORY + (255,))
    poly([(16.3, 18, 19.7, 18, 19.0, 26.3, 16.8, 26.3)], IVORY_D + (255,))
    # torso
    poly([(10.4, 7.2, 21.6, 7.2, 20.4, 12.5, 19.6, 18.6, 12.4, 18.6, 11.6, 12.5)], IVORY + (255,))
    poly([(10.4, 7.2, 14.2, 7.2, 13.6, 12.5, 13.2, 18.6, 12.4, 18.6, 11.6, 12.5)], IVORY_L + (255,))
    poly([(18.6, 7.2, 21.6, 7.2, 20.4, 12.5, 19.6, 18.6, 18.0, 18.6, 18.8, 12.5)], IVORY_D + (255,))
    # arms
    poly([(8.0, 8.2, 10.6, 7.4, 11.2, 16.6, 9.0, 17.2)], IVORY_D + (255,))
    poly([(24.0, 8.2, 21.4, 7.4, 20.8, 16.6, 23.0, 17.2)], IVORY_D + (255,))
    # seams: between the legs, between arms and torso, hip line
    rect((15.75, 18.4, 16.25, 26.2), SEAM + (255,))
    poly([(10.5, 8.0, 11.0, 8.0, 11.7, 16.8, 11.2, 16.8)], SEAM + (255,))
    poly([(21.5, 8.0, 21.0, 8.0, 20.3, 16.8, 20.8, 16.8)], SEAM + (255,))
    rect((12.4, 18.0, 19.6, 18.5), SEAM + (255,))
    # waist ring
    rect((11.6, 13.4, 20.4, 14.5), GOLD + (255,))
    # neck ring + head
    rect((14.0, 5.6, 18.0, 7.4), GOLD + (255,))
    e((12.2, 0.8, 19.8, 6.4), IVORY + (255,))
    e((12.2, 0.8, 16.0, 6.4), IVORY_L + (255,))
    small = big.resize((32, 32), Image.LANCZOS)
    px = small.load()
    # crisp alpha, then a soft dark outline around the figure
    base = {}
    for y in range(32):
        for x in range(32):
            r, g, b, a = px[x, y]
            if a > 110:
                base[(x, y)] = (r, g, b)
    out = Image.new("RGBA", (32, 32), (0, 0, 0, 0))
    op = out.load()
    for (x, y), c in base.items():
        op[x, y] = c + (255,)
    for (x, y) in list(base):
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            n = (x + dx, y + dy)
            if 0 <= n[0] < 32 and 0 <= n[1] < 32 and n not in base:
                op[n] = (160, 128, 112, 255)
    # a few sparkles on the gold
    for (x, y) in ((10, 28), (21, 27)):
        if (x, y) in base:
            op[x, y] = GOLD_LL + (255,)
    return out


# ================================================================== models
def faces_of(tex_all=None, **per_face):
    f = {}
    for name in ("north", "east", "south", "west", "up", "down"):
        t = per_face.get(name, tex_all)
        if t:
            f[name] = {"texture": "#" + t}
    return f


def element(frm, to, tex=None, **per_face):
    return {"from": list(frm), "to": list(to), "faces": faces_of(tex, **per_face)}


def block_display(parent_scale=0.62):
    src = json.loads((MODELS / "item/fitting_room.json").read_text())
    disp = src["display"]
    disp["gui"]["scale"] = [parent_scale] * 3
    return disp


def build_models():
    # ---- mannequin stand (the figure itself is drawn by the renderer)
    tex = {
        "particle": "fittingroom:block/gold",
        "gold": "fittingroom:block/gold",
        "marble": "fittingroom:block/mannequin_marble",
    }
    lower = {
        "render_type": "minecraft:cutout",
        "textures": tex,
        "elements": [
            element((1.5, 0, 1.5), (14.5, 0.5, 14.5), "gold"),
            element((2, 0.5, 2), (14, 1, 14), "marble", up="marble"),
            element((7, 1, 10.7), (9, 1.8, 12.7), "gold"),       # collar of the rod
            element((7.5, 1.8, 11.2), (8.5, 16, 12.2), "gold"),  # rod (behind the figure's back)
        ],
    }
    upper = {
        "render_type": "minecraft:cutout",
        "textures": tex,
        "elements": [
            element((7.5, 0, 11.2), (8.5, 7, 12.2), "gold"),
            element((7.2, 7, 10.9), (8.8, 7.8, 12.5), "gold"),   # cap under the shoulder blades
        ],
    }
    write_json(MODELS / "block/mannequin_lower.json", lower)
    write_json(MODELS / "block/mannequin_upper.json", upper)
    write_json(MODELS / "item/mannequin.json", {"parent": "minecraft:item/generated",
                                                "textures": {"layer0": "fittingroom:item/mannequin"}})


def build_blockstates():
    rot = {"north": 0, "east": 90, "south": 180, "west": 270}
    ms = {}
    for facing, y in rot.items():
        for half in ("lower", "upper"):
            v = {"model": f"fittingroom:block/mannequin_{half}"}
            if y:
                v["y"] = y
            ms[f"facing={facing},half={half}"] = v
    write_json(ASSETS / "blockstates/mannequin.json", {"variants": ms})


def build_data():
    def loot(name, lower_only):
        pool = {"rolls": 1.0, "bonus_rolls": 0.0, "conditions": [],
                "entries": [{"type": "minecraft:item", "name": f"fittingroom:{name}",
                             "conditions": [{"condition": "minecraft:survives_explosion"}]}]}
        if lower_only:
            pool["conditions"].append({"condition": "minecraft:block_state_property",
                                       "block": f"fittingroom:{name}", "properties": {"half": "lower"}})
        else:
            del pool["conditions"]
        write_json(DATA / f"loot_table/blocks/{name}.json",
                   {"type": "minecraft:block", "pools": [pool], "random_sequence": f"fittingroom:blocks/{name}"})

    loot("mannequin", True)

    write_json(DATA / "recipe/mannequin.json", {
        "type": "minecraft:crafting_shaped", "category": "building",
        "key": {"W": {"item": "minecraft:white_wool"}, "Q": {"item": "minecraft:quartz"},
                "S": {"item": "minecraft:stick"}, "G": {"item": "minecraft:gold_ingot"}},
        "pattern": [" W ", "QSQ", " G "],
        "result": {"id": "fittingroom:mannequin", "count": 1}})


def main():
    for p in (BLOCK_TEX, ENTITY_TEX, ITEM_TEX):
        p.mkdir(parents=True, exist_ok=True)
    tex_marble().save(BLOCK_TEX / "mannequin_marble.png")
    tex_mannequin_skin().save(ENTITY_TEX / "mannequin.png")
    tex_item_mannequin().save(ITEM_TEX / "mannequin.png")
    build_models()
    build_blockstates()
    build_data()
    print("showcase generated")


if __name__ == "__main__":
    main()
