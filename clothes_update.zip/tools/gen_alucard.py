#!/usr/bin/env python3
"""
Generates the outfit of Alucard (Hellsing), no hairstyle:
  alucard_hat      (hat)        wide red hat with a dark band and a silver buckle
  alucard_glasses  (accessory)  round orange glasses
  alucard_coat     (top)        long red coat with a black lining, a black double-breasted vest with a white shirt inside, tall collar,
                                a short cape over the shoulders
  alucard_cravat   (accessory, slot tie)   red cravat
  alucard_gloves   (accessory, slot wrist) white gloves with a red pentagram on the hands
  alucard_pants    (bottom)     black trousers
  alucard_boots    (shoes)      tall black boots
Look "alucard". Run:  python3 tools/gen_alucard.py ; python3 tools/zfight_cross.py --all --only=alucard_ ; python3 tools/zfight.py --check
Registration is shared with gen_joseph.py.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import gen_giorno as G  # noqa: E402
import gen_joseph as J  # noqa: E402
from gen_dino import blk, build, mix  # noqa: E402
from gen_accessories import Cube, Icon, ZF, bridge, temples  # noqa: E402
from gen_outerwear import arm_pair, leg_pair  # noqa: E402

ellipse = J.ellipse
RED, RED_D, RED_L = (172, 30, 44), (118, 18, 30), (206, 56, 66)
BLK, BLK_L = (26, 26, 30), (64, 64, 72)
VEST, VEST_L = (40, 40, 46), (66, 66, 76)
WHITE, WHITE_D = (240, 240, 244), (190, 192, 204)
SILVER, SILVER_D = (206, 210, 222), (140, 146, 164)
ORANGE, ORANGE_L = (244, 150, 28), (255, 214, 120)
PENT = (196, 32, 44)


def red(y, h):
    return mix(RED_L, RED, min(1.0, y / max(1, h - 1) * 1.3))


# ====================================================================== COAT
def vest_deco(f, x, y, w, h):
    if f in ("top", "bottom"):
        return None if f == "top" else BLK
    col = mix(VEST_L, VEST, min(1.0, y / max(1, h - 1)))
    if f == "front":
        dx = abs(x + 0.5 - w / 2.0)
        if y < 7 and dx < 4.6 - y * 0.55:
            return WHITE if dx > 0.6 or y < 2 else WHITE_D           # white shirt in the V of the vest
        for cx in (w / 2.0 - 3.5, w / 2.0 + 2.5):                    # two rows of buttons
            for by in (8, 11, 14, 17):
                if abs(x - cx) < 1.0 and by <= y <= by + 1:
                    col = SILVER if y == by else SILVER_D
    return col


def panel_deco(side):
    def d(f, x, y, w, h):
        if f in ("top", "bottom"):
            return None if f == "top" else BLK
        if f in ("right", "left"):
            return mix(RED, RED_D, 0.3)
        if f == "back":
            return BLK
        di = (w - 1 - x) if side == "r" else x                       # distance from the inner edge
        if di < 1:
            return BLK                                               # black lining along the opening
        if di < 2:
            return RED_D
        return red(y, h)
    return d


def back_deco(f, x, y, w, h):
    if f in ("top", "bottom"):
        return None
    return red(y, h)


def skirt_deco(f, x, y, w, h):
    if f == "bottom":
        return BLK
    if f == "front":
        if x in (w // 2 - 1, w // 2):
            return BLK                                               # the opening of the long coat
        if x in (w // 2 - 2, w // 2 + 1):
            return RED_D
    return red(y, h) if f != "top" else None


def collar_deco(inner):
    def d(f, x, y, w, h):
        if f in ("top", "bottom"):
            return RED_L if f == "top" else BLK
        if f == inner:
            return BLK
        return red(y, h)
    return d


def collar_plate(side):
    def d(f, x, y, w, h):
        if f == "top":
            return RED_L
        if f == "bottom":
            return BLK
        if f == "back":
            return red(y, h)                                         # red outside seen from behind
        di = (w - 1 - x) if side == "r" else x                       # distance from the neck side
        if f == "front":
            return BLK if di < 1 or y == 0 else red(y, h)
        return RED_D
    return d


def collar_back(f, x, y, w, h):
    if f == "top":
        return RED_L
    if f == "bottom":
        return BLK
    if f == "front":
        return BLK                                                   # the inside of the collar faces the head
    return RED_D if y == 0 else red(y, h)


def sleeve_deco(f, x, y, w, h):
    if f == "top":
        return None
    if y >= h - 2:
        return RED_D
    return red(y, h)


def cape_deco(f, x, y, w, h):
    if f == "top":
        return None
    if f == "bottom":
        return BLK
    return BLK if y == h - 1 else red(y, h)


def coat():
    cubes = [
        Cube("vest", "body", (0, 6.1, 0), (8.7, 12.2, 4.7), VEST, vest_deco),
        Cube("back", "body", (0, 6.6, 1.1), (9.9, 13.2, 3.7), RED, back_deco),
        Cube("panel_r", "body", (-3.45, 6.6, -1.85), (3.0, 13.2, 2.2), RED, panel_deco("r")),
        Cube("panel_l", "body", (3.45, 6.6, -1.85), (3.0, 13.2, 2.2), RED, panel_deco("l")),
        Cube("skirt", "body", (0, 16.9, 0), (10.3, 9.0, 6.1), RED, skirt_deco),
                Cube("cape_back", "body", (0, 1.7, 1.9), (10.2, 3.6, 3.2), RED, cape_deco),
    ]
    arm_pair(cubes, "sleeve", 4.0, (5.5, 12.6, 5.5), RED, sleeve_deco)
    arm_pair(cubes, "cape", 0.2, (6.5, 4.4, 6.5), RED, cape_deco)
    return build("alucard_coat", cubes)


# ====================================================================== PANTS
def pants():
    def leg(f, x, y, w, h):
        if f in ("top", "bottom"):
            return None
        col = mix(VEST_L, BLK, min(1.0, y / max(1, h - 1) * 1.1))
        if f in ("front", "back") and x == w // 2 and y > 2:
            col = mix(col, BLK_L, 0.35)                              # crease
        return col

    def waist(f, x, y, w, h):
        if f in ("top", "bottom"):
            return None
        return mix(VEST_L, BLK, 0.5)

    def belt(f, x, y, w, h):
        if f in ("top", "bottom"):
            return BLK
        if f == "front" and 7 <= x <= 10:
            return SILVER if (x in (7, 10) or y == 0) else BLK
        return mix(BLK_L, BLK, 0.5)

    cubes = [
        Cube("waist", "body", (0, 11.4, 0), (8.5, 3.2, 4.544), BLK, waist),
        Cube("belt", "body", (0, 9.8, 0), (8.6, 1.2, 4.544), BLK, belt),
    ]
    leg_pair(cubes, "leg", 5.6, (4.34, 11.8, 4.34), BLK, leg)
    return build("alucard_pants", cubes)


def boots():
    return J.boots("alucard_boots", (34, 30, 34), (84, 78, 86), (16, 14, 18), shaft_top=4.4)


# ====================================================================== HAT
def d_brim(f, x, y, w, h):
    if f == "top":
        edge = min(x, y, w - 1 - x, h - 1 - y)
        return RED_D if edge == 0 else mix(RED_L, RED, min(1.0, edge / 6.0))
    return BLK if f == "bottom" else RED_D


def d_band(f, x, y, w, h):
    if f in ("top", "bottom"):
        return BLK
    if f == "front" and 7 <= x <= w - 8:
        inner = 9 <= x <= w - 10 and 2 <= y <= h - 3
        if inner:
            return BLK
        return SILVER if (x in (7, w - 8) or y in (1, h - 2)) else SILVER_D
    return BLK_L if y == 0 else BLK


def d_crown(f, x, y, w, h):
    if f in ("top", "bottom"):
        return None
    return mix(RED_L, RED, min(1.0, y / max(1, h - 1) * 1.2))


def d_plate(f, x, y, w, h):
    if f == "top":
        if abs(x - (w - 1) / 2.0) < 1.4 and 2 <= y <= h - 3:
            return RED_D                                             # the soft dent of the crown
        return RED_L
    return RED_D if f == "bottom" else None


def hat():
    cubes = [
        # brim: a flat middle and four long slabs that droop (each one turned down round its inner edge)
        Cube("brim", "head", (0, -7.3, 0), (11.0, 0.5, 11.0), RED, d_brim),
        Cube("brim_f", "head", (0, -7.3, -7.3), (16.0, 0.5, 4.2), RED, d_brim, pivot=(0, -7.3, -5.2), rot=(16, 0, 0)),
        Cube("brim_b", "head", (0, -7.3, 7.3), (16.0, 0.5, 4.2), RED, d_brim, pivot=(0, -7.3, 5.2), rot=(-16, 0, 0)),
        Cube("brim_r", "head", (-7.3, -7.3, 0), (4.2, 0.5, 10.6), RED, d_brim, pivot=(-5.2, -7.3, 0), rot=(0, 0, -16)),
        Cube("brim_l", "head", (7.3, -7.3, 0), (4.2, 0.5, 10.6), RED, d_brim, pivot=(5.2, -7.3, 0), rot=(0, 0, 16)),
        Cube("band", "head", (0, -8.1, 0), (9.9, 1.8, 9.9), BLK, d_band),
        Cube("crown", "head", (0, -11.1, 0), (9.4, 4.8, 9.4), RED, d_crown),
        Cube("plate", "head", (0, -13.75, 0), (8.4, 0.5, 8.8), RED, d_plate),
    ]
    return build("alucard_hat", cubes)


# ====================================================================== GLASSES
def glasses():
    # every lens is a plus-shaped (rounded) pair of boxes: a wide one and a tall one a hair in front of it
    def wide(f, x, y, w, h):
        if f in ("front", "back"):
            return BLK if (x in (0, w - 1) or y in (0, h - 1)) else ORANGE
        return BLK

    def tall(f, x, y, w, h):
        if f in ("front", "back"):
            if y in (0, h - 1):
                return BLK
            if x in (0, w - 1):
                return BLK if y in (1, h - 2) else ORANGE
            return ORANGE_L if (x, y) == (1, 1) and f == "front" else ORANGE
        return BLK

    cubes = []
    for side, sx in (("r", -1), ("l", 1)):
        m = side == "l"
        cubes.append(Cube(f"lens_a_{side}", "head", (sx * 2.0, -3.0, ZF), (3.0, 2.0, 0.5), ORANGE, wide,
                          twin_of=None if not m else "lens_a_r", mirror=m))
        cubes.append(Cube(f"lens_b_{side}", "head", (sx * 2.0, -3.0, ZF - 0.08), (2.0, 3.0, 0.5), ORANGE, tall,
                          twin_of=None if not m else "lens_b_r", mirror=m))
    cubes += [bridge(BLK, y=-3.4, width=1.0)] + temples(BLK)
    return build("alucard_glasses", cubes)


# ====================================================================== CRAVAT
CRAVAT_SEGS = [("s0", 2.2, 4.4, 2.0), ("s1", 4.4, 6.6, 2.3), ("s2", 6.6, 8.2, 2.5)]
TZ = -2.7


def cravat_deco(y0, tip=False):
    def d(f, x, y, w, h):
        if f in ("front", "back"):
            if tip:
                half = max(1.0, (w / 2.0) * (1.0 - y / float(h)) + 0.4)
                if abs(x + 0.5 - w / 2.0) > half:
                    return "clear"
            return mix(RED_L, RED, 0.5) if abs(x + 0.5 - w / 2.0) < 1.2 else RED
        return "clear" if tip else RED_D
    return d


def cravat():
    cubes = [Cube("knot", "body", (0, 1.7, TZ - 0.05), (3.4, 2.0, 0.9), RED,
                  lambda f, x, y, w, h: mix(RED_L, RED_D, 0.3) if (f == "front" and (x + y) % 3 == 0) else RED)]
    for name, y0, y1, w in CRAVAT_SEGS:
        cubes.append(Cube(name, "body", (0, (y0 + y1) / 2, TZ), (w, y1 - y0, 0.5), RED, cravat_deco(y0)))
    cubes.append(Cube("tip", "body", (0, 9.0, TZ), (2.5, 1.6, 0.5), RED, cravat_deco(8.2, True)))
    return build("alucard_cravat", cubes)


# ====================================================================== GLOVES
STAR = {(5, 1), (4, 2), (6, 2), (3, 3), (7, 3), (5, 3), (4, 4), (6, 4)}


def hand(f, x, y, w, h):
    if f in ("top", "bottom"):
        return WHITE if f == "top" else WHITE_D
    col = mix(WHITE, WHITE_D, y / max(1, h - 1) * 0.5)
    if f == "front":
        if ellipse(x, y, 5.0, 3.0, 4.0, 2.9) and not ellipse(x, y, 5.0, 3.0, 3.0, 1.9):
            return PENT                                              # circle of the pentagram
        if (x, y) in STAR:
            return PENT
    return col


def cuff(f, x, y, w, h):
    if f in ("top", "bottom"):
        return WHITE
    return WHITE_D if y in (0, h - 1) else mix(WHITE, WHITE_D, 0.2)


def gloves():
    cubes = []
    for side, sx, bone in (("r", -1, "right_arm"), ("l", 1, "left_arm")):
        m = side == "l"
        cubes.append(Cube(f"cuff_{side}", bone, (sx * 1, 5.8, 0), (5.0, 2.2, 5.0), WHITE, cuff,
                          twin_of="cuff_r" if m else None, mirror=m))
        cubes.append(Cube(f"hand_{side}", bone, (sx * 1, 8.85, 0), (4.7, 3.5, 4.7), WHITE, hand,
                          twin_of="hand_r" if m else None, mirror=m))
    return build("alucard_gloves", cubes)


# ====================================================================== ICONS
def icon_coat():
    i = Icon()
    blk(i, 1, 3, 3, 14, RED); blk(i, 12, 3, 14, 14, RED)
    blk(i, 3, 2, 12, 15, RED)
    i.rect(6, 3, 9, 15, VEST)
    i.rect(7, 3, 8, 5, WHITE)
    i.rect(7, 12, 8, 15, BLK)
    for y in (7, 9, 11):
        i.put(6, y, SILVER); i.put(9, y, SILVER)
    i.rect(3, 2, 5, 3, RED_L); i.rect(10, 2, 12, 3, RED_L)
    i.save("alucard_coat")


def icon_hat():
    i = Icon()
    blk(i, 4, 2, 11, 8, RED)
    i.rect(4, 7, 11, 8, BLK); i.rect(7, 7, 8, 8, SILVER)
    blk(i, 1, 9, 14, 11, RED)
    i.rect(1, 11, 14, 11, RED_D)
    i.save("alucard_hat")


def icon_glasses():
    i = Icon()
    for x0 in (1, 9):
        blk(i, x0, 5, x0 + 5, 10, BLK)
        i.rect(x0 + 1, 6, x0 + 4, 9, ORANGE)
        i.put(x0 + 1, 6, ORANGE_L)
    i.rect(6, 7, 9, 7, BLK)
    i.save("alucard_glasses")


def icon_cravat():
    i = Icon()
    blk(i, 5, 1, 10, 5, RED)
    i.rect(6, 2, 9, 3, RED_L)
    for y in range(6, 13):
        i.rect(5 + (y - 6) // 3, y, 10 - (y - 6) // 3, y, RED)
    i.save("alucard_cravat")


def icon_gloves():
    i = Icon()
    blk(i, 4, 2, 11, 5, WHITE)
    blk(i, 3, 6, 12, 13, WHITE)
    i.rect(5, 8, 10, 11, PENT)
    i.rect(6, 9, 9, 10, WHITE)
    i.put(7, 9, PENT); i.put(8, 10, PENT)
    i.save("alucard_gloves")


def icon_pants():
    i = Icon()
    blk(i, 3, 2, 12, 4, BLK)
    i.rect(3, 3, 12, 3, BLK_L); i.rect(7, 3, 8, 3, SILVER)
    blk(i, 3, 5, 7, 14, BLK); blk(i, 8, 5, 12, 14, BLK)
    i.rect(7, 5, 8, 14, VEST_L)
    i.save("alucard_pants")


def icon_boots():
    i = Icon()
    for x0 in (2, 9):
        blk(i, x0, 2, x0 + 4, 11, (34, 30, 34))
        i.rect(x0 + 1, 2, x0 + 1, 10, (84, 78, 86))
        blk(i, x0, 12, x0 + 5, 13, (34, 30, 34))
        i.rect(x0, 14, x0 + 5, 14, (16, 14, 18))
    i.save("alucard_boots")


ITEMS = [
    dict(id="alucard_hat", category="hat", ru="Красная широкополая шляпа", en="Wide Red Hat", price=5499, build=hat, icon=icon_hat),
    dict(id="alucard_glasses", category="accessory", slot=None, ru="Круглые оранжевые очки", en="Round Orange Glasses", price=2499,
         build=glasses, icon=icon_glasses),
    dict(id="alucard_coat", category="top", ru="Длинное красное пальто с жилетом", en="Long Red Coat with Vest", price=14999, build=coat,
         icon=icon_coat),
    dict(id="alucard_cravat", category="accessory", slot="tie", ru="Красный шейный платок", en="Red Cravat", price=1999, build=cravat,
         icon=icon_cravat),
    dict(id="alucard_gloves", category="accessory", slot="wrist", ru="Белые перчатки с пентаграммой", en="White Pentagram Gloves", price=2999,
         build=gloves, icon=icon_gloves),
    dict(id="alucard_pants", category="bottom", ru="Чёрные брюки", en="Black Trousers", price=5999, build=pants, icon=icon_pants),
    dict(id="alucard_boots", category="shoes", ru="Высокие чёрные сапоги", en="Tall Black Boots", price=7999, build=boots, icon=icon_boots),
]
LOOKS = [("alucard", "Алукард", "Alucard",
          ["alucard_hat", "alucard_glasses", "alucard_coat", "alucard_cravat", "alucard_gloves", "alucard_pants", "alucard_boots"])]
J.DOC_MARK = "## Alucard"
J.DOC_TEXT = """
## Alucard
`python3 tools/gen_alucard.py` (registration is shared with gen_joseph.py), then `python3 tools/zfight_cross.py --all --only=alucard_` and `python3 tools/zfight.py --check`.
- `alucard_coat` (top): black vest with a white shirt in the V, two red front panels with a black lining along the opening, a clean red back, a long skirt
  with a black opening, collar flaps (black inside), a short cape (a back piece and a cap on each arm).
- `alucard_cravat` (slot `tie`), `alucard_gloves` (slot `wrist`, so they go together with glasses), `alucard_glasses` (main accessory slot),
  `alucard_hat`, `alucard_pants`, `alucard_boots` (tall boots built with gen_joseph.boots). Look `alucard`.
"""

if __name__ == "__main__":
    J.ITEMS, J.LOOKS = ITEMS, LOOKS
    for e in ITEMS:
        e["build"]()
        e["icon"]()
    J.register()
    print("generated:", ", ".join(e["id"] for e in ITEMS))
