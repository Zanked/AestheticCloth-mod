#!/usr/bin/env python3
"""
Generates the navy suit with the big white collar of the fitting room (after the cosplay picture; no hairstyle):

  josuke_jacket  (top)     hip-length navy jacket: a V-opening that shows a yellow tank top, big white shawl collar with a gold
                           peace pin and a heart pin, five gold buttons, gold stripes on the cuffs; on the back a gold heart with
                           "JOJO" under it
  josuke_pants   (bottom)  baggy navy trousers, wide at the thighs and tapered at the ankles

Shoes are not part of the set: `boy_shoes` (black leather shoes) go with it.
Run from the project root:  python3 tools/gen_josuke.py            (models, textures, icons, registration)
                            python3 tools/gen_josuke.py --preview   (also writes previews to /tmp/josuke_preview)
Same smooth painter as gen_suit.py / gen_giorno.py.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import gen_giorno as G  # noqa: E402
from gen_dino import blk, build, mix  # noqa: E402
from gen_accessories import Cube, Icon, shade  # noqa: E402
from gen_outerwear import arm_pair, leg_pair, sd  # noqa: E402

NAVY = (32, 40, 104)
NAVY_L = (58, 70, 144)
NAVY_D = (20, 24, 68)
WHITE = (244, 242, 236)
WHITE_D = (200, 198, 196)
YELLOW = (252, 214, 64)
YELLOW_D = (214, 170, 30)
GOLD, GOLD_D, GOLD_L = G.GOLD, G.GOLD_D, G.GOLD_L

# the heart and the letters on the back (18 x 26 px back face)
HEART = G.HEART
BHX, BHY = 3, 4
J = ["..X", "..X", "..X", "X.X", "XXX"]
O = ["XXX", "X.X", "X.X", "X.X", "XXX"]
TEXT = [J, O, J, O]
TX, TY = 2, 15


def in_back_heart(x, y):
    hx, hy = x - BHX, y - BHY
    return 0 <= hy < len(HEART) and 0 <= hx < len(HEART[0]) and HEART[hy][hx] == "X"


def back_heart_edge(x, y):
    near = ((1, 0), (-1, 0), (0, 1), (0, -1), (2, 0), (-2, 0), (0, 2), (0, -2), (1, 1), (-1, 1), (1, -1), (-1, -1))
    return in_back_heart(x, y) and not all(in_back_heart(x + dx, y + dy) for dx, dy in near)    # a 2 px thick ring


def back_text(x, y):
    for k, g in enumerate(TEXT):
        gx = TX + k * 4
        if 0 <= x - gx < 3 and 0 <= y - TY < 5 and g[y - TY][x - gx] == "X":
            return True
    return False


# ---------------------------------------------------------------- jacket
def vw(y):
    """Half-width (pixels, measured from the middle of the jacket) of the V opening at row y."""
    return max(0.0, 5.0 - y * 0.45)


def panel_deco(side):
    """Front half of the jacket. 'r' = wearer's right (the left half of the picture, the inner edge is x = w-1)."""
    def d(f, x, y, w, h):
        if not sd(f) or f != "front":
            return None
        di = (w - 1 - x) if side == "r" else x
        if y < 10 and di < vw(y):
            return "clear"                                         # V opening: the yellow top shows
        if y <= 12 - (di - vw(y)) * 0.9 and y < 13 and di >= vw(y):
            if abs(di - vw(y)) < 1.0 and y < 11:
                return WHITE_D                                     # edge of the collar
            if side == "r" and (x, y) in ((4, 3), (3, 4), (5, 4), (4, 5), (4, 4)):
                return GOLD if (x, y) != (4, 4) else GOLD_D        # peace pin
            if side == "l" and (x, y) in ((4, 3), (6, 3), (4, 4), (5, 4), (6, 4), (5, 5)):
                return GOLD                                        # heart pin
            return mix(WHITE, WHITE_D, 0.15 + y / 60)
        if side == "r" and 1 <= di <= 2 and y >= 13:
            for by in (14, 17, 20, 23):
                if by <= y <= by + 1:
                    return mix(GOLD, (255, 255, 255), 0.45) if (di, y) == (2, by) else (GOLD_D if y == by + 1 else GOLD)
        if y == h - 1:
            return mix(NAVY, NAVY_D, 0.5)
        return None
    return d


def shirt_deco(f, x, y, w, h):
    if not sd(f):
        return None
    col = mix(YELLOW, YELLOW_D, y / max(1, h - 1) * 0.5)
    if f == "front" and y <= 1 and 4 <= x <= 11:
        return mix(YELLOW, YELLOW_D, 0.7)                           # neckline
    return col


def back_deco(f, x, y, w, h):
    if f == "back":
        if back_text(x, y):
            return GOLD
        if in_back_heart(x, y):
            return GOLD if back_heart_edge(x, y) else mix(NAVY, NAVY_L, 0.25)
        if x in (w // 2 - 1, w // 2) and y > 21:
            return mix(NAVY, NAVY_D, 0.5)                           # centre seam below the embroidery
    return None


def skirt_deco(f, x, y, w, h):
    if f == "front":
        if x in (w // 2 - 1, w // 2):
            return mix(NAVY, NAVY_D, 0.6)
        if x in (6, 7) and y in (2, 3):
            return GOLD if (x, y) != (7, 3) else GOLD_D
        if y == h - 1:
            return mix(NAVY, NAVY_D, 0.5)
        return None
    if f == "back":
        if x in (w // 2 - 1, w // 2):
            return mix(NAVY, NAVY_D, 0.55)
        if y == h - 1:
            return mix(NAVY, NAVY_D, 0.5)
        return None
    if f == "bottom":
        return mix(NAVY, NAVY_D, 0.4)
    return None


def sleeve_deco(f, x, y, w, h):
    if f == "top":
        return None
    if y in (h - 7, h - 6):                                         # gold stripe on the cuff
        return GOLD if y == h - 7 else GOLD_D
    if y == h - 1:
        return mix(NAVY, NAVY_D, 0.5)
    return None


def jacket():
    cubes = [
        Cube("shirt", "body", (0, 5.9, -0.2), (7.4, 12.0, 3.8), YELLOW, shirt_deco),
        Cube("back", "body", (0, 6.3, 1.0), (8.4, 12.6, 2.6), NAVY, back_deco),
        Cube("panel_r", "body", (-2.1, 6.3, -1.0), (4.2, 12.6, 2.4), NAVY, panel_deco("r")),
        Cube("panel_l", "body", (2.1, 6.3, -1.0), (4.2, 12.6, 2.4), NAVY, panel_deco("l")),
        Cube("skirt", "body", (0, 14.0, 0), (8.8, 4.0, 4.8), NAVY, skirt_deco),
    ]
    arm_pair(cubes, "sleeve", 4.0, (4.2, 12.2, 4.2), NAVY, sleeve_deco)
    return build("josuke_jacket", cubes)


# ---------------------------------------------------------------- trousers
def pants():
    def thigh(f, x, y, w, h):
        if f in ("top", "bottom"):
            return None
        col = mix(NAVY_L, NAVY, min(1.0, y / max(1, h - 1) * 0.9))
        if f in ("front", "back") and x == w // 2 - 1 and y > 2:
            return mix(col, NAVY_D, 0.4)                            # crease
        return col

    def calf(f, x, y, w, h):
        if f in ("top", "bottom"):
            return None
        col = mix(NAVY_L, NAVY, 0.7)
        if f in ("front", "back") and x == w // 2 - 1:
            return mix(col, NAVY_D, 0.4)
        if y >= h - 3:
            return mix(col, NAVY_D, 0.35 + (y - (h - 3)) * 0.15)    # gathered hem
        return col

    def waist(f, x, y, w, h):
        return mix(NAVY, NAVY_D, 0.4) if f == "front" and y == 0 else None

    cubes = [Cube("waist", "body", (0, 11.4, 0), (8.2, 3.2, 4.5), NAVY, waist)]
    leg_pair(cubes, "thigh", 2.4, (4.8, 5.0, 4.6), NAVY, thigh)
    leg_pair(cubes, "calf", 7.6, (4.2, 8.0, 4.2), NAVY, calf)
    return build("josuke_pants", cubes)


# ---------------------------------------------------------------- icons
def icon_jacket():
    i = Icon()
    blk(i, 1, 4, 3, 12, NAVY)                     # sleeves
    blk(i, 12, 4, 14, 12, NAVY)
    i.rect(1, 10, 3, 10, GOLD); i.rect(12, 10, 14, 10, GOLD)
    blk(i, 3, 2, 12, 14, NAVY)                    # body
    i.rect(5, 2, 10, 6, YELLOW)                   # V opening with the yellow top
    i.rect(6, 7, 9, 7, YELLOW); i.rect(7, 8, 8, 8, YELLOW)
    for x, y in ((3, 2), (4, 2), (3, 3), (4, 3), (5, 3), (3, 4), (4, 4), (5, 4), (6, 4), (4, 5), (5, 5), (5, 6)):
        i.put(x, y, WHITE)                        # collar, left
        i.put(15 - x, y, WHITE)                   # collar, right
    i.put(4, 3, GOLD); i.put(11, 3, GOLD)
    for y in (9, 11, 13):
        i.put(7, y, GOLD); i.put(8, y, GOLD_D)
    i.rect(3, 14, 12, 14, shade(NAVY, 0.8))
    i.save("josuke_jacket")


def icon_pants():
    i = Icon()
    blk(i, 2, 2, 13, 4, NAVY)
    blk(i, 2, 5, 7, 10, NAVY)                     # wide thighs
    blk(i, 8, 5, 13, 10, NAVY)
    blk(i, 3, 10, 6, 14, NAVY_D if False else shade(NAVY, 0.9))
    blk(i, 9, 10, 12, 14, shade(NAVY, 0.9))
    i.rect(7, 5, 8, 10, shade(NAVY, 0.75))
    i.rect(3, 13, 6, 14, NAVY_D); i.rect(9, 13, 12, 14, NAVY_D)
    i.save("josuke_pants")


# ---------------------------------------------------------------- registration
ITEMS = [
    dict(id="josuke_jacket", category="top", ru="Синий китель с белым воротником", en="Navy Jacket with White Collar",
         price=13999, build=jacket, icon=icon_jacket),
    dict(id="josuke_pants", category="bottom", ru="Синие свободные брюки", en="Navy Baggy Trousers",
         price=6499, build=pants, icon=icon_pants),
]
DOC_MARK = "## Navy jacket with the white collar"
DOC_TEXT = """
## Navy jacket with the white collar
`python3 tools/gen_josuke.py` regenerates the models, textures, icons and (idempotently) the entries in `clothes.json`, the lang files,
`ClothingCatalog`, `ClothingPrices` and `Looks` (look `josuke`: jacket, trousers and `boy_shoes`).
- `josuke_jacket` (top): a yellow tank-top box, a back piece and two front panels on the `body` bone, plus a short skirt box for the hip
  length. The V opening on the panels is transparent pixels (the yellow top shows through it); the big white shawl collar, the peace and
  heart pins and the five buttons are painted on the panels. The back piece carries the gold heart with "JOJO" (an 18 x 26 px back face).
  Sleeves have a gold stripe on the cuffs.
- `josuke_pants` (bottom): baggy trousers made of two boxes per leg (wide thigh, narrow calf with a gathered hem) and a waist box.
"""


def register():
    import json
    res = G.ROOT / "src/main/resources/assets/fittingroom"
    cj = json.loads((res / "clothes.json").read_text(encoding="utf-8"))
    have = {it["id"] for it in cj["items"]}
    for e in ITEMS:
        if e["id"] in have:
            continue
        cj["items"].append({"id": e["id"], "category": e["category"],
                            "name": {"ru_ru": e["ru"], "en_us": e["en"]},
                            "model": f"fittingroom:clothes_models/{e['id']}.json",
                            "texture": f"fittingroom:textures/clothes/{e['id']}.png",
                            "icon": f"fittingroom:textures/gui/clothes/{e['id']}.png"})
    (res / "clothes.json").write_text(json.dumps(cj, ensure_ascii=False) + "\n", encoding="utf-8")

    for lang, key, look in (("ru_ru", "ru", "Джоске"), ("en_us", "en", "Josuke")):
        path = res / f"lang/{lang}.json"
        data = json.loads(path.read_text(encoding="utf-8"))
        for e in ITEMS:
            data.setdefault(f"clothes.fittingroom.{e['id']}", e[key])
        data.setdefault("look.fittingroom.josuke", look)
        path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    java = G.ROOT / "src/main/java/com/fittingroom/wardrobe/ClothingCatalog.java"
    text = java.read_text(encoding="utf-8")
    close = "\n    );\n\n    private static final Map<String, Item> BY_ID"
    cat = {"top": "TOP", "bottom": "BOTTOM"}
    lines = [f'            new Item("{e["id"]}", Category.{cat[e["category"]]})' for e in ITEMS if f'"{e["id"]}"' not in text]
    if lines:
        assert close in text, "end of the item list not found"
        java.write_text(text.replace(close, ",\n" + ",\n".join(lines) + close), encoding="utf-8")

    prices = G.ROOT / "src/main/java/com/fittingroom/wardrobe/ClothingPrices.java"
    text = prices.read_text(encoding="utf-8")
    anchor = "        // ---- scarves ----\n"
    assert anchor in text, "anchor for the prices not found"
    add = "".join(f'        p("{e["id"]}", {e["price"]});\n' for e in ITEMS if f'"{e["id"]}"' not in text)
    if add:
        prices.write_text(text.replace(anchor, "        // ---- navy jacket with the white collar ----\n" + add + "\n" + anchor, 1), encoding="utf-8")

    looks = G.ROOT / "src/main/java/com/fittingroom/wardrobe/Looks.java"
    text = looks.read_text(encoding="utf-8")
    if '"josuke"' not in text:
        end = text.index("\n    );", text.index("public static final List<Look> ALL = List.of("))
        add = ',\n            new Look("josuke", List.of("josuke_jacket", "josuke_pants", "boy_shoes"))'
        looks.write_text(text[:end] + add + text[end:], encoding="utf-8")

    doc = G.ROOT / "docs/clothes-models.md"
    text = doc.read_text(encoding="utf-8")
    if DOC_MARK not in text:
        doc.write_text(text.rstrip("\n") + "\n" + DOC_TEXT, encoding="utf-8")


if __name__ == "__main__":
    for e in ITEMS:
        e["build"]()
        e["icon"]()
    register()
    print("generated:", ", ".join(e["id"] for e in ITEMS))
    if "--preview" in sys.argv:
        G.preview(["josuke_jacket", "josuke_pants", "boy_shoes"], ITEMS, "josuke")
