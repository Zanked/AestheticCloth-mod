#!/usr/bin/env python3
"""
Generates the Halloween set of the fitting room (15 items, available all year round):
  halloween_pumpkin_hat      (hat)       jack-o'-lantern pumpkin with a stem and a leaf
  halloween_ghost_hood       (hat)       sheet over the head with a cute face and a ragged hem
  halloween_bat_headband     (hat)       black headband with two bats on springs
  halloween_devil_horns      (hat)       red headband with curved horns
  halloween_ghost_sheet      (top)       long white sheet with ragged sleeves and hem
  halloween_vampire_cape     (top)       white shirt, black vest, red bow, tall collar and a red-lined cape
  halloween_witch_dress      (top)       black witch dress with purple trim, an orange belt and a ragged hem
  halloween_skeleton_top/_pants          black clothes with painted bones (top and bottom)
  halloween_mummy_top/_pants             bandage wraps with loose ends (top and bottom)
  halloween_devil_pants      (bottom)    black trousers with a red stripe and a long tail with a spade
  halloween_witch_boots      (shoes)     pointed boots with a curled toe, a buckle and striped socks
  halloween_candy_bucket     (accessory) pumpkin pail with candies hanging from the right hand
  necklace_spider            (necklace)  spider pendant on a chain
Models, 32x textures and 16x16 GUI icons, and (idempotently) the entries in clothes.json, the lang files,
ClothingCatalog.java and ClothingPrices.java. Same smooth painter as gen_dino.py.

Run from the project root:  python3 tools/gen_halloween.py
"""
import math
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from gen_dino import blk, build, grad, mix  # noqa: E402
from gen_accessories import Cube, Icon, shade  # noqa: E402
from gen_hats import chain  # noqa: E402
from gen_jewelry import chain_points, NZ, SILVER, SILVER_D  # noqa: E402
import gen_outerwear  # noqa: E402
from gen_outerwear import arm_pair, hem_band, keep, sd, tw, weave  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent
WHITE = (252, 250, 246)
ORANGE, ORANGE_D, ORANGE_L = (240, 120, 30), (186, 76, 16), (255, 176, 80)
GREEN, GREEN_D = (96, 150, 64), (58, 100, 40)
PURPLE, PURPLE_D, PURPLE_L = (128, 64, 170), (84, 40, 120), (178, 118, 220)
BLACK, BLACK_L = (34, 30, 42), (76, 70, 92)
RED, RED_D, RED_L = (190, 28, 48), (120, 14, 32), (236, 84, 96)
BONE = (240, 236, 220)
GOLD, GOLD_D = (240, 196, 84), (186, 136, 48)
BANDAGE, BANDAGE_D = (226, 216, 188), (168, 156, 124)


def legs(cubes, n, cy, dims, base, deco, ox=0.1):
    for side, sx in (("r", -1), ("l", 1)):
        bone = "right_leg" if side == "r" else "left_leg"
        cubes.append(Cube(f"{n}_{side}", bone, (sx * ox, cy, 0), dims, base, deco, twin_of=tw(side, n), mirror=side == "l"))


def pair(cubes, n, c, dims, base, deco=None, bone="head", **kw):
    for side, sx in (("r", -1), ("l", 1)):
        cubes.append(Cube(f"{n}_{side}", bone, (sx * c[0], c[1], c[2]), dims, base, deco,
                          twin_of=tw(side, n), mirror=side == "l", **kw))


def shaded(col, k):
    return tuple(max(0, min(255, int(v * k))) for v in col)


# ====================================================================== PUMPKIN HAT
def pumpkin_deco(face=False):
    def d(f, x, y, w, h):
        if f == "top":
            return mix(ORANGE, ORANGE_L, 0.4)
        if f == "bottom":
            return ORANGE_D
        col = shaded(ORANGE, (1.08, 1.0, 0.94, 0.88, 0.94, 1.0)[x % 6])
        if y == 0:
            col = mix(col, ORANGE_L, 0.3)
        if y == h - 1:
            col = mix(col, ORANGE_D, 0.5)
        if face and f == "front":
            c = w // 2
            eye = lambda cx: (abs(x - cx) <= 2 - (y - 2) // 2 and 2 <= y <= 3)
            if eye(c - 5) or eye(c + 5):
                return (255, 214, 90) if y == 3 else (70, 26, 12)
            if 5 <= y <= 6 and abs(x - c) <= 6 - (y - 5):
                return (255, 214, 90) if (x % 4 in (0, 1)) else (70, 26, 12)
        return col
    return d


def pumpkin_hat(name):
    cubes = [Cube("base", "head", (0, -9.0, 0), (10.4, 1.8, 10.4), ORANGE_D, pumpkin_deco()),
             Cube("mid", "head", (0, -11.8, 0), (11.4, 3.8, 11.4), ORANGE, pumpkin_deco(True)),
             Cube("top", "head", (0, -14.4, 0), (10.2, 1.6, 10.2), ORANGE, pumpkin_deco()),
             Cube("stem", "head", (0.3, -16.2, 0), (1.8, 2.2, 1.8), GREEN, grad(mix(GREEN, WHITE, 0.2), GREEN_D), pivot=(0.3, -15.4, 0), rot=(0, 0, 12)),
             Cube("leaf", "head", (-2.0, -15.4, 0.2), (3.0, 0.4, 1.8), GREEN, grad(GREEN, GREEN_D), pivot=(-0.8, -15.4, 0.2), rot=(0, 0, -22))]
    return build(name, cubes)


def icon_pumpkin(name):
    i = Icon()
    for y, x0, x1 in ((4, 4, 11), (5, 2, 13), (6, 1, 14), (7, 1, 14), (8, 1, 14), (9, 2, 13), (10, 4, 11)):
        for x in range(x0, x1 + 1):
            col = shaded(ORANGE, (1.1, 1.0, 0.92)[(x - x0) % 3 if x not in (x0,) else 0])
            i.put(x, y, col)
    for x in (5, 6, 9, 10):
        i.put(x, 6, (70, 26, 12))
    for x in range(5, 11):
        i.put(x, 8, (70, 26, 12) if x % 2 else (255, 214, 90))
    i.put(7, 3, GREEN); i.put(8, 3, GREEN); i.put(8, 2, GREEN); i.put(4, 3, GREEN_D)
    i.save(name)


# ====================================================================== GHOST HOOD
def ghost_face(f, x, y, w, h):
    if not sd(f):
        return WHITE if f == "top" else (214, 220, 236)
    col = mix(WHITE, (214, 220, 240), 0.5 * (y / max(1, h - 1)))
    if f == "front":
        c = w // 2
        for cx in (c - 4, c + 4):
            if abs(x - cx) <= 1 and 7 <= y <= 11:
                return (252, 252, 255) if (x == cx - 1 and y == 7) else (30, 26, 44)
        if abs(x - c) <= 1 and 13 <= y <= 15:
            return (30, 26, 44)
        if abs(x - c) >= 5 and abs(x - c) <= 6 and y == 12:
            return (250, 170, 190)
    return col


def ghost_hood(name):
    cubes = [Cube("sheet", "head", (0, -4.6, 0), (10.6, 10.8, 10.6), WHITE, ghost_face)]
    for k, (x, cy, hh) in enumerate(((-3.6, 1.3, 2.0), (0.0, 1.6, 2.6), (3.6, 1.3, 2.0))):
        cubes.append(Cube(f"hem{k}", "head", (x, cy, 0), (3.6, hh, 10.6), WHITE,
                          lambda f, x_, y, w, h: None if f in ("top", "bottom") else mix(WHITE, (200, 208, 230), y / max(1, h - 1))))
    return build(name, cubes)


def icon_ghost_hood(name):
    i = Icon()
    for y in range(2, 12):
        for x in range(3, 13):
            if y >= 11 and x % 3 == 0:
                continue
            i.put(x, y, mix(WHITE, (200, 208, 232), (y - 2) / 12))
    for y in range(3, 5):
        for x in range(4, 12):
            i.put(x, y, WHITE)
    for cx in (6, 9):
        i.rect(cx, 6, cx, 8, (30, 26, 44))
    i.rect(7, 10, 8, 10, (30, 26, 44))
    i.put(5, 9, (250, 170, 190)); i.put(10, 9, (250, 170, 190))
    i.save(name)


# ====================================================================== BAT HEADBAND AND DEVIL HORNS
def band_cubes(col, hi, dark):
    return [Cube("band_top", "head", (0, -8.8, 0), (10.4, 0.9, 1.4), col, lambda f, x, y, w, h: hi if f == "top" else (dark if f == "bottom" else None)),
            Cube("band_r", "head", (-4.95, -7.0, 0), (0.8, 3.6, 1.4), col),
            Cube("band_l", "head", (4.95, -7.0, 0), (0.8, 3.6, 1.4), col)]


def bat_headband(name):
    cubes = band_cubes(BLACK, BLACK_L, (16, 14, 22))
    for tag, sx in (("r", -1), ("l", 1)):
        wire_x = sx * 2.6
        cubes.append(Cube(f"wire_{tag}", "head", (wire_x, -10.6, 0.2), (0.4, 3.2, 0.4), SILVER_D, None))
        by = -13.4
        cubes.append(Cube(f"bat_body_{tag}", "head", (wire_x, by, 0.2), (1.8, 2.0, 1.4), BLACK,
                          lambda f, x, y, w, h: (RED_L if (f == "front" and y == 0 and x in (0, w - 1)) else None)))
        for wing, ang in (("a", sx * 24), ("b", sx * -6)):
            cubes.append(Cube(f"bat_wing{wing}_{tag}", "head", (wire_x + sx * 2.3, by - (0.3 if wing == "a" else -0.7), 0.2), (3.2, 1.2, 0.5), PURPLE_D,
                              lambda f, x, y, w, h: mix(PURPLE_D, PURPLE, 0.3) if (x + y) % 3 == 0 else None,
                              pivot=(wire_x + sx * 0.8, by, 0.2), rot=(0, 0, ang)))
        cubes.append(Cube(f"bat_ear_{tag}", "head", (wire_x + sx * 0.5, by - 1.4, 0.2), (0.6, 0.9, 0.6), BLACK, None))
    return build(name, cubes)


def icon_bat(name):
    i = Icon()
    i.rect(3, 12, 12, 13, BLACK); i.rect(2, 13, 3, 14, BLACK); i.rect(12, 13, 13, 14, BLACK); i.rect(3, 12, 12, 12, BLACK_L)
    for cx in (4, 11):
        i.rect(cx, 7, cx, 11, SILVER_D)
        i.rect(cx - 1, 4, cx + 1, 6, BLACK)
        i.put(cx - 3, 4, PURPLE); i.put(cx - 2, 3, PURPLE); i.put(cx - 2, 4, PURPLE); i.put(cx - 2, 5, PURPLE_D)
        i.put(cx + 3, 4, PURPLE); i.put(cx + 2, 3, PURPLE); i.put(cx + 2, 4, PURPLE); i.put(cx + 2, 5, PURPLE_D)
        i.put(cx - 1, 4, RED_L); i.put(cx + 1, 4, RED_L)
    i.save(name)


def devil_horns(name):
    cubes = band_cubes(RED_D, RED, (60, 6, 20))
    for tag, sx in (("r", -1), ("l", 1)):
        segs = [(1.8, 1.8, 1.8, sx * -4, RED_D, None), (1.5, 1.5, 1.8, sx * -14, RED, None),
                (1.2, 1.2, 1.6, sx * -28, RED, None), (0.9, 0.9, 1.4, sx * -40, RED_L, None)]
        chain(cubes, f"horn_{tag}_", "head", (sx * 2.7, -8.9, 0.0), segs, axis="z")
    return build(name, cubes)


def icon_horns(name):
    i = Icon()
    i.rect(3, 12, 12, 13, RED_D); i.rect(2, 13, 3, 14, RED_D); i.rect(12, 13, 13, 14, RED_D); i.rect(3, 12, 12, 12, RED)
    pts = [(4, 11), (4, 10), (3, 9), (3, 8), (2, 7), (2, 6), (3, 5), (3, 4), (4, 3)]
    for k, (x, y) in enumerate(pts):
        col = RED_D if k < 3 else (RED if k < 6 else RED_L)
        for xx in (x, 15 - x):
            i.put(xx, y, col)
            i.put(xx + (1 if xx < 8 else -1), y, shade(col, 0.75)) if k < 7 else None
    i.save(name)


# ====================================================================== GHOST SHEET
def sheet_deco(f, x, y, w, h):
    if f in ("top", "bottom"):
        return mix(WHITE, (210, 216, 236), 0.4)
    col = mix(WHITE, (214, 220, 240), 0.35 * (y / max(1, h - 1)))
    return fold_w(col, x)


def fold_w(col, x):
    return shaded(col, 0.94) if x % 5 == 4 else col


def ghost_sheet(name):
    cubes = [Cube("body", "body", (0, 6.1, 0), (10.2, 12.6, 6.2), WHITE, sheet_deco),
             Cube("sk1", "body", (0, 14.0, 0), (11.2, 4.6, 7.2), WHITE, sheet_deco),
             Cube("sk2", "body", (0, 17.6, 0), (12.4, 3.2, 8.4), WHITE, sheet_deco)]
    for k, (x, cy, hh) in enumerate(((-4.9, 20.0, 2.6), (-1.6, 20.6, 3.8), (1.7, 20.1, 2.8), (4.9, 20.5, 3.4))):
        cubes.append(Cube(f"hem{k}", "body", (x, cy, 0), (3.4, hh, 8.4), WHITE,
                          lambda f, x_, y, w, h: None if f in ("top", "bottom") else mix(WHITE, (200, 208, 232), y / max(1, h - 1))))
    arm_pair(cubes, "sleeve", 3.9, (5.8, 9.0, 5.8), WHITE, sheet_deco)
    for k, (dx, hh) in enumerate(((-1.8, 2.0), (0.0, 3.0), (1.8, 2.2))):
        arm_pair(cubes, f"frill{k}", 8.4 + hh / 2 - 1.0 + 0.6, (1.9, hh, 5.8), WHITE,
                 lambda f, x, y, w, h: None if f in ("top", "bottom") else mix(WHITE, (200, 208, 232), y / max(1, h - 1)),
                 ox=1.0, off=dx, offcentre=True)
    return build(name, cubes)


def icon_ghost_sheet(name):
    i = Icon()
    for y in range(1, 14):
        x0, x1 = (5, 10) if y < 4 else (4, 11) if y < 8 else (3, 12) if y < 11 else (2, 13)
        for x in range(x0, x1 + 1):
            if y >= 13 and x % 3 == 0:
                continue
            i.put(x, y, mix(WHITE, (200, 208, 232), y / 16))
    blk(i, 0, 5, 3, 9, WHITE); blk(i, 12, 5, 15, 9, WHITE)
    for cx in (6, 9):
        i.rect(cx, 4, cx, 6, (30, 26, 44))
    i.rect(7, 8, 8, 8, (30, 26, 44))
    i.save(name)


# ====================================================================== VAMPIRE CAPE
def vampire_body(f, x, y, w, h):
    if not sd(f):
        return None
    c = w // 2
    if f == "front":
        edge = 7 - y * 0.35
        if y < 20 and abs(x - c) <= edge:
            if abs(x - c) >= edge - 1.5 or y >= 12:
                return mix(WHITE, (210, 214, 230), 0.4) if abs(x - c) < 2 else WHITE
        if y >= 4 and abs(x - c) > 1 and abs(x - c) <= 9:
            vest = shaded(BLACK, 1.0) if (x + y) % 5 else BLACK_L
            if abs(x - c) <= 2 and y > 12 and y % 5 == 0:
                return GOLD
            return vest
    return mix(BLACK, BLACK_L, 0.2) if (x + y) % 4 == 0 else BLACK


def vampire_cape(name):
    outer = lambda f, x, y, w, h: (RED if f == "front" else None) if sd(f) and f == "front" else (
        None if not sd(f) else (RED_D if y >= h - 2 else (mix(BLACK, BLACK_L, 0.3) if (x + y) % 5 == 0 else BLACK)))
    cubes = [Cube("body", "body", (0, 6.1, 0), (9.8, 12.4, 5.8), WHITE, vampire_body)]
    arm_pair(cubes, "sleeve", 3.9, (5.4, 11.4, 5.4), WHITE,
             lambda f, x, y, w, h: None if not sd(f) else (BLACK if y > h - 4 else mix(WHITE, (214, 218, 236), 0.4 * (x % 2))))
    arm_pair(cubes, "cuff", 9.0, (5.6, 1.6, 5.6), BLACK, None)
    cubes.append(Cube("tie", "body", (0, 0.8, -3.1), (3.0, 1.6, 0.8), RED, None))
    cubes.append(Cube("brooch", "body", (0, 2.4, -3.2), (1.2, 1.2, 0.5), GOLD, None))
    cubes.append(Cube("collar_b", "body", (0, -2.4, 3.3), (11.0, 5.6, 0.9), BLACK, outer, pivot=(0, 0.4, 3.3), rot=(-10, 0, 0)))
    for tag, sx in (("r", -1), ("l", 1)):
        cubes.append(Cube(f"collar_{tag}", "body", (sx * 5.4, -1.8, 1.6), (0.9, 4.4, 4.6), BLACK,
                          lambda f, x, y, w, h: None if f in ("top", "bottom") else (RED if f in ("left", "right") else BLACK),
                          pivot=(sx * 5.4, 0.4, 1.6), rot=(0, 0, sx * 12)))
    cubes.append(Cube("cape", "body", (0, 8.2, 4.0), (11.6, 17.2, 0.9), BLACK, outer, pivot=(0, -0.4, 4.0), rot=(6, 0, 0)))
    for tag, sx in (("r", -1), ("l", 1)):
        cubes.append(Cube(f"cape_shoulder_{tag}", "body", (sx * 5.2, 1.4, 2.8), (1.0, 4.4, 2.8), BLACK, outer))
    return build(name, cubes)


def icon_vampire(name):
    i = Icon()
    blk(i, 2, 3, 13, 14, BLACK)
    for y in range(4, 14):
        i.put(2, y, RED); i.put(13, y, RED)
    i.rect(2, 14, 13, 14, RED_D)
    blk(i, 5, 3, 10, 11, WHITE)
    for x in (5, 6, 9, 10):
        for y in range(5, 12):
            i.put(x, y, BLACK) if x in (5, 10) or y > 6 else None
    i.rect(7, 5, 8, 11, WHITE)
    i.rect(7, 3, 8, 4, RED)
    i.put(7, 6, GOLD)
    i.rect(3, 2, 4, 3, BLACK); i.rect(11, 2, 12, 3, BLACK)
    i.save(name)


# ====================================================================== WITCH DRESS
def witch_deco(f, x, y, w, h):
    if not sd(f):
        return mix(BLACK, PURPLE_D, 0.4)
    col = mix(BLACK, BLACK_L, 0.3) if (x + y) % 5 == 0 else BLACK
    if (x // 4 + y // 4) % 6 == 0 and f in ("front", "back"):
        col = PURPLE_D
    if y >= h - 2:
        col = PURPLE
    return col


def witch_dress(name):
    cubes = [Cube("bodice", "body", (0, 5.4, 0), (9.8, 11.0, 5.8), BLACK,
                  lambda f, x, y, w, h: (PURPLE if (f == "front" and y == 2 and x % 2 == 0) else witch_deco(f, x, y, w, h))),
             Cube("belt", "body", (0, 10.6, 0), (10.1, 1.6, 6.1), ORANGE,
                  lambda f, x, y, w, h: None if not sd(f) else (ORANGE_L if y == 0 else ORANGE)),
             Cube("buckle", "body", (0, 10.6, -3.2), (2.2, 1.8, 0.5), GOLD, lambda f, x, y, w, h: GOLD_D if f == "front" and 1 <= x <= w - 2 and 1 <= y <= h - 2 and (x in (1, w - 2) or y in (1, h - 2)) is False else None)]
    for n, cy, ch, cw, cd in (("sk1", 12.6, 3.2, 10.8, 7.0), ("sk2", 15.6, 3.2, 12.2, 8.4)):
        cubes.append(Cube(n, "body", (0, cy, 0), (cw, ch, cd), BLACK, witch_deco))
    for k, (x, hh) in enumerate(((-5.2, 3.2), (-2.6, 4.6), (0.0, 3.4), (2.6, 4.4), (5.2, 3.0))):
        cubes.append(Cube(f"rag{k}", "body", (x, 17.2 + hh / 2, 0), (2.7, hh, 9.4), BLACK,
                          lambda f, x_, y, w, h: None if f in ("top", "bottom") else (PURPLE if y >= h - 2 else (mix(BLACK, BLACK_L, 0.3) if (x_ + y) % 5 == 0 else BLACK))))
    arm_pair(cubes, "sleeve", 3.9, (5.4, 11.4, 5.4), BLACK,
             lambda f, x, y, w, h: None if not sd(f) else (ORANGE if (y // 3) % 3 == 1 and y > 8 else (PURPLE if (y // 3) % 3 == 2 and y > 8 else witch_deco(f, x, y, w, h))))
    cubes.append(Cube("collar", "body", (0, 0.2, 0), (10.2, 1.4, 6.2), PURPLE,
                      lambda f, x, y, w, h: None if not sd(f) else (PURPLE_L if y == h - 1 and x % 2 == 0 else PURPLE)))
    return build(name, cubes)


def icon_witch_dress(name):
    i = Icon()
    blk(i, 1, 3, 3, 9, BLACK); blk(i, 12, 3, 14, 9, BLACK)
    i.rect(1, 7, 3, 8, PURPLE); i.rect(12, 7, 14, 8, PURPLE)
    for y in range(2, 15):
        x0, x1 = (5, 10) if y < 8 else (max(1, 5 - (y - 7) // 2), min(14, 10 + (y - 7) // 2))
        for x in range(x0, x1 + 1):
            if y >= 14 and x % 2:
                continue
            i.put(x, y, BLACK if (x + y) % 5 else BLACK_L)
    i.rect(5, 8, 10, 8, ORANGE); i.put(7, 8, GOLD); i.put(8, 8, GOLD)
    i.rect(5, 2, 10, 2, PURPLE)
    for x in range(1, 15):
        if (x % 2) == 0:
            i.put(x, 14, PURPLE)
    i.save(name)


# ====================================================================== SKELETON / MUMMY (clothes with painted details)
def skeleton_body(f, x, y, w, h):
    if not sd(f):
        return None
    col = mix(BLACK, BLACK_L, 0.25) if (x + y) % 4 == 0 else BLACK
    c = w // 2
    if f == "front":
        for ry in (6, 10, 14, 18):
            dx = abs(x - c)
            if 2 <= dx <= 7 and y == ry + (dx // 4):
                return BONE
        if y == 3 and 2 <= abs(x - c) <= 8:
            return BONE
        if c - 1 <= x <= c and 3 <= y <= 22 and y % 4 != 0:
            return BONE
    if f == "back":
        if c - 1 <= x <= c and y % 3 != 2:
            return BONE
        if y in (3, 9, 15) and abs(x - c) <= 5:
            return mix(BONE, BLACK, 0.4)
    return col


def skeleton_limb(f, x, y, w, h):
    if not sd(f):
        return None
    col = mix(BLACK, BLACK_L, 0.25) if (x + y) % 4 == 0 else BLACK
    if f in ("front", "back"):
        c = w // 2
        if c - 1 <= x <= c and 2 <= y <= h - 3:
            return BONE
        if y in (1, 2, h - 3, h - 2) and (x == c - 2 or x == c + 1):
            return BONE
        if abs(y - h // 2) <= 1 and c - 2 <= x <= c + 1:
            return mix(BONE, BLACK, 0.3)
    return col


def skeleton_top(name):
    cubes = [Cube("body", "body", (0, 6.1, 0), (9.8, 12.4, 5.8), BLACK, skeleton_body)]
    arm_pair(cubes, "sleeve", 3.9, (5.4, 11.4, 5.4), BLACK, skeleton_limb)
    cubes.append(Cube("collar", "body", (0, -0.1, 0), (10.0, 1.2, 6.0), BLACK_L, None))
    return build(name, cubes)


def skeleton_pants(name):
    cubes = [Cube("belt", "body", (0, 11.3, 0), (8.9, 1.6, 4.9), BLACK_L,
                  lambda f, x, y, w, h: None if not sd(f) else (BONE if f == "front" and abs(x - w // 2) in (2, 3) and y < 2 else BLACK_L))]
    legs(cubes, "leg", 5.2, (4.9, 10.4, 4.9), BLACK, skeleton_limb)
    return build(name, cubes)


def mummy_deco(f, x, y, w, h):
    if not sd(f):
        return BANDAGE_D
    k = ((x + 2 * y) // 4) % 3
    col = (BANDAGE, mix(BANDAGE, WHITE, 0.4), mix(BANDAGE, BANDAGE_D, 0.5))[k]
    if (x + 2 * y) % 4 == 3:
        col = BANDAGE_D
    if f == "front" and y in (6, 7) and 3 <= x <= 4:
        return (40, 36, 44)
    return col


def mummy_top(name):
    cubes = [Cube("body", "body", (0, 6.1, 0), (9.9, 12.5, 5.9), BANDAGE, mummy_deco)]
    arm_pair(cubes, "sleeve", 3.9, (5.5, 11.4, 5.5), BANDAGE, mummy_deco)
    for k, dx in enumerate((-2.8, 0.4, 3.0)):
        cubes.append(Cube(f"loose{k}", "body", (dx, 14.2 + k * 0.5, -3.1), (1.4, 3.6 + k, 0.5), BANDAGE, mummy_deco))
    return build(name, cubes)


def mummy_pants(name):
    cubes = [Cube("belt", "body", (0, 11.3, 0), (8.9, 1.6, 4.9), BANDAGE, mummy_deco)]
    legs(cubes, "leg", 5.2, (4.9, 10.4, 4.9), BANDAGE, mummy_deco)
    return build(name, cubes)


def icon_bone_top(name, kind):
    i = Icon()
    base = BLACK if kind == "skeleton" else BANDAGE
    blk(i, 1, 4, 3, 12, base); blk(i, 12, 4, 14, 12, base); blk(i, 4, 3, 11, 14, base)
    if kind == "skeleton":
        i.rect(7, 4, 8, 13, BONE)
        for y in (5, 7, 9, 11):
            i.rect(4, y, 6, y, BONE); i.rect(9, y, 11, y, BONE)
        for x in (2, 13):
            i.rect(x, 5, x, 10, BONE)
    else:
        for y in range(3, 15):
            for x in range(1, 15):
                if (x + y) % 4 == 0 and i.px.get((x, y)):
                    i.put(x, y, BANDAGE_D)
        i.rect(5, 6, 6, 6, (40, 36, 44))
    i.save(name)


def icon_bone_pants(name, kind):
    i = Icon()
    base = BLACK if kind == "skeleton" else BANDAGE
    blk(i, 3, 3, 12, 4, BLACK_L if kind == "skeleton" else base)
    for x0, x1 in ((3, 6), (9, 12)):
        blk(i, x0, 5, x1, 13, base)
    if kind == "skeleton":
        for x in (4, 10):
            i.rect(x, 6, x, 12, BONE)
        i.put(3, 6, BONE); i.put(5, 6, BONE); i.put(9, 6, BONE); i.put(11, 6, BONE)
        i.put(5, 12, BONE); i.put(3, 12, BONE); i.put(11, 12, BONE); i.put(9, 12, BONE)
        i.rect(6, 3, 9, 3, BONE)
    else:
        for y in range(4, 14):
            for x in range(3, 13):
                if (x + y) % 3 == 0 and i.px.get((x, y)):
                    i.put(x, y, BANDAGE_D)
    i.save(name)


# ====================================================================== DEVIL PANTS (with a tail)
def devil_pants(name):
    def leg(f, x, y, w, h):
        if f == "top":
            return BLACK_L
        if f == "bottom":
            return None
        col = mix(BLACK, BLACK_L, 0.25) if (x + y) % 4 == 0 else BLACK
        if f in ("left", "right") and x == w // 2 or f == "front" and x == w - 3:
            return RED
        return col
    cubes = [Cube("belt", "body", (0, 11.3, 0), (8.9, 1.6, 4.9), RED_D,
                  lambda f, x, y, w, h: None if not sd(f) else (RED if y == 0 else RED_D))]
    legs(cubes, "leg", 5.2, (4.9, 10.4, 4.9), BLACK, leg)
    py, pz = 10.8, 2.6
    for i, (w, ang) in enumerate(zip((1.6, 1.4, 1.3, 1.2, 1.1, 1.0), (12, -8, -28, -52, -78, -104))):
        length = 2.6
        rot = (-ang, 0, 0)
        piv = (0, py, pz)
        cubes.append(Cube(f"tail{i}", "body", (0, py, pz + length / 2), (w, w, length), RED_D,
                          lambda f, x, y, ww, hh: mix(RED_D, RED, 0.4 * (y / max(1, hh - 1))), pivot=piv, rot=rot))
        py += math.sin(math.radians(ang)) * length
        pz += math.cos(math.radians(ang)) * length
    cubes.append(Cube("spade", "body", (0, py - 0.6, pz + 0.2), (2.2, 2.2, 0.7), RED,
                      lambda f, x, y, w, h: RED_L if (x, y) == (0, 0) else None, pivot=(0, py - 0.6, pz + 0.2), rot=(0, 0, 45)))
    return build(name, cubes)


def icon_devil_pants(name):
    i = Icon()
    blk(i, 2, 3, 11, 4, RED_D)
    for x0, x1 in ((2, 5), (8, 11)):
        blk(i, x0, 5, x1, 13, BLACK)
        i.rect(x1 if x0 == 2 else x0, 5, x1 if x0 == 2 else x0, 13, RED)
    for x, y in ((12, 4), (13, 3), (13, 2), (14, 2), (14, 1), (13, 0), (14, 0), (12, 0), (13, 1)):
        i.put(x, y, RED if (x, y) != (13, 1) else RED_L)
    i.save(name)


# ====================================================================== WITCH BOOTS
def witch_boots(name):
    def shaft(f, x, y, w, h):
        if f == "top":
            return BLACK_L
        if f == "bottom":
            return None
        col = mix(BLACK, BLACK_L, 0.25) if (x + y) % 4 == 0 else BLACK
        if f == "front" and 5 <= y <= 7 and 3 <= x <= w - 4 and (x in (3, w - 4) or y in (5, 7)):
            return GOLD
        return col
    stripe = lambda f, x, y, w, h: None if f in ("top", "bottom") else (ORANGE if (y // 2) % 2 == 0 else BLACK)
    cubes = []
    for side, sx in (("r", -1), ("l", 1)):
        bone, m, ox = ("right_leg" if side == "r" else "left_leg"), side == "l", sx * 0.1
        t = lambda n: tw(side, n)
        cubes += [
            Cube(f"sock_{side}", bone, (ox, 3.4, 0), (4.4, 4.4, 4.4), ORANGE, stripe, twin_of=t("sock"), mirror=m),
            Cube(f"shaft_{side}", bone, (ox, 8.2, 0), (5.0, 5.2, 5.0), BLACK, shaft, twin_of=t("shaft"), mirror=m),
            Cube(f"cuff_{side}", bone, (ox, 5.9, 0), (5.3, 1.0, 5.3), PURPLE, None, twin_of=t("cuff"), mirror=m),
            Cube(f"toe_{side}", bone, (ox, 10.5, -3.6), (4.4, 2.2, 3.6), BLACK, grad(BLACK_L, BLACK), twin_of=t("toe"), mirror=m),
            Cube(f"tip1_{side}", bone, (ox, 10.0, -5.8), (3.0, 1.8, 1.8), BLACK, grad(BLACK_L, BLACK), twin_of=t("tip1"), mirror=m),
            Cube(f"tip2_{side}", bone, (ox, 9.2, -7.0), (1.8, 1.4, 1.6), BLACK, grad(BLACK_L, BLACK), twin_of=t("tip2"), mirror=m),
            Cube(f"sole_{side}", bone, (ox, 11.85, -1.2), (4.8, 0.7, 8.0), PURPLE_D,
                 lambda f, x, y, w, h: None if f in ("top", "bottom") else PURPLE_D, twin_of=t("sole"), mirror=m),
        ]
    return build(name, cubes)


def icon_witch_boots(name):
    i = Icon()
    for x0 in (1, 9):
        blk(i, x0 + 1, 2, x0 + 4, 4, ORANGE)
        for y in (2, 4):
            i.rect(x0 + 1, y, x0 + 4, y, BLACK)
        blk(i, x0 + 1, 5, x0 + 4, 9, BLACK)
        i.rect(x0 + 1, 5, x0 + 4, 5, PURPLE)
        i.rect(x0 + 2, 7, x0 + 3, 7, GOLD)
        blk(i, x0, 10, x0 + 5, 12, BLACK)
        i.put(x0 - 1, 11, BLACK); i.put(x0 - 1, 10, BLACK); i.put(x0 - 1, 9, BLACK_L)
        i.rect(x0, 13, x0 + 5, 13, PURPLE_D)
    i.save(name)


# ====================================================================== CANDY BUCKET (right hand)
CANDY = [(236, 84, 96), (250, 216, 84), (110, 196, 120), (90, 160, 236), (166, 120, 230)]


def candy_bucket(name):
    cx, cy = -1.6, 15.2
    cubes = [Cube("mid", "right_arm", (cx, cy, 0), (5.8, 3.6, 5.8), ORANGE, pumpkin_deco(True), **keep((cx, cy, 0))),
             Cube("low", "right_arm", (cx, cy + 2.4, 0), (4.8, 1.4, 4.8), ORANGE_D, pumpkin_deco(), **keep((cx, cy + 2.4, 0))),
             Cube("rim", "right_arm", (cx, cy - 1.9, 0), (5.2, 0.5, 5.2), (50, 30, 20), None, **keep((cx, cy - 1.9, 0)))]
    for k, (dx, dz, col) in enumerate(((-1.2, -0.8, CANDY[0]), (0.9, 0.6, CANDY[1]), (-0.4, 1.2, CANDY[2]), (1.3, -1.1, CANDY[3]), (0.0, -0.2, CANDY[4]))):
        c = (cx + dx, cy - 2.5 - (k % 2) * 0.3, dz)
        cubes.append(Cube(f"candy{k}", "right_arm", c, (1.2, 1.0, 1.2), col, None, **keep(c)))
    for k, sx in enumerate((-1, 1)):
        c = (cx + sx * 2.5, cy - 4.1, 0)
        cubes.append(Cube(f"post{k}", "right_arm", c, (0.4, 3.4, 0.4), SILVER_D, None, **keep(c)))
    top = (cx, cy - 5.9, 0)
    cubes.append(Cube("grip", "right_arm", top, (5.4, 0.5, 0.6), SILVER_D, None, **keep(top)))
    return build(name, cubes)


def icon_bucket(name):
    i = Icon()
    i.rect(4, 3, 11, 3, SILVER_D); i.rect(4, 3, 4, 6, SILVER_D); i.rect(11, 3, 11, 6, SILVER_D)
    for x, y, col in ((6, 5, CANDY[0]), (8, 5, CANDY[1]), (7, 6, CANDY[2]), (9, 6, CANDY[3])):
        i.put(x, y, col)
    for y, x0, x1 in ((7, 3, 12), (8, 2, 13), (9, 2, 13), (10, 2, 13), (11, 3, 12), (12, 4, 11)):
        for x in range(x0, x1 + 1):
            i.put(x, y, shaded(ORANGE, (1.1, 1.0, 0.92)[(x - x0) % 3]))
    for x in (5, 6, 9, 10):
        i.put(x, 9, (70, 26, 12))
    for x in range(5, 11):
        i.put(x, 11, (70, 26, 12) if x % 2 else (255, 214, 90))
    i.save(name)


# ====================================================================== SPIDER NECKLACE (slot "necklace")
def spider_necklace(name):
    cubes = []
    pts = chain_points(8)
    for k, (x, y) in enumerate(pts):
        col = BLACK_L if k % 2 == 0 else SILVER
        cubes.append(Cube(f"c{k}_r", "body", (x, y, NZ), (0.7, 0.7, 0.5), col, None))
        cubes.append(Cube(f"c{k}_l", "body", (-x, y, NZ), (0.7, 0.7, 0.5), col, None, twin_of=f"c{k}_r", mirror=True))
    body = (0, 5.4, NZ - 0.2)
    cubes.append(Cube("spider", "body", body, (2.0, 2.0, 0.9), BLACK,
                      lambda f, x, y, w, h: RED_L if f == "front" and (x, y) in ((1, 1), (2, 2)) else None))
    cubes.append(Cube("head", "body", (0, 4.2, NZ - 0.2), (1.2, 1.0, 0.8), BLACK_L, None))
    for k, ang in enumerate((28, -28, 62, -62)):
        cubes.append(Cube(f"leg{k}", "body", (0, 5.4, NZ - 0.25), (4.6, 0.4, 0.4), BLACK, None, pivot=(0, 5.4, NZ - 0.25), rot=(0, 0, ang)))
    return build(name, cubes)


def icon_spider(name):
    i = Icon()
    for k, (x, y) in enumerate(((2, 1), (3, 2), (4, 3), (5, 4), (6, 5), (9, 5), (10, 4), (11, 3), (12, 2), (13, 1))):
        i.put(x, y, SILVER if k % 2 else BLACK_L)
    cx, cy = 7, 9
    blk(i, cx, cy - 1, cx + 1, cy + 2, BLACK)
    i.put(cx, cy - 1, BLACK_L); i.put(cx + 1, cy - 1, BLACK_L)
    i.put(cx, cy + 1, RED_L)
    for dx, dy in ((-1, -1), (-2, -2), (-3, -2), (-1, 1), (-2, 2), (-3, 3), (-1, 0), (-2, 0), (-3, 0)):
        i.put(cx + dx, cy + dy, BLACK)
        i.put(cx + 1 - dx, cy + dy, BLACK)
    i.save(name)


# ====================================================================== run + registration
ITEMS = [
    ("halloween_pumpkin_hat", "hat", None, "Шапка-тыква", "Pumpkin Hat", 3499, pumpkin_hat, icon_pumpkin),
    ("halloween_ghost_hood", "hat", None, "Капюшон-привидение", "Ghost Hood", 3299, ghost_hood, icon_ghost_hood),
    ("halloween_bat_headband", "hat", None, "Ободок с летучими мышами", "Bat Headband", 2799, bat_headband, icon_bat),
    ("halloween_devil_horns", "hat", None, "Рожки дьяволёнка", "Devil Horns", 2799, devil_horns, icon_horns),
    ("halloween_ghost_sheet", "top", None, "Костюм привидения", "Ghost Sheet", 4999, ghost_sheet, icon_ghost_sheet),
    ("halloween_vampire_cape", "top", None, "Костюм вампира с плащом", "Vampire Cape Outfit", 7999, vampire_cape, icon_vampire),
    ("halloween_witch_dress", "top", None, "Платье ведьмочки", "Witch Dress", 5999, witch_dress, icon_witch_dress),
    ("halloween_skeleton_top", "top", None, "Кофта со скелетом", "Skeleton Top", 3999, skeleton_top, lambda n: icon_bone_top(n, "skeleton")),
    ("halloween_skeleton_pants", "bottom", None, "Штаны со скелетом", "Skeleton Pants", 3499, skeleton_pants, lambda n: icon_bone_pants(n, "skeleton")),
    ("halloween_mummy_top", "top", None, "Мумия: бинты (верх)", "Mummy Wraps Top", 3999, mummy_top, lambda n: icon_bone_top(n, "mummy")),
    ("halloween_mummy_pants", "bottom", None, "Мумия: бинты (низ)", "Mummy Wraps Pants", 3499, mummy_pants, lambda n: icon_bone_pants(n, "mummy")),
    ("halloween_devil_pants", "bottom", None, "Штаны дьяволёнка с хвостом", "Devil Pants with Tail", 4499, devil_pants, icon_devil_pants),
    ("halloween_witch_boots", "shoes", None, "Ботинки ведьмочки", "Witch Boots", 4999, witch_boots, icon_witch_boots),
    ("halloween_candy_bucket", "accessory", None, "Ведёрко-тыква со сладостями", "Candy Pumpkin Pail", 2999, candy_bucket, icon_bucket),
    ("necklace_spider", "accessory", "necklace", "Кулон-паучок", "Spider Necklace", 2499, spider_necklace, icon_spider),
]

DOC_MARK = "## Halloween"
DOC_TEXT = """
## Halloween
`python3 tools/gen_halloween.py` regenerates fifteen Halloween items (models, textures, icons) and registers them. They are not
seasonal (they show all year); to make them seasonal give them the `season` window and the `newYear(...)`-like constructor, as the
New Year items do.
- Hats: `halloween_pumpkin_hat` (three pumpkin segments with a carved glowing face, stem and leaf), `halloween_ghost_hood`
  (a sheet cube with a face and three hem cubes of different heights), `halloween_bat_headband` (bats on wires, flapping wing boxes),
  `halloween_devil_horns` (two `chain()` horns bent outwards).
- Tops: `halloween_ghost_sheet` (long sheet, ragged sleeves and hem), `halloween_vampire_cape` (shirt + vest + bow + cape with a red
  lining, tilted 6 degrees, tall collar made of three boxes), `halloween_witch_dress` (ragged five-piece hem, orange belt),
  `halloween_skeleton_top`/`_pants` (bones painted on black), `halloween_mummy_top`/`_pants` (diagonal bandage wraps, loose ends).
- `halloween_devil_pants`: trousers with a red stripe and a six-segment tail that curls up, with a spade on the tip.
- `halloween_witch_boots`: pointed boots with a curled toe made of three boxes, a golden buckle and orange-and-black striped socks.
- `halloween_candy_bucket`: a pumpkin pail on a wire handle in the right hand (`right_arm` cubes, `keep()`), candies peek out.
- `necklace_spider` (slot `necklace`): chain + a black spider with four crossed legs.
"""


def register(items):
    gen_outerwear.CATEGORY.update({"shoes": "SHOES", "hat": "HAT", "accessory": "ACCESSORY"})
    plain = [e for e in items if not e["slot"]]
    jewelry = [e for e in items if e["slot"]]
    gen_outerwear.register(plain)
    res = ROOT / "src/main/resources/assets/fittingroom"
    import json
    cj = json.loads((res / "clothes.json").read_text(encoding="utf-8"))
    have = {it["id"] for it in cj["items"]}
    for e in jewelry:
        if e["id"] in have:
            continue
        cj["items"].append({"id": e["id"], "category": "accessory", "slot": e["slot"],
                            "name": {"ru_ru": e["ru"], "en_us": e["en"]},
                            "model": f"fittingroom:clothes_models/{e['id']}.json",
                            "texture": f"fittingroom:textures/clothes/{e['id']}.png",
                            "icon": f"fittingroom:textures/gui/clothes/{e['id']}.png"})
    (res / "clothes.json").write_text(json.dumps(cj, ensure_ascii=False) + "\n", encoding="utf-8")
    for lang, key in (("ru_ru", "ru"), ("en_us", "en")):
        path = res / f"lang/{lang}.json"
        data = json.loads(path.read_text(encoding="utf-8"))
        for e in jewelry:
            data.setdefault(f"clothes.fittingroom.{e['id']}", e[key])
        path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    java = ROOT / "src/main/java/com/fittingroom/wardrobe/ClothingCatalog.java"
    text = java.read_text(encoding="utf-8")
    close = "\n    );\n\n    private static final Map<String, Item> BY_ID"
    lines = [f'            jewel("{e["id"]}", NECKLACE)' for e in jewelry if f'"{e["id"]}"' not in text]
    if lines:
        assert close in text, "end of the item list not found"
        java.write_text(text.replace(close, ",\n" + ",\n".join(lines) + close), encoding="utf-8")
    prices = ROOT / "src/main/java/com/fittingroom/wardrobe/ClothingPrices.java"
    text = prices.read_text(encoding="utf-8")
    anchor = "        // ---- scarves ----\n"
    add = "".join(f'        p("{e["id"]}", {e["price"]});\n' for e in jewelry if f'"{e["id"]}"' not in text)
    if add:
        prices.write_text(text.replace(anchor, add + anchor, 1), encoding="utf-8")


if __name__ == "__main__":
    items = []
    for id_, cat, slot, ru, en, price, model_fn, icon_fn in ITEMS:
        model_fn(id_)
        icon_fn(id_)
        items.append(dict(id=id_, category=cat, slot=slot, ru=ru, en=en, price=price))
    register(items)
    doc = ROOT / "docs/clothes-models.md"
    text = doc.read_text(encoding="utf-8")
    if DOC_MARK not in text:
        doc.write_text(text.rstrip("\n") + "\n" + DOC_TEXT, encoding="utf-8")
    print("halloween generated:", len(items))
