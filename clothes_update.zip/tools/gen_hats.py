#!/usr/bin/env python3
"""
Generates ten extra hats of the fitting room (all year round, no season):
  hat_witch       Witch hat: wide brim, tall cone that bends backwards, gold buckle and little stars
  hat_mushroom    Fly-agaric cap: red layered dome with white spots and cream gills underneath
  hat_crown       Gold crown with pearl tips and ruby / sapphire / emerald gems
  hat_bunny       Pink headband with a bow, one straight bunny ear and one floppy ear that droops
  hat_frog        Green beanie with two big bulging frog eyes on top
  hat_halo        Floating golden angel halo on a thin wire
  hat_chef        Tall puffy chef hat with pleats and a little red heart
  hat_propeller   Four-colour beanie with a button, a stick and a propeller
  hat_strawberry  Strawberry beanie with seeds and a green leaf crown
  hat_flowers     Flower crown: leafy wreath with daisies all around
Models, 32x textures and 16x16 GUI icons, and (idempotently) the entries in clothes.json, the lang files,
ClothingCatalog.java and ClothingPrices.java. Same smooth painter as gen_dino.py.

Run from the project root:  python3 tools/gen_hats.py
"""
import json
import math
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from gen_dino import blk, build, mix  # noqa: E402
from gen_accessories import Cube, Icon, shade  # noqa: E402
from gen_jewelry import GOLD, GOLD_D, GOLD_L, SILVER_L  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent
WHITE = (250, 248, 242)
CREAM = (238, 222, 184)
BLACK = (34, 28, 36)


# ---------------------------------------------------------------- helpers
def over(*decos):
    """First deco that returns a colour wins."""
    def d(f, x, y, w, h):
        for fn in decos:
            if fn is None:
                continue
            c = fn(f, x, y, w, h)
            if c is not None:
                return c
        return None
    return d


def sides(fn):
    """Applies a deco to the four side faces only."""
    def d(f, x, y, w, h):
        return None if f in ("top", "bottom") else fn(f, x, y, w, h)
    return d


def only(faces, col):
    def d(f, x, y, w, h):
        return col if f in faces else None
    return d


def marks(points, col, shape="plus", centre=None):
    """Little shapes at (face, cx, cy). shape: plus (5 px) or dot (2x2)."""
    pts = {}
    offs = ((0, 0), (1, 0), (-1, 0), (0, 1), (0, -1)) if shape == "plus" else ((0, 0), (1, 0), (0, 1), (1, 1))
    for f, cx, cy in points:
        for dx, dy in offs:
            pts[(f, cx + dx, cy + dy)] = centre if (shape == "plus" and (dx, dy) == (0, 0) and centre) else col
    return lambda f, x, y, w, h: pts.get((f, x, y))


def blobs(points, col):
    """Filled circles at (face, cx, cy, r)."""
    pts = {}
    for f, cx, cy, r in points:
        for yy in range(int(cy - r) - 1, int(cy + r) + 2):
            for xx in range(int(cx - r) - 1, int(cx + r) + 2):
                if (xx - cx) ** 2 + (yy - cy) ** 2 <= r * r:
                    pts[(f, xx, yy)] = col
    return lambda f, x, y, w, h: pts.get((f, x, y))


def pattern(face, pat, x0, y0, colors):
    """A small bitmap (list of strings) placed on one face; colors maps characters to colours."""
    def d(f, x, y, w, h):
        if f != face:
            return None
        yy, xx = y - y0, x - x0
        if 0 <= yy < len(pat) and 0 <= xx < len(pat[0]):
            return colors.get(pat[yy][xx])
        return None
    return d


def stripes_v(cols, n):
    """Vertical stripes of n pixels on the side faces, counted from the middle of the face, so that stacked parts
    of different widths keep their stripes in line."""
    return sides(lambda f, x, y, w, h: cols[((x - w // 2) // n) % len(cols)])


def chain(cubes, name, bone, base, segs, axis="x"):
    """A bent stalk made of boxes. segs: (width, depth, length, angle, colour, deco). Every angle is absolute
    (degrees, rotation about x: the top moves to -z for positive angles; about z: the top moves to +x).
    Each box is a little longer than its step so that the joints close. Returns the tip."""
    bx, by, bz = base
    for n, (w, dep, length, ang, col, deco) in enumerate(segs):
        rot = (ang, 0, 0) if axis == "x" else (0, 0, ang)
        cubes.append(Cube(f"{name}{n}", bone, (bx, by - (length + 0.45) / 2, bz), (w, length + 0.45, dep), col, deco,
                          pivot=(bx, by, bz), rot=rot))
        t = math.radians(ang)
        if axis == "x":
            by -= length * math.cos(t)
            bz -= length * math.sin(t)
        else:
            bx += length * math.sin(t)
            by -= length * math.cos(t)
    return (bx, by, bz)


def rim(top=None, bottom=None):
    """Plain top/bottom colours for a part."""
    def d(f, x, y, w, h):
        if f == "top":
            return top
        if f == "bottom":
            return bottom
        return None
    return d


def thick(i, pts, col, r=1.2):
    """A line of pixels that is about 2r+1 pixels wide (icons)."""
    n = int(r + 1)
    for (x, y) in pts:
        for dx in range(-n, n + 1):
            for dy in range(-n, n + 1):
                if dx * dx + dy * dy <= r * r:
                    i.put(x + dx, y + dy, col)


# ====================================================================== 1. WITCH HAT
PUR, PUR_D, PUR_L = (108, 62, 160), (72, 40, 116), (150, 100, 204)
HATBAND = (44, 32, 62)


def witch():
    star = marks([("front", 5, 3), ("right", 9, 4), ("back", 11, 2), ("left", 4, 5)], GOLD_L, centre=WHITE)
    cubes = [
        Cube("brim", "head", (0, -7.5, 0), (13.8, 0.8, 13.8), PUR_D,
             lambda f, x, y, w, h: mix(PUR_D, PUR, 0.35) if f == "top" and (x in (0, w - 1) or y in (0, h - 1)) else
             (shade(PUR_D, 0.8) if f == "bottom" else None)),
        Cube("band", "head", (0, -8.5, 0), (10.0, 1.4, 10.0), HATBAND),
    ]
    # the buckle is its own little frame on the front of the band
    cubes.append(Cube("buckle", "head", (0, -8.5, -5.05), (2.6, 1.8, 0.5), GOLD,
                      lambda f, x, y, w, h: (HATBAND if 2 <= x <= w - 3 and 2 <= y <= h - 3 else
                                             (GOLD_L if x == 0 or y == 0 else None)) if f == "front" else None))
    segs = []
    for w, length, ang, col in ((8.6, 2.4, 0, PUR), (7.0, 2.4, -6, mix(PUR, PUR_L, 0.2)), (5.4, 2.2, -16, mix(PUR, PUR_L, 0.4)),
                                (4.0, 2.2, -30, mix(PUR, PUR_L, 0.6)), (2.8, 2.0, -48, PUR_L)):
        segs.append((w, w, length, ang, col, sides(star) if w > 3 else None))
    tip = chain(cubes, "cone", "head", (0, -8.9, 0), segs)
    cubes.append(Cube("tip_ball", "head", (tip[0], tip[1] - 0.3, tip[2] + 0.2), (1.4, 1.4, 1.4), GOLD, rim(GOLD_L, GOLD_D)))
    return build("hat_witch", cubes)


def icon_witch():
    i = Icon()
    blk(i, 0, 11, 15, 12, PUR_D)
    blk(i, 4, 9, 11, 10, HATBAND)
    i.rect(7, 9, 8, 10, GOLD)
    i.put(7, 9, GOLD_L)
    i.put(8, 10, GOLD_D)
    blk(i, 4, 6, 11, 8, PUR)
    blk(i, 5, 4, 10, 5, mix(PUR, PUR_L, 0.4))
    blk(i, 6, 2, 10, 3, mix(PUR, PUR_L, 0.6))
    blk(i, 9, 0, 12, 1, PUR_L)
    i.put(6, 7, GOLD_L)
    i.put(9, 5, GOLD_L)
    i.put(8, 2, GOLD_L)
    i.save("hat_witch")


# ====================================================================== 2. MUSHROOM CAP
CAP, CAP_D = (214, 48, 58), (160, 30, 46)
GILL = (238, 214, 168)


def mushroom():
    spot = (252, 246, 234)
    cubes = [
        Cube("cap1", "head", (0, -7.6, 0), (11.4, 1.3, 11.4), CAP_D,
             lambda f, x, y, w, h: (GILL if (x // 2 + y // 2) % 2 == 0 else mix(GILL, (206, 176, 128), 0.5)) if f == "bottom" else None),
        Cube("cap2", "head", (0, -9.1, 0), (10.6, 1.8, 10.6), CAP,
             over(blobs([("front", 5, 2, 1.8), ("front", 17, 1, 1.4), ("right", 4, 2, 1.8), ("right", 16, 1, 1.4),
                         ("back", 6, 1, 1.6), ("back", 16, 2, 1.8), ("left", 5, 1, 1.6), ("left", 17, 2, 1.4),
                         ("top", 3, 3, 2), ("top", 17, 16, 2.4), ("top", 16, 4, 1.6)], spot))),
        Cube("cap3", "head", (0, -10.8, 0), (8.8, 1.8, 8.8), CAP,
             over(blobs([("front", 10, 2, 1.8), ("right", 4, 1, 1.4), ("back", 4, 2, 1.6), ("left", 12, 1, 1.4),
                         ("top", 4, 12, 2.2), ("top", 13, 5, 1.8)], spot))),
        Cube("cap4", "head", (0, -12.3, 0), (6.2, 1.4, 6.2), mix(CAP, (240, 80, 80), 0.3),
             over(blobs([("top", 6, 6, 3.2), ("front", 4, 1, 1.2), ("back", 8, 1, 1.2)], spot))),
    ]
    return build("hat_mushroom", cubes)


def icon_mushroom():
    i = Icon()
    for y, x0, x1 in ((3, 5, 10), (4, 4, 11), (5, 3, 12), (6, 2, 13), (7, 1, 14), (8, 1, 14)):
        col = CAP if y < 8 else CAP_D
        i.rect(x0, y, x1, y, col)
        i.put(x0, y, shade(col, 1.1))
        i.put(x1, y, shade(col, 0.85))
    i.rect(2, 9, 13, 10, GILL)
    for x in range(2, 14, 2):
        i.put(x, 10, mix(GILL, (190, 160, 110), 0.6))
    for (x, y) in ((6, 4), (7, 4), (6, 5), (7, 5), (3, 7), (4, 7), (3, 6), (10, 6), (11, 6), (10, 7), (11, 7), (8, 8), (9, 8), (13, 8)):
        i.put(x, y, (252, 246, 234))
    i.save("hat_mushroom")


# ====================================================================== 3. JEWELED CROWN
RUBY, RUBY_D = (224, 40, 70), (150, 20, 50)
SAPH, SAPH_D = (60, 110, 230), (30, 64, 160)
EMER, EMER_D = (50, 190, 110), (24, 120, 70)
PEARL = (252, 250, 246)


def gem(base, dark):
    def d(f, x, y, w, h):
        if f in ("top",):
            return mix(base, WHITE, 0.45)
        if f == "bottom":
            return dark
        if x == 0 or y == 0:
            return mix(base, WHITE, 0.55)
        if x == w - 1 or y == h - 1:
            return dark
        return None
    return d


def gold_deco(f, x, y, w, h):
    if f == "top":
        return GOLD_L
    if f == "bottom":
        return GOLD_D
    if y == 0:
        return GOLD_L
    if y == h - 1:
        return GOLD_D
    if y == h // 2 and x % 4 == 1:
        return GOLD_D
    return None


def crown():
    cubes = [
        Cube("band_f", "head", (0, -8.6, -4.5), (10.0, 2.2, 1.0), GOLD, gold_deco),
        Cube("band_b", "head", (0, -8.6, 4.5), (10.0, 2.2, 1.0), GOLD, gold_deco),
        Cube("band_r", "head", (-4.5, -8.6, 0), (1.0, 2.2, 8.0), GOLD, gold_deco),
        Cube("band_l", "head", (4.5, -8.6, 0), (1.0, 2.2, 8.0), GOLD, gold_deco),
    ]
    spots = []
    for ix in (-1, 0, 1):
        for iz in (-1, 0, 1):
            if ix == 0 and iz == 0:
                continue
            spots.append((ix, iz))
    for n, (ix, iz) in enumerate(spots):
        mid = (ix == 0 or iz == 0)
        height = 3.4 if mid else 2.4
        cx, cz = ix * 4.0, iz * 4.0
        cubes.append(Cube(f"spike{n}", "head", (cx, -9.7 - height / 2, cz), (1.6, height, 1.6), GOLD,
                          lambda f, x, y, w, h: GOLD_L if f == "top" else (GOLD_D if f == "bottom" else (GOLD_L if x == 0 else None))))
        cubes.append(Cube(f"tip{n}", "head", (cx, -9.7 - height - 0.35, cz), (1.5, 1.5, 1.5) if mid else (1.1, 1.1, 1.1),
                          PEARL if mid else GOLD_L, rim(WHITE, (214, 210, 204))))
    cubes += [
        Cube("ruby", "head", (0, -8.6, -5.3), (2.2, 1.6, 0.8), RUBY, gem(RUBY, RUBY_D)),
        Cube("sapphire_r", "head", (-5.3, -8.6, 0), (0.8, 1.6, 2.2), SAPH, gem(SAPH, SAPH_D)),
        Cube("sapphire_l", "head", (5.3, -8.6, 0), (0.8, 1.6, 2.2), SAPH, gem(SAPH, SAPH_D)),
        Cube("emerald", "head", (0, -8.6, 5.3), (2.2, 1.6, 0.8), EMER, gem(EMER, EMER_D)),
    ]
    return build("hat_crown", cubes)


def icon_crown():
    i = Icon()
    blk(i, 2, 10, 13, 12, GOLD)
    blk(i, 2, 7, 3, 9, GOLD)
    blk(i, 6, 5, 9, 9, GOLD)
    blk(i, 12, 7, 13, 9, GOLD)
    blk(i, 4, 6, 5, 9, GOLD_L)
    blk(i, 10, 6, 11, 9, GOLD_L)
    i.rect(7, 3, 8, 4, PEARL)
    i.put(2, 6, GOLD_L)
    i.put(13, 6, GOLD_L)
    i.rect(7, 11, 8, 11, RUBY)
    i.put(4, 11, SAPH)
    i.put(11, 11, EMER)
    i.save("hat_crown")


# ====================================================================== 4. BUNNY EARS (one floppy)
PINK, PINK_D, PINK_L = (246, 150, 178), (206, 100, 134), (255, 206, 220)
BOW = (232, 62, 96)


def ear_deco(f, x, y, w, h):
    if f == "front":
        if 1 <= x <= w - 2:
            return mix(PINK, PINK_L, 0.4) if x in (1, w - 2) else PINK
        return None
    if f in ("top", "bottom"):
        return WHITE
    return None


def bunny():
    cubes = [
        Cube("band_top", "head", (0, -8.8, 0), (10.4, 0.9, 1.4), PINK, rim(PINK_L, PINK_D)),
        Cube("band_r", "head", (-4.95, -7.0, 0), (0.8, 3.6, 1.4), PINK),
        Cube("band_l", "head", (4.95, -7.0, 0), (0.8, 3.6, 1.4), PINK),
        Cube("bow_knot", "head", (-3.4, -9.7, -0.2), (1.0, 1.0, 1.0), BOW),
        Cube("bow_a", "head", (-4.6, -9.7, -0.2), (1.8, 1.4, 0.9), BOW, rim(mix(BOW, WHITE, 0.3), shade(BOW, 0.7))),
        Cube("bow_b", "head", (-2.2, -9.7, -0.2), (1.8, 1.4, 0.9), BOW, rim(mix(BOW, WHITE, 0.3), shade(BOW, 0.7))),
    ]
    # straight ear on the player's right (-x), leaning a little outwards
    chain(cubes, "ear_r", "head", (-2.4, -9.2, 0.4),
          [(2.7, 1.2, 3.3, -5, WHITE, ear_deco), (2.7, 1.2, 3.3, -2, WHITE, ear_deco), (2.5, 1.2, 2.8, 3, WHITE, ear_deco)], axis="z")
    # floppy ear on the left: goes up, then bends over in a tight arc and hangs down
    segs = [(2.7, 1.2, 2.0, 4, WHITE, ear_deco)]
    segs += [(2.7, 1.2, 0.95, a, WHITE, ear_deco) for a in (28, 56, 84, 112, 140, 164)]
    segs += [(2.5, 1.2, 2.2, 176, WHITE, ear_deco)]
    chain(cubes, "ear_l", "head", (2.4, -9.2, 0.4), segs, axis="z")
    return build("hat_bunny", cubes)


def icon_bunny():
    i = Icon()
    # headband
    i.rect(3, 12, 12, 13, PINK)
    i.rect(2, 13, 3, 14, PINK)
    i.rect(12, 13, 13, 14, PINK)
    i.rect(3, 12, 12, 12, PINK_L)
    # straight ear
    thick(i, [(4, y) for y in range(2, 11)], WHITE, 1.1)
    for y in range(3, 10):
        i.put(4, y, PINK)
    for y in range(2, 11):
        i.put(5, y, (222, 218, 214))
    # floppy ear: up, over, down
    path = [(10, 10), (10, 9), (10, 8), (10, 7), (10, 6), (10, 5), (11, 4), (12, 3), (13, 3), (14, 4), (14, 5), (14, 6), (14, 7)]
    thick(i, path, WHITE, 1.0)
    for (x, y) in path[3:-1]:
        i.put(x, y, PINK)
    # bow
    i.rect(6, 10, 7, 11, BOW)
    i.rect(8, 10, 9, 11, BOW)
    i.put(7, 10, mix(BOW, WHITE, 0.4))
    i.put(8, 11, shade(BOW, 0.7))
    i.save("hat_bunny")


# ====================================================================== 5. FROG BEANIE
FROG, FROG_D, FROG_L = (92, 178, 84), (58, 130, 62), (136, 208, 112)


def frog():
    cubes = [
        Cube("base", "head", (0, -7.5, 0), (10.0, 2.2, 10.0), FROG_D),
        Cube("mid", "head", (0, -9.5, 0), (9.2, 1.9, 9.2), FROG),
        Cube("top", "head", (0, -11.1, 0), (7.2, 1.6, 7.2), FROG_L),
    ]
    def eye(f, x, y, w, h):
        if f == "front":
            return BLACK if 1 <= x <= w - 2 and 2 <= y <= h - 2 else None
        return (254, 254, 250) if f == "top" else ((216, 222, 214) if f == "bottom" else None)

    for tag, sx in (("r", -1), ("l", 1)):
        cubes.append(Cube(f"eye_{tag}", "head", (sx * 2.5, -13.0, -1.5), (3.2, 3.2, 3.2), WHITE, eye))
        cubes.append(Cube(f"shine_{tag}", "head", (sx * 2.5 - sx * 0.3, -13.2, -3.12), (0.8, 0.8, 0.3), WHITE))
        cubes.append(Cube(f"lid_{tag}", "head", (sx * 2.5, -14.6, -1.5), (3.5, 1.4, 3.5), FROG_L, rim(mix(FROG_L, WHITE, 0.3), FROG_D)))
    return build("hat_frog", cubes)


def icon_frog():
    i = Icon()
    for y, x0, x1 in ((8, 4, 11), (9, 2, 13), (10, 2, 13), (11, 1, 14), (12, 1, 14)):
        col = FROG_L if y == 8 else (FROG if y < 12 else FROG_D)
        i.rect(x0, y, x1, y, col)
        i.put(x0, y, shade(col, 1.1))
        i.put(x1, y, shade(col, 0.85))
    for ex in (2, 9):
        i.rect(ex, 3, ex + 3, 7, WHITE)
        i.rect(ex, 3, ex + 3, 4, FROG_L)
        i.rect(ex + 1, 5, ex + 2, 7, BLACK)
        i.put(ex + 1, 5, WHITE)
    i.save("hat_frog")


# ====================================================================== 6. ANGEL HALO
HALO = (255, 226, 104)
HALO_D = (214, 164, 48)


def halo():
    cubes = []
    r_mid, y = 3.45, -12.8
    for n in range(8):
        phi = n * 45.0
        mx, mz = r_mid * math.sin(math.radians(phi)), -r_mid * math.cos(math.radians(phi))
        cubes.append(Cube(f"seg{n}", "head", (mx, y, mz), (3.0, 1.0, 1.1), HALO, rim((255, 246, 190), HALO_D),
                          pivot=(mx, y, mz), rot=(0, -phi, 0)))
    cubes.append(Cube("wire", "head", (0, -10.6, 3.5), (0.6, 4.6, 0.6), GOLD_D))
    cubes.append(Cube("clip", "head", (0, -8.3, 4.2), (2.0, 1.0, 1.0), GOLD, rim(GOLD_L, GOLD_D)))
    return build("hat_halo", cubes)


def icon_halo():
    i = Icon()
    cx, cy, rx, ry = 7.5, 8.0, 6.6, 3.9
    for y in range(16):
        for x in range(16):
            n = math.sqrt(((x - cx) / rx) ** 2 + ((y - cy) / ry) ** 2)
            if 0.58 <= n <= 1.0:
                col = (255, 246, 190) if y < cy - 1 else (HALO if y <= cy + 1 else HALO_D)
                i.put(x, y, col)
    for sx, sy in ((2, 2), (13, 2)):
        for dx, dy in ((0, 0), (1, 0), (-1, 0), (0, 1), (0, -1)):
            i.put(sx + dx, sy + dy, WHITE if (dx, dy) == (0, 0) else (255, 246, 190))
    i.save("hat_halo")


# ====================================================================== 7. CHEF HAT
CH, CH_D = (248, 246, 240), (216, 214, 208)
HEART = ["XX.XX", "XXXXX", "XXXXX", ".XXX.", "..X.."]


def pleats(step, shade_col=CH_D):
    def d(f, x, y, w, h):
        if f in ("top", "bottom"):
            return None
        return shade_col if x % step == step - 1 else None
    return d


def chef():
    cubes = [
        Cube("band", "head", (0, -7.1, 0), (10.0, 2.4, 10.0), CH, over(sides(lambda f, x, y, w, h: CH_D if y == h - 1 else None), pleats(4))),
        Cube("puff1", "head", (0, -9.5, 0), (10.4, 2.2, 10.4), CH, pleats(4)),
        Cube("puff2", "head", (0, -12.3, 0), (11.8, 3.6, 11.8), CH,
             over(pattern("front", HEART, 10, 2, {"X": (226, 52, 76)}), pleats(5), sides(lambda f, x, y, w, h: CH_D if y >= h - 1 else None))),
        Cube("crown", "head", (0, -14.7, 0), (10.0, 1.3, 10.0), CH, rim((255, 255, 252), CH_D)),
    ]
    return build("hat_chef", cubes)


def icon_chef():
    i = Icon()
    for y, x0, x1 in ((1, 5, 10), (2, 3, 12), (3, 2, 13), (4, 1, 14), (5, 1, 14), (6, 1, 14), (7, 1, 14), (8, 2, 13), (9, 3, 12)):
        i.rect(x0, y, x1, y, CH)
        i.put(x1, y, CH_D)
        i.put(x0, y, WHITE)
    for x in range(4, 13, 3):
        i.rect(x, 3, x, 8, CH_D)
    i.rect(3, 10, 12, 13, CH)
    i.rect(3, 13, 12, 13, CH_D)
    for x in range(5, 12, 3):
        i.rect(x, 10, x, 12, CH_D)
    for (x, y) in ((6, 5), (7, 5), (9, 5), (10, 5)):
        i.put(x, y, (226, 52, 76))
    i.rect(6, 6, 10, 6, (226, 52, 76))
    i.rect(7, 7, 9, 7, (226, 52, 76))
    i.put(8, 8, (226, 52, 76))
    i.save("hat_chef")


# ====================================================================== 8. PROPELLER BEANIE
PROP = [(222, 58, 66), (250, 208, 64), (66, 122, 216), (70, 172, 96)]


def quadrants(f, x, y, w, h):
    return PROP[(x >= w // 2) + 2 * (y >= h // 2)] if f == "top" else None


def propeller():
    pan = over(stripes_v(PROP, 4), quadrants)
    cubes = [
        Cube("base", "head", (0, -7.5, 0), (10.0, 2.2, 10.0), PROP[0], over(pan, rim(None, (60, 50, 70)))),
        Cube("mid", "head", (0, -9.4, 0), (9.2, 1.8, 9.2), PROP[1], pan),
        Cube("top", "head", (0, -11.0, 0), (6.8, 1.6, 6.8), PROP[2], pan),
        Cube("button", "head", (0, -12.2, 0), (1.8, 1.0, 1.8), (250, 214, 70), rim((255, 238, 160), GOLD_D)),
        Cube("stick", "head", (0, -13.2, 0), (0.8, 1.4, 0.8), (150, 154, 170)),
    ]

    def blade(col, tip):
        def d(f, x, y, w, h):
            if f == "top":
                return mix(col, WHITE, 0.25) if x < 3 or x > w - 4 else None
            if f == "bottom":
                return shade(col, 0.7)
            return None
        return d

    cubes.append(Cube("blade_a", "head", (0, -14.1, 0), (8.4, 0.5, 1.9), PROP[0], blade(PROP[0], WHITE),
                      pivot=(0, -14.1, 0), rot=(0, 30, 0)))
    cubes.append(Cube("blade_b", "head", (0, -14.1, 0), (8.4, 0.5, 1.9), PROP[2], blade(PROP[2], WHITE),
                      pivot=(0, -14.1, 0), rot=(0, 120, 0)))
    cubes.append(Cube("hub", "head", (0, -14.3, 0), (1.2, 0.8, 1.2), (250, 214, 70), rim((255, 238, 160), GOLD_D)))
    return build("hat_propeller", cubes)


def icon_propeller():
    i = Icon()
    for y, x0, x1 in ((7, 5, 10), (8, 3, 12), (9, 2, 13), (10, 2, 13), (11, 2, 13), (12, 2, 13)):
        for x in range(x0, x1 + 1):
            col = PROP[((x - 2) // 3) % 4]
            if y == 7:
                col = shade(col, 1.12)
            if y == 12:
                col = shade(col, 0.78)
            i.put(x, y, col)
    i.rect(7, 5, 8, 6, (250, 214, 70))
    i.put(7, 5, (255, 238, 160))
    i.rect(1, 3, 7, 4, PROP[0])
    i.rect(8, 3, 14, 4, PROP[2])
    i.rect(1, 3, 2, 3, WHITE)
    i.rect(13, 3, 14, 3, WHITE)
    i.save("hat_propeller")


# ====================================================================== 9. STRAWBERRY BEANIE
BERRY, BERRY_D = (216, 52, 68), (162, 34, 54)
SEED = (252, 224, 126)
LEAF, LEAF_D, LEAF_L = (76, 172, 86), (44, 116, 60), (130, 206, 112)


def seeds(f, x, y, w, h):
    if f == "bottom":
        return None
    if f == "top":
        return SEED if (x % 5 == 2 and y % 5 == 2) else None
    row = y // 3
    off = 2 if row % 2 else 0
    return SEED if (x + off) % 5 == 2 and y % 3 == 1 else None


def strawberry():
    cubes = [
        Cube("base", "head", (0, -7.5, 0), (10.0, 2.2, 10.0), BERRY_D, over(seeds)),
        Cube("mid", "head", (0, -9.6, 0), (9.4, 2.0, 9.4), BERRY, seeds),
        Cube("upper", "head", (0, -11.4, 0), (7.6, 1.8, 7.6), BERRY, seeds),
        Cube("top", "head", (0, -12.9, 0), (4.8, 1.4, 4.8), mix(BERRY, WHITE, 0.08), seeds),
        Cube("stem", "head", (0, -14.5, 0), (0.9, 1.6, 0.9), LEAF_D, rim(LEAF, LEAF_D)),
    ]

    def leaf(f, x, y, w, h):
        if f == "top":
            return LEAF_L if (x == w // 2 or x == w // 2 - 1) else LEAF
        if f == "bottom":
            return LEAF_D
        return None

    top_y = -13.85
    for tag, c, d, rot in (
        ("f", (0, top_y, -2.4), (2.4, 0.6, 4.4), (20, 0, 0)),
        ("b", (0, top_y, 2.4), (2.4, 0.6, 4.4), (-20, 0, 0)),
        ("r", (-2.4, top_y, 0), (4.4, 0.6, 2.4), (0, 0, -20)),
        ("l", (2.4, top_y, 0), (4.4, 0.6, 2.4), (0, 0, 20)),
    ):
        cubes.append(Cube(f"leaf_{tag}", "head", c, d, LEAF, leaf, pivot=(0, top_y, 0), rot=rot))
    return build("hat_strawberry", cubes)


def icon_strawberry():
    i = Icon()
    rows = ((5, 4, 11), (6, 3, 12), (7, 2, 13), (8, 2, 13), (9, 2, 13), (10, 2, 13), (11, 3, 12), (12, 3, 12))
    for y, x0, x1 in rows:
        col = BERRY if y < 11 else BERRY_D
        i.rect(x0, y, x1, y, col)
        i.put(x0, y, shade(col, 1.12))
        i.put(x1, y, shade(col, 0.85))
    for (x, y) in ((5, 6), (9, 6), (4, 8), (7, 8), (11, 8), (6, 10), (9, 10), (12, 10)):
        i.put(x, y, SEED)
    for (x0, x1, y) in ((2, 5, 4), (10, 13, 4), (5, 7, 3), (8, 10, 3)):
        i.rect(x0, y, x1, y, LEAF)
    i.rect(6, 1, 9, 2, LEAF_L)
    i.rect(7, 0, 8, 1, LEAF_D)
    i.save("hat_strawberry")


# ====================================================================== 10. FLOWER CROWN
WREATH, WREATH_D = (86, 160, 76), (56, 116, 56)
DAISY = ["..XX..", ".XXXX.", "XXCCXX", "XXCCXX", ".XXXX.", "..XX.."]
FLOWER_COLS = {"white": (252, 250, 244), "pink": (248, 142, 178), "blue": (116, 164, 244),
               "coral": (252, 150, 98), "violet": (178, 130, 232)}


def flower_deco(col):
    def d(f, x, y, w, h):
        if f == "front":
            if 0 <= y < 6 and 0 <= x < 6:
                c = DAISY[y][x]
                if c == "C":
                    return (252, 206, 66)
                if c == "X":
                    return col
                return "clear"
            return None
        return shade(col, 0.88) if f != "top" else mix(col, WHITE, 0.3)
    return d


def flowers():
    def leafy(f, x, y, w, h):
        if f == "bottom":
            return WREATH_D
        base = ((x + y) // 3) % 2
        if f == "top":
            return mix(WREATH, WHITE, 0.15) if base else WREATH
        return WREATH_D if base else None

    cubes = [
        Cube("wreath_f", "head", (0, -8.1, -4.3), (10.0, 1.2, 1.4), WREATH, leafy),
        Cube("wreath_b", "head", (0, -8.1, 4.3), (10.0, 1.2, 1.4), WREATH, leafy),
        Cube("wreath_r", "head", (-4.3, -8.1, 0), (1.4, 1.2, 7.2), WREATH, leafy),
        Cube("wreath_l", "head", (4.3, -8.1, 0), (1.4, 1.2, 7.2), WREATH, leafy),
    ]
    spec = [
        ("w_front", (0, -8.1, -5.35), 0, "pink"),
        ("w_fr", (-3.6, -8.1, -4.55), 33, "white"),
        ("w_fl", (3.6, -8.1, -4.55), -33, "blue"),
        ("w_sr", (-5.4, -8.1, -0.9), 90, "coral"),
        ("w_sl", (5.4, -8.1, -0.9), -90, "violet"),
        ("w_back", (0, -8.1, 5.35), 180, "pink"),
        ("w_br", (-4.1, -8.1, 3.6), 128, "white"),
        ("w_bl", (4.1, -8.1, 3.6), -128, "blue"),
    ]
    for name, c, ry, col in spec:
        cubes.append(Cube(name, "head", c, (3.0, 3.0, 0.9), FLOWER_COLS[col], flower_deco(FLOWER_COLS[col]),
                          pivot=c, rot=(0, ry, 0)))
    for name, c, ry in (("leaf_a", (-1.9, -8.1, -5.1), 12), ("leaf_b", (1.9, -8.1, -5.1), -12)):
        cubes.append(Cube(name, "head", c, (1.6, 1.0, 0.7), LEAF, rim(LEAF_L, LEAF_D), pivot=c, rot=(0, ry, 0)))
    return build("hat_flowers", cubes)


def icon_flowers():
    i = Icon()
    arch = []
    for x in range(1, 15):
        y = 12 - round(2.4 * math.sin(math.pi * (x - 1) / 13))
        arch.append((x, y))
        i.put(x, y, WREATH)
        i.put(x, y + 1, WREATH_D if x % 2 else WREATH)
        i.put(x, y + 2, WREATH_D)

    def daisy(cx, cy, col):
        for dx, dy in ((0, -1), (-1, 0), (1, 0), (0, 1)):
            i.put(cx + dx, cy + dy, col)
        i.put(cx, cy, (252, 206, 66))

    daisy(3, 10, FLOWER_COLS["pink"])
    daisy(8, 8, FLOWER_COLS["white"])
    daisy(12, 10, FLOWER_COLS["blue"])
    i.put(6, 10, LEAF_L)
    i.put(10, 9, LEAF_L)
    i.put(5, 7, FLOWER_COLS["coral"])
    i.put(11, 6, FLOWER_COLS["violet"])
    i.save("hat_flowers")


# ====================================================================== registration
ENTRIES = [
    dict(id="hat_witch", ru="Шляпа ведьмочки", en="Witch Hat", price=3499, build=witch, icon=icon_witch),
    dict(id="hat_mushroom", ru="Шапка-мухомор", en="Mushroom Cap", price=2999, build=mushroom, icon=icon_mushroom),
    dict(id="hat_crown", ru="Корона с самоцветами", en="Jeweled Crown", price=4999, build=crown, icon=icon_crown),
    dict(id="hat_bunny", ru="Заячьи ушки с бантиком", en="Bunny Ears with a Bow", price=2499, build=bunny, icon=icon_bunny),
    dict(id="hat_frog", ru="Шапка-лягушка", en="Frog Beanie", price=2799, build=frog, icon=icon_frog),
    dict(id="hat_halo", ru="Нимб ангелочка", en="Angel Halo", price=1999, build=halo, icon=icon_halo),
    dict(id="hat_chef", ru="Поварской колпак", en="Chef Hat", price=1999, build=chef, icon=icon_chef),
    dict(id="hat_propeller", ru="Шапка с пропеллером", en="Propeller Beanie", price=1799, build=propeller, icon=icon_propeller),
    dict(id="hat_strawberry", ru="Шапка-клубничка", en="Strawberry Beanie", price=2299, build=strawberry, icon=icon_strawberry),
    dict(id="hat_flowers", ru="Веночек из цветов", en="Flower Crown", price=2499, build=flowers, icon=icon_flowers),
]

DOC_MARK = "## More hats (all year)"
DOC_TEXT = """
## More hats (all year)
Ten hats without a season, all in the Hats tab (`python3 tools/gen_hats.py` regenerates models, textures and icons and
registers the items idempotently in `clothes.json`, the lang files, `ClothingCatalog` and `ClothingPrices`).
- `hat_witch`: wide brim, gold buckle and a cone of five boxes that bends backwards, with little gold stars.
- `hat_mushroom`: layered red fly-agaric cap with white spots and cream gills on the underside of the brim.
- `hat_crown`: gold band with eight spikes (pearl tips on the tall ones) and a ruby, two sapphires and an emerald.
- `hat_bunny`: pink headband with a bow, one straight ear and one floppy ear made of six bent segments.
- `hat_frog`: green beanie with two big eyes on top (pupils on the front face, green eyelids).
- `hat_halo`: octagon of eight bars (each turned with `rot` around its own centre) floating over the head on a wire.
- `hat_chef`: tall pleated chef hat with a small red heart on the front.
- `hat_propeller`: beanie with four colour panels, a button, a stick and two crossed blades.
- `hat_strawberry`: red beanie with seeds painted in a staggered grid and a calyx of four tilted leaves.
- `hat_flowers`: leafy wreath with eight daisies; the flowers are turned around their centres (`rot`) to follow the head
  and their petals are cut out of the texture with transparent pixels.
Bent parts (ears, the witch cone) are built by `chain()` in the script: every box is a bit longer than its step, so the
joints close even on the outside of a bend.
"""

CATEGORY = {"hat": "HAT"}


def register(entries):
    res = ROOT / "src/main/resources/assets/fittingroom"
    cj = json.loads((res / "clothes.json").read_text(encoding="utf-8"))
    have = {it["id"] for it in cj["items"]}
    for e in entries:
        if e["id"] in have:
            continue
        cj["items"].append({
            "id": e["id"], "category": "hat",
            "name": {"ru_ru": e["ru"], "en_us": e["en"]},
            "model": f"fittingroom:clothes_models/{e['id']}.json",
            "texture": f"fittingroom:textures/clothes/{e['id']}.png",
            "icon": f"fittingroom:textures/gui/clothes/{e['id']}.png"})
    (res / "clothes.json").write_text(json.dumps(cj, ensure_ascii=False) + "\n", encoding="utf-8")

    for lang, key in (("ru_ru", "ru"), ("en_us", "en")):
        path = res / f"lang/{lang}.json"
        data = json.loads(path.read_text(encoding="utf-8"))
        for e in entries:
            data.setdefault(f"clothes.fittingroom.{e['id']}", e[key])
        path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    java = ROOT / "src/main/java/com/fittingroom/wardrobe/ClothingCatalog.java"
    text = java.read_text(encoding="utf-8")
    start = text.index("public static final List<Item> ITEMS = List.of(")
    end = text.index("\n    );", start)
    lines = "".join(f',\n            new Item("{e["id"]}", Category.HAT)' for e in entries if f'"{e["id"]}"' not in text)
    if lines:
        java.write_text(text[:end] + lines + text[end:], encoding="utf-8")

    prices = ROOT / "src/main/java/com/fittingroom/wardrobe/ClothingPrices.java"
    text = prices.read_text(encoding="utf-8")
    anchor = "        // ---- scarves ----\n"
    assert anchor in text, "anchor for the prices not found"
    lines = "".join(f'        p("{e["id"]}", {e["price"]});\n' for e in entries if f'"{e["id"]}"' not in text)
    if lines:
        prices.write_text(text.replace(anchor, "        // ---- hats (all year) ----\n" + lines + "\n" + anchor, 1), encoding="utf-8")

    doc = ROOT / "docs/clothes-models.md"
    text = doc.read_text(encoding="utf-8")
    if DOC_MARK not in text:
        doc.write_text(text.rstrip("\n") + "\n" + DOC_TEXT, encoding="utf-8")


if __name__ == "__main__":
    for e in ENTRIES:
        e["build"]()
        e["icon"]()
    register(ENTRIES)
    print("hats generated:", ", ".join(e["id"] for e in ENTRIES))
