#!/usr/bin/env python3
"""
Generates the extra New Year clothes of the fitting room (seasonal, like the Santa set: Dec 15 - Jan 14):
  reindeer_antlers    (hat)        brown headband with two branching antlers and a red Rudolph nose
  snow_kokoshnik      (hat)        Snow Maiden: blue fan-shaped kokoshnik with pearls and a long blonde braid
  xmas_sweater        (top)        red knitted sweater: white snowflake yoke, green fir trees, ribbed hem and cuffs
  snow_coat           (top)        Snow Maiden fur coat: blue, white fur collar / front / hem / cuffs, silver embroidery
  snow_valenki        (shoes)      white felt boots with a blue ornament and a rolled cuff
  candy_cane          (accessory)  striped cane carried in the right hand
  necklace_snowflake  (accessory, slot "necklace")  silver chain with an icy snowflake
  bracelet_bells      (accessory, slot "wrist")     red-green ribbon with golden jingle bells (both wrists)
Models, 32x textures, 16x16 GUI icons and (idempotently) the entries in clothes.json, the lang files,
ClothingCatalog.java and ClothingPrices.java. Same smooth painter as gen_dino.py.

Run from the project root:  python3 tools/gen_newyear.py
"""
import json
import math
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from gen_dino import blk, build, mix  # noqa: E402
from gen_accessories import Cube, Icon, shade  # noqa: E402
from gen_jewelry import GOLD, GOLD_D, GOLD_L, NZ, RW, SILVER, SILVER_D, SILVER_L, chain_points, shaped  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent
WHITE = (250, 248, 242)
RED, RED_D = (200, 44, 58), (148, 30, 46)
GREEN, GREEN_L = (44, 134, 80), (72, 172, 104)
BROWN = (156, 104, 64)
BROWN_D, BROWN_L = (112, 72, 44), (206, 152, 102)
BLUE, BLUE_D, BLUE_L = (66, 116, 196), (40, 78, 154), (110, 156, 226)
FELT, FELT_D = (238, 234, 226), (196, 190, 182)
HAIR, HAIR_D = (232, 196, 132), (196, 150, 86)


def tw(side, n):
    return None if side == "r" else n + "_r"


def keep(center):
    """pivot/rot for an arm cube that must keep its authored X offset: the loader squeezes and re-centres every
    arm cube WITHOUT a rotation on slim (Alex) arms, so an off-centre part (cane crook, bells) would sink into the arm."""
    return dict(pivot=center, rot=(0, 0, 0.01))


def pat_at(pat, x, y, x0, y0):
    yy, xx = y - y0, x - x0
    if 0 <= yy < len(pat) and 0 <= xx < len(pat[0]):
        return pat[yy][xx]
    return None


def fur(x, y):
    """White fur with a few cold-blue specks."""
    return (218, 230, 246) if (x * 3 + y * 5) % 7 == 0 else WHITE


SNOW5 = ["X.X.X", ".XXX.", "XXXXX", ".XXX.", "X.X.X"]
TREE = ["..G..", ".GGG.", "..G..", ".GGG.", "GGGGG", "..B.."]


# ====================================================================== 1. REINDEER ANTLERS (hat)
BAND = (96, 64, 48)
NOSE = (222, 40, 52)


def antler_deco(f, x, y, w, h):
    if f == "top":
        return BROWN_L
    return BROWN_D if y % 7 == 4 else None


def beam(cubes, name, base, length, thick, rz, rx=0):
    """A bar growing from `base` (its lower end) in a direction tilted by rz (top moves to +x) and rx (top moves to -z).
    Returns the upper end, so that tines can start there."""
    bx, by, bz = base
    cubes.append(Cube(name, "head", (bx, by - length / 2, bz), (thick, length, thick), BROWN, antler_deco,
                      pivot=base, rot=(rx, 0, rz)))
    t, p = math.radians(rz), math.radians(rx)
    dx = length * math.sin(t)
    dy = -length * math.cos(t) * math.cos(p)
    dz = -length * math.sin(p)
    return (bx + dx, by + dy, bz + dz)


def antlers():
    cubes = [
        Cube("band_top", "head", (0, -9.0, 0), (10.6, 0.8, 1.2), BAND, lambda f, x, y, w, h: None if f in ("top", "bottom") else
             (mix(BAND, (60, 40, 30), 0.5) if y == h - 1 else None)),
        Cube("band_r", "head", (-4.95, -7.3, 0), (0.7, 3.6, 1.2), BAND),
        Cube("band_l", "head", (4.95, -7.3, 0), (0.7, 3.6, 1.2), BAND),
        Cube("nose", "head", (0, -2.4, -4.85), (2.0, 1.8, 1.4), NOSE,
             lambda f, x, y, w, h: (255, 168, 176) if f == "front" and x == 0 and y == 0 else None),
    ]
    for tag, sx in (("r", -1), ("l", 1)):
        base = (sx * 2.7, -9.3, 0.2)
        tip = beam(cubes, f"beam_{tag}", base, 5.0, 1.0, sx * 15)
        mid = (base[0] + (tip[0] - base[0]) * 0.5, base[1] + (tip[1] - base[1]) * 0.5, base[2])
        beam(cubes, f"tine_out_{tag}", mid, 2.8, 0.8, sx * 52)
        beam(cubes, f"tine_front_{tag}", mid, 2.4, 0.8, sx * 8, rx=42)
        beam(cubes, f"tine_back_{tag}", tip, 2.2, 0.8, sx * -12, rx=-38)
    return build("reindeer_antlers", cubes)


def icon_antlers():
    i = Icon()
    for x in range(4, 12):
        i.put(x, 11, BAND)
    for y in (12, 13):
        i.put(3, y, BAND)
        i.put(12, y, BAND)
    for sx in (0, 1):
        def X(v):
            return 15 - v if sx else v
        for (x, y) in ((5, 10), (5, 9), (4, 8), (4, 7), (4, 6), (3, 5), (3, 4)):
            i.put(X(x), y, BROWN)
        for (x, y) in ((5, 7), (6, 6), (6, 5), (2, 7), (1, 6)):
            i.put(X(x), y, BROWN_L)
        i.put(X(4), 5, BROWN_D)
    i.rect(7, 13, 8, 14, NOSE)
    i.put(7, 13, (255, 168, 176))
    i.save("reindeer_antlers")


# ====================================================================== 2. SNOW MAIDEN KOKOSHNIK + BRAID (hat)
PEARL = (252, 250, 246)


def band_deco(f, x, y, w, h):
    if f in ("top", "bottom"):
        return None
    if y in (0, h - 1):
        return SILVER
    if y == h // 2 and x % 3 == 0:
        return PEARL
    return None


def bar_deco(f, x, y, w, h):
    if f == "top":
        return PEARL
    if f == "bottom":
        return None
    if y == 0:
        return PEARL if x % 2 == 0 else SILVER_L
    if x in (0, w - 1):
        return SILVER
    if y % 4 == 2 and x % 2 == 1:
        return PEARL
    if y % 4 == 0:
        return BLUE_L
    return None


def braid_deco(f, x, y, w, h):
    if f in ("top", "bottom"):
        return None
    return HAIR_D if ((x + y) // 2) % 2 == 0 else HAIR


def kokoshnik():
    cubes = [Cube("band", "head", (0, -7.1, 0), (9.9, 1.8, 9.9), BLUE_D, band_deco)]
    xs = (-3.9, -2.6, -1.3, 0.0, 1.3, 2.6, 3.9)
    hs = (1.8, 3.2, 4.6, 5.6, 4.6, 3.2, 1.8)
    for n, (x, h) in enumerate(zip(xs, hs)):
        cubes.append(Cube(f"bar{n}", "head", (x, -7.8 - h / 2, -4.4), (1.35, h, 1.0), BLUE, bar_deco))
    for n in range(4):
        ox = 0.3 if n % 2 else -0.3
        cubes.append(Cube(f"braid{n}", "body", (ox, 1.4 + n * 2.6, 3.0), (2.0, 2.8, 1.6), HAIR, braid_deco))
    cubes.append(Cube("ribbon", "body", (0, 11.0, 3.0), (2.6, 1.2, 2.0), BLUE,
                      lambda f, x, y, w, h: None if f in ("top", "bottom") else (PEARL if y == 0 and x % 2 == 0 else None)))
    return build("snow_kokoshnik", cubes)


def icon_kokoshnik():
    i = Icon()
    heights = [4, 3, 6, 5, 8, 7, 8, 5, 6, 3, 4]
    for n, h in enumerate(heights[:10]):
        x = 3 + n
        h = heights[n] + (1 if n in (4, 5) else 0)
        col = BLUE if n % 2 == 0 else BLUE_L
        i.rect(x, 11 - h, x, 10, col)
        if n % 2 == 0:
            i.put(x, 10 - h, PEARL)
            i.put(x, 11 - h, SILVER_L)
        if h >= 6:
            i.put(x, 8, SILVER_L if n % 2 == 0 else PEARL)
    i.rect(2, 11, 13, 12, SILVER_L)
    for x in range(2, 14, 2):
        i.put(x, 11, BLUE_D)
    i.rect(2, 12, 13, 12, SILVER)
    i.rect(12, 13, 13, 14, HAIR)
    i.put(13, 15, BLUE)
    i.save("snow_kokoshnik")


# ====================================================================== 3. CHRISTMAS SWEATER (top)
SWEATER = dict(base=RED, rib=(244, 240, 232))


def sweater_deco(kind):
    base, rib = SWEATER["base"], SWEATER["rib"]

    def d(f, x, y, w, h):
        if f in ("top", "bottom"):
            return None
        if kind == "body" and y >= h - 3:
            return rib if x % 2 == 0 else mix(rib, base, 0.4)
        mx = (x + (1 if kind == "sleeve" else 0)) % 8
        if 4 <= y <= 8 and mx < 5 and SNOW5[y - 4][mx] == "X":
            return WHITE
        if y == 11:
            return WHITE if x % 4 < 2 else GREEN
        if kind == "body":
            if 13 <= y <= 18 and mx < 5:
                ch = TREE[y - 13][mx]
                if ch == "G":
                    return GREEN_L
                if ch == "B":
                    return (150, 100, 62)
            if y == 20:
                return WHITE if x % 4 < 2 else GREEN
            if y == 22 and x % 4 == 0:
                return WHITE
        else:
            if y == 14 and x % 4 == 0:
                return WHITE
        return None
    return d


def sweater():
    p = SWEATER
    rib = lambda f, x, y, w, h: None if f in ("top", "bottom") else (p["rib"] if x % 2 == 0 else mix(p["rib"], p["base"], 0.35))
    cubes = [
        Cube("body", "body", (0, 6.1, 0), (9.8, 12.6, 5.8), p["base"], sweater_deco("body")),
        Cube("collar", "body", (0, -0.1, 0), (10.0, 1.6, 6.0), p["rib"], rib),
    ]
    for side, sx in (("r", -1), ("l", 1)):
        bone, m = ("right_arm" if side == "r" else "left_arm"), side == "l"
        cubes.append(Cube(f"sleeve_{side}", bone, (sx * 1, 3.9, 0), (5.4, 11.4, 5.4), p["base"], sweater_deco("sleeve"),
                          twin_of=tw(side, "sleeve"), mirror=m))
        cubes.append(Cube(f"cuff_{side}", bone, (sx * 1, 9.0, 0), (5.6, 2.0, 5.6), p["rib"], rib,
                          twin_of=tw(side, "cuff"), mirror=m))
    return build("xmas_sweater", cubes)


def icon_sweater():
    i = Icon()
    base, rib = RED, (244, 240, 232)
    blk(i, 1, 4, 3, 12, base)
    blk(i, 12, 4, 14, 12, base)
    i.rect(1, 11, 3, 12, rib)
    i.rect(12, 11, 14, 12, rib)
    blk(i, 4, 3, 11, 14, base)
    i.rect(5, 3, 10, 3, rib)
    i.rect(4, 14, 11, 14, rib)
    for x in (5, 7, 9):
        i.put(x, 5, WHITE)
    for x in (6, 8, 10):
        i.put(x, 6, WHITE)
    for x in range(4, 12):
        i.put(x, 8, WHITE if x % 4 < 2 else GREEN)
    for x, y in ((5, 11), (6, 10), (7, 11), (9, 11), (10, 10)):
        i.put(x, y, GREEN_L)
    i.put(6, 12, (150, 100, 62))
    i.put(10, 12, (150, 100, 62))
    i.save("xmas_sweater")


# ====================================================================== 4. SNOW MAIDEN COAT (top)
def coat_body_deco(f, x, y, w, h):
    if f in ("top", "bottom"):
        return None
    if y >= h - 3:
        return fur(x, y)
    if f == "front":
        c = w // 2
        if c - 2 <= x < c + 2:
            return fur(x, y)
        if x in (c - 4, c + 3) and y % 3 != 2:
            return SILVER
        for x0 in (1, c + 4):
            for y0 in (6, 15):
                if pat_at(SNOW5, x, y, x0, y0) == "X":
                    return SILVER_L
        return None
    return SILVER if y % 6 == 3 and x % 4 == 1 else None


def coat():
    fur_deco = lambda f, x, y, w, h: None if f in ("top", "bottom") else fur(x, y)
    cubes = [
        Cube("body", "body", (0, 6.1, 0), (9.8, 12.6, 5.8), BLUE, coat_body_deco),
        Cube("collar", "body", (0, -0.1, 0), (10.2, 1.8, 6.2), WHITE, fur_deco),
        Cube("hem", "body", (0, 11.8, 0), (10.8, 1.6, 6.8), WHITE, fur_deco),
    ]

    def sleeve_deco(f, x, y, w, h):
        if f in ("top", "bottom"):
            return None
        if y == 6 and x % 3 != 2:
            return SILVER
        if y in (4, 8) and x % 2 == 0:
            return SILVER_L
        return None

    for side, sx in (("r", -1), ("l", 1)):
        bone, m = ("right_arm" if side == "r" else "left_arm"), side == "l"
        cubes.append(Cube(f"sleeve_{side}", bone, (sx * 1, 3.9, 0), (5.4, 11.4, 5.4), BLUE, sleeve_deco,
                          twin_of=tw(side, "sleeve"), mirror=m))
        cubes.append(Cube(f"cuff_{side}", bone, (sx * 1, 8.9, 0), (5.8, 2.4, 5.8), WHITE, fur_deco,
                          twin_of=tw(side, "cuff"), mirror=m))
    return build("snow_coat", cubes)


def icon_coat():
    i = Icon()
    blk(i, 1, 4, 3, 12, BLUE)
    blk(i, 12, 4, 14, 12, BLUE)
    blk(i, 1, 10, 3, 12, WHITE)
    blk(i, 12, 10, 14, 12, WHITE)
    blk(i, 4, 3, 11, 14, BLUE)
    i.rect(4, 3, 11, 4, WHITE)
    i.rect(7, 4, 8, 14, WHITE)
    i.rect(4, 13, 11, 14, WHITE)
    for y in (6, 9, 11):
        i.put(5, y, SILVER_L)
        i.put(10, y, SILVER_L)
    i.put(6, 7, SILVER)
    i.put(9, 7, SILVER)
    i.save("snow_coat")


# ====================================================================== 5. VALENKI (shoes)
def valenki_shaft_deco(f, x, y, w, h):
    if f in ("top", "bottom"):
        return None
    if f == "front" and pat_at(SNOW5, x, y, (w - 5) // 2, 2) == "X":
        return BLUE
    if y == 10 and x % 2 == 0:
        return BLUE
    if y == 12 and x % 2 == 1:
        return BLUE_L
    return mix(FELT, FELT_D, 0.5) if (x * 7 + y * 3) % 11 == 0 else None


def valenki():
    cubes = []
    for side, sx in (("r", -1), ("l", 1)):
        bone, m = ("right_leg" if side == "r" else "left_leg"), side == "l"

        def add(n, center, dims, base, deco=None):
            cubes.append(Cube(f"{n}_{side}", bone, center, dims, base, deco, twin_of=tw(side, n), mirror=m))

        add("shaft", (0, 9.0, 0), (5.0, 6.4, 5.0), FELT, valenki_shaft_deco)
        add("cuff", (0, 6.1, 0), (5.5, 1.4, 5.5), BLUE,
            lambda f, x, y, w, h: None if f in ("top", "bottom") else (PEARL if y == h // 2 and x % 3 == 0 else None))
        add("foot", (0, 10.9, -1.0), (5.0, 2.6, 7.0), FELT,
            lambda f, x, y, w, h: None if f in ("top", "bottom") else (mix(FELT, FELT_D, 0.5) if (x * 5 + y * 3) % 9 == 0 else None))
        add("sole", (0, 11.85, -1.0), (5.2, 0.6, 7.4), (62, 66, 84))
    return build("snow_valenki", cubes)


def icon_valenki():
    i = Icon()
    blk(i, 5, 3, 9, 11, FELT)
    i.rect(5, 3, 9, 4, BLUE)
    for x in (5, 7, 9):
        i.put(x, 3, PEARL)
    i.put(7, 6, BLUE)
    i.put(6, 7, BLUE)
    i.put(8, 7, BLUE)
    i.put(7, 8, BLUE)
    blk(i, 5, 10, 13, 13, FELT)
    i.rect(5, 14, 13, 14, (62, 66, 84))
    i.save("snow_valenki")


# ====================================================================== 6. CANDY CANE (accessory, right hand)
def stripes(f, x, y, w, h):
    if f in ("top", "bottom"):
        return WHITE
    return RED if ((x + y) // 3) % 2 == 0 else WHITE


def candy_cane():
    z = -3.2
    parts = [("shaft", (-1.0, 15.3, z), (1.0, 13.5, 1.0)),
             ("crook_bar", (-2.2, 8.3, z), (3.4, 1.0, 1.0)),
             ("crook_tip", (-3.4, 9.4, z), (1.0, 1.8, 1.0))]
    cubes = [Cube(n, "right_arm", c, d, WHITE, stripes, **keep(c)) for n, c, d in parts]
    return build("candy_cane", cubes)


def icon_cane():
    i = Icon()
    for y in range(5, 15):
        col = RED if (y // 2) % 2 == 0 else WHITE
        i.put(9, y, col)
        i.put(10, y, col)
    for x, col in ((8, WHITE), (7, RED), (6, RED), (5, WHITE)):
        i.put(x, 3, col)
        i.put(x, 4, col)
    i.put(9, 4, RED)
    i.put(10, 4, WHITE)
    i.put(5, 5, RED)
    i.put(5, 6, WHITE)
    i.put(4, 5, RED)
    i.put(4, 6, WHITE)
    i.save("candy_cane")


# ====================================================================== 7. SNOWFLAKE NECKLACE (slot "necklace")
SNOW10 = ["X...XX...X", ".X..XX..X.", "..X.XX.X..", "...XXXX...", "XXXXXXXXXX",
          "XXXXXXXXXX", "...XXXX...", "..X.XX.X..", ".X..XX..X.", "X...XX...X"]
SNOW7 = ["X..X..X", ".X.X.X.", "..XXX..", "XXXXXXX", "..XXX..", ".X.X.X.", "X..X..X"]
ICE, ICE_EDGE = (190, 228, 252), (92, 152, 212)


def in_snow(u, v):
    return SNOW10[min(9, int(v * 10))][min(9, int(u * 10))] == "X"


def necklace_snowflake():
    cubes = []
    for n, (x, y) in enumerate(chain_points(8)):
        col = SILVER if n % 2 == 0 else SILVER_D
        cubes.append(Cube(f"c{n}_r", "body", (x, y, NZ), (0.7, 0.7, 0.5), col))
        cubes.append(Cube(f"c{n}_l", "body", (-x, y, NZ), (0.7, 0.7, 0.5), col, twin_of=f"c{n}_r", mirror=True))
    cubes.append(Cube("charm", "body", (0, 5.3, NZ - 0.1), (4.4, 4.4, 0.4), ICE,
                      shaped(in_snow, ICE, WHITE, ICE_EDGE, SILVER_D)))
    return build("necklace_snowflake", cubes)


def icon_snowflake():
    i = Icon()
    pts = [(2, 2), (3, 3), (3, 4), (4, 5), (4, 6), (5, 7), (6, 8), (6, 9)]
    for n, (x, y) in enumerate(pts):
        for xx in (x, 15 - x):
            i.put(xx, y, SILVER if n % 2 == 0 else SILVER_D)
    for dy, row in enumerate(SNOW7):
        for dx, ch in enumerate(row):
            if ch == "X":
                i.put(4 + dx, 8 + dy, WHITE if (dx, dy) == (3, 3) else ICE if (dx + dy) % 2 else (150, 204, 244))
    i.save("necklace_snowflake")


# ====================================================================== 8. JINGLE BELL BRACELET (slot "wrist")
def bells():
    cubes = []
    for side, sx in (("r", -1), ("l", 1)):
        bone, m = ("right_arm" if side == "r" else "left_arm"), side == "l"
        cx = sx * 1

        def add(n, center, dims, base, deco=None):
            cubes.append(Cube(f"{n}_{side}", bone, center, dims, base, deco, twin_of=tw(side, n), mirror=m))

        add("ring", (cx, 7.0, 0), (RW, 1.2, RW), RED,
            lambda f, x, y, w, h: None if f in ("top", "bottom") else (GREEN if (x // 2) % 2 else RED))

        def bell(f, x, y, w, h):
            if f in ("top", "bottom"):
                return GOLD_L if f == "top" else GOLD_D
            if y == h - 2 and 1 <= x <= w - 2:
                return GOLD_D
            return GOLD_L if x == 0 and y == 0 else None

        for n, c in (("bell_a", (sx * 3.3, 8.4, -1.0)), ("bell_b", (sx * 3.3, 8.4, 1.0))):
            cubes.append(Cube(f"{n}_{side}", bone, c, (1.3, 1.3, 1.3), GOLD, bell, mirror=m, **keep(c)))
    return build("bracelet_bells", cubes)


def icon_bells():
    i = Icon()
    for deg in range(0, 360, 10):
        x = round(7.5 + 5.5 * math.cos(math.radians(deg)))
        y = round(6.5 + 3.5 * math.sin(math.radians(deg)))
        i.put(x, y, RED if (deg // 40) % 2 == 0 else GREEN)
    for bx in (5, 9):
        i.rect(bx, 11, bx + 1, 12, GOLD)
        i.put(bx, 11, GOLD_L)
        i.rect(bx, 13, bx + 1, 13, GOLD_D)
    i.save("bracelet_bells")


# ====================================================================== registration
ENTRIES = [
    dict(id="reindeer_antlers", category="hat", ru="Рожки оленя с носиком", en="Reindeer Antlers", price=1499, build=antlers, icon=icon_antlers),
    dict(id="snow_kokoshnik", category="hat", ru="Кокошник Снегурочки с косой", en="Snow Maiden Kokoshnik", price=2999, build=kokoshnik, icon=icon_kokoshnik),
    dict(id="xmas_sweater", category="top", ru="Новогодний свитер", en="Christmas Sweater", price=4499, build=sweater, icon=icon_sweater),
    dict(id="snow_coat", category="top", ru="Шубка Снегурочки", en="Snow Maiden Fur Coat", price=5999, build=coat, icon=icon_coat),
    dict(id="snow_valenki", category="shoes", ru="Белые валенки с узором", en="Patterned Felt Boots", price=3999, build=valenki, icon=icon_valenki),
    dict(id="candy_cane", category="accessory", ru="Леденцовая трость", en="Candy Cane", price=799, build=candy_cane, icon=icon_cane),
    dict(id="necklace_snowflake", category="accessory", slot="necklace", ru="Кулон-снежинка", en="Snowflake Necklace", price=3999,
         build=necklace_snowflake, icon=icon_snowflake),
    dict(id="bracelet_bells", category="accessory", slot="wrist", ru="Браслет с бубенчиками", en="Jingle Bell Bracelet", price=1499,
         build=bells, icon=icon_bells),
]
CATEGORY = {"hat": "HAT", "top": "TOP", "bottom": "BOTTOM", "shoes": "SHOES", "accessory": "ACCESSORY"}
SLOT_CONST = {"necklace": "NECKLACE", "wrist": "WRIST", "choker": "CHOKER", "neck": "NECK"}


def register(entries):
    res = ROOT / "src/main/resources/assets/fittingroom"
    cj = json.loads((res / "clothes.json").read_text(encoding="utf-8"))
    have = {it["id"] for it in cj["items"]}
    for e in entries:
        if e["id"] in have:
            continue
        item = {"id": e["id"], "category": e["category"]}
        if e.get("slot"):
            item["slot"] = e["slot"]
        item.update({
            "name": {"ru_ru": e["ru"], "en_us": e["en"]},
            "model": f"fittingroom:clothes_models/{e['id']}.json",
            "texture": f"fittingroom:textures/clothes/{e['id']}.png",
            "icon": f"fittingroom:textures/gui/clothes/{e['id']}.png",
            "season": {"from": "12-15", "to": "01-14"}})
        cj["items"].append(item)
    (res / "clothes.json").write_text(json.dumps(cj, ensure_ascii=False) + "\n", encoding="utf-8")

    for lang, key in (("ru_ru", "ru"), ("en_us", "en")):
        path = res / f"lang/{lang}.json"
        data = json.loads(path.read_text(encoding="utf-8"))
        for e in entries:
            data.setdefault(f"clothes.fittingroom.{e['id']}", e[key])
        path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    java = ROOT / "src/main/java/com/fittingroom/wardrobe/ClothingCatalog.java"
    text = java.read_text(encoding="utf-8")
    anchor = '            newYear("santa_boots", Category.SHOES),\n'
    assert anchor in text, "anchor for the catalog not found"
    lines = ""
    for e in entries:
        if f'"{e["id"]}"' in text:
            continue
        if e.get("slot"):
            lines += (f'            new Item("{e["id"]}", Category.{CATEGORY[e["category"]]}, NEW_YEAR_FROM, NEW_YEAR_TO, '
                      f'{SLOT_CONST[e["slot"]]}),\n')
        else:
            lines += f'            newYear("{e["id"]}", Category.{CATEGORY[e["category"]]}),\n'
    if lines:
        java.write_text(text.replace(anchor, anchor + lines), encoding="utf-8")

    prices = ROOT / "src/main/java/com/fittingroom/wardrobe/ClothingPrices.java"
    text = prices.read_text(encoding="utf-8")
    anchor = '        p("scarf_xmas", 2499);\n'
    assert anchor in text, "anchor for the prices not found"
    lines = "".join(f'        p("{e["id"]}", {e["price"]});\n' for e in entries if f'"{e["id"]}"' not in text)
    if lines:
        prices.write_text(text.replace(anchor, anchor + lines), encoding="utf-8")


if __name__ == "__main__":
    for e in ENTRIES:
        e["build"]()
        e["icon"]()
    register(ENTRIES)
    print("new year set generated:", ", ".join(e["id"] for e in ENTRIES))
