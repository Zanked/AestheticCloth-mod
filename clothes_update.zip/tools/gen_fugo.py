#!/usr/bin/env python3
"""
Generates the outfit of Pannacotta Fugo (no hairstyle):
  fugo_jacket (top)     lime jacket, one gold button, the front open below it (bare waist), holes in the sleeves, puffed shoulders not modelled
  fugo_pants  (bottom)  lime slim trousers full of oval holes, black belt with a gold buckle
  fugo_tie    (accessory, slot tie)  blue tie with strawberries
  fugo_shoes  (shoes)   blue pointed shoes with a pink lining and a strawberry on the toe
Look "fugo". Run from the project root:  python3 tools/gen_fugo.py
then  python3 tools/zfight_cross.py --all --only=fugo_   and  python3 tools/zfight.py --check
Registration is shared with gen_joseph.py.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import gen_giorno as G  # noqa: E402
import gen_joseph as J  # noqa: E402
from gen_dino import blk, build, mix  # noqa: E402
from gen_accessories import Cube, Icon, shade  # noqa: E402
from gen_outerwear import arm_pair, leg_pair  # noqa: E402

GOLD, GOLD_D, GOLD_L = G.GOLD, G.GOLD_D, G.GOLD_L
LIME, LIME_D, LIME_L = (172, 202, 66), (120, 150, 42), (204, 228, 104)
BLK, BLK_L = (30, 30, 34), (70, 70, 78)
BLUE, BLUE_D, BLUE_L = (56, 62, 170), (34, 38, 112), (92, 100, 214)
PINK, RED, LEAF = (232, 72, 140), (214, 48, 80), (60, 160, 60)
SHOE, SHOE_D, SHOE_L = (52, 80, 168), (30, 48, 110), (96, 130, 220)
ellipse = J.ellipse


def holes(spec):
    def hit(x, y):
        return any(ellipse(x, y, cx, cy, rx, ry) for cx, cy, rx, ry in spec)
    return hit


# ====================================================================== JACKET
def sleeve_holes(side):
    front = holes([(5, 6, 3.0, 3.6), (4, 22, 2.4, 3.0)])
    back = holes([(5, 14, 3.2, 3.8)])
    return front, back


def sleeve_deco(f, x, y, w, h):
    if f == "top":
        return None
    hf, hb = sleeve_holes(0)
    if f == "front" and hf(x, y):
        return "clear"
    if f == "back" and hb(x, y):
        return "clear"
    if f in ("right", "left") and ellipse(x, y, w / 2.0, 20, 3.0, 3.4):
        return "clear"
    col = mix(LIME_L, LIME, min(1.0, y / max(1, h - 1) * 1.4))
    if f in ("right", "left"):
        col = mix(col, LIME_D, 0.25)
    if y in (h - 4, h - 3):
        col = mix(LIME, LIME_D, 0.5)                            # cuff seam
    if (y in (11, 12, 13) and (x + y) % 4 == 0) or (y == h - 1):
        col = mix(col, LIME_D, 0.4)                             # creases
    return col


def panel_deco(side):
    def d(f, x, y, w, h):
        if f in ("top", "bottom"):
            return None if f == "top" else LIME_D
        if f != "front":
            return mix(LIME, LIME_D, 0.35) if f in ("right", "left") else None
        di = (w - 1 - x) if side == "r" else x                  # distance from the inner edge
        if y < 5 and di < 1.6 - y * 0.35:
            return "clear"                                       # round neckline
        if y >= 6 and di < (y - 5) * 0.55 + 0.5:
            return "clear"                                       # open front below the button: the waist is bare
        col = mix(LIME_L, LIME, min(1.0, y / 14.0))
        if side == "l" and (di, y) in ((1, 5), (2, 5), (1, 4), (2, 4)):
            return GOLD_L if (di, y) == (1, 4) else GOLD       # the only button
        if y >= 6 and abs(di - ((y - 5) * 0.55 + 0.5)) < 1.3:
            col = mix(col, LIME_D, 0.45)                         # fold along the opening
        if y == h - 1:
            col = mix(col, LIME_D, 0.5)
        if x in (w // 2, w // 2 + 3) and 8 < y < h - 3 and (x + y) % 3 == 0:
            col = mix(col, LIME_D, 0.3)
        return col
    return d


def back_deco(f, x, y, w, h):
    if f in ("top", "bottom"):
        return None
    return mix(LIME_L, LIME, min(1.0, y / max(1, h - 1) * 1.2))   # same lime as the front, no shading on the back


def jacket():
    cubes = [
        Cube("back", "body", (0, 6.2, 1.0), (8.7, 12.4, 2.8), LIME, back_deco),
        Cube("panel_r", "body", (-2.17, 6.2, -1.05), (4.36, 12.4, 2.5), LIME, panel_deco("r")),
        Cube("panel_l", "body", (2.17, 6.2, -1.05), (4.36, 12.4, 2.5), LIME, panel_deco("l")),
    ]
    arm_pair(cubes, "sleeve", 4.0, (4.3, 12.2, 4.3), LIME, sleeve_deco)
    return build("fugo_jacket", cubes)


# ====================================================================== PANTS
LEG_F = holes([(5, 5, 2.4, 3.4), (4, 13, 2.2, 3.6), (6, 20, 2.0, 2.8)])
LEG_B = holes([(4, 8, 2.6, 3.6), (6, 17, 2.2, 3.2)])
LEG_S = holes([(5, 11, 2.2, 3.2), (5, 19, 2.0, 3.0)])


def pants():
    def leg(f, x, y, w, h):
        if f in ("top", "bottom"):
            return None
        if f == "front" and LEG_F(x, y):
            return "clear"
        if f == "back" and LEG_B(x, y):
            return "clear"
        if f in ("right", "left") and LEG_S(x, y):
            return "clear"
        col = mix(LIME_L, LIME, min(1.0, y / max(1, h - 1) * 1.2))
        if f in ("right", "left"):
            col = mix(col, LIME_D, 0.2)
        if f == "front" and x == w // 2 and y > 3:
            col = mix(col, LIME_D, 0.3)
        if y >= h - 3:
            col = mix(col, LIME_D, 0.35)
        return col

    def waist(f, x, y, w, h):
        if f in ("top", "bottom"):
            return None
        col = mix(LIME_L, LIME, 0.4)
        if f == "front" and x in (w // 2 - 1, w // 2) and y > 1:
            col = mix(col, LIME_D, 0.5)
        if y == 0:
            col = mix(col, LIME_D, 0.3)
        return col

    def belt(f, x, y, w, h):
        if f in ("top", "bottom"):
            return BLK
        if f == "front" and 7 <= x <= 10:
            return GOLD_L if (x in (7, 10) or y == 0) else (BLK if 8 <= x <= 9 and 0 < y < h - 1 else GOLD)
        return mix(BLK_L, BLK, y / max(1, h - 1))

    cubes = [
        Cube("waist", "body", (0, 11.4, 0), (8.5, 3.2, 4.544), LIME, waist),
        Cube("belt", "body", (0, 9.8, 0), (8.6, 1.2, 4.544), BLK, belt),
    ]
    leg_pair(cubes, "leg", 5.6, (4.34, 11.8, 4.34), LIME, leg)
    return build("fugo_pants", cubes)


# ====================================================================== TIE
BERRY = ["..G..", ".RRR.", "RRRRR", ".RRR."]


def tie_px(u, gy):
    cell = gy % 6
    sx, sy = u + 2, cell - 1
    if 0 <= sx < 5 and 0 <= sy < 4:
        ch = BERRY[sy][sx]
        if ch == "R":
            return RED if (sx + sy) % 4 else (255, 120, 140)
        if ch == "G":
            return LEAF
    return mix(BLUE, BLUE_L, 0.15) if abs(u + 0.5) < 1.0 else BLUE


SEGS = [("s0", 2.0, 4.0, 1.8), ("s1", 4.0, 6.0, 2.2), ("s2", 6.0, 8.0, 2.6), ("s3", 8.0, 10.0, 2.9), ("s4", 10.0, 12.0, 3.1)]
TZ = -2.85


def tie_deco(y0, tip=False):
    gy0 = int(round((y0 - 2.0) * 2))

    def d(f, x, y, w, h):
        if f in ("front", "back"):
            if tip:
                half = max(1.0, (w / 2.0) * (1.0 - y / float(h)) + 0.4)
                if abs(x + 0.5 - w / 2.0) > half:
                    return "clear"
            return tie_px(x - w // 2, gy0 + y)
        return "clear" if tip else BLUE_D
    return d


def tie():
    cubes = [Cube("knot", "body", (0, 1.5, TZ - 0.05), (2.2, 1.3, 0.9), BLUE, lambda f, x, y, w, h: mix(BLUE_D, BLUE_L, 0.5) if (f == "front" and y < 2) else BLUE_D)]
    for name, y0, y1, w in SEGS:
        cubes.append(Cube(name, "body", (0, (y0 + y1) / 2, TZ), (w, y1 - y0, 0.5), BLUE, tie_deco(y0)))
    cubes.append(Cube("tip", "body", (0, 12.8, TZ), (3.1, 1.6, 0.5), BLUE, tie_deco(12.0, True)))
    return build("fugo_tie", cubes)


# ====================================================================== SHOES
def shoes():
    def upper(f, x, y, w, h):
        if f == "top":
            return PINK if (x in (0, w - 1) or y in (0, h - 1)) else mix(PINK, (255, 255, 255), 0.0) if False else (PINK if x < 1 else None)
        if f == "bottom":
            return SHOE_D
        return mix(SHOE_L, SHOE, min(1.0, y / max(1, h - 1)))

    def toe(f, x, y, w, h):
        if f == "top":
            cx, cy = w / 2.0, h * 0.6
            if ellipse(x, y, cx, cy, 2.4, 3.0):
                if ellipse(x, y, cx, cy - 1.6, 1.4, 0.9) and y < cy - 1.2:
                    return LEAF
                return PINK if (x + y) % 5 else (255, 160, 200)
            return mix(SHOE_L, SHOE, 0.4)
        if f == "bottom":
            return SHOE_D
        return mix(SHOE_L, SHOE, 0.4 + y / max(1, h - 1) * 0.6)

    def plain(f, x, y, w, h):
        return SHOE_D if f == "bottom" else mix(SHOE_L, SHOE, 0.5)

    cubes = []
    for side, sx in (("r", -1), ("l", 1)):
        m = side == "l"
        bone = "right_leg" if side == "r" else "left_leg"
        ox = sx * 0.1
        tw = (lambda n: None) if side == "r" else (lambda n: n + "_r")
        cubes.append(Cube(f"upper_{side}", bone, (ox, 10.4, 0.25), (4.5, 2.8, 4.6), SHOE, upper, twin_of=tw("upper"), mirror=m))
        cubes.append(Cube(f"toe_{side}", bone, (ox, 11.1, -3.9), (3.8, 1.6, 4.4), SHOE, toe, twin_of=tw("toe"), mirror=m))
        cubes.append(Cube(f"tip_{side}", bone, (ox, 11.3, -6.3), (2.6, 1.2, 2.6), SHOE, plain, twin_of=tw("tip"), mirror=m))
        cubes.append(Cube(f"heel_{side}", bone, (ox, 11.55, 1.7), (4.1, 1.5, 2.3), SHOE_D, plain, twin_of=tw("heel"), mirror=m))
        cubes.append(Cube(f"sole_{side}", bone, (ox, 11.9, -1.8), (4.3, 0.5, 11.2), SHOE_D, None, twin_of=tw("sole"), mirror=m))
    return build("fugo_shoes", cubes)


# ====================================================================== ICONS
def icon_jacket():
    i = Icon()
    blk(i, 1, 3, 3, 13, LIME); blk(i, 12, 3, 14, 13, LIME)
    blk(i, 3, 2, 6, 14, LIME); blk(i, 9, 2, 12, 14, LIME)
    i.rect(7, 4, 8, 14, (226, 178, 140))
    i.rect(6, 7, 6, 14, LIME_D); i.rect(9, 7, 9, 14, LIME_D)
    i.put(6, 4, GOLD); i.put(6, 5, GOLD)
    i.put(2, 7, 0) if False else None
    for x, y in ((2, 6), (13, 8), (2, 10)):
        i.put(x, y, (226, 178, 140))
    i.save("fugo_jacket")


def icon_pants():
    i = Icon()
    blk(i, 3, 2, 12, 4, LIME)
    i.rect(3, 3, 12, 3, BLK); i.rect(7, 3, 8, 3, GOLD)
    blk(i, 3, 5, 7, 14, LIME); blk(i, 8, 5, 12, 14, LIME)
    i.rect(7, 5, 8, 14, LIME_D)
    for x, y in ((5, 7), (5, 8), (10, 9), (10, 10), (5, 11), (5, 12), (10, 12), (10, 13)):
        i.put(x, y, (226, 178, 140))
    i.save("fugo_pants")


def icon_tie():
    i = Icon()
    i.rect(6, 1, 9, 3, BLUE_D)
    i.rect(6, 3, 9, 3, BLUE)
    for y in range(4, 14):
        w = 1 + (y - 4) // 4
        i.rect(7 - w, y, 8 + w, y, BLUE)
    for x, y in ((7, 6), (8, 9), (6, 11), (9, 12), (7, 13)):
        i.put(x, y, RED)
    i.put(7, 5, LEAF)
    i.save("fugo_tie")


def icon_shoes():
    i = Icon()
    for x0 in (2, 9):
        blk(i, x0, 8, x0 + 3, 11, SHOE)
        i.rect(x0, 8, x0 + 3, 8, PINK)
        blk(i, x0 - 1, 12, x0 + 4, 13, SHOE)
        i.put(x0 + 1, 12, RED)
        i.rect(x0 - 1, 14, x0 + 4, 14, SHOE_D)
    i.save("fugo_shoes")


ITEMS = [
    dict(id="fugo_jacket", category="top", ru="Лаймовый пиджак с дырами", en="Lime Jacket with Holes", price=11999, build=jacket, icon=icon_jacket),
    dict(id="fugo_pants", category="bottom", ru="Лаймовые брюки с дырами", en="Lime Trousers with Holes", price=6499, build=pants, icon=icon_pants),
    dict(id="fugo_tie", category="accessory", slot="tie", ru="Синий галстук с клубникой", en="Blue Strawberry Tie", price=1999, build=tie, icon=icon_tie),
    dict(id="fugo_shoes", category="shoes", ru="Синие туфли с клубникой", en="Blue Strawberry Shoes", price=6999, build=shoes, icon=icon_shoes),
]
LOOKS = [("fugo", "Паннакотта Фуго", "Pannacotta Fugo", ["fugo_jacket", "fugo_pants", "fugo_tie", "fugo_shoes"])]
J.DOC_MARK = "## Pannacotta Fugo"
J.DOC_TEXT = """
## Pannacotta Fugo
`python3 tools/gen_fugo.py` (registration is shared with gen_joseph.py), then `python3 tools/zfight_cross.py --all --only=fugo_` and `python3 tools/zfight.py --check`.
- `fugo_jacket` (top): a back box and two front panels; the panels are cut with transparent pixels into a round neckline and an open front below the only
  gold button, so the bare waist shows. Holes in the sleeves and `fugo_pants` (bottom) are transparent ovals on the front, back and side faces
  (the skin's own leg is visible through them; its trouser layer is hidden while a bottom is worn).
- `fugo_tie` (accessory, slot `tie`): blue tie with strawberries, long enough for the open jacket. `fugo_shoes` (shoes): pointed blue shoes, pink lining, strawberry on the toe.
- Look `fugo`.
"""

if __name__ == "__main__":
    J.ITEMS, J.LOOKS = ITEMS, LOOKS
    for e in ITEMS:
        e["build"]()
        e["icon"]()
    J.register()
    print("generated:", ", ".join(e["id"] for e in ITEMS))
