#!/usr/bin/env python3
"""
Generates the pink suit of the fitting room (after the figure pictures; no hairstyle):

  giorno_jacket  (top)     short pink jacket with a stand collar, puffed shoulders, a heart-shaped cut-out on the chest framed in gold,
                           a gold zip line down the middle, three blue "ladybug" brooches, gold cuffs, a flared peplum and a
                           purple/lilac argyle pattern on the back and sides of the peplum
  giorno_pants   (bottom)  slim pink trousers with a crease
  giorno_shoes   (shoes)   dark blue shoes with a teal sole and a blue dot

Run from the project root:  python3 tools/gen_giorno.py            (models, textures, icons, registration)
                            python3 tools/gen_giorno.py --preview   (also writes previews to /tmp/giorno_preview)
Same smooth painter as gen_suit.py / gen_jotaro.py.
"""
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from gen_dino import blk, build, grad, mix  # noqa: E402
from gen_accessories import ASSETS, PX, Cube, Icon, shade  # noqa: E402
from gen_outerwear import arm_pair, leg_pair, sd  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent

PINK = (206, 116, 178)
PINK_L = (230, 154, 202)
PINK_D = (152, 74, 132)
PURPLE = (148, 84, 172)
LILAC = (228, 152, 208)
GOLD = (238, 200, 94)
GOLD_D = (178, 132, 52)
GOLD_L = (255, 233, 152)
SKIN = (226, 178, 140)
NAVY = (36, 38, 108)
NAVY_L = (62, 66, 150)
NAVY_D = (22, 22, 70)
TEAL = (70, 190, 176)
BLUE = (40, 150, 204)

# ---------------------------------------------------------------- motifs
HEART = [".XXXX..XXXX.",
         "XXXXXXXXXXXX",
         "XXXXXXXXXXXX",
         "XXXXXXXXXXXX",
         ".XXXXXXXXXX.",
         "..XXXXXXXX..",
         "...XXXXXX...",
         "....XXXX....",
         ".....XX....."]
HX, HY = 3, 4            # where the heart sits on the 18 x 26 px front of the torso

LADY = [".GGGG.",
        "GBKBKG",
        "GBBKBG",
        "GKBBKG",
        "GBBBBG",
        ".GGGG."]
WING_R = ["..XXX.",
          ".XXXXX",
          "XXXXX.",
          "XXX..."]
WING_L = [row[::-1] for row in WING_R]


def decal(rows, cols):
    """A flat decal: the shape is drawn on the front, everything else is transparent."""
    def d(f, x, y, w, h):
        if f != "front":
            return "clear"
        ch = rows[y][x] if y < len(rows) and x < len(rows[y]) else "."
        return cols.get(ch, "clear")
    return d


LADY_COLS = {"G": GOLD, "B": BLUE, "K": (18, 30, 70)}
WING_COLS = {"X": GOLD}


def in_heart(x, y):
    hx, hy = x - HX, y - HY
    return 0 <= hy < len(HEART) and 0 <= hx < len(HEART[0]) and HEART[hy][hx] == "X"


def heart_edge(x, y):
    return in_heart(x, y) and not all(in_heart(x + dx, y + dy) for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)))


# ---------------------------------------------------------------- jacket
def torso_deco(f, x, y, w, h):
    if f == "front":
        if in_heart(x, y):
            return GOLD if heart_edge(x, y) else "clear"        # the chest shows through the heart
        hy = y - HY
        if x in (w // 2 - 1, w // 2) and y >= HY + len(HEART) - 1:
            return GOLD if x == w // 2 - 1 else mix(PINK, PINK_D, 0.6)    # gold zip line from the tip of the heart down
        if y <= 1:
            return GOLD_D if y == 1 else PINK_L                   # collar band
        if y == h - 1:
            return mix(PINK, PINK_D, 0.5)
        return None
    if f == "back":
        if x in (w // 2 - 1, w // 2):
            return mix(PINK, PINK_D, 0.55)
        if y <= 1:
            return PINK_L
        return None
    if f in ("right", "left") and y <= 1:
        return PINK_L
    return None


def argyle(x, y):
    cx, cy = (x % 4) - 1.5, (y % 4) - 1.5
    if abs(cx) + abs(cy) <= 1.6:
        return PURPLE if ((x // 4) + (y // 4)) % 2 == 0 else LILAC
    return None


def peplum_deco(f, x, y, w, h):
    if f == "front":
        if x in (w // 2 - 1, w // 2):
            return GOLD if x == w // 2 - 1 else mix(PINK, PINK_D, 0.6)
        if y == h - 1:
            return GOLD_D
        return None
    if f in ("back", "left", "right"):
        if y == h - 1:
            return mix(PINK, PINK_D, 0.5)
        return argyle(x, y)
    if f == "bottom":
        return mix(PINK, PINK_D, 0.5)
    return None


def sleeve_deco(f, x, y, w, h):
    if f == "top":
        return None
    if y in (h - 5, h - 4):                                       # gold cuff band
        return GOLD if y == h - 5 else GOLD_D
    if y == h - 1:
        return mix(PINK, PINK_D, 0.4)
    return None


def pad_deco(f, x, y, w, h):
    if f == "top":
        return PINK_L
    if y == h - 1:
        return mix(PINK, PINK_D, 0.4)
    return None


def jacket():
    cubes = [
        Cube("torso", "body", (0, 5.9, 0), (8.4, 12.2, 4.4), PINK, torso_deco),
        Cube("peplum", "body", (0, 13.7, 0), (9.2, 3.4, 5.2), PINK, peplum_deco),
        Cube("wing_r", "body", (-2.3, 0.7, -2.35), (2.4, 1.6, 0.5), GOLD, decal(WING_L, WING_COLS)),
        Cube("wing_l", "body", (2.3, 0.7, -2.35), (2.4, 1.6, 0.5), GOLD, decal(WING_R, WING_COLS)),
        Cube("bug_r", "body", (-3.0, 6.2, -2.35), (2.4, 2.4, 0.5), GOLD, decal(LADY, LADY_COLS)),
        Cube("bug_l", "body", (3.0, 6.2, -2.35), (2.4, 2.4, 0.5), GOLD, decal(LADY, LADY_COLS)),
        Cube("bug_c", "body", (0.0, 10.0, -2.35), (2.4, 2.4, 0.5), GOLD, decal(LADY, LADY_COLS)),
    ]
    arm_pair(cubes, "sleeve", 4.0, (4.2, 12.2, 4.2), PINK, sleeve_deco)
    arm_pair(cubes, "pad", 0.2, (4.6, 3.0, 4.6), PINK, pad_deco)    # puffed shoulders
    return build("giorno_jacket", cubes)


# ---------------------------------------------------------------- trousers
def pants():
    def leg(f, x, y, w, h):
        if f in ("top", "bottom"):
            return None
        col = mix(PINK_L, PINK, min(1.0, y / max(1, h - 1) * 0.9))
        if f in ("front", "back") and x == w // 2 - 1:
            return mix(col, PINK_D, 0.45)                           # crease
        if f in ("front", "back") and y == h - 1:
            return mix(col, PINK_D, 0.35)
        return col

    def waist(f, x, y, w, h):
        return mix(PINK, PINK_D, 0.4) if f == "front" and y == 0 else None

    cubes = [Cube("waist", "body", (0, 11.4, 0), (8.2, 3.2, 4.5), PINK, waist)]
    leg_pair(cubes, "leg", 5.6, (4.1, 11.8, 4.1), PINK, leg)
    return build("giorno_pants", cubes)


# ---------------------------------------------------------------- shoes
def d_dot(f, x, y, w, h):
    if f == "top" and 2 <= x <= 3 and 1 <= y <= 2:
        return BLUE
    return None


def shoes():
    cubes = []
    for side, sx in (("r", -1), ("l", 1)):
        m = side == "l"
        ox = sx * 0.1
        bone = "right_leg" if side == "r" else "left_leg"

        def tw(n):
            return None if side == "r" else n + "_r"
        cubes += [
            Cube(f"shoe_{side}", bone, (ox, 10.9, 0.2), (4.3, 2.2, 4.2), NAVY, grad(NAVY_L, NAVY), twin_of=tw("shoe"), mirror=m),
            Cube(f"toe_{side}", bone, (ox, 11.0, -2.9), (4.0, 2.0, 2.4), NAVY, d_dot, twin_of=tw("toe"), mirror=m),
            Cube(f"sole_{side}", bone, (ox, 11.85, -0.8), (4.3, 0.6, 6.8), TEAL, None, twin_of=tw("sole"), mirror=m),
        ]
    return build("giorno_shoes", cubes)


# ---------------------------------------------------------------- icons
def icon_jacket():
    i = Icon()
    blk(i, 1, 4, 3, 11, PINK)                      # sleeves
    blk(i, 12, 4, 14, 11, PINK)
    i.rect(1, 3, 3, 3, PINK_L); i.rect(12, 3, 14, 3, PINK_L)
    i.rect(1, 9, 3, 9, GOLD); i.rect(12, 9, 14, 9, GOLD)
    blk(i, 3, 2, 12, 11, PINK)                     # torso
    blk(i, 2, 11, 13, 14, PINK)                    # peplum
    i.rect(2, 13, 13, 13, shade(PINK, 0.85))
    i.rect(2, 14, 13, 14, GOLD_D)
    for x in range(3, 13, 2):
        i.put(x, 12, PURPLE)
    for x in range(4, 13, 2):
        i.put(x, 13, PURPLE)
    heart = [(5, 4), (6, 4), (9, 4), (10, 4), (5, 5), (6, 5), (7, 5), (8, 5), (9, 5), (10, 5),
             (6, 6), (7, 6), (8, 6), (9, 6), (7, 7), (8, 7)]
    for x, y in heart:
        i.put(x, y, SKIN)
    for x, y in ((5, 3), (6, 3), (9, 3), (10, 3), (4, 4), (11, 4), (4, 5), (11, 5), (5, 6), (10, 6), (6, 7), (9, 7), (7, 8), (8, 8)):
        i.put(x, y, GOLD)
    i.put(7, 9, GOLD); i.rect(7, 10, 7, 13, GOLD)
    i.put(4, 7, BLUE); i.put(11, 7, BLUE); i.put(8, 10, BLUE)
    i.rect(5, 2, 6, 2, GOLD); i.rect(9, 2, 10, 2, GOLD)
    i.save("giorno_jacket")


def icon_pants():
    i = Icon()
    blk(i, 3, 2, 12, 4, PINK)
    blk(i, 3, 5, 7, 14, PINK)
    blk(i, 8, 5, 12, 14, PINK)
    i.rect(3, 2, 12, 2, shade(PINK, 0.82))
    i.rect(7, 5, 8, 14, shade(PINK, 0.78))
    i.rect(5, 6, 5, 13, PINK_L); i.rect(10, 6, 10, 13, PINK_L)
    i.save("giorno_pants")


def icon_shoes():
    i = Icon()
    for x0 in (1, 8):
        blk(i, x0 + 1, 6, x0 + 5, 11, NAVY)
        blk(i, x0, 9, x0 + 6, 12, NAVY)
        i.rect(x0 + 1, 6, x0 + 3, 7, NAVY_L)
        i.put(x0 + 4, 10, BLUE)
        i.rect(x0, 13, x0 + 6, 13, TEAL)
    i.save("giorno_shoes")


# ---------------------------------------------------------------- registration
ITEMS = [
    dict(id="giorno_jacket", category="top", ru="Розовый жакет с сердцем", en="Pink Heart Jacket", price=14999,
         build=jacket, icon=icon_jacket),
    dict(id="giorno_pants", category="bottom", ru="Розовые брюки", en="Pink Trousers", price=6999,
         build=pants, icon=icon_pants),
    dict(id="giorno_shoes", category="shoes", ru="Синие туфли с бирюзовой подошвой", en="Navy Shoes with Teal Soles", price=5499,
         build=shoes, icon=icon_shoes),
]
CATEGORY = {"top": "TOP", "bottom": "BOTTOM", "shoes": "SHOES"}
DOC_MARK = "## Pink heart suit"
DOC_TEXT = """
## Pink heart suit
`python3 tools/gen_giorno.py` regenerates the models, textures, icons and (idempotently) the entries in `clothes.json`, the lang files,
`ClothingCatalog`, `ClothingPrices` and `Looks` (look `giorno`).
- `giorno_jacket` (top): ONE closed, slim torso box (8.4 x 4.4, just over the skin's 8 x 4) on the `body` bone (the player's skin is covered), so the heart-shaped hole on its front
  is simply transparent pixels and the wearer's own chest shows through; the heart outline, the zip line and the hem are gold. A flared
  peplum box below it carries a purple/lilac argyle pattern on the back and sides. Puffed shoulders are a second pair of boxes on the
  arm bones (`pad`, the top is pulled up over the skin shoulder by `arm_pair`), the cuffs are gold bands painted on the sleeves. The three
  blue ladybug brooches and the two gold collar wings are flat decals (0.5 thick boxes with the shape cut out by transparent pixels).
  The collar is only painted (a lighter band + gold line): the head hides everything of a stand-up collar that is inside x = +-4.
- `giorno_pants` (bottom): slim trousers with a crease. `giorno_shoes` (shoes): navy shoes, teal sole, blue dot on the toe.
"""


def register():
    res = ROOT / "src/main/resources/assets/fittingroom"
    cj = json.loads((res / "clothes.json").read_text(encoding="utf-8"))
    have = {it["id"] for it in cj["items"]}
    for e in ITEMS:
        if e["id"] in have:
            continue
        cj["items"].append({"id": e["id"], "category": e["category"],
                            "name": {"ru_ru": e["ru"], "en_us": e["en"]},
                            "model": f"fittingroom:clothes_models/{e['id']}.json",
                            "texture": f"fittingroom:textures/clothes/{e['id']}.png",
                            "icon": f"fittingroom:textures/gui/clothes/{e['id']}.png"})
    (res / "clothes.json").write_text(json.dumps(cj, ensure_ascii=False) + "\n", encoding="utf-8")

    for lang, key, look in (("ru_ru", "ru", "Джорно"), ("en_us", "en", "Giorno")):
        path = res / f"lang/{lang}.json"
        data = json.loads(path.read_text(encoding="utf-8"))
        for e in ITEMS:
            data.setdefault(f"clothes.fittingroom.{e['id']}", e[key])
        data.setdefault("look.fittingroom.giorno", look)
        path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    java = ROOT / "src/main/java/com/fittingroom/wardrobe/ClothingCatalog.java"
    text = java.read_text(encoding="utf-8")
    close = "\n    );\n\n    private static final Map<String, Item> BY_ID"
    lines = [f'            new Item("{e["id"]}", Category.{CATEGORY[e["category"]]})' for e in ITEMS if f'"{e["id"]}"' not in text]
    if lines:
        assert close in text, "end of the item list not found"
        java.write_text(text.replace(close, ",\n" + ",\n".join(lines) + close), encoding="utf-8")

    prices = ROOT / "src/main/java/com/fittingroom/wardrobe/ClothingPrices.java"
    text = prices.read_text(encoding="utf-8")
    anchor = "        // ---- scarves ----\n"
    assert anchor in text, "anchor for the prices not found"
    add = "".join(f'        p("{e["id"]}", {e["price"]});\n' for e in ITEMS if f'"{e["id"]}"' not in text)
    if add:
        prices.write_text(text.replace(anchor, "        // ---- pink heart suit ----\n" + add + "\n" + anchor, 1), encoding="utf-8")

    looks = ROOT / "src/main/java/com/fittingroom/wardrobe/Looks.java"
    text = looks.read_text(encoding="utf-8")
    if '"giorno"' not in text:
        end = text.index("\n    );", text.index("public static final List<Look> ALL = List.of("))
        add = ',\n            new Look("giorno", List.of("giorno_jacket", "giorno_pants", "giorno_shoes"))'
        looks.write_text(text[:end] + add + text[end:], encoding="utf-8")

    doc = ROOT / "docs/clothes-models.md"
    text = doc.read_text(encoding="utf-8")
    if DOC_MARK not in text:
        doc.write_text(text.rstrip("\n") + "\n" + DOC_TEXT, encoding="utf-8")


# ---------------------------------------------------------------- preview (front and side, no game needed)
def preview(ids=None, items=None, name="giorno"):
    from PIL import Image, ImageDraw
    items = items or ITEMS
    out = Path(f"/tmp/{name}_preview")
    out.mkdir(parents=True, exist_ok=True)
    S = 16
    pivots = {"body": (0, 0), "head": (0, 0), "right_arm": (-5, 2), "left_arm": (5, 2), "right_leg": (-1.9, 12), "left_leg": (1.9, 12)}
    ids = ids or ["giorno_jacket", "giorno_pants", "giorno_shoes"]
    cubes = []
    for i in ids:
        m = json.loads((ASSETS / f"clothes_models/{i}.json").read_text())
        tex = Image.open(ASSETS / f"textures/clothes/{i}.png").convert("RGBA")
        cubes += [(c, tex) for c in m["cubes"]]

    def render(side):
        W, H = 26 * S, 40 * S
        img = Image.new("RGBA", (W, H), (60, 70, 120, 255))
        dr = ImageDraw.Draw(img)

        def X(v):
            return int(round((v + 13) * S))
        boxes = ((-4, -8, 4, 0), (-4, 0, 4, 12), (-8, 0, -4, 12), (4, 0, 8, 12), (-3.9, 12, 0, 24), (0, 12, 3.9, 24))
        for (a, b, c2, d2) in boxes:
            if side:
                a, c2 = (-4, 4) if b < 12 and a > -5 and c2 < 5 else (-2, 2)
            dr.rectangle([X(a), X(b), X(c2), X(d2)], fill=SKIN if b < 12 else (70, 70, 120))
        if side:
            order = sorted(cubes, key=lambda ct: -(ct[0]["pos"][0] + pivots[ct[0]["bone"]][0]))
        else:
            order = sorted(cubes, key=lambda ct: ct[0]["pos"][2] - ct[0]["grow"][2], reverse=True)
        for c, tex in order:
            px, py = pivots[c["bone"]]
            w, h, d = c["size"]
            g = c["grow"]
            u, v = c["uv"]
            if side:
                if px > 0:
                    continue
                a0, a1 = c["pos"][2] - g[2], c["pos"][2] + d + g[2]
                ux = (u + d + w) if c.get("mirror") else u
                face = tex.crop((ux * PX, (v + d) * PX, (ux + d) * PX, (v + d + h) * PX))
            else:
                a0, a1 = px + c["pos"][0] - g[0], px + c["pos"][0] + w + g[0]
                face = tex.crop(((u + d) * PX, (v + d) * PX, (u + d + w) * PX, (v + d + h) * PX))
                if c.get("mirror"):
                    face = face.transpose(Image.FLIP_LEFT_RIGHT)
            y0, y1 = py + c["pos"][1] - g[1], py + c["pos"][1] + h + g[1]
            face = face.resize((max(1, X(a1) - X(a0)), max(1, X(y1) - X(y0))), Image.NEAREST)
            img.alpha_composite(face, (X(a0), X(y0)))
        return img.convert("RGB")

    def render_back():
        W, H = 26 * S, 40 * S
        img = Image.new("RGBA", (W, H), (60, 70, 120, 255))
        dr = ImageDraw.Draw(img)

        def X(v):
            return int(round((13 - v) * S))            # seen from behind: the wearer's left is on the left of the picture

        def Y(v):
            return int(round((v + 13) * S))
        for (a0, b0, c0, d0) in ((-4, -8, 4, 0), (-4, 0, 4, 12), (-8, 0, -4, 12), (4, 0, 8, 12), (-3.9, 12, 0, 24), (0, 12, 3.9, 24)):
            dr.rectangle([X(c0), Y(b0), X(a0), Y(d0)], fill=SKIN if b0 < 12 else (90, 90, 110))
        for c, tex in sorted(cubes, key=lambda ct: ct[0]["pos"][2] + ct[0]["size"][2] + ct[0]["grow"][2]):
            px, py = pivots[c["bone"]]
            w, h, d = c["size"]
            g = c["grow"]
            u, v = c["uv"]
            x0, x1 = px + c["pos"][0] - g[0], px + c["pos"][0] + w + g[0]
            y0, y1 = py + c["pos"][1] - g[1], py + c["pos"][1] + h + g[1]
            face = tex.crop(((u + 2 * d + w) * PX, (v + d) * PX, (u + 2 * d + 2 * w) * PX, (v + d + h) * PX))
            if c.get("mirror"):
                face = face.transpose(Image.FLIP_LEFT_RIGHT)
            face = face.resize((max(1, X(x0) - X(x1)), max(1, Y(y1) - Y(y0))), Image.NEAREST)
            img.alpha_composite(face, (X(x1), Y(y0)))
        return img.convert("RGB")

    a, b, c3 = render(False), render(True), render_back()
    sheet = Image.new("RGB", (a.width * 3, a.height))
    sheet.paste(a, (0, 0)); sheet.paste(b, (a.width, 0)); sheet.paste(c3, (a.width * 2, 0))
    sheet.save(out / "all.png")
    ic = Image.new("RGBA", (len(items) * 136, 136), (190, 190, 190, 255))
    for k, e in enumerate(items):
        im = Image.open(ASSETS / f"textures/gui/clothes/{e['id']}.png").convert("RGBA").resize((128, 128), Image.NEAREST)
        ic.alpha_composite(im, (k * 136 + 4, 4))
    ic.save(out / "icons.png")
    print("previews in", out)


if __name__ == "__main__":
    for e in ITEMS:
        e["build"]()
        e["icon"]()
    register()
    print("generated:", ", ".join(e["id"] for e in ITEMS))
    if "--preview" in sys.argv:
        preview()
