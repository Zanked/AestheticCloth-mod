#!/usr/bin/env python3
"""
Generates two long-coat costumes of the fitting room (after the two cosplay pictures):

  white (Part 4 style)   jotaro_p4_cap    (hat)     white peaked cap with gold fish and sun badges and a gold-edged visor
                         jotaro_p4_coat   (top)     long white coat: tall collar, purple cuffs, seven gold buttons, a gold
                                                    "heart" brooch and a gold triangle on the shoulder; the purple shirt with a
                                                    white sash and gold plates shows in the open front
                         jotaro_p4_pants  (bottom)  white trousers with a purple belt and two orange-gold plates
  black (Part 3 style)   jotaro_p3_cap    (hat)     black peaked cap with a gold stripe, a gold square plate and a round button
                         jotaro_p3_coat   (top)     long black coat with white lining on the opening edges, three gold buttons,
                                                    a grey shirt with a purple clip
                         jotaro_p3_pants  (bottom)  black trousers with a green / orange / red triangle belt and a buckle
                         jotaro_p3_chain  (accessory, own slot "chain")  gold chain hanging from the collar over the chest

Shoes are not part of the sets: `boy_shoes` (black leather shoes) go with both.
Run from the project root:  python3 tools/gen_jotaro.py            (models, textures, icons, registration)
                            python3 tools/gen_jotaro.py --preview   (also writes front-view previews to /tmp/jotaro_preview)
Same smooth painter as gen_suit.py / gen_dino.py.
"""
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from gen_dino import blk, build, mix  # noqa: E402
from gen_accessories import ASSETS, PX, Cube, Icon, shade  # noqa: E402
from gen_outerwear import arm_pair, leg_pair, sd  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent

GOLD = (238, 200, 94)
GOLD_D = (178, 132, 52)
GOLD_L = (255, 233, 152)
SILVER = (206, 210, 224)

PALETTES = {
    "p4": dict(
        kind="white", base=(238, 238, 246), light=(255, 255, 255), dark=(184, 186, 206), lining=(214, 214, 232),
        shirt=(134, 40, 130), shirt_d=(98, 26, 96), cuff=(132, 38, 128), cuff_d=(92, 22, 90), cuff_l=(166, 78, 158),
        buttons=(3, 8, 13, 18, 23), skirt_buttons=(3, 12),
        ru_cap="Кепка Джотаро (белая)", en_cap="Jotaro Cap (White)",
        ru_coat="Пальто Джотаро (белое)", en_coat="Jotaro Coat (White)",
        ru_pants="Брюки Джотаро (белые)", en_pants="Jotaro Trousers (White)",
        ru_look="Джотаро (белый)", en_look="Jotaro (White)",
    ),
    "p3": dict(
        kind="black", base=(32, 32, 40), light=(56, 56, 68), dark=(16, 16, 22), lining=(232, 232, 240),
        shirt=(122, 124, 124), shirt_d=(88, 90, 90), cuff=(32, 32, 40), cuff_d=(16, 16, 22), cuff_l=(56, 56, 68),
        buttons=(8, 15, 22), skirt_buttons=(),
        ru_cap="Кепка Джотаро (чёрная)", en_cap="Jotaro Cap (Black)",
        ru_coat="Пальто Джотаро (чёрное)", en_coat="Jotaro Coat (Black)",
        ru_pants="Брюки Джотаро (чёрные)", en_pants="Jotaro Trousers (Black)",
        ru_look="Джотаро (чёрный)", en_look="Jotaro (Black)",
    ),
}


# ====================================================================== flat gold decals (shape cut out of the texture)
def pat_deco(rows):
    """A decal is a 0.5 thick box: the shape is drawn on the front, everything else is transparent."""
    cols = {"X": GOLD, "D": GOLD_D, "L": GOLD_L}

    def d(f, x, y, w, h):
        if f != "front":
            return "clear"
        ch = rows[y][x] if y < len(rows) and x < len(rows[y]) else "."
        return cols.get(ch, "clear")
    return d


FISH = ["..XXX.",
        ".XXXD.",
        "XXXD..",
        "XXDX..",
        ".XXXD.",
        "..XXX."]
SUN = ["X.XX.X",
       ".XLLX.",
       "XLXXDX",
       "XXXDDX",
       ".XDDX.",
       "X.XX.X"]
PLATE = ["XXXXXX",
         "XDDDDX",
         "XDLLDX",
         "XDLXDX",
         "XDDDDX",
         "XXXXXX"]
BUTTON = [".XX.",
          "XLXX",
          "XXXD",
          ".XD."]
HEART = [".XX..XX.",
         "XXXXXXXX",
         "XLXXXXDX",
         "XXXXXXXX",
         ".XXXXXX.",
         "..XXXX..",
         "...XX...",
         "........"]
TRIANGLE = ["...XX...",
            "...XX...",
            "..XLXX..",
            "..XDDX..",
            ".XXDDXX.",
            ".XDXXDX.",
            "XXXXXXXX",
            "XXXXXXXX"]


# ====================================================================== COAT
def shirt_deco(p):
    base, dark = p["shirt"], p["shirt_d"]
    if p["kind"] == "white":
        def d(f, x, y, w, h):
            if not sd(f):
                return None
            col = mix(base, dark, y / max(1, h - 1) * 0.5)
            if f == "front":
                if y < 3 and 6 <= x <= 11:
                    return mix(base, dark, 0.7)          # neckline
                xc = 12.6 - y * 0.40                      # the white sash runs from the right shoulder to the left hip
                if y < 21 and abs(x - xc) < 1.3:
                    if (3 <= y <= 5 or 13 <= y <= 15) and abs(x - xc) < 0.95:
                        return GOLD_D if (y in (5, 15)) else GOLD
                    return (236, 236, 246) if abs(x - xc) < 0.9 else mix((236, 236, 246), base, 0.5)
            return col
        return d

    def d(f, x, y, w, h):
        if not sd(f):
            return None
        col = mix(base, dark, y / max(1, h - 1) * 0.4)
        if f == "front":
            if y < 3 and 6 <= x <= 11:
                return mix(base, dark, 0.7)
            if y % 3 == 2 and y < 22 and 4 <= x <= 13:
                return mix(col, dark, 0.45)                # ribbed knit
            if 7 <= y <= 9 and 10 <= x <= 12:              # purple clip on the wearer's left chest
                return (206, 168, 240) if y == 7 else ((164, 118, 206) if y == 8 else (116, 78, 156))
        return col
    return d


def panel_deco(p, side):
    """Front half of the coat. side 'r' = wearer's right (seen on the left): the inner edge is x = w-1;
    'l' = wearer's left: the inner edge is x = 0."""
    base, dark = p["base"], p["dark"]

    def d(f, x, y, w, h):
        if not sd(f) or f != "front":
            return None
        di = (w - 1 - x) if side == "r" else x
        if y == h - 1:
            return mix(base, dark, 0.5)
        if p["kind"] == "black":
            lw = 2 if y < 7 else 1                          # white lining: a wider lapel at the top
            if di < lw:
                return p["lining"] if di == 0 or y < 7 else mix(p["lining"], base, 0.3)
        elif di == 0:
            return mix(base, dark, 0.55)                    # front edge of the opening
        if side == "r":
            for by in p["buttons"]:
                if by <= y <= by + 1 and 2 <= di <= 3:
                    return mix(GOLD, (255, 255, 255), 0.45) if (di, y) == (3, by) else (GOLD_D if y == by + 1 else GOLD)
        if y in (3, 4) and di > 3 and p["kind"] == "white":
            return mix(base, dark, 0.18)                   # fold of the stand-up collar
        return None
    return d


def back_deco(p):
    base, dark = p["base"], p["dark"]

    def d(f, x, y, w, h):
        if f == "back" and x in (w // 2 - 1, w // 2):
            return mix(base, dark, 0.55)                    # centre seam
        return None
    return d


def skirt_deco(p):
    base, dark = p["base"], p["dark"]

    def d(f, x, y, w, h):                                   # w = 22, h = 22 on the front
        if f == "front":
            if 7 <= x <= 14:
                return "clear"                              # the coat is open in front
            di = (6 - x) if x < 7 else (x - 15)             # distance from the inner edge of each half
            if y == h - 1:
                return mix(base, dark, 0.5)
            if di == 0:
                return p["lining"] if p["kind"] == "black" else mix(base, dark, 0.55)
            if x < 7:
                for by in p["skirt_buttons"]:
                    if by <= y <= by + 1 and 2 <= di <= 3:
                        return mix(GOLD, (255, 255, 255), 0.45) if (di, y) == (3, by) else (GOLD_D if y == by + 1 else GOLD)
            return None
        if f == "back":
            if x in (w // 2 - 1, w // 2):
                return mix(base, dark, 0.55)
            if y > h - 11 and x in (w // 2 + 1, w // 2 - 2):
                return mix(base, dark, 0.22)               # vent
            if y == h - 1:
                return mix(base, dark, 0.5)
            return None
        if f == "bottom":
            return p["lining"] if p["kind"] == "black" else mix(base, dark, 0.35)
        if f in ("right", "left") and y == h - 1:
            return mix(base, dark, 0.5)
        return None
    return d


def collar_deco(p, inner):
    """Stand-up collar piece; `inner` is the face that looks at the neck (white lining on the black coat)."""
    base, dark = p["base"], p["dark"]

    def d(f, x, y, w, h):
        if f == "top":
            return p["lining"]
        if f == inner:
            return p["lining"] if p["kind"] == "black" else mix(base, dark, 0.25)
        if f == "bottom":
            return None
        if y == h - 1:
            return mix(base, dark, 0.45)
        if y == 0:
            return mix(base, p["light"], 0.3)
        return None
    return d


def sleeve_deco(p):
    base, dark = p["base"], p["dark"]

    def d(f, x, y, w, h):
        if f == "top":
            return None
        if p["kind"] == "white" and y >= h - 7:             # wide purple cuff
            if y == h - 7:
                return p["cuff_l"]
            if y == h - 1:
                return p["cuff_d"]
            return p["cuff"]
        if y == h - 1:
            return mix(base, dark, 0.5)
        if p["kind"] == "black" and y == h - 6:
            return mix(base, dark, 0.5)                     # cuff seam
        return None
    return d


def coat(key, p):
    cubes = [
        Cube("shirt", "body", (0, 6.1, 0), (9.0, 12.2, 5.2), p["shirt"], shirt_deco(p)),
        Cube("back", "body", (0, 6.2, 1.1), (9.9, 13.2, 3.7), p["base"], back_deco(p)),
        Cube("panel_r", "body", (-3.45, 6.2, -1.85), (3.0, 13.2, 2.2), p["base"], panel_deco(p, "r")),
        Cube("panel_l", "body", (3.45, 6.2, -1.85), (3.0, 13.2, 2.2), p["base"], panel_deco(p, "l")),
        Cube("skirt", "body", (0, 17.6, 0), (10.4, 10.4, 6.1), p["base"], skirt_deco(p)),
        # stand-up collar: two flaps beside the head (the head hides everything that is inside x = +-4) and a low roll at the nape
        Cube("collar_r", "body", (-4.4, -1.6, -0.3), (0.8, 5.0, 5.2), p["base"], collar_deco(p, "left")),
        Cube("collar_l", "body", (4.4, -1.6, -0.3), (0.8, 5.0, 5.2), p["base"], collar_deco(p, "right")),
        Cube("nape", "body", (0, 0.3, 3.45), (9.6, 1.6, 0.9), p["base"], collar_deco(p, "front")),
    ]
    arm_pair(cubes, "sleeve", 4.0, (5.5, 12.6, 5.5), p["base"], sleeve_deco(p))
    if key == "p4":
        cubes.append(Cube("brooch", "body", (-3.2, 3.2, -3.1), (4.0, 4.0, 0.5), GOLD, pat_deco(HEART)))
        cubes.append(Cube("epaulette", "body", (3.2, 2.6, -3.1), (4.0, 4.0, 0.5), GOLD, pat_deco(TRIANGLE)))
    return build(f"jotaro_{key}_coat", cubes)


# ====================================================================== CAP
def band_deco(p):
    base, dark = p["base"], p["dark"]

    def d(f, x, y, w, h):
        if f in ("top", "bottom"):
            return None
        if p["kind"] == "black":
            if 1 <= y <= 2:
                return GOLD if y == 1 else GOLD_D          # gold stripe round the cap
            return None
        if y == h - 1:
            return mix(base, dark, 0.45)
        return None
    return d


def visor_deco(p):
    def d(f, x, y, w, h):
        if p["kind"] == "white" and f == "front":
            return GOLD
        if p["kind"] == "black" and f == "front":
            return mix(p["base"], p["dark"], 0.5)
        return None
    return d


def cap(key, p):
    base = p["base"]
    cubes = [
        Cube("band", "head", (0, -7.9, 0), (9.0, 1.6, 9.0), base, band_deco(p)),
        Cube("crown", "head", (0, -9.5, 0), (9.4, 1.6, 9.4), base, None),
        Cube("plate", "head", (0, -10.6, 0), (9.2, 0.6, 9.2), mix(base, p["light"], 0.25), None),
        Cube("visor", "head", (0, -7.8, -5.9), (6.4, 0.5, 3.0), mix(base, p["dark"], 0.15), visor_deco(p),
             pivot=(0, -7.8, -4.4), rot=(10, 0, 0)),
    ]
    if key == "p4":
        cubes.append(Cube("fish", "head", (-2.3, -9.1, -4.85), (3.0, 3.0, 0.5), GOLD, pat_deco(FISH)))
        cubes.append(Cube("sun", "head", (1.9, -9.1, -4.85), (3.0, 3.0, 0.5), GOLD, pat_deco(SUN)))
    else:
        cubes.append(Cube("button", "head", (-2.4, -9.0, -4.85), (2.0, 2.0, 0.5), GOLD, pat_deco(BUTTON)))
        cubes.append(Cube("plate_badge", "head", (1.8, -9.1, -4.85), (3.0, 3.0, 0.5), GOLD, pat_deco(PLATE)))
    return build(f"jotaro_{key}_cap", cubes)


# ====================================================================== TROUSERS
TRI_G, TRI_O, TRI_R = (46, 150, 70), (240, 170, 48), (208, 52, 42)
TRI_ROWS = ["GGGGGG",
            "OGGGGO",
            "OOGGOO",
            "OORROO",
            "ORRRRO",
            "RRRRRR"]


def belt_deco(p):
    if p["kind"] == "white":
        PLATE_C, PLATE_D = (222, 158, 66), (160, 100, 40)

        def d(f, x, y, w, h):
            if f in ("top", "bottom"):
                return (118, 44, 134)
            if y == 0:
                return (226, 220, 244)                      # light edge of the belt
            col = (140, 64, 154) if y < h - 1 else (104, 36, 118)
            if f == "front" and 1 <= y <= h - 2 and (5 <= x <= 8 or 11 <= x <= 14):
                return PLATE_D if (x in (5, 11) or x in (8, 14) or y in (1, h - 2)) else PLATE_C
            return col
        return d

    def d(f, x, y, w, h):
        if f in ("top", "bottom"):
            return TRI_O
        ch = TRI_ROWS[y % 6][x % 6]
        if f == "front" and 8 <= x <= 11 and 1 <= y <= 4:    # buckle
            return GOLD_D if (x in (8, 11) or y in (1, 4)) else GOLD
        return {"G": TRI_G, "O": TRI_O, "R": TRI_R}[ch]
    return d


def pants(key, p):
    base, dark, light = p["base"], p["dark"], p["light"]
    pb = (240, 240, 246) if p["kind"] == "white" else (30, 30, 38)
    pd = (186, 188, 206) if p["kind"] == "white" else (14, 14, 20)
    pl = (255, 255, 255) if p["kind"] == "white" else (56, 56, 68)

    def leg(f, x, y, w, h):
        if f in ("top", "bottom"):
            return None
        col = mix(pl, pb, min(1.0, y / max(1, h - 1) * 0.9))
        if f in ("front", "back") and x == w // 2 - 1:
            return mix(col, pd, 0.5)                        # pressed crease
        if f in ("front", "back") and y == h - 1:
            return mix(col, pd, 0.35)                       # hem
        return col

    def waist(f, x, y, w, h):
        if f == "front" and x in (w // 2 - 1, w // 2) and y > 5:
            return mix(pb, pd, 0.45)                        # fly
        return None

    cubes = [
        Cube("waist", "body", (0, 11.4, 0), (9.5, 3.2, 5.5), pb, waist),
        Cube("belt", "body", (0, 10.6, 0), (9.7, 2.4, 5.7), (140, 64, 154) if p["kind"] == "white" else TRI_O, belt_deco(p)),
    ]
    leg_pair(cubes, "leg", 5.6, (4.8, 11.8, 4.8), pb, leg)
    return build(f"jotaro_{key}_pants", cubes)


# ====================================================================== CHAIN
def ring_deco(face_names):
    """Ring with a see-through hole on the given faces, plain gold elsewhere."""
    def d(f, x, y, w, h):
        if f in face_names:
            if 1 <= x <= w - 2 and 1 <= y <= h - 2:
                return "clear"
            return GOLD_L if (x == 0 or y == 0) else GOLD_D if (x == w - 1 or y == h - 1) else GOLD
        return GOLD_D if f in ("top", "bottom") else GOLD
    return d


def chain():
    cubes = []
    for i in range(5):
        y = 1.5 + i * 1.9
        if i % 2 == 0:
            cubes.append(Cube(f"link{i}", "body", (-2.5, y, -3.35), (1.6, 2.4, 0.6), GOLD, ring_deco(("front", "back"))))
        else:
            cubes.append(Cube(f"link{i}", "body", (-2.5, y, -3.35), (0.6, 2.4, 1.6), GOLD, ring_deco(("right", "left"))))
    return build("jotaro_p3_chain", cubes)


# ====================================================================== ICONS
def icon_cap(key, p):
    base, dark, light = p["base"], p["dark"], p["light"]
    i = Icon()
    blk(i, 3, 3, 12, 8, base)
    i.px.pop((3, 3)); i.px.pop((12, 3))
    blk(i, 3, 8, 12, 10, mix(base, dark, 0.25))
    blk(i, 4, 11, 11, 12, mix(base, dark, 0.4))
    if key == "p4":
        i.rect(4, 12, 11, 12, GOLD)
        i.rect(4, 4, 6, 7, GOLD); i.put(5, 5, GOLD_D); i.put(6, 4, base); i.put(6, 7, base)    # fish
        i.rect(8, 5, 11, 7, GOLD); i.put(9, 6, GOLD_L); i.put(8, 5, base); i.put(11, 5, base); i.put(8, 7, base); i.put(11, 7, base)
        i.put(9, 4, GOLD); i.put(10, 4, GOLD)
    else:
        i.rect(3, 9, 12, 9, GOLD)
        i.put(4, 5, GOLD); i.put(5, 5, GOLD); i.put(4, 6, GOLD); i.put(5, 6, GOLD_D)       # round button
        i.rect(8, 4, 11, 7, GOLD); i.rect(9, 5, 10, 6, GOLD_D); i.put(9, 5, GOLD_L)         # plate
    i.save(f"jotaro_{key}_cap")


def icon_coat(key, p):
    base, dark, light = p["base"], p["dark"], p["light"]
    i = Icon()
    blk(i, 2, 2, 5, 14, base)                           # left half
    blk(i, 10, 2, 13, 14, base)                         # right half
    blk(i, 0, 4, 2, 11, base)                           # sleeves
    blk(i, 13, 4, 15, 11, base)
    if p["kind"] == "white":
        i.rect(0, 9, 2, 11, p["cuff"]); i.rect(13, 9, 15, 11, p["cuff"])
        i.rect(0, 9, 2, 9, p["cuff_l"]); i.rect(13, 9, 15, 9, p["cuff_l"])
        i.put(3, 5, GOLD); i.put(3, 8, GOLD); i.put(3, 11, GOLD)
        i.put(3, 5, GOLD); i.put(4, 6, GOLD_L)
        i.rect(5, 3, 10, 13, p["shirt"])
        i.rect(8, 3, 9, 4, (236, 236, 246)); i.rect(7, 6, 8, 8, (236, 236, 246)); i.rect(6, 9, 7, 11, (236, 236, 246))
        i.put(8, 4, GOLD); i.put(7, 8, GOLD)
        i.rect(3, 3, 3, 3, GOLD)                        # brooch
        i.rect(11, 3, 12, 4, GOLD); i.put(11, 3, GOLD_D)  # triangle
        i.rect(2, 1, 5, 2, base); i.rect(10, 1, 13, 2, base)
        i.rect(5, 1, 10, 1, shade(base, 0.9))
    else:
        i.rect(4, 3, 4, 13, p["lining"]); i.rect(11, 3, 11, 13, p["lining"])
        i.rect(5, 3, 10, 13, p["shirt"])
        for y in (5, 7, 9, 11):
            i.rect(5, y, 10, y, p["shirt_d"])
        i.put(9, 6, (186, 140, 226)); i.put(9, 7, (140, 96, 186))
        i.put(3, 6, GOLD); i.put(3, 9, GOLD); i.put(3, 12, GOLD)
        i.rect(2, 1, 5, 2, base); i.rect(10, 1, 13, 2, base)
        i.rect(5, 1, 10, 1, shade(base, 0.9))
        i.rect(4, 2, 5, 2, p["lining"]); i.rect(10, 2, 11, 2, p["lining"])
    i.save(f"jotaro_{key}_coat")


def icon_pants(key, p):
    i = Icon()
    pb = (240, 240, 246) if p["kind"] == "white" else (36, 36, 46)
    blk(i, 3, 2, 12, 4, pb)
    blk(i, 3, 5, 7, 14, pb)
    blk(i, 8, 5, 12, 14, pb)
    if p["kind"] == "white":
        i.rect(3, 2, 12, 4, (140, 64, 154)); i.rect(3, 2, 12, 2, (226, 220, 244))
        i.rect(5, 3, 6, 4, (222, 158, 66)); i.rect(9, 3, 10, 4, (222, 158, 66))
    else:
        for x in range(3, 13):
            i.put(x, 2, TRI_G if x % 2 else TRI_O)
            i.put(x, 3, TRI_O if x % 2 else TRI_G)
            i.put(x, 4, TRI_R if x % 2 else TRI_O)
        i.rect(7, 3, 8, 4, GOLD)
    i.rect(7, 5, 8, 14, shade(pb, 0.78))
    i.save(f"jotaro_{key}_pants")


def icon_chain():
    i = Icon()
    for k in range(4):
        y = 1 + k * 3
        i.rect(5, y, 10, y + 2, GOLD)
        i.rect(6, y + 1, 9, y + 1, GOLD_D if False else (0, 0, 0))
        i.px.pop((6, y + 1)); i.px.pop((7, y + 1)); i.px.pop((8, y + 1)); i.px.pop((9, y + 1))
        i.put(5, y, GOLD_L)
        i.put(10, y + 2, GOLD_D)
    i.save("jotaro_p3_chain")


# ====================================================================== REGISTRATION
PRICE = {"cap": 3499, "coat": 15999, "pants": 6999, "chain": 2499}


def entries():
    out = []
    for key, p in PALETTES.items():
        out.append(dict(id=f"jotaro_{key}_cap", category="hat", slot=None, ru=p["ru_cap"], en=p["en_cap"],
                        price=PRICE["cap"], build=lambda k=key, p=p: cap(k, p), icon=lambda k=key, p=p: icon_cap(k, p)))
        out.append(dict(id=f"jotaro_{key}_coat", category="top", slot=None, ru=p["ru_coat"], en=p["en_coat"],
                        price=PRICE["coat"], build=lambda k=key, p=p: coat(k, p), icon=lambda k=key, p=p: icon_coat(k, p)))
        out.append(dict(id=f"jotaro_{key}_pants", category="bottom", slot=None, ru=p["ru_pants"], en=p["en_pants"],
                        price=PRICE["pants"], build=lambda k=key, p=p: pants(k, p), icon=lambda k=key, p=p: icon_pants(k, p)))
    out.append(dict(id="jotaro_p3_chain", category="accessory", slot="chain", ru="Золотая цепь с воротника",
                    en="Gold Collar Chain", price=PRICE["chain"], build=chain, icon=icon_chain))
    return out


CATEGORY = {"hat": "HAT", "top": "TOP", "bottom": "BOTTOM", "accessory": "ACCESSORY"}
DOC_MARK = "## Long-coat costumes (white and black)"
DOC_TEXT = """
## Long-coat costumes (white and black)
`python3 tools/gen_jotaro.py` regenerates the models, textures, icons and (idempotently) the entries in `clothes.json`, the lang files,
`ClothingCatalog`, `ClothingPrices` and `Looks`. Two colours, `p4` (white) and `p3` (black): the palettes are at the top of the script.
- `jotaro_<p>_cap` (hat): a peaked cap (band, crown, top plate and a tilted visor). The white one has a gold-edged visor and two flat gold
  badges (fish, sun); the black one has a gold stripe round the band, a round button and a square plate. The badges are decals:
  0.5 thick boxes whose shape is cut out of the texture with transparent pixels (sides are fully transparent).
- `jotaro_<p>_coat` (top): a long coat on the `body` bone. The upper part is a back piece, two front panels with a gap between them and a
  shirt in the gap (so the shirt is part of the top). The skirt is ONE deep box whose front face is transparent in the middle, so the coat
  really is open in front and you see the trousers and the inside of the back through it. Tall collar box, sleeves with purple cuffs (white)
  or a cuff seam (black), gold buttons, and for the white coat two decals: the "heart" brooch and the triangle on the shoulder.
  The black coat has white lining along the opening and a grey ribbed shirt with a purple clip.
- `jotaro_<p>_pants` (bottom): trousers with a pressed crease and a 2-unit-high belt (purple with two orange-gold plates / green-orange-red
  triangles with a buckle). The belt shows through the gap of the coat. Shoes are not part of the set (`boy_shoes` go with it).
- `jotaro_p3_chain` (accessory in its own slot `chain`, `ClothingCatalog.CHAIN`): five gold links, flat and edge-on ones alternating, hanging
  over the chest on the wearer's right from the collar; the holes of the links are transparent.
- Looks `jotaro_white` and `jotaro_black` are in `Looks.java`.
"""


def register(items):
    res = ROOT / "src/main/resources/assets/fittingroom"
    cj = json.loads((res / "clothes.json").read_text(encoding="utf-8"))
    have = {it["id"] for it in cj["items"]}
    for e in items:
        if e["id"] in have:
            continue
        item = {"id": e["id"], "category": e["category"]}
        if e["slot"]:
            item["slot"] = e["slot"]
        item.update({"name": {"ru_ru": e["ru"], "en_us": e["en"]},
                     "model": f"fittingroom:clothes_models/{e['id']}.json",
                     "texture": f"fittingroom:textures/clothes/{e['id']}.png",
                     "icon": f"fittingroom:textures/gui/clothes/{e['id']}.png"})
        cj["items"].append(item)
    (res / "clothes.json").write_text(json.dumps(cj, ensure_ascii=False) + "\n", encoding="utf-8")

    look_names = {}
    for key, p in PALETTES.items():
        look_names["look.fittingroom.jotaro_" + ("white" if key == "p4" else "black")] = (p["ru_look"], p["en_look"])
    for lang, idx, key in (("ru_ru", 0, "ru"), ("en_us", 1, "en")):
        path = res / f"lang/{lang}.json"
        data = json.loads(path.read_text(encoding="utf-8"))
        for e in items:
            data.setdefault(f"clothes.fittingroom.{e['id']}", e[key])
        for k, names in look_names.items():
            data.setdefault(k, names[idx])
        path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    java = ROOT / "src/main/java/com/fittingroom/wardrobe/ClothingCatalog.java"
    text = java.read_text(encoding="utf-8")
    if "String CHAIN" not in text:
        old = '    public static final String TIE = "tie";\n'
        assert old in text, "TIE constant not found"
        text = text.replace(old, old + '    /** A chain hanging over the chest: worn together with the other accessories (one chain at a time). */\n'
                            '    public static final String CHAIN = "chain";\n')
        old = "slot.equals(CHOKER) || slot.equals(NECKLACE) || slot.equals(TIE) ? 6"
        assert old in text, "render order of the jewelry not found"
        text = text.replace(old, "slot.equals(CHOKER) || slot.equals(NECKLACE) || slot.equals(TIE) || slot.equals(CHAIN) ? 6")
    close = "\n    );\n\n    private static final Map<String, Item> BY_ID"
    lines = []
    for e in items:
        if f'"{e["id"]}"' in text:
            continue
        if e["slot"]:
            lines.append(f'            jewel("{e["id"]}", {e["slot"].upper()})')
        else:
            lines.append(f'            new Item("{e["id"]}", Category.{CATEGORY[e["category"]]})')
    if lines:
        assert close in text, "end of the item list not found"
        text = text.replace(close, ",\n" + ",\n".join(lines) + close)
    java.write_text(text, encoding="utf-8")

    prices = ROOT / "src/main/java/com/fittingroom/wardrobe/ClothingPrices.java"
    text = prices.read_text(encoding="utf-8")
    anchor = "        // ---- scarves ----\n"
    assert anchor in text, "anchor for the prices not found"
    add = "".join(f'        p("{e["id"]}", {e["price"]});\n' for e in items if f'"{e["id"]}"' not in text)
    if add:
        prices.write_text(text.replace(anchor, "        // ---- long-coat costumes (white and black cost the same) ----\n" + add + "\n" + anchor, 1),
                          encoding="utf-8")

    looks = ROOT / "src/main/java/com/fittingroom/wardrobe/Looks.java"
    text = looks.read_text(encoding="utf-8")
    start = text.index("public static final List<Look> ALL = List.of(")
    end = text.index("\n    );", start)
    add = ""
    if '"jotaro_white"' not in text:
        add += (',\n            new Look("jotaro_white", List.of("jotaro_p4_cap", "jotaro_p4_coat", "jotaro_p4_pants", "boy_shoes"))')
    if '"jotaro_black"' not in text:
        add += (',\n            new Look("jotaro_black", List.of("jotaro_p3_cap", "jotaro_p3_coat", "jotaro_p3_pants", '
                '"jotaro_p3_chain", "boy_shoes"))')
    if add:
        looks.write_text(text[:end] + add + text[end:], encoding="utf-8")

    doc = ROOT / "docs/clothes-models.md"
    text = doc.read_text(encoding="utf-8")
    if DOC_MARK not in text:
        doc.write_text(text.rstrip("\n") + "\n" + DOC_TEXT, encoding="utf-8")


# ====================================================================== front-view preview (no game needed)
def preview(items):
    from PIL import Image, ImageDraw
    out = Path("/tmp/jotaro_preview")
    out.mkdir(parents=True, exist_ok=True)
    S = 16
    pivots = {"body": (0, 0), "head": (0, 0), "right_arm": (-5, 2), "left_arm": (5, 2),
              "right_leg": (-1.9, 12), "left_leg": (1.9, 12)}

    def render(ids, name, back=False):
        W, H = 26 * S, 40 * S
        img = Image.new("RGBA", (W, H), (96, 120, 100, 255))
        dr = ImageDraw.Draw(img)

        def X(v):
            return int(round((v + 13) * S))

        def Y(v):
            return int(round((v + 13) * S))
        skin, shirt, pant = (226, 178, 140), (120, 120, 130), (70, 70, 120)
        for (x0, y0, x1, y1, c) in ((-4, -8, 4, 0, skin), (-4, 0, 4, 12, shirt), (-8, 0, -4, 12, skin), (4, 0, 8, 12, skin),
                                    (-3.9, 12, 0, 24, pant), (0, 12, 3.9, 24, pant)):
            dr.rectangle([X(x0), Y(y0), X(x1), Y(y1)], fill=c)
        cubes = []
        for i in ids:
            m = json.loads((ASSETS / f"clothes_models/{i}.json").read_text())
            tex = Image.open(ASSETS / f"textures/clothes/{i}.png").convert("RGBA")
            for c in m["cubes"]:
                cubes.append((c, tex))

        def zf(ct):
            c = ct[0]
            return c["pos"][2] - c["grow"][2]
        cubes.sort(key=zf, reverse=True)
        for c, tex in cubes:
            px, py = pivots[c["bone"]]
            w, h, d = c["size"]
            g = c["grow"]
            x0 = px + c["pos"][0] - g[0]
            y0 = py + c["pos"][1] - g[1]
            x1 = px + c["pos"][0] + w + g[0]
            y1 = py + c["pos"][1] + h + g[1]
            u, v = c["uv"]
            face = tex.crop(((u + d) * PX, (v + d) * PX, (u + d + w) * PX, (v + d + h) * PX))
            if c.get("mirror"):
                face = face.transpose(Image.FLIP_LEFT_RIGHT)
            tw_, th_ = max(1, X(x1) - X(x0)), max(1, Y(y1) - Y(y0))
            face = face.resize((tw_, th_), Image.NEAREST)
            img.alpha_composite(face, (X(x0), Y(y0)))
        img.convert("RGB").save(out / f"{name}.png")

    def render_side(ids, name):
        W, H = 26 * S, 40 * S
        img = Image.new("RGBA", (W, H), (96, 120, 100, 255))
        dr = ImageDraw.Draw(img)

        def Z(v):
            return int(round((v + 13) * S))

        def Y(v):
            return int(round((v + 13) * S))
        skin, shirt, pant = (226, 178, 140), (120, 120, 130), (70, 70, 120)
        for (z0, y0, z1, y1, c) in ((-4, -8, 4, 0, skin), (-2, 0, 2, 12, shirt), (-2, 0, 2, 12, skin), (-2, 12, 2, 24, pant)):
            dr.rectangle([Z(z0), Y(y0), Z(z1), Y(y1)], fill=c)
        cubes = []
        for i in ids:
            m = json.loads((ASSETS / f"clothes_models/{i}.json").read_text())
            tex = Image.open(ASSETS / f"textures/clothes/{i}.png").convert("RGBA")
            for c in m["cubes"]:
                cubes.append((c, tex))
        cubes.sort(key=lambda ct: -(ct[0]["pos"][0] + ct[0]["size"][0] / 2 + (pivots[ct[0]["bone"]][0])), reverse=False)
        for c, tex in cubes:
            px, py = pivots[c["bone"]]
            if px > 0:
                continue                                  # the far (left) arm / leg is hidden behind the near one
            w, h, d = c["size"]
            g = c["grow"]
            z0 = c["pos"][2] - g[2]
            z1 = c["pos"][2] + d + g[2]
            y0 = py + c["pos"][1] - g[1]
            y1 = py + c["pos"][1] + h + g[1]
            u, v = c["uv"]
            ux = (u + d + w) if c.get("mirror") else u
            face = tex.crop((ux * PX, (v + d) * PX, (ux + d) * PX, (v + d + h) * PX))
            tw_, th_ = max(1, Z(z1) - Z(z0)), max(1, Y(y1) - Y(y0))
            img.alpha_composite(face.resize((tw_, th_), Image.NEAREST), (Z(z0), Y(y0)))
        img.convert("RGB").save(out / f"{name}.png")

    render_side(["jotaro_p4_cap", "jotaro_p4_coat", "jotaro_p4_pants", "boy_shoes"], "white_side")
    render_side(["jotaro_p3_cap", "jotaro_p3_coat", "jotaro_p3_pants", "jotaro_p3_chain", "boy_shoes"], "black_side")
    render(["jotaro_p4_cap", "jotaro_p4_coat", "jotaro_p4_pants", "boy_shoes"], "white_front")
    render(["jotaro_p3_cap", "jotaro_p3_coat", "jotaro_p3_pants", "jotaro_p3_chain", "boy_shoes"], "black_front")
    print("previews in", out)


if __name__ == "__main__":
    items = entries()
    for e in items:
        e["build"]()
        e["icon"]()
    register(items)
    print("generated:", ", ".join(e["id"] for e in items))
    if "--preview" in sys.argv:
        preview(items)
