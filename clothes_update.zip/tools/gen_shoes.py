#!/usr/bin/env python3
"""
Generates more shoes of the fitting room (category "shoes"), each in three colours:
  shoes_rain_*      rubber rain boots: yellow, red, pink with white dots
  shoes_ballet_*    ballet flats with a toe bow and ankle ribbons: pink, black, white
  shoes_platform_*  chunky platform boots with laces and buckles: black, white, pink
  shoes_bunny_*     fluffy bunny slippers with long ears and a little face: white, pink, gray
Models, 32x textures and 16x16 GUI icons, and (idempotently) the entries in clothes.json, the lang files,
ClothingCatalog.java and ClothingPrices.java. Same smooth painter as gen_dino.py.

Run from the project root:  python3 tools/gen_shoes.py
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from gen_dino import blk, build, grad, mix  # noqa: E402
from gen_accessories import Cube, Icon, shade  # noqa: E402
import gen_outerwear  # noqa: E402
from gen_outerwear import sd, tile_col, tw, weave  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent
WHITE = (252, 250, 246)
RUBBER = (236, 232, 224)
RUBBER_D = (170, 164, 156)
DOT = ["XX", "XX"]


def pair(cubes, n, c, dims, base, deco):
    """Right + mirrored left cube on the leg bones; c = (x offset, y, z) of the right cube's centre."""
    for side, sx in (("r", -1), ("l", 1)):
        bone = "right_leg" if side == "r" else "left_leg"
        cubes.append(Cube(f"{n}_{side}", bone, (sx * 0.1 + c[0], c[1], c[2]), dims, base, deco,
                          twin_of=tw(side, n), mirror=side == "l"))


# ====================================================================== RAIN BOOTS
RAIN = {
    "yellow": dict(base=(250, 206, 60), dark=(206, 152, 28), light=(255, 238, 140), sole=(60, 56, 64), dots=None,
                   ru="Жёлтые резиновые сапоги", en="Yellow Rain Boots", price=3999),
    "red": dict(base=(214, 52, 62), dark=(150, 28, 40), light=(250, 130, 130), sole=(56, 40, 40), dots=None,
                ru="Красные резиновые сапоги", en="Red Rain Boots", price=3999),
    "pink": dict(base=(248, 166, 198), dark=(212, 116, 154), light=(255, 220, 234), sole=(120, 72, 96), dots=WHITE,
                 ru="Розовые сапоги в горошек", en="Pink Polka Dot Rain Boots", price=4299),
}


def rain_shaft(p):
    def d(f, x, y, w, h):
        if f == "top":
            return p["dark"]
        if f == "bottom":
            return None
        col = p["base"]
        if p["dots"] and (x // 3 + y // 3) % 2 == 0 and x % 3 < 2 and y % 3 < 2 and y > 1:
            col = p["dots"]
        if f == "front" and x in (2, 3) and y > 3:
            return mix(col, p["light"], 0.6)
        if f in ("left", "right") and x in (w - 3, w - 4) and y > 2:
            return mix(col, p["light"], 0.5)
        if y >= h - 3:
            col = mix(col, p["dark"], 0.3)
        return col
    return d


def rain(name, p):
    cubes = []
    pair(cubes, "shaft", (0, 8.0, 0), (5.0, 7.6, 5.0), p["base"], rain_shaft(p))
    pair(cubes, "cuff", (0, 4.4, 0), (5.3, 1.2, 5.3), p["dark"],
         lambda f, x, y, w, h: None if not sd(f) else (p["light"] if y == 0 else p["dark"]))
    pair(cubes, "cap", (0, 10.8, -2.9), (4.8, 2.4, 2.8), p["base"], grad(p["base"], p["dark"]))
    pair(cubes, "sole", (0, 11.85, -0.9), (5.2, 0.7, 7.4), p["sole"],
         lambda f, x, y, w, h: None if f in ("top", "bottom") else shade(p["sole"], 1.2 if y == 0 else 1.0))
    return build(name, cubes)


def icon_rain(name, p):
    i = Icon()
    for x0 in (1, 9):
        blk(i, x0 + 1, 2, x0 + 4, 10, p["base"])
        i.rect(x0 + 1, 2, x0 + 4, 3, p["dark"]); i.rect(x0 + 1, 2, x0 + 4, 2, p["light"])
        i.rect(x0 + 1, 4, x0 + 1, 9, mix(p["base"], p["light"], 0.6))
        blk(i, x0, 10, x0 + 5, 12, p["base"])
        i.rect(x0, 13, x0 + 5, 13, p["sole"])
        if p["dots"]:
            for x, y in ((x0 + 3, 5), (x0 + 2, 7), (x0 + 4, 8)):
                i.put(x, y, p["dots"])
    i.save(name)


# ====================================================================== BALLET FLATS
BALLET = {
    "pink": dict(base=(248, 176, 204), dark=(214, 128, 164), light=(255, 224, 238), rib=(240, 130, 172), sole=(190, 120, 140),
                 ru="Розовые балетки с лентами", en="Pink Ballet Flats", price=3499),
    "black": dict(base=(46, 44, 56), dark=(26, 24, 34), light=(96, 94, 112), rib=(230, 150, 180), sole=(20, 18, 26),
                  ru="Чёрные балетки с бантиком", en="Black Ballet Flats", price=3499),
    "white": dict(base=(248, 246, 250), dark=(206, 204, 220), light=WHITE, rib=(180, 200, 240), sole=(190, 186, 200),
                  ru="Белые балетки с лентами", en="White Ballet Flats", price=3499),
}


def satin(p, ribbon=False):
    def d(f, x, y, w, h):
        if f == "bottom":
            return p["dark"]
        col = p["rib"] if ribbon else p["base"]
        if (x + y) % 7 == 0:
            col = mix(col, p["light"], 0.5)
        if f != "top" and y == h - 1:
            col = mix(col, p["dark"], 0.4)
        return col
    return d


def ballet(name, p):
    cubes = []
    pair(cubes, "vamp", (0, 11.0, -1.5), (4.6, 1.8, 5.6), p["base"], satin(p))
    pair(cubes, "heel", (0, 11.0, 1.7), (4.4, 1.8, 1.4), p["base"], satin(p))
    pair(cubes, "toe", (0, 11.0, -4.0), (4.2, 1.6, 1.0), p["base"], satin(p))
    pair(cubes, "sole", (0, 11.9, -1.0), (4.8, 0.5, 7.4), p["sole"],
         lambda f, x, y, w, h: None if f in ("top", "bottom") else p["sole"])
    pair(cubes, "bow", (0, 10.0, -3.2), (2.0, 0.8, 1.0), p["rib"], None)
    pair(cubes, "bow_knot", (0, 10.0, -3.2), (0.7, 0.9, 1.1), shade(p["rib"], 0.8), None)
    pair(cubes, "ribbon1", (0, 9.3, 0), (4.3, 0.6, 4.3), p["rib"], satin(p, True))
    pair(cubes, "ribbon2", (0, 7.9, 0), (4.3, 0.6, 4.3), p["rib"], satin(p, True))
    return build(name, cubes)


def icon_ballet(name, p):
    i = Icon()
    for x0 in (1, 9):
        i.rect(x0 + 1, 3, x0 + 1, 3, p["rib"]); i.rect(x0 + 4, 5, x0 + 4, 5, p["rib"])
        for y in (3, 5, 7):
            i.rect(x0 + 1, y, x0 + 4, y, p["rib"])
        for y in (4, 6):
            i.put(x0 + 2 if y == 4 else x0 + 3, y, shade(p["rib"], 0.8))
        blk(i, x0, 9, x0 + 5, 12, p["base"])
        i.rect(x0, 9, x0 + 5, 9, p["light"])
        i.rect(x0 + 2, 10, x0 + 3, 10, p["rib"])
        i.rect(x0, 13, x0 + 5, 13, p["sole"])
    i.save(name)


# ====================================================================== PLATFORM BOOTS
PLATFORM = {
    "black": dict(base=(40, 38, 48), dark=(22, 20, 28), light=(96, 94, 112), lace=WHITE, sole=(236, 232, 224), metal=(206, 212, 224),
                  ru="Чёрные ботинки на платформе", en="Black Platform Boots", price=5499),
    "white": dict(base=(246, 244, 250), dark=(196, 194, 214), light=WHITE, lace=(120, 130, 190), sole=(60, 58, 70), metal=(206, 212, 224),
                  ru="Белые ботинки на платформе", en="White Platform Boots", price=5499),
    "pink": dict(base=(248, 156, 196), dark=(206, 104, 148), light=(255, 214, 232), lace=WHITE, sole=(255, 244, 248), metal=(240, 196, 84),
                 ru="Розовые ботинки на платформе", en="Pink Platform Boots", price=5499),
}


def platform_shaft(p):
    def d(f, x, y, w, h):
        if f == "top":
            return p["dark"]
        if f == "bottom":
            return None
        col = weave(p["base"], p["light"], x, y)
        if y <= 1:
            return mix(col, p["dark"], 0.5)
        if f == "front":
            if y in (3, 5, 7, 9) and 2 <= x <= w - 3:
                return p["lace"]
            if y in (3, 5, 7, 9) and x in (1, w - 2):
                return p["metal"]
        if f in ("left", "right") and 2 <= x <= 5 and 7 <= y <= 9:
            return p["metal"] if y == 8 else p["dark"]
        return col
    return d


def platform(name, p):
    cubes = []
    pair(cubes, "shaft", (0, 7.4, 0), (5.0, 6.4, 5.0), p["base"], platform_shaft(p))
    pair(cubes, "cap", (0, 9.7, -3.0), (4.8, 2.4, 3.0), p["base"], grad(p["base"], p["dark"]))
    pair(cubes, "plat", (0, 11.15, -0.8), (5.4, 1.9, 7.6), p["sole"],
         lambda f, x, y, w, h: None if f in ("top", "bottom") else (mix(p["sole"], p["base"], 0.35) if y == h - 1 else p["sole"]))
    pair(cubes, "strap", (0, 8.9, 0), (5.2, 0.8, 5.2), p["dark"],
         lambda f, x, y, w, h: None if not sd(f) else (p["metal"] if f == "front" and w // 2 - 1 <= x <= w // 2 and y < 2 else p["dark"]))
    return build(name, cubes)


def icon_platform(name, p):
    i = Icon()
    for x0 in (1, 9):
        blk(i, x0 + 1, 3, x0 + 4, 9, p["base"])
        i.rect(x0 + 1, 3, x0 + 4, 3, p["dark"])
        for y in (5, 7):
            i.rect(x0 + 2, y, x0 + 3, y, p["lace"])
        i.put(x0 + 1, 8, p["metal"])
        blk(i, x0, 9, x0 + 5, 10, p["base"])
        blk(i, x0, 11, x0 + 5, 13, p["sole"])
        i.rect(x0, 13, x0 + 5, 13, shade(p["sole"], 0.8))
    i.save(name)


# ====================================================================== BUNNY SLIPPERS
BUNNY = {
    "white": dict(base=(250, 248, 250), dark=(214, 208, 220), ear_in=(250, 176, 204), nose=(240, 120, 160), sole=(240, 160, 190),
                  ru="Белые тапочки-зайчики", en="White Bunny Slippers", price=2999),
    "pink": dict(base=(250, 184, 208), dark=(214, 136, 164), ear_in=(255, 236, 244), nose=(200, 60, 100), sole=(255, 240, 246),
                 ru="Розовые тапочки-зайчики", en="Pink Bunny Slippers", price=2999),
    "gray": dict(base=(184, 188, 202), dark=(140, 144, 162), ear_in=(250, 190, 208), nose=(240, 120, 160), sole=(250, 248, 250),
                 ru="Серые тапочки-зайчики", en="Gray Bunny Slippers", price=2999),
}


def fluff(p):
    def d(f, x, y, w, h):
        if f == "bottom":
            return p["dark"]
        col = mix(p["base"], p["dark"], 0.28) if (x * 5 + y * 3) % 7 == 0 else p["base"]
        if (x * 3 + y * 7) % 11 == 0:
            col = mix(col, WHITE, 0.4)
        if f != "top" and y == h - 1:
            col = mix(col, p["dark"], 0.3)
        return col
    return d


def bunny(name, p):
    def face(f, x, y, w, h):
        if f == "front":
            if y == 1 and x in (2, 3, w - 4, w - 3):
                return (50, 36, 56)
            if y == 2 and w // 2 - 1 <= x <= w // 2:
                return p["nose"]
        return fluff(p)(f, x, y, w, h)

    def ear(f, x, y, w, h):
        if f in ("front",) and 1 <= x <= w - 2 and 1 <= y <= h - 2:
            return p["ear_in"]
        return fluff(p)(f, x, y, w, h)
    cubes = []
    pair(cubes, "body", (0, 10.7, -0.9), (4.9, 2.6, 6.6), p["base"], fluff(p))
    pair(cubes, "toe", (0, 10.9, -3.7), (4.5, 2.2, 2.4), p["base"], face)
    pair(cubes, "ring", (0, 9.5, 0), (4.8, 1.0, 4.8), p["base"], fluff(p))
    pair(cubes, "sole", (0, 11.95, -0.9), (5.0, 0.5, 7.0), p["sole"],
         lambda f, x, y, w, h: None if f in ("top", "bottom") else p["sole"])
    for side, sx in (("r", -1), ("l", 1)):
        bone = "right_leg" if side == "r" else "left_leg"
        for k, dx in enumerate((-1.0, 1.0)):
            c = (sx * 0.1 + dx, 7.6, -2.9)
            cubes.append(Cube(f"ear{k}_{side}", bone, c, (0.9, 3.8, 1.3), p["base"], ear,
                              twin_of=tw(side, f"ear{k}"), mirror=side == "l"))
    return build(name, cubes)


def icon_bunny(name, p):
    i = Icon()
    for x0 in (1, 9):
        for dx in (1, 4):
            i.rect(x0 + dx, 2, x0 + dx, 7, p["base"])
            i.rect(x0 + dx, 3, x0 + dx, 6, p["ear_in"])
            i.put(x0 + dx, 2, p["base"])
        blk(i, x0, 8, x0 + 5, 12, p["base"])
        for yy in (9, 11):
            for xx in range(x0 + 1, x0 + 5):
                if (xx + yy) % 2:
                    i.put(xx, yy, mix(p["base"], WHITE, 0.5))
        i.put(x0 + 1, 10, (50, 36, 56)); i.put(x0 + 4, 10, (50, 36, 56)); i.put(x0 + 2, 11, p["nose"]); i.put(x0 + 3, 11, p["nose"])
        i.rect(x0, 13, x0 + 5, 13, p["sole"])
    i.save(name)


# ====================================================================== run
SETS = [("shoes_rain_", RAIN, rain, icon_rain), ("shoes_ballet_", BALLET, ballet, icon_ballet),
        ("shoes_platform_", PLATFORM, platform, icon_platform), ("shoes_bunny_", BUNNY, bunny, icon_bunny)]

DOC_MARK = "## Rain boots, ballet flats, platform boots and bunny slippers"
DOC_TEXT = """
## Rain boots, ballet flats, platform boots and bunny slippers
`python3 tools/gen_shoes.py` regenerates twelve shoes (models, textures, icons) and registers them (category `shoes`).
All cubes sit on the leg bones; the foot is the same as in `casual_kedy_*` (sole at y = 11.85 to 12.2, toe towards -z).
- `shoes_rain_yellow/red/pink`: tall glossy rubber boots (shaft + folded cuff + toe cap + dark sole), the pink ones have white dots.
- `shoes_ballet_pink/black/white`: low satin flats made of a vamp, a heel and a toe piece, a bow on the toe and two ribbons round the ankle.
- `shoes_platform_black/white/pink`: ankle boots with laces, metal eyelets, an ankle strap and a thick 1.9 unit platform sole.
- `shoes_bunny_white/pink/gray`: fluffy slippers (dithered fur texture), a face with eyes and a nose on the toe and two ears standing
  on the toe (`ear0` / `ear1`).
"""

if __name__ == "__main__":
    gen_outerwear.CATEGORY["shoes"] = "SHOES"
    items = []
    for prefix, palettes, model_fn, icon_fn in SETS:
        for key, p in palettes.items():
            name = prefix + key
            model_fn(name, p)
            icon_fn(name, p)
            items.append(dict(id=name, category="shoes", ru=p["ru"], en=p["en"], price=p["price"]))
    gen_outerwear.register(items)
    doc = ROOT / "docs/clothes-models.md"
    text = doc.read_text(encoding="utf-8")
    if DOC_MARK not in text:
        doc.write_text(text.rstrip("\n") + "\n" + DOC_TEXT, encoding="utf-8")
    print("shoes generated:", len(items))
