#!/usr/bin/env python3
"""
Generates four more kinds of hats of the fitting room (all year round), each in three colours:
  hat_beanie_*   knitted beanie: ribbed folded cuff, slouchy crown; gray, mustard (pom-pom), pink (striped, pom-pom)
  hat_beret_*    french beret: flat tilted disc with a little stem; red, black, cream
  hat_panama_*   woven straw hat: sloped brim, ribbon band, pinched crown; natural, white, pink
  hat_cowboy_*   western hat: wide brim curled up at the sides, creased crown, band with a concho; brown, black, cream
Models, 32x textures and 16x16 GUI icons, and (idempotently) the entries in clothes.json, the lang files,
ClothingCatalog.java and ClothingPrices.java. Same smooth painter as gen_dino.py.

Run from the project root:  python3 tools/gen_hats_more.py
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from gen_dino import blk, build, mix  # noqa: E402
from gen_accessories import Cube, Icon, shade  # noqa: E402
from gen_hats import register  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent
WHITE = (250, 248, 242)
SILVER = (206, 212, 224)
TURQ = (70, 196, 190)


def sd(f):
    return f not in ("top", "bottom")


# ====================================================================== BEANIES
BEANIES = {
    "gray": dict(base=(150, 154, 166), dark=(108, 112, 126), light=(192, 196, 208), cuff=(124, 128, 142), pom=None, stripe=None,
                 ru="Серая шапка-бини", en="Gray Beanie", price=1999),
    "mustard": dict(base=(236, 176, 56), dark=(196, 134, 30), light=(252, 214, 110), cuff=(214, 154, 40), pom=(255, 248, 236), stripe=None,
                    ru="Горчичная бини с помпоном", en="Mustard Pom-pom Beanie", price=2299),
    "pink": dict(base=(248, 172, 198), dark=(214, 124, 158), light=(255, 214, 230), cuff=(236, 148, 182), pom=(255, 246, 250),
                 stripe=(255, 246, 250), ru="Розовая полосатая бини", en="Pink Striped Beanie", price=2299),
}


def knit(p, ribs=False):
    def d(f, x, y, w, h):
        if not sd(f):
            return mix(p["base"], p["light"], 0.25) if f == "top" else p["dark"]
        if ribs:
            col = p["cuff"] if x % 4 in (0, 1) else mix(p["cuff"], p["dark"], 0.45)
            return mix(col, p["dark"], 0.5) if y == h - 1 else col
        col = mix(p["base"], p["light"], 0.22) if (x + y // 2) % 3 == 0 else p["base"]
        if p["stripe"] and (y // 3) % 3 == 1:
            col = p["stripe"] if (x + y // 2) % 3 else mix(p["stripe"], p["light"], 0.4)
        return col
    return d


def beanie(name, p):
    cubes = [Cube("cuff", "head", (0, -7.4, 0), (9.9, 2.6, 9.9), p["cuff"], knit(p, True)),
             Cube("crown", "head", (0, -10.0, 0), (9.2, 3.2, 9.2), p["base"], knit(p)),
             Cube("top", "head", (0, -12.2, 0), (7.6, 1.6, 7.6), p["base"], knit(p))]
    if p["pom"]:
        def fur(f, x, y, w, h):
            return mix(p["pom"], p["dark"], 0.18) if (x * 5 + y * 3) % 7 == 0 else p["pom"]
        cubes.append(Cube("pom", "head", (0, -14.6, 0), (3.6, 3.6, 3.6), p["pom"], fur))
    else:
        cubes.append(Cube("knob", "head", (0, -13.3, 0), (2.0, 0.8, 2.0), p["dark"], None))
    return build(name, cubes)


def icon_beanie(name, p):
    i = Icon()
    if p["pom"]:
        blk(i, 6, 1, 9, 4, p["pom"])
    for y, x0, x1 in ((4, 5, 10), (5, 4, 11), (6, 3, 12), (7, 3, 12)):
        for x in range(x0, x1 + 1):
            col = p["light"] if x == x0 else (p["dark"] if x == x1 else p["base"])
            if p["stripe"] and y in (5,):
                col = p["stripe"]
            i.put(x, y, col)
    for y in (8, 9, 10, 11):
        for x in range(2, 14):
            col = p["cuff"] if x % 3 else mix(p["cuff"], p["dark"], 0.45)
            if y == 11:
                col = p["dark"]
            i.put(x, y, col)
    i.save(name)


# ====================================================================== BERETS
BERETS = {
    "red": dict(base=(196, 40, 58), dark=(138, 24, 40), light=(232, 90, 104), ru="Красный берет", en="Red Beret", price=2499),
    "black": dict(base=(48, 46, 58), dark=(26, 24, 34), light=(96, 94, 112), ru="Чёрный берет", en="Black Beret", price=2499),
    "cream": dict(base=(236, 224, 198), dark=(194, 176, 142), light=(252, 248, 234), ru="Кремовый берет", en="Cream Beret", price=2499),
}


def beret(name, p):
    def wool(f, x, y, w, h):
        if f == "top":
            return mix(p["base"], p["light"], 0.3)
        if f == "bottom":
            return p["dark"]
        return mix(p["base"], p["light"], 0.16) if (x * 3 + y * 2) % 7 == 0 else p["base"]
    band = lambda f, x, y, w, h: None if not sd(f) else (mix(p["dark"], p["base"], 0.3) if y == h - 1 else p["dark"])
    cubes = [Cube("band", "head", (0, -7.3, 0), (9.6, 1.4, 9.6), p["dark"], band)]
    c = (0.9, -8.6, 0.0)
    tilt = dict(pivot=(0, -7.6, 0), rot=(0, 0, -9))
    for n, (cy, w, h) in enumerate(((-8.3, 11.6, 1.2), (-9.4, 12.0, 1.2), (-10.4, 11.0, 1.0), (-11.1, 9.2, 0.8))):
        cubes.append(Cube(f"disc{n}", "head", (0.9, cy, 0.4), (w, h, w - 0.4), p["base"], wool, **tilt))
    cubes.append(Cube("stem", "head", (0.9, -11.9, 0.4), (1.0, 1.0, 1.0), p["dark"], None, **tilt))
    return build(name, cubes)


def icon_beret(name, p):
    i = Icon()
    for y, x0, x1 in ((4, 5, 11), (5, 3, 13), (6, 1, 14), (7, 1, 15), (8, 2, 15), (9, 3, 14), (10, 5, 12)):
        for x in range(x0, x1 + 1):
            col = p["base"]
            if y <= 5:
                col = mix(p["base"], p["light"], 0.35)
            if y >= 9:
                col = p["dark"]
            if x == x0:
                col = p["light"]
            i.put(x, y, col)
    i.rect(8, 2, 9, 3, p["dark"])
    i.rect(5, 11, 11, 12, p["dark"])
    i.rect(5, 11, 11, 11, mix(p["dark"], p["base"], 0.3))
    i.save(name)


# ====================================================================== PANAMA HATS
PANAMAS = {
    "natural": dict(base=(232, 200, 132), dark=(190, 156, 88), light=(250, 228, 170), ribbon=(40, 38, 48), ru="Панама из соломы", en="Straw Panama Hat", price=2699),
    "white": dict(base=(246, 242, 228), dark=(206, 198, 176), light=(255, 254, 246), ribbon=(52, 84, 150), ru="Белая панама с синей лентой", en="White Panama Hat", price=2699),
    "pink": dict(base=(248, 188, 202), dark=(212, 140, 160), light=(255, 224, 232), ribbon=(255, 250, 250), ru="Розовая панама", en="Pink Panama Hat", price=2699),
}


def straw(p):
    def d(f, x, y, w, h):
        col = p["base"]
        if (x // 2 + y // 2) % 2 == 0:
            col = mix(col, p["light"], 0.35)
        elif (x + y) % 5 == 0:
            col = mix(col, p["dark"], 0.3)
        if f == "bottom":
            return mix(col, p["dark"], 0.5)
        if f != "top" and y == h - 1:
            return mix(col, p["dark"], 0.35)
        return col
    return d


def panama(name, p):
    ribbon = lambda f, x, y, w, h: None if not sd(f) else (mix(p["ribbon"], WHITE, 0.25) if y == 0 else p["ribbon"])
    cubes = [Cube("brim", "head", (0, -7.1, 0), (13.4, 0.9, 13.4), p["base"], straw(p)),
             Cube("brim_edge", "head", (0, -7.5, 0), (11.0, 0.8, 11.0), p["base"], straw(p)),
             Cube("band", "head", (0, -8.5, 0), (10.0, 1.6, 10.0), p["ribbon"], ribbon),
             Cube("crown", "head", (0, -10.5, 0), (9.6, 2.6, 9.6), p["base"], straw(p)),
             Cube("dent", "head", (0, -12.2, 0), (7.4, 1.2, 7.4), p["base"],
                  lambda f, x, y, w, h: (mix(p["dark"], p["base"], 0.3) if f == "top" and x in (w // 2 - 1, w // 2) else straw(p)(f, x, y, w, h)))]
    cubes.append(Cube("bow", "head", (-3.2, -8.4, -5.15), (2.6, 1.8, 0.7), p["ribbon"], None))
    return build(name, cubes)


def icon_panama(name, p):
    i = Icon()
    for y, x0, x1 in ((3, 5, 10), (4, 4, 11), (5, 4, 11), (6, 4, 11), (7, 4, 11), (8, 4, 11)):
        for x in range(x0, x1 + 1):
            col = p["base"] if (x + y) % 3 else p["light"]
            if x == x1:
                col = p["dark"]
            i.put(x, y, col)
    i.rect(4, 8, 11, 9, p["ribbon"])
    i.rect(4, 8, 11, 8, mix(p["ribbon"], WHITE, 0.25))
    for y, x0, x1 in ((10, 1, 14), (11, 0, 15), (12, 1, 14)):
        for x in range(x0, x1 + 1):
            col = p["base"] if (x + y) % 3 else p["light"]
            if y == 12:
                col = p["dark"]
            i.put(x, y, col)
    i.save(name)


# ====================================================================== COWBOY HATS
COWBOYS = {
    "brown": dict(base=(150, 98, 56), dark=(104, 64, 34), light=(186, 134, 86), band=(70, 42, 26), stone=SILVER,
                  ru="Коричневая ковбойская шляпа", en="Brown Cowboy Hat", price=3299),
    "black": dict(base=(52, 50, 58), dark=(28, 26, 34), light=(94, 92, 106), band=(150, 36, 44), stone=SILVER,
                  ru="Чёрная ковбойская шляпа", en="Black Cowboy Hat", price=3299),
    "cream": dict(base=(234, 216, 178), dark=(190, 166, 124), light=(252, 242, 214), band=(120, 78, 46), stone=TURQ,
                  ru="Кремовая ковбойская шляпа", en="Cream Cowboy Hat", price=3299),
}


def felt(p):
    def d(f, x, y, w, h):
        col = mix(p["base"], p["light"], 0.14) if (x * 7 + y * 3) % 9 == 0 else p["base"]
        if f == "bottom":
            return mix(p["base"], p["dark"], 0.6)
        if f != "top" and y == h - 1:
            return mix(col, p["dark"], 0.4)
        return col
    return d


def cowboy(name, p):
    band = lambda f, x, y, w, h: None if not sd(f) else (mix(p["band"], p["light"], 0.3) if y == 0 else
                                                          (mix(p["band"], WHITE, 0.4) if y == h - 1 and x % 3 == 0 else p["band"]))
    cubes = [Cube("brim", "head", (0, -7.1, -0.3), (12.4, 0.8, 14.6), p["base"], felt(p)),
             Cube("band", "head", (0, -8.4, 0), (10.0, 1.8, 10.0), p["band"], band),
             Cube("crown", "head", (0, -11.0, 0), (9.4, 3.8, 9.4), p["base"], felt(p)),
             Cube("top_r", "head", (-2.4, -13.4, 0), (4.0, 1.4, 8.4), p["base"], felt(p)),
             Cube("top_l", "head", (2.4, -13.4, 0), (4.0, 1.4, 8.4), p["base"], felt(p)),
             Cube("crease", "head", (0, -12.8, 0), (1.6, 1.0, 8.2), p["dark"], None),
             Cube("front_pinch", "head", (0, -11.6, -4.85), (1.4, 3.2, 0.5), p["dark"], None),
             Cube("concho", "head", (0, -8.4, -5.15), (1.8, 1.4, 0.5), p["stone"],
                  lambda f, x, y, w, h: shade(p["stone"], 1.18) if (x, y) == (0, 0) else None)]
    for tag, sx in (("r", -1), ("l", 1)):
        pivot = (sx * 6.1, -7.1, -0.3)
        cubes.append(Cube(f"curl_{tag}", "head", (sx * 7.6, -7.1, -0.3), (3.0, 0.8, 14.6), p["base"], felt(p),
                          pivot=pivot, rot=(0, 0, 24 * sx * -1)))
    return build(name, cubes)


def icon_cowboy(name, p):
    i = Icon()
    for y, x0, x1 in ((2, 5, 6), (2, 9, 10), (3, 4, 11), (4, 4, 11), (5, 4, 11), (6, 4, 11), (7, 4, 11)):
        for x in range(x0, x1 + 1):
            col = p["base"] if x < x1 else p["dark"]
            if y == 2 or y == 3:
                col = p["light"] if x < x1 else p["base"]
            i.put(x, y, col)
    i.rect(7, 2, 8, 4, p["dark"])
    i.rect(4, 8, 11, 9, p["band"])
    i.put(7, 8, p["stone"]); i.put(8, 8, p["stone"])
    # brim: a smile, curled up at both ends
    for x, y in ((0, 8), (1, 9), (1, 10), (2, 10), (2, 11)):
        i.rect(x, y, x, y, p["base"]) if x < 2 else None
    for y in (10, 11, 12):
        for x in range(2, 14):
            if y == 10 and not (3 <= x <= 12):
                continue
            col = p["base"] if y < 12 else p["dark"]
            i.put(x, y, col)
    for x, y in ((0, 7), (0, 8), (1, 8), (1, 9), (2, 9), (15, 7), (15, 8), (14, 8), (14, 9), (13, 9)):
        i.put(x, y, p["base"] if y < 9 else mix(p["base"], p["dark"], 0.4))
    for x, y in ((1, 10), (14, 10), (2, 11), (13, 11)):
        i.put(x, y, mix(p["base"], p["dark"], 0.4))
    i.save(name)


# ====================================================================== run
SETS = [("hat_beanie_", BEANIES, beanie, icon_beanie), ("hat_beret_", BERETS, beret, icon_beret),
        ("hat_panama_", PANAMAS, panama, icon_panama), ("hat_cowboy_", COWBOYS, cowboy, icon_cowboy)]

DOC_MARK = "## Beanies, berets, panamas and cowboy hats"
DOC_TEXT = """
## Beanies, berets, panamas and cowboy hats
`python3 tools/gen_hats_more.py` regenerates twelve all-year hats (models, textures, icons) and registers them in `clothes.json`,
the lang files, `ClothingCatalog` and `ClothingPrices` through the same `register()` as `gen_hats.py`.
- `hat_beanie_gray/mustard/pink`: ribbed folded cuff, slouchy knit crown; the mustard and pink ones have a fluffy pom-pom, the pink one is striped.
- `hat_beret_red/black/cream`: flat disc made of four layers, tilted 9 degrees with `rot`, with a stem on top and a darker lining band.
- `hat_panama_natural/white/pink`: woven straw texture (checker of 2x2 pixels), two-step brim, ribbon with a bow, pinched crown with a groove.
- `hat_cowboy_brown/black/cream`: wide brim whose two side flaps are turned up 24 degrees, creased crown (two halves and a groove),
  pinched front, band with a silver or turquoise concho.
"""

if __name__ == "__main__":
    entries = []
    for prefix, palettes, model_fn, icon_fn in SETS:
        for key, p in palettes.items():
            name = prefix + key
            model_fn(name, p)
            icon_fn(name, p)
            entries.append(dict(id=name, ru=p["ru"], en=p["en"], price=p["price"]))
    register(entries)
    doc = ROOT / "docs/clothes-models.md"
    text = doc.read_text(encoding="utf-8")
    if DOC_MARK not in text:
        doc.write_text(text.rstrip("\n") + "\n" + DOC_TEXT, encoding="utf-8")
    print("hats generated:", len(entries))
