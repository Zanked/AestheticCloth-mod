# Clothes models

Every garment is a JSON file in `assets/fittingroom/clothes_models/<id>.json` plus a texture.
Garments are made of cubes attached to the player's bones. All numbers are in Minecraft model units
(1 unit = 1/16 block). Textures are 32x: the PNG is twice as big as `texture_size`
(`texture_size` is the layout in units, the PNG has 2 pixels per unit).

```json
{
  "texture": "fittingroom:textures/clothes/santa_hat.png",
  "texture_size": [64, 26],
  "cubes": [
    { "name": "band", "bone": "head",
      "pos": [-4.0, -7.0, -4.0],     // corner of the cube, relative to the bone's pivot (vanilla model space)
      "size": [8, 2, 8],             // integers: the texture layout is a normal box unwrap
      "uv": [0, 0],                  // top-left of the unwrap in `texture_size` units
      "grow": [0.95, 0.95, 0.95],    // makes the cube bigger on every side without changing the unwrap
      "mirror": false,               // true for the left twin of a right-hand cube (same uv)
      "pivot": [0, 0, 0], "rot": [0, 0, 0]   // optional: rotation in degrees around `pivot`
    }
  ]
}
```
Bones: `head`, `body`, `right_arm`, `left_arm`, `right_leg`, `left_leg`. The format is the same as a
Blockbench "Modded Entity" (Java) model, so a model made there can be converted to it.
Reload with F3+T while the game is running.

`gen_santa3d.py` in the project builder writes these files; the cubes are described there with
simpler coordinates (player's right = +x, up = +y, front = -z).

## Slim (Alex) arms
Models are authored for the 4-wide Steve arm. For players with slim arms the loader automatically squeezes
every cube on `right_arm` / `left_arm` (without `rot`) to 3/4 of its width in X and centres it on the 3-wide arm,
so the same JSON and texture work for both skin types. Nothing to do in the model files.

## Seasonal clothes
`ClothingCatalog` can limit a garment to a period of the year (`Item.seasonFrom` / `seasonTo`).
The Santa set is only available from December 15th to January 14th: outside of it the clothes are not shown
in the fitting room, cannot be put on (the server checks the date too) and are not drawn on players
(what a player saved stays and comes back with the next season).
To test, start the game with `-Dfittingroom.date=2026-12-31`.

## Cat costume
`cat_ears` (hat), `cat_sweater` (top), `cat_pants` (bottom, with a tail made of 4 rotated segments on the body bone)
and `cat_paws` (shoes). Textures are 2 px per unit like all the others.

## Dino kigurumi
`dino_hood` (hat: green hood with a snout, teeth hanging from it, two angry eyes, red lining and a spiky crest),
`dino_top` (onesie top with a light belly panel with buttons, red collar, ribbed cuffs and plates down the back),
`dino_pants` (onesie bottom with a long tail of five segments, bent down, with spikes on top) and `dino_slippers`
(green boots with ribbed rims and three claws on each foot). Teeth are drawn as transparent pixels between the
white triangles, so they really are zigzag. `python3 tools/gen_dino.py` regenerates the models, textures and icons.
The set comes in two colours: green (`dino_*`) and blue (`dino_blue_*`, cream-yellow spikes, white-blue belly);
the palettes are at the top of the script, so another colour is one more entry in `PALETTES` plus its items in
`ClothingCatalog`, `clothes.json` and the lang files.
Unlike the older generator this one paints soft shading and clean details instead of per-pixel noise.

## Japanese school uniform
`school_bow` (hat: red hair ribbon on the side of the head), `school_top` (sailor blouse: white, short sleeves with a
navy cuff and a white stripe, navy sailor collar with two white stripes, red ribbon bow), `school_skirt` (bottom: navy
plaid pleated skirt in two flared tiers; the pleat creases are painted into the texture), `school_socks` (shoes: white
knee socks with a navy band and black loafers) and `school_bag` (accessory: leather satchel carried in the right hand,
it hangs from a handle loop and swings with the arm). `python3 tools/gen_school.py` regenerates the set; it reuses the
smooth painter of `gen_dino.py`.

The school uniform also comes in black (`school_black_*`: black blouse and plaid skirt with the white collar stripes,
black knee socks, brown loafers, black satchel with a silver clasp). The palettes are at the top of `gen_school.py`.

## Boys' school uniform (gakuran)
`boy_cap` (hat: black peaked cap with a gold emblem on the band and a tilted visor), `boy_gakuran` (top: black
jacket with five gold buttons, a white collar tab, gold collar badges, pocket flaps and long sleeves with cuffs),
`boy_trousers` (bottom: black trousers with a pressed crease and a belt with a silver buckle) and `boy_shoes` (shoes:
black laced shoes). The satchel of the girls' set (`school_black_bag`) goes with it. `python3 tools/gen_school_boy.py`
regenerates the set.

## Plush backpacks
`plush_cat`, `plush_dino` and `plush_bear` (accessories): a soft toy sits on the back and looks at whoever stands
behind the player. Each one has a head with glossy eyes and blush, a body with a light belly oval, little arms, legs
with paw pads and shoulder straps laid out like the normal backpack. Cat: ears with a pink inside, a ringed tail and a
collar with a bell. Dino: a snout, three crest spikes and a short tail. Bear: round ears, a muzzle and a red bow.
`python3 tools/gen_plush.py` regenerates all three; to add another animal, add an entry to `SPECIES` and its ears/tail.

## Balloons and gloves (accessories, several colours)
`balloon_<colour>` (red, pink, blue, yellow, green, purple): a glossy balloon built from layered cubes (each layer
twice, turned 45 degrees, so it looks round) on a thin string held in the right hand; it floats beside the head and
swings with the arm. `balloon_bunch_rainbow` and `balloon_bunch_pastel` hold three balloons on three strings.
`gloves_<colour>` (white, black, red, pink, blue, yellow, green, purple): short gloves with finger lines and a ribbed
cuff on both hands. Colours are the `COLOURS` dict of `python3 tools/gen_balloons_gloves.py`; a new colour is one
entry there plus the items in `ClothingCatalog`, `clothes.json` and the lang files.

## Accessories
The "Accessories" tab holds `casual_backpack` (straps + bag on the back), `punk_cuffs` (leather wristbands with
spikes on both forearms; the top/bottom faces of the ring are transparent so the arm goes through it) and
`santa_sack` (a seasonal gift sack with a rope strap, New Year season like the rest of the Santa set).
Only one accessory can be worn at a time. They are drawn above the tops and below the hats.
Note for arms: cubes on `right_arm` / `left_arm` without `rot` are re-centred on the arm for slim skins, so all
arm accessories must sit in the middle of the arm (that is why the cuff spikes are only on the front and back).
`python3 tools/gen_accessories.py` regenerates the models, textures and icons of these three.

### Glasses
`glasses_round`, `glasses_sun`, `glasses_heart`, `glasses_3d` and `glasses_pixel` are cubes on the `head` bone:
lenses at x = +-2, y = -3, in front of the face (z about -4.7, outside the skin's hat layer), plus a bridge and
two arms along the sides of the head. Clear parts (the middle of the round frames, the outside of the hearts) are
transparent pixels in the texture. They live in the Accessories tab, so they replace the backpack/cuffs/sack
(one accessory at a time). `tools/gen_accessories.py` regenerates them too.

