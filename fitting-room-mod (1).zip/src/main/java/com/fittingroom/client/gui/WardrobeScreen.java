package com.fittingroom.client.gui;

import com.fittingroom.network.SetOutfitPayload;
import com.fittingroom.wardrobe.Category;
import com.fittingroom.wardrobe.ClientWardrobeStore;
import com.fittingroom.wardrobe.ClothingCatalog;
import dev.aestheticjobs.economy.Money;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.ChatFormatting;
import net.minecraft.sounds.SoundEvents;
import net.neoforged.neoforge.network.PacketDistributor;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * The fitting room screen. All art comes from textures/gui/fitting_room.png, see {@link GuiLayout}.
 * Picking a garment shows it on the player immediately (preview); "Wear" sends it to the server,
 * closing the screen any other way throws the preview away.
 * <p>
 * Clothes cost money: the ones you do not own yet are dimmed and marked with "$", the tooltip shows the price,
 * and when the outfit contains something unpaid the button says "Buy" and charges your bank account (the server
 * does the payment, see {@code Shop}).
 */
public class WardrobeScreen extends Screen {
    private static final int TEXT = 0xFF5E3E36;
    private static final int TEXT_DISABLED = 0xFFA09482;
    private static final int PRICE_GOLD = 0xFFFFD34D;
    private static final int PRICE_RED = 0xFFFF6B6B;
    private static final int[] TAB_ICON_U = {
            GuiLayout.ICON_HAT_U, GuiLayout.ICON_SHIRT_U, GuiLayout.ICON_PANTS_U,
            GuiLayout.ICON_SHOES_U, GuiLayout.ICON_ACCESSORY_U};
    private static final Map<String, ResourceLocation> ICONS = new HashMap<>();

    private final AbstractClientPlayer player;
    private final List<String> original;
    /** slot -> id of the worn item (one per slot; the Accessories tab has two slots: accessory and neck). */
    private final Map<String, String> selection = new LinkedHashMap<>();

    private Category tab = Category.HAT;
    private int scrollRow = 0;
    private float rotation = 20.0F;
    private int heldRotate = 0;
    private boolean applied = false;
    private int left;
    private int top;

    public WardrobeScreen(AbstractClientPlayer player) {
        super(Component.translatable("gui.fittingroom.title"));
        this.player = player;
        this.original = List.copyOf(ClientWardrobeStore.get(player.getUUID()));
        for (String id : original) {
            ClothingCatalog.Item item = ClothingCatalog.byId(id);
            if (item != null && item.isAvailable()) {
                selection.put(item.slot(), item.id());
            }
        }
    }

    @Override
    protected void init() {
        this.left = (this.width - GuiLayout.WIDTH) / 2;
        this.top = (this.height - GuiLayout.HEIGHT) / 2;
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    // ------------------------------------------------------------------ state

    private List<String> currentList() {
        return new ArrayList<>(selection.values());
    }

    private void pushPreview() {
        ClientWardrobeStore.set(player.getUUID(), currentList());
    }

    private boolean hasTabSelection() {
        for (String id : selection.values()) {
            ClothingCatalog.Item item = ClothingCatalog.byId(id);
            if (item != null && item.category() == tab) {
                return true;
            }
        }
        return false;
    }

    /** "Remove" takes off everything worn from the current tab. */
    private void clearTab() {
        selection.values().removeIf(id -> {
            ClothingCatalog.Item item = ClothingCatalog.byId(id);
            return item != null && item.category() == tab;
        });
    }

    private void toggle(ClothingCatalog.Item item) {
        if (item.id().equals(selection.get(item.slot()))) {
            selection.remove(item.slot());
        } else {
            selection.put(item.slot(), item.id());
        }
        pushPreview();
    }

    /** Price of everything in the current outfit that the player has not bought yet, in cents. */
    private long cartTotal() {
        long total = 0;
        for (String id : selection.values()) {
            ClothingCatalog.Item item = ClothingCatalog.byId(id);
            if (item != null && !ClientWardrobeStore.owns(id)) {
                total += item.priceCents();
            }
        }
        return total;
    }

    private boolean canAfford() {
        return ClientWardrobeStore.balance() >= cartTotal();
    }

    private void apply() {
        if (!canAfford()) {
            return;
        }
        PacketDistributor.sendToServer(new SetOutfitPayload(currentList()));
        applied = true;
        onClose();
    }

    private int maxScroll() {
        int items = ClothingCatalog.inCategory(tab).size();
        int rows = (items + GuiLayout.COLS - 1) / GuiLayout.COLS;
        return Math.max(0, rows - GuiLayout.ROWS);
    }

    @Override
    public void removed() {
        if (!applied) {
            ClientWardrobeStore.set(player.getUUID(), original);
        }
        super.removed();
    }

    @Override
    public void tick() {
        if (heldRotate != 0) {
            rotation += heldRotate * 6.0F;
        }
    }

    // ------------------------------------------------------------------ geometry helpers

    private static boolean in(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    private int slotX(int col) {
        return left + GuiLayout.GRID_X + GuiLayout.SLOT_PITCH * col;
    }

    private int slotY(int row) {
        return top + GuiLayout.GRID_Y + GuiLayout.SLOT_PITCH * row;
    }

    private static ResourceLocation icon(String id) {
        return ICONS.computeIfAbsent(id,
                k -> ResourceLocation.fromNamespaceAndPath("fittingroom", "textures/gui/clothes/" + k + ".png"));
    }

    private ClothingCatalog.Item slotItemAt(double mx, double my) {
        List<ClothingCatalog.Item> items = ClothingCatalog.inCategory(tab);
        int first = scrollRow * GuiLayout.COLS;
        for (int idx = first; idx < items.size() && idx < first + GuiLayout.COLS * GuiLayout.ROWS; idx++) {
            int rel = idx - first;
            int col = rel % GuiLayout.COLS;
            int row = rel / GuiLayout.COLS;
            if (in(mx, my, slotX(col), slotY(row), GuiLayout.SLOT_SIZE, GuiLayout.SLOT_SIZE)) {
                return items.get(idx);
            }
        }
        return null;
    }

    private boolean overRotateLeft(double mx, double my) {
        return in(mx, my, left + GuiLayout.ROT_LEFT_X, top + GuiLayout.ROT_Y, GuiLayout.ARROW_SIZE, GuiLayout.ARROW_SIZE);
    }

    private boolean overRotateRight(double mx, double my) {
        return in(mx, my, left + GuiLayout.ROT_RIGHT_X, top + GuiLayout.ROT_Y, GuiLayout.ARROW_SIZE, GuiLayout.ARROW_SIZE);
    }

    private boolean overApply(double mx, double my) {
        return in(mx, my, left + GuiLayout.BTN_LEFT_X, top + GuiLayout.BTN_Y, GuiLayout.BTN_W, GuiLayout.BTN_H);
    }

    private boolean overRemove(double mx, double my) {
        return in(mx, my, left + GuiLayout.BTN_RIGHT_X, top + GuiLayout.BTN_Y, GuiLayout.BTN_W, GuiLayout.BTN_H);
    }

    private boolean overPreview(double mx, double my) {
        return in(mx, my, left + GuiLayout.PREVIEW_X, top + GuiLayout.PREVIEW_Y, GuiLayout.PREVIEW_W, GuiLayout.PREVIEW_H);
    }

    private void click() {
        if (this.minecraft != null) {
            this.minecraft.getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.UI_BUTTON_CLICK, 1.0F));
        }
    }

    // ------------------------------------------------------------------ rendering

    @Override
    public void render(GuiGraphics g, int mx, int my, float partialTick) {
        super.render(g, mx, my, partialTick);

        g.blit(GuiLayout.TEXTURE, left, top, 0, 0, GuiLayout.WIDTH, GuiLayout.HEIGHT, GuiLayout.TEX_W, GuiLayout.TEX_H);
        g.drawString(this.font, this.title, left + GuiLayout.TITLE_CENTER_X - this.font.width(this.title) / 2,
                top + GuiLayout.TITLE_Y, TEXT, false);

        drawPlayer(g);
        drawTabs(g);
        drawSlots(g, mx, my);
        drawScrollbar(g);
        drawRotateButtons(g, mx, my);
        drawButtons(g, mx, my);
        drawWalletBar(g);
        drawTooltips(g, mx, my);
    }

    /** A strip under the window: money on the account and the price of the current outfit. */
    private void drawWalletBar(GuiGraphics g) {
        int y = top + GuiLayout.HEIGHT + 3;
        g.fill(left, y, left + GuiLayout.WIDTH, y + 14, 0xAA000000);
        Component balance = Component.translatable("gui.fittingroom.balance", Money.format(ClientWardrobeStore.balance()));
        g.drawString(this.font, balance, left + 6, y + 3, 0xFFFFFFFF, true);
        long total = cartTotal();
        if (total > 0) {
            Component cart = Component.translatable("gui.fittingroom.total", Money.format(total));
            g.drawString(this.font, cart, left + GuiLayout.WIDTH - 6 - this.font.width(cart), y + 3,
                    canAfford() ? PRICE_GOLD : PRICE_RED, true);
        }
    }

    private void drawPlayer(GuiGraphics g) {
        int x1 = left + GuiLayout.PREVIEW_X;
        int y1 = top + GuiLayout.PREVIEW_Y;
        g.enableScissor(x1, y1, x1 + GuiLayout.PREVIEW_W, y1 + GuiLayout.PREVIEW_H);

        AbstractClientPlayer p = this.player;
        int scale = 38;
        float centerX = left + GuiLayout.PLAYER_FEET_X;
        float centerY = top + GuiLayout.PLAYER_FEET_Y - p.getBbHeight() / 2.0F * scale;
        Vector3f translate = new Vector3f(0.0F, p.getBbHeight() / 2.0F, 0.0F);
        Quaternionf pose = new Quaternionf().rotateZ((float) Math.PI);
        Quaternionf camera = new Quaternionf().rotateX(0.1F);
        pose.mul(camera);

        float yaw = 180.0F + rotation;
        float bodyRot = p.yBodyRot;
        float yRot = p.getYRot();
        float xRot = p.getXRot();
        float headRotO = p.yHeadRotO;
        float headRot = p.yHeadRot;
        p.yBodyRot = yaw;
        p.setYRot(yaw);
        p.setXRot(0.0F);
        p.yHeadRot = yaw;
        p.yHeadRotO = yaw;

        InventoryScreen.renderEntityInInventory(g, centerX, centerY, scale, translate, pose, camera, p);

        p.yBodyRot = bodyRot;
        p.setYRot(yRot);
        p.setXRot(xRot);
        p.yHeadRotO = headRotO;
        p.yHeadRot = headRot;

        g.disableScissor();
    }

    private void drawTabs(GuiGraphics g) {
        Category[] categories = Category.values();
        for (int i = 0; i < categories.length; i++) {
            int x = left + GuiLayout.TAB_X + GuiLayout.TAB_W * i;
            int y = top + GuiLayout.TAB_Y;
            boolean selected = categories[i] == tab;
            if (selected) {
                g.blit(GuiLayout.TEXTURE, x, y, GuiLayout.TAB_SEL_U, GuiLayout.TAB_SEL_V,
                        GuiLayout.TAB_W, GuiLayout.TAB_SEL_H, GuiLayout.TEX_W, GuiLayout.TEX_H);
            } else {
                g.blit(GuiLayout.TEXTURE, x, y, GuiLayout.TAB_U, GuiLayout.TAB_V,
                        GuiLayout.TAB_W, GuiLayout.TAB_H, GuiLayout.TEX_W, GuiLayout.TEX_H);
            }
            g.blit(GuiLayout.TEXTURE, x + GuiLayout.TAB_ICON_DX,
                    y + (selected ? GuiLayout.TAB_ICON_SEL_DY : GuiLayout.TAB_ICON_DY),
                    TAB_ICON_U[i], GuiLayout.ICON_V, GuiLayout.ICON_SIZE, GuiLayout.ICON_SIZE,
                    GuiLayout.TEX_W, GuiLayout.TEX_H);
        }
    }

    private void drawSlots(GuiGraphics g, int mx, int my) {
        List<ClothingCatalog.Item> items = ClothingCatalog.inCategory(tab);
        int first = scrollRow * GuiLayout.COLS;
        for (int idx = first; idx < items.size() && idx < first + GuiLayout.COLS * GuiLayout.ROWS; idx++) {
            int rel = idx - first;
            int sx = slotX(rel % GuiLayout.COLS);
            int sy = slotY(rel / GuiLayout.COLS);
            ClothingCatalog.Item item = items.get(idx);

            boolean owned = ClientWardrobeStore.owns(item.id());
            if (!owned) {
                g.setColor(0.55F, 0.55F, 0.55F, 1.0F);
            }
            g.blit(icon(item.id()), sx + GuiLayout.ITEM_ICON_OFFSET, sy + GuiLayout.ITEM_ICON_OFFSET,
                    0, 0, 16, 16, 16, 16);
            if (!owned) {
                g.setColor(1.0F, 1.0F, 1.0F, 1.0F);
                g.drawString(this.font, "$", sx + GuiLayout.SLOT_SIZE - 7, sy + GuiLayout.SLOT_SIZE - 9, PRICE_GOLD, true);
            }
            if (in(mx, my, sx, sy, GuiLayout.SLOT_SIZE, GuiLayout.SLOT_SIZE)) {
                g.blit(GuiLayout.TEXTURE, sx, sy, GuiLayout.SLOT_HOVER_U, GuiLayout.SLOT_HOVER_V,
                        GuiLayout.SLOT_SIZE, GuiLayout.SLOT_SIZE, GuiLayout.TEX_W, GuiLayout.TEX_H);
            }
            if (item.id().equals(selection.get(item.slot()))) {
                g.blit(GuiLayout.TEXTURE, sx - 1, sy - 1, GuiLayout.SLOT_SELECTED_U, GuiLayout.SLOT_SELECTED_V,
                        GuiLayout.SLOT_SELECTED_SIZE, GuiLayout.SLOT_SELECTED_SIZE, GuiLayout.TEX_W, GuiLayout.TEX_H);
            }
        }
    }

    private void drawScrollbar(GuiGraphics g) {
        int max = maxScroll();
        int x = left + GuiLayout.SCROLL_X;
        int y = top + GuiLayout.SCROLL_Y;
        if (max <= 0) {
            g.blit(GuiLayout.TEXTURE, x, y, GuiLayout.THUMB_DISABLED_U, GuiLayout.THUMB_V,
                    GuiLayout.SCROLL_W, GuiLayout.THUMB_H, GuiLayout.TEX_W, GuiLayout.TEX_H);
        } else {
            int travel = GuiLayout.SCROLL_H - GuiLayout.THUMB_H;
            g.blit(GuiLayout.TEXTURE, x, y + travel * scrollRow / max, GuiLayout.THUMB_U, GuiLayout.THUMB_V,
                    GuiLayout.SCROLL_W, GuiLayout.THUMB_H, GuiLayout.TEX_W, GuiLayout.TEX_H);
        }
    }

    private void drawRotateButtons(GuiGraphics g, int mx, int my) {
        int ly = top + GuiLayout.ROT_Y;
        g.blit(GuiLayout.TEXTURE, left + GuiLayout.ROT_LEFT_X, ly,
                overRotateLeft(mx, my) ? GuiLayout.ARROW_LEFT_HOVER_U : GuiLayout.ARROW_LEFT_U, GuiLayout.ARROW_V,
                GuiLayout.ARROW_SIZE, GuiLayout.ARROW_SIZE, GuiLayout.TEX_W, GuiLayout.TEX_H);
        g.blit(GuiLayout.TEXTURE, left + GuiLayout.ROT_RIGHT_X, ly,
                overRotateRight(mx, my) ? GuiLayout.ARROW_RIGHT_HOVER_U : GuiLayout.ARROW_RIGHT_U, GuiLayout.ARROW_V,
                GuiLayout.ARROW_SIZE, GuiLayout.ARROW_SIZE, GuiLayout.TEX_W, GuiLayout.TEX_H);
    }

    private void drawButtons(GuiGraphics g, int mx, int my) {
        int by = top + GuiLayout.BTN_Y;
        boolean canRemove = hasTabSelection();

        int applyX = left + GuiLayout.BTN_LEFT_X;
        boolean buying = cartTotal() > 0;
        boolean canApply = canAfford();
        int applyU = !canApply ? GuiLayout.BTN_DISABLED_U : (overApply(mx, my) ? GuiLayout.BTN_HOVER_U : GuiLayout.BTN_U);
        g.blit(GuiLayout.TEXTURE, applyX, by, applyU,
                GuiLayout.BTN_V, GuiLayout.BTN_W, GuiLayout.BTN_H, GuiLayout.TEX_W, GuiLayout.TEX_H);
        Component apply = Component.translatable(buying ? "gui.fittingroom.buy" : "gui.fittingroom.apply");
        g.drawString(this.font, apply, applyX + (GuiLayout.BTN_W - this.font.width(apply)) / 2, by + 5,
                canApply ? TEXT : TEXT_DISABLED, false);

        int removeX = left + GuiLayout.BTN_RIGHT_X;
        int u = !canRemove ? GuiLayout.BTN_DISABLED_U : (overRemove(mx, my) ? GuiLayout.BTN_HOVER_U : GuiLayout.BTN_U);
        g.blit(GuiLayout.TEXTURE, removeX, by, u, GuiLayout.BTN_V, GuiLayout.BTN_W, GuiLayout.BTN_H,
                GuiLayout.TEX_W, GuiLayout.TEX_H);
        Component remove = Component.translatable("gui.fittingroom.remove");
        g.drawString(this.font, remove, removeX + (GuiLayout.BTN_W - this.font.width(remove)) / 2, by + 5,
                canRemove ? TEXT : TEXT_DISABLED, false);
    }

    private void drawTooltips(GuiGraphics g, int mx, int my) {
        ClothingCatalog.Item hovered = slotItemAt(mx, my);
        if (hovered != null) {
            List<Component> lines = new ArrayList<>();
            lines.add(Component.translatable(hovered.translationKey()));
            if (ClientWardrobeStore.owns(hovered.id())) {
                lines.add(Component.translatable("gui.fittingroom.owned").withStyle(ChatFormatting.GREEN));
            } else {
                lines.add(Component.translatable("gui.fittingroom.price", Money.format(hovered.priceCents()))
                        .withStyle(ChatFormatting.GOLD));
            }
            g.renderComponentTooltip(this.font, lines, mx, my);
            return;
        }
        if (overApply(mx, my) && !canAfford()) {
            g.renderTooltip(this.font, Component.translatable("gui.fittingroom.not_enough"), mx, my);
            return;
        }
        Category[] categories = Category.values();
        for (int i = 0; i < categories.length; i++) {
            if (in(mx, my, left + GuiLayout.TAB_X + GuiLayout.TAB_W * i, top + GuiLayout.TAB_Y,
                    GuiLayout.TAB_W, GuiLayout.TAB_H)) {
                g.renderTooltip(this.font, Component.translatable("gui.fittingroom.category." + categories[i].id()), mx, my);
                return;
            }
        }
    }

    // ------------------------------------------------------------------ input

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button == 0) {
            Category[] categories = Category.values();
            for (int i = 0; i < categories.length; i++) {
                if (in(mx, my, left + GuiLayout.TAB_X + GuiLayout.TAB_W * i, top + GuiLayout.TAB_Y,
                        GuiLayout.TAB_W, GuiLayout.TAB_H)) {
                    tab = categories[i];
                    scrollRow = 0;
                    click();
                    return true;
                }
            }
            ClothingCatalog.Item item = slotItemAt(mx, my);
            if (item != null) {
                toggle(item);
                click();
                return true;
            }
            if (overRotateLeft(mx, my)) {
                rotation -= 25.0F;
                heldRotate = -1;
                click();
                return true;
            }
            if (overRotateRight(mx, my)) {
                rotation += 25.0F;
                heldRotate = 1;
                click();
                return true;
            }
            if (overApply(mx, my)) {
                click();
                apply();
                return true;
            }
            if (overRemove(mx, my) && hasTabSelection()) {
                clearTab();
                pushPreview();
                click();
                return true;
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        heldRotate = 0;
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dragX, double dragY) {
        if (button == 0 && overPreview(mx, my)) {
            rotation += (float) dragX * 1.2F;
            return true;
        }
        return super.mouseDragged(mx, my, button, dragX, dragY);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double scrollX, double scrollY) {
        int max = maxScroll();
        if (max > 0) {
            scrollRow = Math.max(0, Math.min(max, scrollRow - (int) Math.signum(scrollY)));
            return true;
        }
        return super.mouseScrolled(mx, my, scrollX, scrollY);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (this.minecraft != null && this.minecraft.options.keyInventory.matches(keyCode, scanCode)) {
            this.onClose();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }
}
