Put your existing aestheticjobs-0.8.0.jar here (from the Aesthetic Jobs project: build/libs). Only needed to compile this mod.
