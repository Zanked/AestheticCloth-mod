#!/usr/bin/env python3
"""
Generates the accessories of the fitting room: models (clothes_models/<id>.json),
32x textures (textures/clothes/<id>.png) and 16x16 GUI icons (textures/gui/clothes/<id>.png).

Run from the project root:  python3 tools/gen_accessories.py
Needs Pillow. Cubes are described by their *real* centre and size (in model units, vanilla model space,
y goes down); the script turns them into the pos / size / grow / uv that docs/clothes-models.md describes.
"""
import json
import math
import random
from pathlib import Path

from PIL import Image

ASSETS = Path(__file__).resolve().parent.parent / "src/main/resources/assets/fittingroom"
PX = 2  # texture pixels per model unit
SHEET_W = 64  # texture_size width in units (PNG = 128 px)

OUTLINE = (118, 84, 72)  # same brown outline as the other GUI icons


def shade(c, k):
    return tuple(max(0, min(255, int(round(v * k)))) for v in c)


class Cube:
    def __init__(self, name, bone, center, dims, base, deco=None, pivot=None, rot=None,
                 mirror=False, twin_of=None):
        self.name, self.bone, self.center, self.dims = name, bone, center, dims
        self.base, self.deco, self.pivot, self.rot = base, deco, pivot, rot
        self.mirror, self.twin_of = mirror, twin_of
        self.size = tuple(max(1, math.ceil(d - 1e-6)) for d in dims)
        self.grow = tuple(round((d - s) / 2.0, 3) for d, s in zip(dims, self.size))
        self.uv = (0, 0)

    def pos(self):
        o = self.pivot or (0, 0, 0)
        return [round(c - o[i] - self.size[i] / 2.0, 3) for i, c in enumerate(self.center)]

    def unwrap(self):
        w, h, d = self.size
        return 2 * d + 2 * w, d + h

    def to_json(self):
        out = {
            "name": self.name, "bone": self.bone, "size": list(self.size),
            "uv": list(self.uv), "grow": list(self.grow), "mirror": self.mirror,
            "pos": self.pos(),
        }
        if self.rot:
            out["pivot"] = [round(v, 3) for v in self.pivot]
            out["rot"] = list(self.rot)
        return out


def layout(cubes):
    """Packs the box unwraps of all cubes (twins share the unwrap of their original) into rows."""
    x = y = row_h = 0
    by_name = {}
    for c in cubes:
        by_name[c.name] = c
        if c.twin_of:
            continue
        w, h = c.unwrap()
        if x + w > SHEET_W:
            x, y, row_h = 0, y + row_h, 0
        c.uv = (x, y)
        x += w
        row_h = max(row_h, h)
    for c in cubes:
        if c.twin_of:
            c.uv = by_name[c.twin_of].uv
    return y + row_h


FACE_LIGHT = {"top": 1.12, "bottom": 0.76, "front": 1.0, "back": 0.93, "right": 0.9, "left": 0.85}


def paint(img, c):
    w, h, d = c.size
    faces = {
        "top": (d, 0, w, d), "bottom": (d + w, 0, w, d),
        "right": (0, d, d, h), "front": (d, d, w, h),
        "left": (d + w, d, d, h), "back": (2 * d + w, d, w, h),
    }
    rnd = random.Random(c.name)
    for fname, (fx, fy, fw, fh) in faces.items():
        pw, ph = fw * PX, fh * PX
        for py in range(ph):
            for px in range(pw):
                col = c.deco(fname, px, py, pw, ph) if c.deco else None
                if col == "clear":
                    img.putpixel((c.uv[0] * PX + fx * PX + px, c.uv[1] * PX + fy * PX + py), (0, 0, 0, 0))
                    continue
                col = col or c.base
                k = FACE_LIGHT[fname]
                if fname not in ("top", "bottom"):
                    k *= 1.06 - 0.12 * (py / max(1, ph))
                    if py == ph - 1:
                        k *= 0.92
                    elif py == 0:
                        k *= 1.05
                k *= 1 + rnd.uniform(-0.035, 0.035)
                img.putpixel((c.uv[0] * PX + fx * PX + px, c.uv[1] * PX + fy * PX + py), shade(col, k) + (255,))


def build(model_id, cubes):
    rows = layout(cubes)
    img = Image.new("RGBA", (SHEET_W * PX, rows * PX), (0, 0, 0, 0))
    for c in cubes:
        if not c.twin_of:
            paint(img, c)
    (ASSETS / "textures/clothes").mkdir(parents=True, exist_ok=True)
    img.save(ASSETS / f"textures/clothes/{model_id}.png")
    model = {
        "texture": f"fittingroom:textures/clothes/{model_id}.png",
        "texture_size": [SHEET_W, rows],
        "cubes": [c.to_json() for c in cubes],
    }
    (ASSETS / "clothes_models").mkdir(parents=True, exist_ok=True)
    (ASSETS / f"clothes_models/{model_id}.json").write_text(json.dumps(model, indent=1) + "\n")
    return cubes


# ---------------------------------------------------------------- palettes
TEAL, TEAL_D, TEAL_L = (58, 157, 155), (40, 120, 124), (96, 188, 180)
NAVY, NAVY_L = (48, 60, 84), (92, 108, 140)
ORANGE, YELLOW = (236, 140, 70), (246, 205, 86)
LEATHER, SILVER, SILVER_L, RED_P = (28, 28, 34), (190, 196, 208), (228, 233, 243), (176, 32, 42)
SACK_RED, SACK_RED_D = (200, 48, 52), (170, 34, 44)
FUR, CREAM, TAN, ROPE = (244, 244, 250), (236, 222, 170), (214, 170, 110), (150, 104, 62)
GREEN = (58, 150, 80)


def dashed(f, x, y, w, h, col, pad=0):
    """Stitch line along the long axis of a face."""
    if w >= 3 and h > w and x == w // 2 and y % 3 != 2 and pad <= y < h - pad:
        return col
    if w >= 3 and w >= h and y == h // 2 and x % 3 != 2 and pad <= x < w - pad:
        return col
    return None


# ---------------------------------------------------------------- 1. backpack
def backpack():
    def d_main(f, x, y, w, h):
        if f in ("back", "front"):
            if y >= h - 2:
                return TEAL_D
            if (x == 2 or x == w - 3) and y % 2 == 0 and y < h - 3:
                return TEAL_L
        return None

    def d_flap(f, x, y, w, h):
        if f in ("back", "front"):
            if 7 <= x <= 8 and 4 <= y <= 6:
                return ORANGE if y < 6 else (160, 84, 40)
            if y == 1 and x % 3 != 2:
                return TEAL_L
        return None

    def d_pocket(f, x, y, w, h):
        if f == "back":
            if y == 1:
                return YELLOW if x >= w - 3 else TEAL_D
            if y >= h - 1 or x in (0, w - 1):
                return TEAL_D
        return None

    def d_strap(f, x, y, w, h):
        return dashed(f, x, y, w, h, NAVY_L)

    def d_buckle(f, x, y, w, h):
        if f in ("front", "back") and w >= 2 and (x, y) in ((w // 2, h // 2), (w // 2 - 1, h // 2)):
            return (120, 70, 36)
        return None

    cubes = [
        Cube("main", "body", (0, 8.25, 4.7), (7, 6.5, 3), TEAL, d_main),
        Cube("flap", "body", (0, 4.25, 4.8), (7.4, 3.5, 3.4), TEAL_D, d_flap),
        Cube("pocket", "body", (0, 8.8, 6.7), (5, 3.5, 1), TEAL_L, d_pocket),
        Cube("strap_r", "body", (-2.9, 4.8, -3.65), (1.6, 9.2, 0.6), NAVY, d_strap),
        Cube("strap_l", "body", (2.9, 4.8, -3.65), (1.6, 9.2, 0.6), NAVY, d_strap, twin_of="strap_r", mirror=True),
        Cube("link_r", "body", (-2.9, -1.0, -0.15), (1.6, 0.6, 7.0), NAVY, d_strap),
        Cube("link_l", "body", (2.9, -1.0, -0.15), (1.6, 0.6, 7.0), NAVY, d_strap, twin_of="link_r", mirror=True),
        Cube("back_r", "body", (-2.9, 1.0, 3.3), (1.6, 4.0, 0.6), NAVY, d_strap),
        Cube("back_l", "body", (2.9, 1.0, 3.3), (1.6, 4.0, 0.6), NAVY, d_strap, twin_of="back_r", mirror=True),
        Cube("chest", "body", (0, 3.4, -3.75), (5.8, 0.6, 0.5), NAVY, d_strap),
        Cube("buckle", "body", (0, 3.4, -3.85), (1.4, 1.2, 0.5), ORANGE, d_buckle),
        Cube("charm", "body", (-2.2, 12.5, 5.2), (0.9, 1.6, 0.9), YELLOW),
    ]
    return build("casual_backpack", cubes)


# ---------------------------------------------------------------- 2. punk wristbands
def punk_cuffs():
    def d_cuff(f, x, y, w, h):
        if f in ("top", "bottom"):
            if 2 <= x < w - 2 and 2 <= y < h - 2:
                return "clear"  # hollow ring: the arm goes through it
            return None
        if y == h - 1:
            return RED_P
        if y == 1 and x % 3 == 1:
            return SILVER_L
        return None

    cubes = [
        Cube("cuff_r", "right_arm", (-1, 7.0, 0), (6.1, 2.0, 6.1), LEATHER, d_cuff),
        Cube("spike_rf", "right_arm", (-1, 7.0, -3.55), (1.4, 1.4, 1.0), SILVER),
        Cube("tip_rf", "right_arm", (-1, 7.0, -4.45), (0.6, 0.6, 0.8), SILVER_L),
        Cube("spike_rb", "right_arm", (-1, 7.0, 3.55), (1.4, 1.4, 1.0), SILVER, twin_of="spike_rf"),
        Cube("tip_rb", "right_arm", (-1, 7.0, 4.45), (0.6, 0.6, 0.8), SILVER_L, twin_of="tip_rf"),
        Cube("cuff_l", "left_arm", (1, 7.0, 0), (6.1, 2.0, 6.1), LEATHER, d_cuff, twin_of="cuff_r", mirror=True),
        Cube("spike_lf", "left_arm", (1, 7.0, -3.55), (1.4, 1.4, 1.0), SILVER, twin_of="spike_rf", mirror=True),
        Cube("tip_lf", "left_arm", (1, 7.0, -4.45), (0.6, 0.6, 0.8), SILVER_L, twin_of="tip_rf", mirror=True),
        Cube("spike_lb", "left_arm", (1, 7.0, 3.55), (1.4, 1.4, 1.0), SILVER, twin_of="spike_rf", mirror=True),
        Cube("tip_lb", "left_arm", (1, 7.0, 4.45), (0.6, 0.6, 0.8), SILVER_L, twin_of="tip_rf", mirror=True),
    ]
    # the back spike has the same size as the front one, so it can reuse its unwrap
    return build("punk_cuffs", cubes)


# ---------------------------------------------------------------- 3. Santa's sack (seasonal)
def santa_sack():
    def d_low(f, x, y, w, h):
        if f in ("back", "front", "left", "right"):
            if f == "back" and 5 <= x <= 10 and 5 <= y <= 10:
                edge = x in (5, 10) or y in (5, 10)
                return (120, 84, 50) if edge and (x + y) % 2 == 0 else TAN
            if x % 5 == 3:
                return SACK_RED_D
        return None

    def d_mid(f, x, y, w, h):
        return SACK_RED_D if f in ("back", "front", "left", "right") and x % 6 == 2 else None

    def d_fur(f, x, y, w, h):
        return (222, 228, 240) if (x * 7 + y * 13) % 5 == 0 else None

    def d_tie(f, x, y, w, h):
        return (196, 170, 112) if (x + y) % 3 == 0 else None

    def d_rope(f, x, y, w, h):
        return (112, 74, 44) if (x + y) % 4 < 2 else None

    def gift(ribbon, base):
        def d(f, x, y, w, h):
            if x in (w // 2 - 1, w // 2) or (f in ("top", "bottom") and y in (h // 2 - 1, h // 2)):
                return ribbon
            return None
        return d

    strap_pivot = (0, 6.3, -3.65)
    cubes = [
        Cube("sack_low", "body", (0, 8.7, 5.4), (8, 6.2, 3.8), SACK_RED, d_low),
        Cube("sack_mid", "body", (0, 4.65, 5.3), (6.4, 3.3, 3.4), SACK_RED, d_mid),
        Cube("sack_neck", "body", (0, 2.3, 5.3), (3.8, 1.6, 3.2), SACK_RED_D),
        Cube("tie", "body", (0, 2.35, 5.3), (4.4, 0.7, 3.8), CREAM, d_tie),
        Cube("fur", "body", (0, 0.9, 5.3), (5.4, 1.8, 4.0), FUR, d_fur),
        Cube("gift_g", "body", (1.1, -0.4, 5.3), (2.4, 2.4, 2.4), GREEN, gift(SACK_RED, GREEN),
             pivot=(1.1, -0.4, 5.3), rot=(0, 0, 14)),
        Cube("gift_r", "body", (-1.2, -0.1, 5.2), (2.2, 2.2, 2.2), SACK_RED, gift((240, 200, 80), SACK_RED),
             pivot=(-1.2, -0.1, 5.2), rot=(0, 20, -16)),
        Cube("strap", "body", (0, 6.3, -3.65), (0.9, 13.5, 0.6), ROPE, d_rope, pivot=strap_pivot, rot=(0, 0, 32)),
        Cube("link", "body", (3.3, -1.0, -0.15), (1.2, 0.6, 7.2), ROPE, d_rope),
        Cube("back_link", "body", (3.3, 1.0, 3.3), (1.2, 4.0, 0.6), ROPE, d_rope),
    ]
    return build("santa_sack", cubes)


# ---------------------------------------------------------------- GUI icons
class Icon:
    def __init__(self):
        self.px = {}

    def rect(self, x0, y0, x1, y1, col):
        for y in range(y0, y1 + 1):
            for x in range(x0, x1 + 1):
                self.px[(x, y)] = col

    def put(self, x, y, col):
        self.px[(x, y)] = col

    def save(self, name):
        img = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
        for (x, y), col in self.px.items():
            img.putpixel((x, y), col + (255,))
        for y in range(16):
            for x in range(16):
                if (x, y) in self.px:
                    continue
                if any((x + dx, y + dy) in self.px for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1))):
                    img.putpixel((x, y), OUTLINE + (255,))
        (ASSETS / "textures/gui/clothes").mkdir(parents=True, exist_ok=True)
        img.save(ASSETS / f"textures/gui/clothes/{name}.png")


def icon_backpack():
    i = Icon()
    i.rect(2, 7, 2, 13, NAVY)
    i.rect(13, 7, 13, 13, NAVY)
    i.rect(3, 5, 12, 14, TEAL)
    i.rect(3, 5, 3, 14, shade(TEAL, 1.12))
    i.rect(12, 5, 12, 14, shade(TEAL, 0.86))
    i.rect(3, 14, 12, 14, shade(TEAL, 0.78))
    i.rect(3, 4, 12, 8, TEAL_D)
    i.rect(3, 4, 12, 4, shade(TEAL_D, 1.2))
    i.rect(3, 8, 12, 8, shade(TEAL_D, 0.8))
    i.rect(7, 7, 8, 9, ORANGE)
    i.rect(7, 9, 8, 9, (160, 84, 40))
    i.rect(5, 10, 10, 13, TEAL_L)
    i.rect(5, 10, 10, 10, TEAL_D)
    i.put(9, 10, YELLOW)
    i.rect(6, 2, 9, 2, NAVY)
    i.put(6, 3, NAVY)
    i.put(9, 3, NAVY)
    i.save("casual_backpack")


def icon_cuffs():
    i = Icon()
    for x, top in ((4, 4), (7, 3), (10, 4)):
        i.rect(x, top, x, 6, SILVER)
        i.put(x, top, SILVER_L)
    i.rect(2, 7, 13, 12, LEATHER)
    i.rect(2, 7, 13, 7, (74, 74, 88))
    i.rect(2, 12, 13, 12, (16, 16, 21))
    i.rect(2, 11, 13, 11, RED_P)
    for x in (4, 7, 10):
        i.put(x, 9, SILVER_L)
    i.put(13, 9, SILVER)
    i.save("punk_cuffs")


def icon_sack():
    i = Icon()
    rows = {7: (5, 10), 8: (4, 11), 9: (3, 12), 10: (3, 12), 11: (3, 12), 12: (3, 12), 13: (4, 11), 14: (5, 10)}
    for y, (x0, x1) in rows.items():
        for x in range(x0, x1 + 1):
            k = 1.0
            if x <= x0 + 1:
                k = 1.14
            elif x >= x1 - 1:
                k = 0.84
            if y == 14:
                k *= 0.85
            i.put(x, y, shade(SACK_RED, k))
    i.rect(5, 4, 10, 5, FUR)
    i.rect(5, 5, 10, 5, (222, 228, 240))
    i.rect(5, 6, 10, 6, CREAM)
    i.rect(6, 10, 8, 12, TAN)
    i.put(6, 10, (120, 84, 50))
    i.put(8, 12, (120, 84, 50))
    i.rect(5, 1, 7, 3, GREEN)
    i.rect(6, 1, 6, 3, SACK_RED)
    i.rect(9, 2, 11, 3, SACK_RED)
    i.rect(10, 2, 10, 3, (240, 200, 80))
    i.save("santa_sack")


# ---------------------------------------------------------------- 4. glasses (head bone)
# Eyes of the vanilla head are at x = +-(1..3), y = -4..-2; the face is z = -4 (the skin's hat layer reaches -4.5),
# so the frames sit in front of that at z ~ -4.7. Lenses are 3 x 3 units, centred at x = +-2, y = -3.
ZF = -4.7


def temples(col, y=-3.6):
    """Hinge pieces and the arms that run back along the sides of the head."""
    out = []
    for side, sx in (("r", -1), ("l", 1)):
        out.append(Cube(f"hinge_{side}", "head", (sx * 4.25, y, ZF), (1.5, 0.5, 0.5), col,
                        twin_of=None if side == "r" else "hinge_r", mirror=side == "l"))
        out.append(Cube(f"arm_{side}", "head", (sx * 4.7, y, -2.85), (0.5, 0.5, 4.2), col,
                        twin_of=None if side == "r" else "arm_r", mirror=side == "l"))
    return out


def bridge(col, y=-3.6, width=1.0):
    return Cube("bridge", "head", (0, y, ZF), (width, 0.5, 0.5), col)


def glasses_round():
    GOLD = (222, 176, 70)
    CORNERS = {(0, 0), (5, 0), (0, 5), (5, 5)}

    def d_ring(f, x, y, w, h):
        if f in ("front", "back"):
            if (x, y) in CORNERS:
                return "clear"
            if 1 <= x <= 4 and 1 <= y <= 4:
                return "clear"  # clear lens
        return None

    cubes = [
        Cube("ring_r", "head", (-2.0, -3.0, ZF), (3.0, 3.0, 0.5), GOLD, d_ring),
        Cube("ring_l", "head", (2.0, -3.0, ZF), (3.0, 3.0, 0.5), GOLD, d_ring, twin_of="ring_r", mirror=True),
        bridge(GOLD, y=-3.4, width=1.0),
    ] + temples(GOLD)
    return build("glasses_round", cubes)


def glasses_sun():
    FRAME, LENS, GLINT = (34, 34, 42), (24, 28, 44), (132, 146, 186)

    def d_lens(f, x, y, w, h):
        if f in ("front", "back"):
            if (x, y) in ((1, 1), (2, 1), (1, 2)):
                return GLINT
            if x in (0, w - 1) or y in (0, h - 1):
                return FRAME
        return None

    cubes = [
        Cube("lens_r", "head", (-2.0, -3.0, ZF), (3.0, 2.4, 0.5), LENS, d_lens),
        Cube("lens_l", "head", (2.0, -3.0, ZF), (3.0, 2.4, 0.5), LENS, d_lens, twin_of="lens_r", mirror=True),
        Cube("brow", "head", (0, -4.45, ZF), (7.4, 0.6, 0.55), FRAME),
        bridge(FRAME, y=-4.0, width=1.0),
    ] + temples(FRAME, y=-4.0)
    return build("glasses_sun", cubes)


def glasses_heart():
    PINK, HL = (240, 104, 158), (255, 190, 214)
    MASK = ["XX..XX", "XXXXXX", "XXXXXX", "XXXXXX", ".XXXX.", "..XX.."]

    def d_heart(f, x, y, w, h):
        if f in ("front", "back"):
            if MASK[y][x] != "X":
                return "clear"
            if (x, y) in ((1, 1), (1, 0)) and f == "front":
                return HL
        return None

    cubes = [
        Cube("heart_r", "head", (-2.0, -3.0, ZF), (3.0, 3.0, 0.5), PINK, d_heart),
        Cube("heart_l", "head", (2.0, -3.0, ZF), (3.0, 3.0, 0.5), PINK, d_heart, twin_of="heart_r", mirror=True),
        bridge(PINK, y=-3.9, width=1.4),
    ] + temples(PINK, y=-3.9)
    return build("glasses_heart", cubes)


def glasses_3d():
    PAPER, RED, CYAN = (242, 238, 226), (212, 52, 62), (64, 198, 222)

    def lens(col):
        def d(f, x, y, w, h):
            if f in ("front", "back"):
                return PAPER if x in (0, w - 1) or y in (0, h - 1) else col
            return None
        return d

    cubes = [
        Cube("lens_r", "head", (-2.0, -3.0, ZF), (3.0, 2.6, 0.5), PAPER, lens(CYAN)),
        Cube("lens_l", "head", (2.0, -3.0, ZF), (3.0, 2.6, 0.5), PAPER, lens(RED)),
        bridge(PAPER, y=-3.9, width=1.0),
    ] + temples(PAPER, y=-3.9)
    return build("glasses_3d", cubes)


def glasses_pixel():
    BLACK, SHINE = (16, 16, 20), (236, 238, 245)

    def d_top(f, x, y, w, h):
        if f in ("front", "back") and (x, y) in ((3, 0), (4, 0), (12, 0), (13, 0)):
            return SHINE
        return None

    def d_block(f, x, y, w, h):
        if f in ("front", "back") and (x, y) in ((1, 0), (2, 1)):
            return (96, 100, 116)
        return None

    cubes = [
        Cube("top", "head", (0, -4.1, ZF - 0.05), (7.8, 1.2, 0.6), BLACK, d_top),
        Cube("block_r", "head", (-2.1, -2.9, ZF - 0.05), (3.2, 1.2, 0.6), BLACK, d_block),
        Cube("block_l", "head", (2.1, -2.9, ZF - 0.05), (3.2, 1.2, 0.6), BLACK, d_block, twin_of="block_r", mirror=True),
    ] + temples(BLACK, y=-4.0)
    return build("glasses_pixel", cubes)


def icon_glasses():
    GOLD = (222, 176, 70)
    # round
    i = Icon()
    for x0 in (2, 9):
        i.rect(x0 + 1, 5, x0 + 3, 5, GOLD)
        i.rect(x0 + 1, 9, x0 + 3, 9, shade(GOLD, 0.82))
        i.rect(x0, 6, x0, 8, GOLD)
        i.rect(x0 + 4, 6, x0 + 4, 8, shade(GOLD, 0.82))
        i.put(x0 + 1, 6, (206, 232, 246))
    i.rect(7, 7, 8, 7, GOLD)
    i.put(1, 6, GOLD)
    i.put(14, 6, GOLD)
    i.save("glasses_round")
    # sunglasses
    i = Icon()
    i.rect(2, 5, 13, 5, (34, 34, 42))
    for x0 in (2, 9):
        i.rect(x0, 6, x0 + 4, 9, (24, 28, 44))
        i.put(x0 + 1, 7, (132, 146, 186))
        i.put(x0 + 2, 6, (132, 146, 186))
    i.rect(7, 6, 8, 6, (34, 34, 42))
    i.put(1, 5, (34, 34, 42))
    i.put(14, 5, (34, 34, 42))
    i.save("glasses_sun")
    # hearts
    i = Icon()
    heart = ["XX.XX", "XXXXX", "XXXXX", ".XXX.", "..X.."]
    for x0 in (2, 9):
        for dy, row in enumerate(heart):
            for dx, ch in enumerate(row):
                if ch == "X":
                    i.put(x0 + dx, 5 + dy, (240, 104, 158) if (dx, dy) != (1, 1) else (255, 190, 214))
    i.rect(7, 6, 8, 6, (240, 104, 158))
    i.save("glasses_heart")
    # 3D
    i = Icon()
    paper = (242, 238, 226)
    for x0, col in ((2, (64, 198, 222)), (9, (212, 52, 62))):
        i.rect(x0, 5, x0 + 4, 10, paper)
        i.rect(x0 + 1, 6, x0 + 3, 9, col)
    i.rect(7, 6, 8, 6, paper)
    i.save("glasses_3d")
    # pixel shades
    i = Icon()
    black = (16, 16, 20)
    i.rect(2, 5, 13, 6, black)
    i.rect(2, 7, 6, 9, black)
    i.rect(9, 7, 13, 9, black)
    for x, y in ((4, 5), (5, 5), (11, 5), (12, 5)):
        i.put(x, y, (236, 238, 245))
    i.put(3, 7, (96, 100, 116))
    i.put(10, 7, (96, 100, 116))
    i.save("glasses_pixel")


if __name__ == "__main__":
    for fn in (backpack, punk_cuffs, santa_sack, icon_backpack, icon_cuffs, icon_sack,
               glasses_round, glasses_sun, glasses_heart, glasses_3d, glasses_pixel, icon_glasses):
        fn()
    print("accessories generated")
