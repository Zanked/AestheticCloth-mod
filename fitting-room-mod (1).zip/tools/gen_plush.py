#!/usr/bin/env python3
"""
Generates the plush animal backpacks of the fitting room (accessories): plush_cat, plush_dino, plush_bear.
A soft toy sits on the back with its face and belly turned to whoever stands behind the player: head with
ears, body with a belly oval, little arms, legs with paw pads, a tail or spikes, and shoulder straps like the
normal backpack. Models, 32x textures and 16x16 icons; same smooth painter as gen_dino.py.

Run from the project root:  python3 tools/gen_plush.py
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from gen_dino import blk, build, grad, mix  # noqa: E402
from gen_accessories import Cube, Icon, dashed, shade  # noqa: E402

EYE = (34, 28, 44)
WHITE = (250, 248, 244)
BLUSH = (255, 158, 170)

SPECIES = {
    "cat": dict(body=(248, 184, 112), light=(255, 240, 214), dark=(214, 132, 62), inner=(250, 160, 176),
                nose=(238, 124, 146), strap=(240, 142, 168), pad=(246, 150, 168)),
    "dino": dict(body=(110, 186, 128), light=(244, 246, 206), dark=(70, 146, 98), inner=(255, 224, 130),
                 nose=(52, 112, 80), strap=(250, 214, 110), pad=(232, 238, 176)),
    "bear": dict(body=(180, 130, 90), light=(226, 182, 134), dark=(122, 82, 56), inner=(236, 186, 156),
                 nose=(58, 38, 38), strap=(212, 74, 84), pad=(244, 168, 160)),
}
P = SPECIES["cat"]


def soft(top_k=1.08, bottom_k=0.92):
    def d(f, x, y, w, h):
        return None
    return d


def eyes(f, x, y, w, h):
    """Two glossy eyes and blush on the 'back' face of the head (16x10)."""
    if f != "back":
        return None
    for ex in (3, 11):
        if ex <= x <= ex + 1 and 3 <= y <= 5:
            return WHITE if (x, y) == (ex, 3) else EYE
    if y == 6 and (1 <= x <= 2 or 13 <= x <= 14):
        return BLUSH
    return None


def head_deco(sp):
    def d(f, x, y, w, h):
        c = eyes(f, x, y, w, h)
        if c:
            return c
        if f == "back":
            if sp == "cat":
                if 7 <= x <= 8 and y == 5:
                    return P["nose"]
                if (x, y) in ((6, 7), (9, 7), (7, 6), (8, 6)):
                    return mix(P["dark"], EYE, 0.5)
                if y in (5, 7) and (x <= 1 or x >= 14):
                    return (252, 244, 232)
        if f in ("top", "bottom"):
            return None
        return mix(mix(P["body"], WHITE, 0.12), P["body"], y / max(1, h - 1))
    return d


def d_belly(f, x, y, w, h):
    if f != "back":
        return P["light"]
    nx, ny = (x + 0.5) / w * 2 - 1, (y + 0.5) / h * 2 - 1
    if nx * nx + ny * ny <= 1.0:
        return mix(P["light"], WHITE, 0.25) if ny < -0.4 else P["light"]
    return "clear"


def d_pad(f, x, y, w, h):
    if f != "back":
        return None
    toes = ((0, 2), (1, 2), (2, 1), (3, 1), (4, 2), (5, 2))
    pad = [(x0, y0) for y0 in (3, 4) for x0 in range(1, 5)] + [(2, 5), (3, 5)]
    if (x, y) in toes or (x, y) in pad:
        return P["pad"]
    return None


def d_ear_back(inner, size=(3, 3)):
    def d(f, x, y, w, h):
        if f == "back" and 1 <= x <= w - 2 and 2 <= y <= h - 2:
            return inner
        return None
    return d


def d_ring(col):
    def d(f, x, y, w, h):
        if f in ("front", "back", "left", "right") and y % 5 in (1, 2):
            return col
        return None
    return d


def d_strap(f, x, y, w, h):
    return dashed(f, x, y, w, h, mix(P["strap"], WHITE, 0.55))


def d_snout(sp):
    def d(f, x, y, w, h):
        if f == "back":
            if sp == "bear":
                if 2 <= x <= 3 and 0 <= y <= 1:
                    return P["nose"]
                if y == 3 and x in (2, 3):
                    return mix(P["dark"], EYE, 0.4)
            if sp == "dino":
                if y == 1 and x in (2, 5):
                    return P["nose"]
                if y == 3 and 1 <= x <= w - 2:
                    return mix(P["dark"], EYE, 0.3)
        if f in ("top", "bottom"):
            return None
        return mix(mix(P["light"] if sp == "bear" else P["body"], WHITE, 0.15), P["body"] if sp == "dino" else P["light"],
                   y / max(1, h - 1))
    return d


def plush(sp):
    global P
    P = SPECIES[sp]
    body_g = grad(mix(P["body"], WHITE, 0.14), P["body"])
    cubes = [
        Cube("body", "body", (0, 7.9, 5.6), (7, 6, 4), P["body"], body_g),
        Cube("belly", "body", (0, 8.0, 7.8), (4.6, 4.4, 0.4), P["light"], d_belly),
        Cube("head", "body", (0, 2.0, 5.6), (8, 5, 4), P["body"], head_deco(sp)),
    ]
    # ears / crest
    if sp == "cat":
        for side, sx in (("r", -1), ("l", 1)):
            piv = (sx * 2.7, -0.5, 5.6)
            rot = (0, 0, sx * 7)
            tw = None if side == "r" else "ear_r"
            cubes.append(Cube(f"ear_{side}", "body", (sx * 2.7, -1.6, 5.6), (2.6, 2.2, 1.2), P["body"],
                              d_ear_back(P["inner"]), pivot=piv, rot=rot, twin_of=tw, mirror=side == "l"))
            tt = None if side == "r" else "tip_r"
            cubes.append(Cube(f"tip_{side}", "body", (sx * 2.7, -3.3, 5.6), (1.4, 1.4, 1.0), P["body"],
                              d_ear_back(P["inner"]), pivot=piv, rot=rot, twin_of=tt, mirror=side == "l"))
    if sp == "bear":
        for side, sx in (("r", -1), ("l", 1)):
            tw = None if side == "r" else "ear_r"
            cubes.append(Cube(f"ear_{side}", "body", (sx * 3.0, -1.2, 5.6), (2.4, 2.4, 1.2), P["body"],
                              d_ear_back(P["inner"]), twin_of=tw, mirror=side == "l"))
        cubes.append(Cube("muzzle", "body", (0, 3.6, 8.1), (3, 2, 1), P["light"], d_snout("bear")))
    if sp == "dino":
        cubes.append(Cube("snout", "body", (0, 3.4, 8.6), (4, 2, 2), P["body"], d_snout("dino")))
        for i, (z, s) in enumerate(((4.4, 1.2), (5.7, 1.5), (7.0, 1.2))):
            piv = (0, -0.5, z)
            cubes.append(Cube(f"spike{i}", "body", (0, -0.5 - s * 0.7, z), (s, s * 1.4, s), P["inner"],
                              grad(mix(P["inner"], WHITE, 0.35), P["inner"])))
    # arms and legs with paw pads
    for side, sx in (("r", -1), ("l", 1)):
        tw = None if side == "r" else "arm_r"
        ah = 2.8 if sp == "dino" else 4
        cubes.append(Cube(f"arm_{side}", "body", (sx * 4.5, 5.2 + ah / 2, 5.6), (2 if sp != "dino" else 1.6, ah, 2),
                          P["body"], body_g, twin_of=tw, mirror=side == "l"))
        tl = None if side == "r" else "leg_r"
        cubes.append(Cube(f"leg_{side}", "body", (sx * 1.9, 10.9, 8.0), (2.6, 2.6, 2.6), P["body"], d_pad,
                          twin_of=tl, mirror=side == "l"))
    # tail
    if sp == "cat":
        cubes += [
            Cube("tail_a", "body", (5.2, 11.3, 5.4), (3.4, 1.4, 1.4), P["body"], d_ring(P["dark"])),
            Cube("tail_b", "body", (6.2, 9.4, 5.4), (1.4, 2.8, 1.4), P["body"], d_ring(P["dark"])),
            Cube("tail_c", "body", (6.2, 7.4, 5.4), (1.4, 1.4, 1.4), P["dark"], None),
            Cube("collar", "body", (0, 4.8, 5.6), (7.4, 1.0, 4.2), P["strap"],
                 lambda f, x, y, w, h: mix(mix(P["strap"], WHITE, 0.2), P["strap"], y / max(1, h - 1)) if f not in ("top", "bottom") else None),
            Cube("bell", "body", (0, 5.2, 7.9), (1.2, 1.2, 0.8), (240, 200, 90),
                 grad((255, 236, 150), (200, 150, 50))),
        ]
    if sp == "dino":
        cubes += [
            Cube("tail_a", "body", (5.0, 11.0, 5.4), (2.4, 2.0, 2.4), P["body"], grad(mix(P["body"], WHITE, 0.1), P["dark"])),
            Cube("tail_b", "body", (6.6, 11.4, 5.4), (1.6, 1.6, 1.6), P["body"], grad(P["body"], P["dark"])),
            Cube("tail_s", "body", (5.0, 9.75, 5.4), (1.0, 1.0, 1.0), P["inner"], None),
        ]
    if sp == "bear":
        cubes += [
            Cube("collar", "body", (0, 4.8, 5.6), (7.4, 1.0, 4.2), P["strap"], grad(mix(P["strap"], WHITE, 0.2), P["strap"])),
            Cube("knot", "body", (0, 5.0, 7.9), (1.0, 1.0, 0.6), P["strap"], grad(P["strap"], mix(P["strap"], EYE, 0.3))),
            Cube("bow_r", "body", (-1.3, 5.0, 7.9), (1.6, 1.2, 0.6), P["strap"], grad(mix(P["strap"], WHITE, 0.3), P["strap"]),
                 pivot=(-1.3, 5.0, 7.9), rot=(0, 0, -14)),
            Cube("bow_l", "body", (1.3, 5.0, 7.9), (1.6, 1.2, 0.6), P["strap"], grad(mix(P["strap"], WHITE, 0.3), P["strap"]),
                 pivot=(1.3, 5.0, 7.9), rot=(0, 0, 14), twin_of="bow_r", mirror=True),
        ]
    # shoulder straps, same layout as the normal backpack
    cubes += [
        Cube("strap_r", "body", (-2.9, 4.8, -3.65), (1.6, 9.2, 0.6), P["strap"], d_strap),
        Cube("strap_l", "body", (2.9, 4.8, -3.65), (1.6, 9.2, 0.6), P["strap"], d_strap, twin_of="strap_r", mirror=True),
        Cube("link_r", "body", (-2.9, -1.0, -0.15), (1.6, 0.6, 7.0), P["strap"], d_strap),
        Cube("link_l", "body", (2.9, -1.0, -0.15), (1.6, 0.6, 7.0), P["strap"], d_strap, twin_of="link_r", mirror=True),
        Cube("back_r", "body", (-2.9, 1.0, 3.3), (1.6, 4.0, 0.6), P["strap"], d_strap),
        Cube("back_l", "body", (2.9, 1.0, 3.3), (1.6, 4.0, 0.6), P["strap"], d_strap, twin_of="back_r", mirror=True),
    ]
    return build(f"plush_{sp}", cubes)


# ---------------------------------------------------------------- icons
def icon(sp):
    global P
    P = SPECIES[sp]
    i = Icon()
    body, light = P["body"], P["light"]
    if sp == "cat":
        for x0, sx in ((3, 1), (10, -1)):
            blk(i, x0, 1, x0 + 2, 4, body)
            i.put(x0 + (0 if sx > 0 else 2), 1, shade(body, 1.15))
            i.put(x0 + 1, 3, P["inner"])
    elif sp == "bear":
        for x0 in (2, 11):
            blk(i, x0, 2, x0 + 2, 4, body)
            i.put(x0 + 1, 3, P["inner"])
    else:
        for x0 in (5, 7, 9):
            blk(i, x0, 1, x0 + 1, 3, P["inner"])
    blk(i, 3, 3, 12, 8, body)
    for x in (5, 10):
        i.rect(x, 5, x, 6, EYE)
    i.put(5, 5, WHITE); i.put(10, 5, WHITE)
    i.put(4, 7, BLUSH); i.put(11, 7, BLUSH)
    if sp == "cat":
        i.rect(7, 6, 8, 6, P["nose"])
        i.put(7, 7, mix(P["dark"], EYE, 0.5)); i.put(8, 7, mix(P["dark"], EYE, 0.5))
        i.rect(6, 9, 9, 9, P["strap"]); i.put(7, 10, (240, 200, 90))
    elif sp == "bear":
        blk(i, 6, 6, 9, 8, light)
        i.rect(7, 6, 8, 6, P["nose"])
        i.rect(6, 9, 9, 9, P["strap"]); i.put(7, 10, P["strap"]); i.put(8, 10, P["strap"])
    else:
        blk(i, 5, 6, 10, 8, body)
        i.put(6, 6, P["nose"]); i.put(9, 6, P["nose"])
        i.rect(6, 8, 9, 8, mix(P["dark"], EYE, 0.3))
    blk(i, 4, 9 if sp == "dino" else 10, 11, 13, body)
    i.rect(6, 10 if sp == "dino" else 11, 9, 12, light)
    for x0 in (4, 8):
        blk(i, x0, 13, x0 + 2, 14, shade(body, 0.95))
        i.rect(x0, 14, x0 + 2, 14, P["pad"])
    if sp == "cat":
        blk(i, 12, 9, 13, 13, body)
        i.put(13, 8, P["dark"])
    i.save(f"plush_{sp}")


if __name__ == "__main__":
    for sp in SPECIES:
        plush(sp)
        icon(sp)
    print("plush backpacks generated:", ", ".join(SPECIES))
