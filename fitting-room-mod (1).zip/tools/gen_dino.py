#!/usr/bin/env python3
"""
Generates the dinosaur kigurumi sets of the fitting room (green: dino_*, blue: dino_blue_*): hood (hat), top,
pants (bottom, with a long spiked tail) and slippers (shoes).
Models, 32x textures and 16x16 GUI icons. Reuses Cube / Icon / layout from gen_accessories.py but paints
smoother: soft shading and clean hand-placed details instead of per-pixel noise.

Run from the project root:  python3 tools/gen_dino.py
"""
import json
import math
import sys
import zlib
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import gen_accessories as ga  # noqa: E402
from gen_accessories import ASSETS, PX, SHEET_W, Cube, Icon, layout, shade  # noqa: E402
from PIL import Image  # noqa: E402

G = (52, 124, 76)        # fleece green
GD = (38, 96, 62)        # dark green (cuffs, soles, belly line)
GB = (44, 108, 68)       # body green
GL = (92, 160, 98)       # light green (snout, toes)
BELLY = (224, 238, 164)
BELLY_D = (196, 214, 128)
SPK = (216, 232, 134)
SPK_D = (166, 190, 84)
RED = (200, 48, 60)
RED_D = (150, 32, 48)
WHITE = (250, 248, 238)
BLACK = (28, 24, 30)
CLAW = (242, 234, 200)


PREFIX = "dino"

PALETTES = {
    "dino": dict(G=(52, 124, 76), GD=(38, 96, 62), GB=(44, 108, 68), GL=(92, 160, 98),
                 BELLY=(224, 238, 164), BELLY_D=(196, 214, 128), SPK=(216, 232, 134), SPK_D=(166, 190, 84)),
    "dino_blue": dict(G=(64, 118, 190), GD=(40, 76, 140), GB=(54, 102, 170), GL=(112, 166, 224),
                      BELLY=(226, 240, 252), BELLY_D=(176, 204, 232), SPK=(254, 226, 128), SPK_D=(222, 164, 64)),
}


def mix(a, b, t):
    return tuple(int(round(a[i] + (b[i] - a[i]) * t)) for i in range(3))


# ---------------------------------------------------------------- smooth painter
LIGHT = {"top": 1.10, "bottom": 0.78, "front": 1.0, "back": 0.94, "right": 0.90, "left": 0.86}


def _soft(name, fname, cx, cy):
    """Very quiet fleece mottling on 2x2 pixel cells (a few percent), not per-pixel noise."""
    h = zlib.crc32(f"{name}/{fname}/{cx}/{cy}".encode()) & 0xFFFF  # stable between runs
    return 1.0 + ((h % 7) - 3) * 0.006


def paint(img, c):
    w, h, d = c.size
    faces = {
        "top": (d, 0, w, d), "bottom": (d + w, 0, w, d),
        "right": (0, d, d, h), "front": (d, d, w, h),
        "left": (d + w, d, d, h), "back": (2 * d + w, d, w, h),
    }
    for fname, (fx, fy, fw, fh) in faces.items():
        pw, ph = fw * PX, fh * PX
        for py in range(ph):
            for px in range(pw):
                col = c.deco(fname, px, py, pw, ph) if c.deco else None
                X = c.uv[0] * PX + fx * PX + px
                Y = c.uv[1] * PX + fy * PX + py
                if col == "clear":
                    img.putpixel((X, Y), (0, 0, 0, 0))
                    continue
                detail = col is not None
                col = col or c.base
                k = LIGHT[fname]
                if fname in ("top", "bottom"):
                    if px in (0, pw - 1) or py in (0, ph - 1):
                        k *= 0.94
                else:
                    k *= 1.05 - 0.10 * (py / max(1, ph - 1))
                    if px == 0:
                        k *= 1.03
                    elif px == pw - 1:
                        k *= 0.95
                    if py == ph - 1:
                        k *= 0.93
                if not detail:
                    k *= _soft(c.name, fname, px // 2, py // 2)
                img.putpixel((X, Y), shade(col, k) + (255,))


def build(model_id, cubes):
    rows = layout(cubes)
    img = Image.new("RGBA", (SHEET_W * PX, rows * PX), (0, 0, 0, 0))
    for c in cubes:
        if not c.twin_of:
            paint(img, c)
    (ASSETS / "textures/clothes").mkdir(parents=True, exist_ok=True)
    img.save(ASSETS / f"textures/clothes/{model_id}.png")
    model = {
        "texture": f"fittingroom:textures/clothes/{model_id}.png",
        "texture_size": [SHEET_W, rows],
        "cubes": [c.to_json() for c in cubes],
    }
    (ASSETS / "clothes_models").mkdir(parents=True, exist_ok=True)
    (ASSETS / f"clothes_models/{model_id}.json").write_text(json.dumps(model, indent=1) + "\n")
    return cubes


def grad(top, bottom):
    """Vertical colour ramp on the side faces of a part."""
    def d(f, x, y, w, h):
        if f in ("top", "bottom"):
            return None
        return mix(top, bottom, y / max(1, h - 1))
    return d


# ---------------------------------------------------------------- hood (head bone)
EYE = ["GGDDDD",
       "GDWWWD",
       "DWWKKD",
       "DWWKKD",
       "GDWWDG",
       "GGDDGG"]


def d_eye(f, x, y, w, h):
    if f != "front":
        return None
    ch = EYE[y][x]
    if (x, y) == (3, 2):
        return WHITE
    return {"D": GD, "W": WHITE, "K": BLACK}.get(ch)


TOOTH = {"front": [1, 2, 3, 2, 1, 1, 2, 3, 2, 1], "side": [1, 2, 3, 2, 1, 2, 3, 2]}


def d_teeth(f, x, y, w, h):
    if f == "top":
        return RED
    if f == "bottom":
        return RED_D
    if y == 0:
        return RED if f != "back" else None
    prof = TOOTH["front" if f in ("front", "back") else "side"]
    hh = prof[x % len(prof)]
    if y <= hh:
        return WHITE if y < hh else (232, 228, 214)
    return "clear"


def d_snout(f, x, y, w, h):
    if f == "top":
        if y in (1, 2) and x in (2, 3, 6, 7):
            return GD
        return mix(GL, G, y / max(1, h - 1) * 0.7)
    if f in ("front", "left", "right", "back"):
        return mix(GL, G, y / max(1, h - 1))
    return None


def spike(prefix, bone, x, base_y, z, s, rot=None, twin=None):
    """A two-step spike (wide base + narrow tip), pointing up, optionally tilted around the base."""
    piv = (x, base_y, z)
    base = Cube(prefix + "_b", bone, (x, base_y - 1.0 * s, z), (2 * s, 2 * s, 2 * s), SPK, grad(SPK_D, SPK),
                pivot=piv if rot else None, rot=rot, twin_of=twin and twin + "_b")
    tip = Cube(prefix + "_t", bone, (x, base_y - 2.65 * s, z), (1 * s, 1.3 * s, 1 * s), SPK, grad(SPK, mix(SPK, WHITE, 0.45)),
               pivot=piv if rot else None, rot=rot, twin_of=twin and twin + "_t")
    return [base, tip]


def hood():
    cubes = [
        Cube("hood_top", "head", (0, -6.6, 0), (9.4, 4.4, 9.4), G, grad(mix(G, GL, 0.18), G)),
        Cube("hood_back", "head", (0, -3.0, 4.6), (9.0, 7.6, 1.2), G, grad(G, GB)),
        Cube("hood_side_r", "head", (-4.7, -3.2, -0.3), (1.0, 7.2, 7.6), G, grad(G, GB)),
        Cube("hood_side_l", "head", (4.7, -3.2, -0.3), (1.0, 7.2, 7.6), G, grad(G, GB),
             twin_of="hood_side_r", mirror=True),
        Cube("trim_r", "head", (-4.7, -3.4, -3.9), (1.2, 6.8, 0.9), RED, grad(RED, RED_D)),
        Cube("trim_l", "head", (4.7, -3.4, -3.9), (1.2, 6.8, 0.9), RED, grad(RED, RED_D),
             twin_of="trim_r", mirror=True),
        Cube("eye_r", "head", (-3.4, -6.6, -5.2), (3, 3, 1), G, d_eye),
        Cube("eye_l", "head", (3.4, -6.6, -5.2), (3, 3, 1), G, d_eye, twin_of="eye_r", mirror=True),
        Cube("snout", "head", (0, -6.9, -6.7), (5, 3, 4), GL, d_snout),
        Cube("teeth", "head", (0, -4.4, -6.7), (5, 2, 4), RED, d_teeth),
    ]
    cubes += spike("crest_a", "head", 0, -8.8, -2.4, 1.0, rot=(-12, 0, 0))
    cubes += spike("crest_b", "head", 0, -8.8, 0.9, 1.1, rot=(-12, 0, 0))
    cubes += spike("crest_c", "head", 0, -8.8, 4.0, 0.8, rot=(-12, 0, 0))
    return build(PREFIX + "_hood", cubes)


# ---------------------------------------------------------------- top
def d_belly(f, x, y, w, h):
    if f != "front":
        return mix(BELLY, BELLY_D, 0.5) if f in ("left", "right") else None
    if x in (0, w - 1) or y in (0, h - 1):
        return BELLY_D
    if y % 6 == 5 and 1 <= x <= w - 2:
        return mix(BELLY, BELLY_D, 0.45)
    if x in (3, 4) and y in (4, 5, 11, 12, 18, 19):
        return mix(GD, BELLY, 0.45) if (x, y) in ((3, 4), (3, 11), (3, 18)) else mix(GD, BLACK, 0.25)
    return mix(mix(BELLY, WHITE, 0.45), BELLY, y / max(1, h - 1))


def d_rib(f, x, y, w, h):
    if f in ("top", "bottom"):
        return None
    return mix(GD, BLACK, 0.12) if x % 2 == 0 else mix(GD, G, 0.18)


def top():
    cubes = [
        Cube("body", "body", (0, 6.0, 0), (9.5, 12.8, 5.5), GB, grad(mix(GB, G, 0.4), GB)),
        Cube("belly", "body", (0, 6.3, -2.9), (6, 12, 0.5), BELLY, d_belly),
        Cube("collar", "body", (0, -0.1, 0), (9.9, 1.6, 5.9), RED, grad(mix(RED, (240, 120, 120), 0.2), RED_D)),
        Cube("sleeve_r", "right_arm", (-1, 2.65, 0), (5.5, 10.0, 5.5), G, grad(mix(G, GL, 0.15), G)),
        Cube("cuff_r", "right_arm", (-1, 8.3, 0), (5.8, 3.0, 5.8), GD, d_rib),
        Cube("sleeve_l", "left_arm", (1, 2.65, 0), (5.5, 10.0, 5.5), G, grad(mix(G, GL, 0.15), G),
             twin_of="sleeve_r", mirror=True),
        Cube("cuff_l", "left_arm", (1, 8.3, 0), (5.8, 3.0, 5.8), GD, d_rib, twin_of="cuff_r", mirror=True),
    ]
    # three plates down the spine, pointing backwards
    for i, y in enumerate((2.2, 5.6, 9.0)):
        t = None if i == 0 else "plate0"
        cubes.append(Cube(f"plate{i}_b", "body", (0, y, 3.55), (2.2, 2.4, 1.6), SPK, grad(SPK, SPK_D),
                          twin_of=None if i == 0 else "plate0_b"))
        cubes.append(Cube(f"plate{i}_t", "body", (0, y, 4.6), (1.2, 1.4, 1.0), SPK, grad(SPK, mix(SPK, WHITE, 0.45)),
                          twin_of=None if i == 0 else "plate0_t"))
    return build(PREFIX + "_top", cubes)


# ---------------------------------------------------------------- pants with a spiked tail
def pants():
    cubes = [
        Cube("waist", "body", (0, 11.4, 0), (9.5, 3.2, 5.5), GB, grad(GB, mix(GB, GD, 0.3))),
        Cube("leg_r", "right_leg", (-0.1, 4.0, 0), (5.4, 9.0, 5.4), G, grad(mix(G, GL, 0.12), G)),
        Cube("leg_l", "left_leg", (0.1, 4.0, 0), (5.4, 9.0, 5.4), G, grad(mix(G, GL, 0.12), G),
             twin_of="leg_r", mirror=True),
    ]
    # tail: five segments hanging down and getting thinner, spikes on top
    py, pz = 10.6, 2.6
    length = 3.0
    widths = (4.0, 3.4, 2.8, 2.2, 1.6)
    angles = (6, 16, 28, 40, 52)
    for i, (w, ang) in enumerate(zip(widths, angles)):
        rot = (-ang, 0, 0)
        piv = (0, py, pz)

        def d_tail(f, x, y, ww, hh, i=i):
            if f == "bottom":
                return mix(BELLY_D, BELLY, 0.4)
            if f in ("front", "back", "left", "right"):
                return mix(mix(G, GL, 0.12), mix(G, GD, 0.35), y / max(1, hh - 1))
            return None

        cubes.append(Cube(f"tail{i}", "body", (0, py, pz + length / 2), (w, w, length), G, d_tail, pivot=piv, rot=rot))
        if i < 4:
            s = 1.5 - 0.2 * i
            cubes.append(Cube(f"tspike{i}", "body", (0, py - w / 2 - s / 2 + 0.2, pz + length / 2), (s, s, s), SPK,
                              grad(SPK, SPK_D), pivot=piv, rot=rot))
        py += math.sin(math.radians(ang)) * length
        pz += math.cos(math.radians(ang)) * length
    return build(PREFIX + "_pants", cubes)


# ---------------------------------------------------------------- slippers
def slippers():
    cubes = []
    for side, sx in (("r", -1), ("l", 1)):
        tw = (lambda n: None) if side == "r" else (lambda n: n + "_r")
        m = side == "l"
        ox = sx * 0.1
        bone = "right_leg" if side == "r" else "left_leg"
        cubes += [
            Cube(f"boot_{side}", bone, (ox, 9.8, 0), (5.6, 4.4, 5.6), G, grad(mix(G, GL, 0.1), G),
                 twin_of=tw("boot"), mirror=m),
            Cube(f"rim_{side}", bone, (ox, 7.7, 0), (5.9, 1.0, 5.9), GD, d_rib, twin_of=tw("rim"), mirror=m),
            Cube(f"toe_{side}", bone, (ox, 10.7, -3.6), (5, 3, 3), GL, grad(mix(GL, (140, 200, 130), 0.3), GL),
                 twin_of=tw("toe"), mirror=m),
            Cube(f"sole_{side}", bone, (ox, 11.55, -1.1), (5.8, 0.9, 8.4), GD, None, twin_of=tw("sole"), mirror=m),
        ]
        for j, cx in enumerate((-1.5, 0.0, 1.5)):
            first = (side == "r" and j == 0)
            cubes.append(Cube(f"claw{j}_{side}", bone, (ox + cx, 11.1, -5.6), (1, 1, 2), CLAW,
                              grad(CLAW, mix(CLAW, (200, 190, 150), 0.7)),
                              twin_of=None if first else "claw0_r", mirror=m))
    return build(PREFIX + "_slippers", cubes)


# ---------------------------------------------------------------- icons
def blk(i, x0, y0, x1, y1, col):
    i.rect(x0, y0, x1, y1, col)
    i.rect(x0, y0, x1, y0, shade(col, 1.16))
    i.rect(x0, y0, x0, y1, shade(col, 1.08))
    i.rect(x1, y0, x1, y1, shade(col, 0.84))
    i.rect(x0, y1, x1, y1, shade(col, 0.76))
    i.put(x0, y0, shade(col, 1.2))


def icon_hood():
    i = Icon()
    blk(i, 5, 1, 6, 3, SPK)
    blk(i, 9, 1, 10, 3, SPK)
    blk(i, 7, 0, 8, 3, SPK)
    blk(i, 3, 3, 12, 13, G)
    i.px.pop((3, 3)); i.px.pop((12, 3))
    blk(i, 4, 5, 5, 6, WHITE)
    blk(i, 10, 5, 11, 6, WHITE)
    i.put(5, 6, BLACK); i.put(10, 6, BLACK); i.put(5, 5, BLACK); i.put(10, 5, BLACK)
    i.rect(4, 4, 5, 4, GD); i.rect(10, 4, 11, 4, GD)
    blk(i, 5, 7, 10, 9, GL)
    i.put(6, 7, GD); i.put(9, 7, GD)
    i.rect(5, 10, 10, 10, RED)
    i.rect(5, 11, 10, 11, WHITE)
    i.put(6, 12, WHITE); i.put(9, 12, WHITE)
    i.rect(3, 12, 4, 13, RED_D); i.rect(11, 12, 12, 13, RED_D)
    i.save(PREFIX + "_hood")


def icon_top():
    i = Icon()
    blk(i, 1, 4, 3, 11, G)
    blk(i, 12, 4, 14, 11, G)
    blk(i, 1, 10, 3, 12, GD)
    blk(i, 12, 10, 14, 12, GD)
    blk(i, 4, 3, 11, 14, GB)
    blk(i, 6, 5, 9, 14, BELLY)
    i.rect(4, 3, 11, 4, RED)
    i.rect(4, 4, 11, 4, RED_D)
    for y in (7, 10, 13):
        i.put(7, y, mix(GD, BLACK, 0.25))
    i.rect(6, 9, 9, 9, mix(BELLY, BELLY_D, 0.5)); i.rect(6, 12, 9, 12, mix(BELLY, BELLY_D, 0.5))
    i.save(PREFIX + "_top")


def icon_pants():
    i = Icon()
    blk(i, 3, 3, 11, 5, GB)
    blk(i, 3, 6, 7, 14, G)
    blk(i, 8, 6, 11, 14, G)
    i.rect(9, 6, 9, 14, shade(G, 0.86))
    blk(i, 12, 4, 14, 6, G)
    blk(i, 13, 7, 14, 9, G)
    blk(i, 13, 10, 14, 12, shade(G, 0.9))
    i.put(12, 3, SPK); i.put(13, 3, SPK); i.put(14, 6, SPK); i.put(12, 8, SPK)
    i.save(PREFIX + "_pants")


def icon_slippers():
    i = Icon()
    for x0 in (1, 9):
        blk(i, x0 + 1, 3, x0 + 4, 4, GD)
        blk(i, x0 + 1, 5, x0 + 4, 9, G)
        blk(i, x0, 9, x0 + 5, 12, GL)
        i.rect(x0, 13, x0 + 5, 13, GD)
        for cx in (x0, x0 + 2, x0 + 4):
            i.put(cx, 13, CLAW)
            i.put(cx, 14, mix(CLAW, (200, 190, 150), 0.7))
    i.save(PREFIX + "_slippers")


if __name__ == "__main__":
    for prefix, palette in PALETTES.items():
        PREFIX = prefix
        globals().update(palette)
        for fn in (hood, top, pants, slippers, icon_hood, icon_top, icon_pants, icon_slippers):
            fn()
    print("dino generated:", ", ".join(PALETTES))
