Optional: put aestheticjobs-0.8.0.jar here to have the real bank in runClient.
The mod compiles without it (the bank is reached through reflection), so CI needs nothing here.
