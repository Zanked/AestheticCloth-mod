# Clothes models

Every garment is a JSON file in `assets/fittingroom/clothes_models/<id>.json` plus a texture.
Garments are made of cubes attached to the player's bones. All numbers are in Minecraft model units
(1 unit = 1/16 block). Textures are 32x: the PNG is twice as big as `texture_size`
(`texture_size` is the layout in units, the PNG has 2 pixels per unit).

```json
{
  "texture": "fittingroom:textures/clothes/santa_hat.png",
  "texture_size": [64, 26],
  "cubes": [
    { "name": "band", "bone": "head",
      "pos": [-4.0, -7.0, -4.0],     // corner of the cube, relative to the bone's pivot (vanilla model space)
      "size": [8, 2, 8],             // integers: the texture layout is a normal box unwrap
      "uv": [0, 0],                  // top-left of the unwrap in `texture_size` units
      "grow": [0.95, 0.95, 0.95],    // makes the cube bigger on every side without changing the unwrap
      "mirror": false,               // true for the left twin of a right-hand cube (same uv)
      "pivot": [0, 0, 0], "rot": [0, 0, 0]   // optional: rotation in degrees around `pivot`
    }
  ]
}
```
Bones: `head`, `body`, `right_arm`, `left_arm`, `right_leg`, `left_leg`. The format is the same as a
Blockbench "Modded Entity" (Java) model, so a model made there can be converted to it.
Reload with F3+T while the game is running.

`gen_santa3d.py` in the project builder writes these files; the cubes are described there with
simpler coordinates (player's right = +x, up = +y, front = -z).

## Slim (Alex) arms
Models are authored for the 4-wide Steve arm. For players with slim arms the loader automatically squeezes
every cube on `right_arm` / `left_arm` (without `rot`) to 3/4 of its width in X and centres it on the 3-wide arm,
so the same JSON and texture work for both skin types. Nothing to do in the model files.

## Seasonal clothes
`ClothingCatalog` can limit a garment to a period of the year (`Item.seasonFrom` / `seasonTo`).
The Santa set is only available from December 15th to January 14th: outside of it the clothes are not shown
in the fitting room, cannot be put on (the server checks the date too) and are not drawn on players
(what a player saved stays and comes back with the next season).
To test, start the game with `-Dfittingroom.date=2026-12-31`.

## Cat costume
`cat_ears` (hat), `cat_sweater` (top), `cat_pants` (bottom, with a tail made of 4 rotated segments on the body bone)
and `cat_paws` (shoes). Textures are 2 px per unit like all the others.

## Accessories
The "Accessories" tab holds `casual_backpack` (straps + bag on the back), `punk_cuffs` (leather wristbands with
spikes on both forearms; the top/bottom faces of the ring are transparent so the arm goes through it) and
`santa_sack` (a seasonal gift sack with a rope strap, New Year season like the rest of the Santa set).
Only one accessory can be worn at a time. They are drawn above the tops and below the hats.
Note for arms: cubes on `right_arm` / `left_arm` without `rot` are re-centred on the arm for slim skins, so all
arm accessories must sit in the middle of the arm (that is why the cuff spikes are only on the front and back).
`python3 tools/gen_accessories.py` regenerates the models, textures and icons of these three.

### Glasses
`glasses_round`, `glasses_sun`, `glasses_heart`, `glasses_3d` and `glasses_pixel` are cubes on the `head` bone:
lenses at x = +-2, y = -3, in front of the face (z about -4.7, outside the skin's hat layer), plus a bridge and
two arms along the sides of the head. Clear parts (the middle of the round frames, the outside of the hearts) are
transparent pixels in the texture. They live in the Accessories tab, so they replace the backpack/cuffs/sack
(one accessory at a time). `tools/gen_accessories.py` regenerates them too.

