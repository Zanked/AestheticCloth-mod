# Clothes models

Every garment is a JSON file in `assets/fittingroom/clothes_models/<id>.json` plus a texture.
Garments are made of cubes attached to the player's bones. All numbers are in Minecraft model units
(1 unit = 1/16 block). Textures are 32x: the PNG is twice as big as `texture_size`
(`texture_size` is the layout in units, the PNG has 2 pixels per unit).

```json
{
  "texture": "fittingroom:textures/clothes/santa_hat.png",
  "texture_size": [64, 26],
  "cubes": [
    { "name": "band", "bone": "head",
      "pos": [-4.0, -7.0, -4.0],     // corner of the cube, relative to the bone's pivot (vanilla model space)
      "size": [8, 2, 8],             // integers: the texture layout is a normal box unwrap
      "uv": [0, 0],                  // top-left of the unwrap in `texture_size` units
      "grow": [0.95, 0.95, 0.95],    // makes the cube bigger on every side without changing the unwrap
      "mirror": false,               // true for the left twin of a right-hand cube (same uv)
      "pivot": [0, 0, 0], "rot": [0, 0, 0]   // optional: rotation in degrees around `pivot`
    }
  ]
}
```
Bones: `head`, `body`, `right_arm`, `left_arm`, `right_leg`, `left_leg`. The format is the same as a
Blockbench "Modded Entity" (Java) model, so a model made there can be converted to it.
Reload with F3+T while the game is running.

`gen_santa3d.py` in the project builder writes these files; the cubes are described there with
simpler coordinates (player's right = +x, up = +y, front = -z).

## Slim (Alex) arms
Models are authored for the 4-wide Steve arm. For players with slim arms the loader automatically squeezes
every cube on `right_arm` / `left_arm` (without `rot`) to 3/4 of its width in X and centres it on the 3-wide arm,
so the same JSON and texture work for both skin types. Nothing to do in the model files.

## Seasonal clothes
`ClothingCatalog` can limit a garment to a period of the year (`Item.seasonFrom` / `seasonTo`).
The Santa set is only available from December 15th to January 14th: outside of it the clothes are not shown
in the fitting room, cannot be put on (the server checks the date too) and are not drawn on players
(what a player saved stays and comes back with the next season).
To test, start the game with `-Dfittingroom.date=2026-12-31`.

## Cat costume
`cat_ears` (hat), `cat_sweater` (top), `cat_pants` (bottom, with a tail made of 4 rotated segments on the body bone)
and `cat_paws` (shoes). Textures are 2 px per unit like all the others.

## Dino kigurumi
`dino_hood` (hat: green hood with a snout, teeth hanging from it, two angry eyes, red lining and a spiky crest),
`dino_top` (onesie top with a light belly panel with buttons, red collar, ribbed cuffs and plates down the back),
`dino_pants` (onesie bottom with a long tail of five segments, bent down, with spikes on top) and `dino_slippers`
(green boots with ribbed rims and three claws on each foot). Teeth are drawn as transparent pixels between the
white triangles, so they really are zigzag. `python3 tools/gen_dino.py` regenerates the models, textures and icons.
The set comes in two colours: green (`dino_*`) and blue (`dino_blue_*`, cream-yellow spikes, white-blue belly);
the palettes are at the top of the script, so another colour is one more entry in `PALETTES` plus its items in
`ClothingCatalog`, `clothes.json` and the lang files.
Unlike the older generator this one paints soft shading and clean details instead of per-pixel noise.

## Japanese school uniform
`school_bow` (hat: red hair ribbon on the side of the head), `school_top` (sailor blouse: white, short sleeves with a
navy cuff and a white stripe, navy sailor collar with two white stripes, red ribbon bow), `school_skirt` (bottom: navy
plaid pleated skirt in two flared tiers; the pleat creases are painted into the texture), `school_socks` (shoes: white
knee socks with a navy band and black loafers) and `school_bag` (accessory: leather satchel carried in the right hand,
it hangs from a handle loop and swings with the arm). `python3 tools/gen_school.py` regenerates the set; it reuses the
smooth painter of `gen_dino.py`.

The school uniform also comes in black (`school_black_*`: black blouse and plaid skirt with the white collar stripes,
black knee socks, brown loafers, black satchel with a silver clasp). The palettes are at the top of `gen_school.py`.

## Boys' school uniform (gakuran)
`boy_cap` (hat: black peaked cap with a gold emblem on the band and a tilted visor), `boy_gakuran` (top: black
jacket with five gold buttons, a white collar tab, gold collar badges, pocket flaps and long sleeves with cuffs),
`boy_trousers` (bottom: black trousers with a pressed crease and a belt with a silver buckle) and `boy_shoes` (shoes:
black laced shoes). The satchel of the girls' set (`school_black_bag`) goes with it. `python3 tools/gen_school_boy.py`
regenerates the set.

## Plush backpacks
`plush_cat`, `plush_dino` and `plush_bear` (accessories): a soft toy sits on the back and looks at whoever stands
behind the player. Each one has a head with glossy eyes and blush, a body with a light belly oval, little arms, legs
with paw pads and shoulder straps laid out like the normal backpack. Cat: ears with a pink inside, a ringed tail and a
collar with a bell. Dino: a snout, three crest spikes and a short tail. Bear: round ears, a muzzle and a red bow.
`python3 tools/gen_plush.py` regenerates all three; to add another animal, add an entry to `SPECIES` and its ears/tail.

## Balloons and gloves (accessories, several colours)
`balloon_<colour>` (red, pink, blue, yellow, green, purple): a glossy balloon built from layered cubes (each layer
twice, turned 45 degrees, so it looks round) on a thin string held in the right hand; it floats beside the head and
swings with the arm. `balloon_bunch_rainbow` and `balloon_bunch_pastel` hold three balloons on three strings.
`gloves_<colour>` (white, black, red, pink, blue, yellow, green, purple): short gloves with finger lines and a ribbed
cuff on both hands. Colours are the `COLOURS` dict of `python3 tools/gen_balloons_gloves.py`; a new colour is one
entry there plus the items in `ClothingCatalog`, `clothes.json` and the lang files.

## Accessories
The "Accessories" tab holds `casual_backpack` (straps + bag on the back), `punk_cuffs` (leather wristbands with
spikes on both forearms; the top/bottom faces of the ring are transparent so the arm goes through it) and
`santa_sack` (a seasonal gift sack with a rope strap, New Year season like the rest of the Santa set).
Only one accessory can be worn at a time. They are drawn above the tops and below the hats.
Note for arms: cubes on `right_arm` / `left_arm` without `rot` are re-centred on the arm for slim skins, so all
arm accessories must sit in the middle of the arm (that is why the cuff spikes are only on the front and back).
`python3 tools/gen_accessories.py` regenerates the models, textures and icons of these three.

### Glasses
`glasses_round`, `glasses_sun`, `glasses_heart`, `glasses_3d` and `glasses_pixel` are cubes on the `head` bone:
lenses at x = +-2, y = -3, in front of the face (z about -4.7, outside the skin's hat layer), plus a bridge and
two arms along the sides of the head. Clear parts (the middle of the round frames, the outside of the hearts) are
transparent pixels in the texture. They live in the Accessories tab, so they replace the backpack/cuffs/sack
(one accessory at a time). `tools/gen_accessories.py` regenerates them too.


### Flicker (z-fighting)
Two faces that lie in the same plane, look the same way and overlap flicker in game, because the GPU cannot decide
which one is in front. This happens between two cubes of one garment, and between a cube and the player's own skin
layers (hat layer = head +0.5, jacket/sleeves/pants = +0.25). `tools/zfight.py` finds such pairs and fixes them by
making the cube that must stay on top a hair bigger (`grow`, 0.03 units) on the axis of the clashing face; UVs and
textures are not touched. The generators call it automatically in `build()`; for hand-edited JSON run
`python3 tools/zfight.py` (fix) or `python3 tools/zfight.py --check` (report only, exit code 1 on flicker).
Rotated cubes are skipped. Clashes between two *different* garments worn together are not covered.

### Backpack straps
Front strap, shoulder link and back strap must touch each other: the front strap starts right under the link
(y = -0.7) and the link reaches the strap's front plane (z = -3.95). Balloons are lifted (`LIFT` in
`tools/gen_balloons_gloves.py`) so the lowest knot is above the head's hat layer and they never hide the model.

### Scarves
`scarf_red`, `scarf_blue`, `scarf_pink` (pom-poms), `scarf_plaid`, `scarf_rainbow` and `scarf_xmas` (New Year season)
are in the Accessories tab but in their own slot (`slot: "neck"` in `clothes.json`, `ClothingCatalog.NECK`), so a
scarf can be worn together with a backpack, glasses or gloves; one scarf at a time. Two rings on the `body` bone sit
outside every top and the skin's hat layer, the knot is on the front left, two tails hang down the chest tilted 12
degrees towards the body. They are drawn above the tops and below the other accessories.
`python3 tools/gen_scarves.py` regenerates the models, textures and icons.

## Casual wear (more)
`casual_tee_*` (T-shirts: white, black with a star, pink with a heart, striped), `casual_shorts_*` (denim, black, khaki),
`casual_skirt_*` (denim, pink pleated, red plaid), `casual_cardigan_*` (cream, pink, blue; buttons, pockets, ribbed
hem and cuffs) and `casual_kedy_*` (high-top canvas sneakers: white, red, black). `python3 tools/gen_casual.py`
regenerates them and registers the items in `clothes.json`, the lang files and `ClothingCatalog`.

## Jewelry
Accessories with their own slots (`choker`, `necklace`, `wrist`), so one of each can be worn together with a backpack,
glasses, a scarf and gloves. `choker_*` (punk black leather strap with silver spikes, black velvet with a heart, pink ribbon with a bow, white lace with a pearl,
silver chain with a star) and `necklace_*` (pearls, gold chain with a heart, silver chain with a star, rainbow beads)
sit on the chest in front of every top; charms are flat shapes cut out of the texture with transparent pixels.
`bracelet_*` (gold bangles, silver charm bracelet, beaded, friendship) are rings round both wrists, drawn over gloves
(they are slightly wider than a bare arm, so over long sleeves they sit on the cuff). `python3 tools/gen_jewelry.py`
regenerates the set and registers it.

## Punk leather jacket and combat boots
`punk_jacket_*` (top, black and brown): biker leather jacket with wide lapels, a zipper, zipped pockets, a belt with a
buckle, three silver studs on each shoulder and zipped cuffs. `punk_boots_*` (shoes, black with red laces and brown
with cream laces): combat boots with a laced shaft and eyelets, a folded rim, a buckled ankle strap, a toe cap and a
thick lugged sole. They go with `punk_tee`, `punk_jeans`, `punk_cuffs` and the spiked choker.
`python3 tools/gen_punk.py` regenerates them and registers the items.

### Player's own skin layers
The clothes are drawn on top of the player's skin, and the skin has its own outer layer (sweater, jacket, trousers
painted on it). The garment boxes are not exactly as tall as that layer, so parts of the skin's clothes used to
peek out (for example the hem of the skin's sweater under the belt of the leather jacket). `SkinLayerHider`
therefore hides the jacket and both sleeves of the skin while any garment of the "top" category is worn, and both
trouser legs while any "bottom" garment is worn. The hat layer (hair) is not touched.

## More New Year clothes (seasonal, Dec 15 - Jan 14)
All of them follow the same season as the Santa set (`newYear(...)` in `ClothingCatalog`), so they are also covered
by the New Year sale (-20%). `python3 tools/gen_newyear.py` regenerates the models, textures, icons and (idempotently)
the entries in `clothes.json`, the lang files, `ClothingCatalog.java` and `ClothingPrices.java`.
- **Reindeer:** `reindeer_antlers` (hat): brown headband over the head with two branching antlers (a beam and three
  tines each, tilted with `rot`) and a red nose on the face.
- **Snow Maiden (Snegurochka):** `snow_kokoshnik` (hat: blue fan-shaped kokoshnik with silver edging and pearls; it also
  carries a long blonde braid on the `body` bone with a blue ribbon), `snow_coat` (top: blue fur coat with a white fur
  collar, front panel, hem and cuffs and silver embroidery) and `snow_valenki` (shoes: white felt boots with a blue
  ornament and a rolled cuff). Any skirt or the Santa trousers go with it.
- **Sweater:** `xmas_sweater` (top): red knit with a white snowflake yoke, green fir trees and ribbed hem/cuffs.
- **Accessories:** `candy_cane` (carried in the right hand, crook pointing outwards), `necklace_snowflake` (slot
  `necklace`) and `bracelet_bells` (slot `wrist`, red-green ribbon with golden bells, both wrists).

Note for arm parts that sit off-centre (the cane's crook, the bells): on slim (Alex) arms the loader re-centres every
arm cube that has no `rot`. These cubes therefore get a tiny rotation (`keep()` in the generator), which makes the
loader leave their authored X position alone.

## More hats (all year)
Ten hats without a season, all in the Hats tab (`python3 tools/gen_hats.py` regenerates models, textures and icons and
registers the items idempotently in `clothes.json`, the lang files, `ClothingCatalog` and `ClothingPrices`).
- `hat_witch`: wide brim, gold buckle and a cone of five boxes that bends backwards, with little gold stars.
- `hat_mushroom`: layered red fly-agaric cap with white spots and cream gills on the underside of the brim.
- `hat_crown`: gold band with eight spikes (pearl tips on the tall ones) and a ruby, two sapphires and an emerald.
- `hat_bunny`: pink headband with a bow, one straight ear and one floppy ear made of six bent segments.
- `hat_frog`: green beanie with two big eyes on top (pupils on the front face, green eyelids).
- `hat_halo`: octagon of eight bars (each turned with `rot` around its own centre) floating over the head on a wire.
- `hat_chef`: tall pleated chef hat with a small red heart on the front.
- `hat_propeller`: beanie with four colour panels, a button, a stick and two crossed blades.
- `hat_strawberry`: red beanie with seeds painted in a staggered grid and a calyx of four tilted leaves.
- `hat_flowers`: leafy wreath with eight daisies; the flowers are turned around their centres (`rot`) to follow the head
  and their petals are cut out of the texture with transparent pixels.
Bent parts (ears, the witch cone) are built by `chain()` in the script: every box is a bit longer than its step, so the
joints close even on the outside of a bend.

## Dresses, outerwear, sweaters, kimono, pajamas
`python3 tools/gen_outerwear.py` regenerates the models, textures, icons and (idempotently) the entries in `clothes.json`,
the lang files, `ClothingCatalog` and `ClothingPrices`. Everything is a "top" except the pajama pants (bottom). Tops are
drawn above bottoms, so a long garment goes over trousers.
- **Dresses** (`dress_floral`, `dress_sundress`, `dress_evening`, `dress_polka`): bodice + waist band + two or three flared skirt
  tiers on the `body` bone (it does not swing with the legs, like the skirts). Floral: puff sleeves, daisy print, back bow.
  Sundress: no sleeves, the bodice rows above the straps are transparent pixels so the arms and shoulders stay bare.
  Evening gown: strapless, three tiers down to the calf, gold hem and a gem. Polka dot: white peter-pan collar, red tie.
- **Windbreakers** (`windbreaker_blue/pink/yellow`): colour-block zip jacket, stand collar, hood down on the back, elastic hem and cuffs.
- **Trench coats** (`trench_beige/black`): double-breasted, belt with a buckle, shoulder straps, cuff straps, knee-length skirt.
- **Coats** (`coat_camel` single-breasted with lapels, `coat_gray` double-breasted, `coat_red` flared with a white round collar).
- **Sweaters** (`sweater_cable`, `sweater_nordic`, `sweater_pink` oversize with a heart, `sweater_stripe`).
- **Kimono / yukata** (`kimono_sakura`, `kimono_red`, `yukata_indigo`, `yukata_light`): wrapped collar painted on the front, obi with a
  big bow and two tails on the back, long hanging sleeves (`hang_*`: a 9.6 wide box centred on the arm, its inner half is hidden in the torso, so slim
  arms squeeze it like the sleeve and it never floats away from the arm). Yukata has shorter sleeves.
- **Pajamas** (`pajama_stars_*`, `pajama_hearts_*`, `pajama_stripe_*`, each a `_top` and `_pants`): buttoned top with piping and a
  chest pocket, trousers with a drawstring waistband and ribbed cuffs.
Colours, patterns and prices are the dicts at the top of each section of the script, so another colour is one more entry.

## Beanies, berets, panamas and cowboy hats
`python3 tools/gen_hats_more.py` regenerates twelve all-year hats (models, textures, icons) and registers them in `clothes.json`,
the lang files, `ClothingCatalog` and `ClothingPrices` through the same `register()` as `gen_hats.py`.
- `hat_beanie_gray/mustard/pink`: ribbed folded cuff, slouchy knit crown; the mustard and pink ones have a fluffy pom-pom, the pink one is striped.
- `hat_beret_red/black/cream`: flat disc made of four layers, tilted 9 degrees with `rot`, with a stem on top and a darker lining band.
- `hat_panama_natural/white/pink`: woven straw texture (checker of 2x2 pixels), two-step brim, ribbon with a bow, pinched crown with a groove.
- `hat_cowboy_brown/black/cream`: wide brim whose two side flaps are turned up 24 degrees, creased crown (two halves and a groove),
  pinched front, band with a silver or turquoise concho.

## Bags, umbrellas, wings, sleep masks and earrings
`python3 tools/gen_accessories2.py` regenerates 16 accessories and registers them (also adds the slots `BAG`, `MASK` and `EARRINGS`
to `ClothingCatalog`, so a bag, a mask and earrings can be worn together with each other and with the other jewelry).
- `bag_brown/pink/black` (slot `bag`): a bag on the left hip, a strap that crosses the chest and the back from the right shoulder
  (two flat boxes turned 36.5 degrees, plus a piece over the shoulder). Satchel with a flap and a clasp, heart purse, quilted bag on a gold chain.
- `umbrella_pink/rainbow/black` (main accessory slot): an open umbrella in the right hand, the pole leans a little outwards and back
  so the canopy floats beside the head. Each canopy layer is two boxes, one turned 45 degrees, so it looks round (like the balloons).
  Handle, hook and pole are `right_arm` cubes (`keep()` so slim arms do not squeeze them).
- `wings_angel/butterfly/bat` (main accessory slot): six feather rows per wing on the `body` bone, swept back 26 degrees around the
  root; the left wing is the mirrored twin of the right one. The tips are cut out with transparent pixels.
- `mask_pink/black/lavender` (slot `mask`): elastic band round the head and a patch over the eyes with closed lashes painted on it.
- `earring_pearl/hoop/star/heart` (slot `earrings`): on both sides of the head, below the hat layer; the charms are cut out of a flat box.

## Rain boots, ballet flats, platform boots and bunny slippers
`python3 tools/gen_shoes.py` regenerates twelve shoes (models, textures, icons) and registers them (category `shoes`).
All cubes sit on the leg bones; the foot is the same as in `casual_kedy_*` (sole at y = 11.85 to 12.2, toe towards -z).
- `shoes_rain_yellow/red/pink`: tall glossy rubber boots (shaft + folded cuff + toe cap + dark sole), the pink ones have white dots.
- `shoes_ballet_pink/black/white`: low satin flats made of a vamp, a heel and a toe piece, a bow on the toe and two ribbons round the ankle.
- `shoes_platform_black/white/pink`: ankle boots with laces, metal eyelets, an ankle strap and a thick 1.9 unit platform sole.
- `shoes_bunny_white/pink/gray`: fluffy slippers (dithered fur texture), a face with eyes and a nose on the toe and two ears standing
  on the toe (`ear0` / `ear1`).

## More trousers, leggings, long skirts and overalls
`python3 tools/gen_bottoms.py` regenerates fifteen lower-body items (models, textures, icons) and registers them.
- `pants_*` (bottom): ankle-length trousers made of two leg cubes (10.4 units, so shoes and ankles show below), a belt on the body bone and
  a kind-specific detail: ripped jeans have transparent holes at the knees (skin shows), `jeans_flared` a wide flared hem, trousers a crease,
  cargo pants two side pocket boxes, sweatpants side stripes and ribbed cuffs, leggings a tighter fit (4.4 units).
- `skirt_maxi_floral`, `skirt_maxi_satin` (three flared tiers down to y = 20.6) and `skirt_tennis` (two short pleated tiers with stripes):
  hang on the body bone, so they do not swing with the legs, like the other skirts.
- `overalls_denim`, `overalls_cord` (**top** slot, because tops are drawn over bottoms): tee + hip part + bib + straps (flat boxes in front,
  behind and over the shoulders) + trousers legs; wear them with any shoes, but not with another top.

## Halloween
`python3 tools/gen_halloween.py` regenerates fifteen Halloween items (models, textures, icons) and registers them. They are not
seasonal (they show all year); to make them seasonal give them the `season` window and the `newYear(...)`-like constructor, as the
New Year items do.
- Hats: `halloween_pumpkin_hat` (three pumpkin segments with a carved glowing face, stem and leaf), `halloween_ghost_hood`
  (a sheet cube with a face and three hem cubes of different heights), `halloween_bat_headband` (bats on wires, flapping wing boxes),
  `halloween_devil_horns` (two `chain()` horns bent outwards).
- Tops: `halloween_ghost_sheet` (long sheet, ragged sleeves and hem), `halloween_vampire_cape` (shirt + vest + bow + cape with a red
  lining, tilted 6 degrees, tall collar made of three boxes), `halloween_witch_dress` (ragged five-piece hem, orange belt),
  `halloween_skeleton_top`/`_pants` (bones painted on black), `halloween_mummy_top`/`_pants` (diagonal bandage wraps, loose ends).
- `halloween_devil_pants`: trousers with a red stripe and a six-segment tail that curls up, with a spade on the tip.
- `halloween_witch_boots`: pointed boots with a curled toe made of three boxes, a golden buckle and orange-and-black striped socks.
- `halloween_candy_bucket`: a pumpkin pail on a wire handle in the right hand (`right_arm` cubes, `keep()`), candies peek out.
- `necklace_spider` (slot `necklace`): chain + a black spider with four crossed legs.

## Flicker between garments, and the shoulders
- `tools/zfight_cross.py` finds (and with no flag or `--all` fixes) faces of two different garments that can be worn together
  (different category or accessory slot) and lie in the same plane, e.g. a skirt band exactly as wide as the tee over it. The garment
  that is drawn on top (bottom < shoes < top < hat < accessory) gets the clashing cube a hair bigger (`grow`). After running the generators
  run `python3 tools/zfight_cross.py --all`; it repeats `zfight.py` and itself until nothing changes. `--check` only reports.
- `arm_pair()` in `gen_outerwear.py` pulls the top of every sleeve that starts below y = -2.3 up to -2.3, because the skin arm starts at
  y = -2 and its top face peeked out above the sleeve (the skin showed on the shoulders).
