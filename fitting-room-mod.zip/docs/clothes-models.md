# Clothes models

Every garment is a JSON file in `assets/fittingroom/clothes_models/<id>.json` plus a texture.
Garments are made of cubes attached to the player's bones. All numbers are in Minecraft model units
(1 unit = 1/16 block). Textures are 32x: the PNG is twice as big as `texture_size`
(`texture_size` is the layout in units, the PNG has 2 pixels per unit).

```json
{
  "texture": "fittingroom:textures/clothes/santa_hat.png",
  "texture_size": [64, 26],
  "cubes": [
    { "name": "band", "bone": "head",
      "pos": [-4.0, -7.0, -4.0],     // corner of the cube, relative to the bone's pivot (vanilla model space)
      "size": [8, 2, 8],             // integers: the texture layout is a normal box unwrap
      "uv": [0, 0],                  // top-left of the unwrap in `texture_size` units
      "grow": [0.95, 0.95, 0.95],    // makes the cube bigger on every side without changing the unwrap
      "mirror": false,               // true for the left twin of a right-hand cube (same uv)
      "pivot": [0, 0, 0], "rot": [0, 0, 0]   // optional: rotation in degrees around `pivot`
    }
  ]
}
```
Bones: `head`, `body`, `right_arm`, `left_arm`, `right_leg`, `left_leg`. The format is the same as a
Blockbench "Modded Entity" (Java) model, so a model made there can be converted to it.
Reload with F3+T while the game is running.

`gen_santa3d.py` in the project builder writes these files; the cubes are described there with
simpler coordinates (player's right = +x, up = +y, front = -z).
