# Clothes models

Every garment is a JSON file in `assets/fittingroom/clothes_models/<id>.json` plus a texture.
Garments are made of cubes attached to the player's bones. All numbers are in Minecraft model units
(1 unit = 1/16 block). Textures are 32x: the PNG is twice as big as `texture_size`
(`texture_size` is the layout in units, the PNG has 2 pixels per unit).

```json
{
  "texture": "fittingroom:textures/clothes/santa_hat.png",
  "texture_size": [64, 26],
  "cubes": [
    { "name": "band", "bone": "head",
      "pos": [-4.0, -7.0, -4.0],     // corner of the cube, relative to the bone's pivot (vanilla model space)
      "size": [8, 2, 8],             // integers: the texture layout is a normal box unwrap
      "uv": [0, 0],                  // top-left of the unwrap in `texture_size` units
      "grow": [0.95, 0.95, 0.95],    // makes the cube bigger on every side without changing the unwrap
      "mirror": false,               // true for the left twin of a right-hand cube (same uv)
      "pivot": [0, 0, 0], "rot": [0, 0, 0]   // optional: rotation in degrees around `pivot`
    }
  ]
}
```
Bones: `head`, `body`, `right_arm`, `left_arm`, `right_leg`, `left_leg`. The format is the same as a
Blockbench "Modded Entity" (Java) model, so a model made there can be converted to it.
Reload with F3+T while the game is running.

`gen_santa3d.py` in the project builder writes these files; the cubes are described there with
simpler coordinates (player's right = +x, up = +y, front = -z).

## Slim (Alex) arms
Models are authored for the 4-wide Steve arm. For players with slim arms the loader automatically squeezes
every cube on `right_arm` / `left_arm` (without `rot`) to 3/4 of its width in X and centres it on the 3-wide arm,
so the same JSON and texture work for both skin types. Nothing to do in the model files.

## Seasonal clothes
`ClothingCatalog` can limit a garment to a period of the year (`Item.seasonFrom` / `seasonTo`).
The Santa set is only available from December 15th to January 14th: outside of it the clothes are not shown
in the fitting room, cannot be put on (the server checks the date too) and are not drawn on players
(what a player saved stays and comes back with the next season).
To test, start the game with `-Dfittingroom.date=2026-12-31`.

## Cat costume
`cat_ears` (hat), `cat_sweater` (top), `cat_pants` (bottom, with a tail made of 4 rotated segments on the body bone)
and `cat_paws` (shoes). Textures are 2 px per unit like all the others.

## Dino kigurumi
`dino_hood` (hat: green hood with a snout, teeth hanging from it, two angry eyes, red lining and a spiky crest),
`dino_top` (onesie top with a light belly panel with buttons, red collar, ribbed cuffs and plates down the back),
`dino_pants` (onesie bottom with a long tail of five segments, bent down, with spikes on top) and `dino_slippers`
(green boots with ribbed rims and three claws on each foot). Teeth are drawn as transparent pixels between the
white triangles, so they really are zigzag. `python3 tools/gen_dino.py` regenerates the models, textures and icons.
The set comes in two colours: green (`dino_*`) and blue (`dino_blue_*`, cream-yellow spikes, white-blue belly);
the palettes are at the top of the script, so another colour is one more entry in `PALETTES` plus its items in
`ClothingCatalog`, `clothes.json` and the lang files.
Unlike the older generator this one paints soft shading and clean details instead of per-pixel noise.

## Japanese school uniform
`school_bow` (hat: red hair ribbon on the side of the head), `school_top` (sailor blouse: white, short sleeves with a
navy cuff and a white stripe, navy sailor collar with two white stripes, red ribbon bow), `school_skirt` (bottom: navy
plaid pleated skirt in two flared tiers; the pleat creases are painted into the texture), `school_socks` (shoes: white
knee socks with a navy band and black loafers) and `school_bag` (accessory: leather satchel carried in the right hand,
it hangs from a handle loop and swings with the arm). `python3 tools/gen_school.py` regenerates the set; it reuses the
smooth painter of `gen_dino.py`.

The school uniform also comes in black (`school_black_*`: black blouse and plaid skirt with the white collar stripes,
black knee socks, brown loafers, black satchel with a silver clasp). The palettes are at the top of `gen_school.py`.

## Boys' school uniform (gakuran)
`boy_cap` (hat: black peaked cap with a gold emblem on the band and a tilted visor), `boy_gakuran` (top: black
jacket with five gold buttons, a white collar tab, gold collar badges, pocket flaps and long sleeves with cuffs),
`boy_trousers` (bottom: black trousers with a pressed crease and a belt with a silver buckle) and `boy_shoes` (shoes:
black laced shoes). The satchel of the girls' set (`school_black_bag`) goes with it. `python3 tools/gen_school_boy.py`
regenerates the set.

## Plush backpacks
`plush_cat`, `plush_dino` and `plush_bear` (accessories): a soft toy sits on the back and looks at whoever stands
behind the player. Each one has a head with glossy eyes and blush, a body with a light belly oval, little arms, legs
with paw pads and shoulder straps laid out like the normal backpack. Cat: ears with a pink inside, a ringed tail and a
collar with a bell. Dino: a snout, three crest spikes and a short tail. Bear: round ears, a muzzle and a red bow.
`python3 tools/gen_plush.py` regenerates all three; to add another animal, add an entry to `SPECIES` and its ears/tail.

## Balloons and gloves (accessories, several colours)
`balloon_<colour>` (red, pink, blue, yellow, green, purple): a glossy balloon built from layered cubes (each layer
twice, turned 45 degrees, so it looks round) on a thin string held in the right hand; it floats beside the head and
swings with the arm. `balloon_bunch_rainbow` and `balloon_bunch_pastel` hold three balloons on three strings.
`gloves_<colour>` (white, black, red, pink, blue, yellow, green, purple): short gloves with finger lines and a ribbed
cuff on both hands. Colours are the `COLOURS` dict of `python3 tools/gen_balloons_gloves.py`; a new colour is one
entry there plus the items in `ClothingCatalog`, `clothes.json` and the lang files.

## Accessories
The "Accessories" tab holds `casual_backpack` (straps + bag on the back), `punk_cuffs` (leather wristbands with
spikes on both forearms; the top/bottom faces of the ring are transparent so the arm goes through it) and
`santa_sack` (a seasonal gift sack with a rope strap, New Year season like the rest of the Santa set).
Only one accessory can be worn at a time. They are drawn above the tops and below the hats.
Note for arms: cubes on `right_arm` / `left_arm` without `rot` are re-centred on the arm for slim skins, so all
arm accessories must sit in the middle of the arm (that is why the cuff spikes are only on the front and back).
`python3 tools/gen_accessories.py` regenerates the models, textures and icons of these three.

### Glasses
`glasses_round`, `glasses_sun`, `glasses_heart`, `glasses_3d` and `glasses_pixel` are cubes on the `head` bone:
lenses at x = +-2, y = -3, in front of the face (z about -4.7, outside the skin's hat layer), plus a bridge and
two arms along the sides of the head. Clear parts (the middle of the round frames, the outside of the hearts) are
transparent pixels in the texture. They live in the Accessories tab, so they replace the backpack/cuffs/sack
(one accessory at a time). `tools/gen_accessories.py` regenerates them too.


### Flicker (z-fighting)
Two faces that lie in the same plane, look the same way and overlap flicker in game, because the GPU cannot decide
which one is in front. This happens between two cubes of one garment, and between a cube and the player's own skin
layers (hat layer = head +0.5, jacket/sleeves/pants = +0.25). `tools/zfight.py` finds such pairs and fixes them by
making the cube that must stay on top a hair bigger (`grow`, 0.03 units) on the axis of the clashing face; UVs and
textures are not touched. The generators call it automatically in `build()`; for hand-edited JSON run
`python3 tools/zfight.py` (fix) or `python3 tools/zfight.py --check` (report only, exit code 1 on flicker).
Rotated cubes are skipped. Clashes between two *different* garments worn together are not covered.

### Backpack straps
Front strap, shoulder link and back strap must touch each other: the front strap starts right under the link
(y = -0.7) and the link reaches the strap's front plane (z = -3.95). Balloons are lifted (`LIFT` in
`tools/gen_balloons_gloves.py`) so the lowest knot is above the head's hat layer and they never hide the model.

### Scarves
`scarf_red`, `scarf_blue`, `scarf_pink` (pom-poms), `scarf_plaid`, `scarf_rainbow` and `scarf_xmas` (New Year season)
are in the Accessories tab but in their own slot (`slot: "neck"` in `clothes.json`, `ClothingCatalog.NECK`), so a
scarf can be worn together with a backpack, glasses or gloves; one scarf at a time. Two rings on the `body` bone sit
outside every top and the skin's hat layer, the knot is on the front left, two tails hang down the chest tilted 12
degrees towards the body. They are drawn above the tops and below the other accessories.
`python3 tools/gen_scarves.py` regenerates the models, textures and icons.

## Casual wear (more)
`casual_tee_*` (T-shirts: white, black with a star, pink with a heart, striped), `casual_shorts_*` (denim, black, khaki),
`casual_skirt_*` (denim, pink pleated, red plaid), `casual_cardigan_*` (cream, pink, blue; buttons, pockets, ribbed
hem and cuffs) and `casual_kedy_*` (high-top canvas sneakers: white, red, black). `python3 tools/gen_casual.py`
regenerates them and registers the items in `clothes.json`, the lang files and `ClothingCatalog`.

## Jewelry
Accessories with their own slots (`choker`, `necklace`, `wrist`), so one of each can be worn together with a backpack,
glasses, a scarf and gloves. `choker_*` (punk black leather strap with silver spikes, black velvet with a heart, pink ribbon with a bow, white lace with a pearl,
silver chain with a star) and `necklace_*` (pearls, gold chain with a heart, silver chain with a star, rainbow beads)
sit on the chest in front of every top; charms are flat shapes cut out of the texture with transparent pixels.
`bracelet_*` (gold bangles, silver charm bracelet, beaded, friendship) are rings round both wrists, drawn over gloves
(they are slightly wider than a bare arm, so over long sleeves they sit on the cuff). `python3 tools/gen_jewelry.py`
regenerates the set and registers it.

## Punk leather jacket and combat boots
`punk_jacket_*` (top, black and brown): biker leather jacket with wide lapels, a zipper, zipped pockets, a belt with a
buckle, three silver studs on each shoulder and zipped cuffs. `punk_boots_*` (shoes, black with red laces and brown
with cream laces): combat boots with a laced shaft and eyelets, a folded rim, a buckled ankle strap, a toe cap and a
thick lugged sole. They go with `punk_tee`, `punk_jeans`, `punk_cuffs` and the spiked choker.
`python3 tools/gen_punk.py` regenerates them and registers the items.

### Player's own skin layers
The clothes are drawn on top of the player's skin, and the skin has its own outer layer (sweater, jacket, trousers
painted on it). The garment boxes are not exactly as tall as that layer, so parts of the skin's clothes used to
peek out (for example the hem of the skin's sweater under the belt of the leather jacket). `SkinLayerHider`
therefore hides the jacket and both sleeves of the skin while any garment of the "top" category is worn, and both
trouser legs while any "bottom" garment is worn. The hat layer (hair) is not touched.
