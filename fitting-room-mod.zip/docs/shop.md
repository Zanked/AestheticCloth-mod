# Shop: clothes cost money

Clothes are paid from the player's account in the Aesthetic Jobs bank (USD, amounts in cents). The two mods
must be installed together: `fittingroom` requires `aestheticjobs` 0.8.0 or newer (the bank mod is not changed).

## How it works
- Open the fitting room (right click inside the cabin). The server sends the balance and the list of bought
  clothes, then the screen opens.
- Clothes you do not own are dimmed and have a gold `$`; the tooltip shows the price, owned ones say "Owned".
- Pick an outfit: the strip under the window shows your balance and the total price of the unpaid items.
  The button says **Buy** when something is unpaid, **Wear** otherwise. If the account has less than the total
  the button is grey and nothing happens.
- The server does the payment (`Shop.buyAndWear`): one withdrawal for the whole outfit, transaction type
  `WITHDRAW` (visible in `/bank history`), reason `fittingroom: <ids>`. Not enough money or a bank error means
  nothing is bought and the old outfit is put back on the player.
- Bought clothes are saved on the player (`fittingroom:owned`) and kept after death. Clothes can be worn again
  and again for free.
- Players who wore something before the shop existed get that clothing as owned, once, on login.
- No card or PIN is needed: the payment goes through the account of the player (same as wages and tips).

## Testing
`/bank give <player> 100000` (operator) puts $1,000.00 on the account, `/bank balance` shows it.

## Prices
`ClothingPrices.java`, one line per garment, in cents. For orientation: T-shirt $14.99-24.99, hoodie $49.99,
jeans $59.99, sneakers $79.99, leather jacket $249.99, combat boots $149.99, pearl necklace $99.99,
gold bangles $199.99, balloon $3.99. A garment that is missing in the table gets a price by category
(`fallback`), so nothing is free by accident. For comparison the cafe job pays $12 per hour.
