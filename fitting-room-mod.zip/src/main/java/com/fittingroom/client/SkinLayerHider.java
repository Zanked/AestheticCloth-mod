package com.fittingroom.client;

import com.fittingroom.FittingRoomMod;
import com.fittingroom.wardrobe.ClientWardrobeStore;
import com.fittingroom.wardrobe.ClothingCatalog;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RenderLivingEvent;

import java.util.List;

/**
 * Hides the player's own outer skin layers (jacket, sleeves, pants) under the clothes of the same kind.
 * <p>
 * Without this the sweater / jacket / trousers that are painted into the player's skin show through the
 * garment: the garment boxes are not exactly as tall as the skin's outer layer (for example the leather jacket
 * ends 0.1 above the bottom edge of the skin's jacket layer, so the hem of the skin's own sweater sticks out
 * under the belt). Hidden layers cannot flicker or poke out.
 * <p>
 * The event is fired inside LivingEntityRenderer.render, after PlayerRenderer.setModelProperties has set the
 * visibility from the skin options, and the visibility is set again before every render, so nothing has to be
 * restored afterwards.
 * <p>
 * The hat layer (hair, hats painted into the skin) is left alone on purpose: hats are bigger than that layer all
 * round, and hiding it would also remove the hair that sticks out under a cap.
 */
@EventBusSubscriber(modid = FittingRoomMod.MOD_ID, value = Dist.CLIENT)
public final class SkinLayerHider {
    private SkinLayerHider() {}

    @SubscribeEvent
    public static void onRenderPre(RenderLivingEvent.Pre<?, ?> event) {
        if (!(event.getEntity() instanceof AbstractClientPlayer player)) {
            return;
        }
        Object rawModel = event.getRenderer().getModel();
        if (!(rawModel instanceof PlayerModel<?> model)) {
            return;
        }
        List<String> ids = ClientWardrobeStore.get(player.getUUID());
        if (ids.isEmpty()) {
            return;
        }
        boolean top = false;
        boolean bottom = false;
        // forRender only returns garments that are really drawn (known and in season)
        for (ClothingCatalog.Item item : ClothingCatalog.forRender(ids)) {
            switch (item.category()) {
                case TOP -> top = true;
                case BOTTOM -> bottom = true;
                default -> {
                }
            }
        }
        if (top) {
            model.jacket.visible = false;
            model.leftSleeve.visible = false;
            model.rightSleeve.visible = false;
        }
        if (bottom) {
            model.leftPants.visible = false;
            model.rightPants.visible = false;
        }
    }
}
