package com.fittingroom.client;

import com.fittingroom.FittingRoomMod;
import com.fittingroom.client.garment.GarmentModels;
import com.fittingroom.client.render.DisplayCaseRenderer;
import com.fittingroom.client.render.MannequinRenderer;
import com.fittingroom.client.render.SellerRenderer;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.client.resources.PlayerSkin;
import net.minecraft.server.packs.resources.ResourceManagerReloadListener;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.neoforge.client.event.RegisterClientReloadListenersEvent;

/** Mod-bus events (client only). */
@EventBusSubscriber(modid = FittingRoomMod.MOD_ID, bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientModEvents {
    private ClientModEvents() {}

    @SubscribeEvent
    public static void addLayers(EntityRenderersEvent.AddLayers event) {
        for (PlayerSkin.Model skinModel : event.getSkins()) {
            var renderer = event.getSkin(skinModel);
            if (renderer instanceof PlayerRenderer playerRenderer) {
                playerRenderer.addLayer(new WardrobeLayer(playerRenderer, skinModel == PlayerSkin.Model.SLIM));
            }
        }
    }

    @SubscribeEvent
    public static void registerBlockEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerBlockEntityRenderer(FittingRoomMod.MANNEQUIN_BE.get(), MannequinRenderer::new);
        event.registerBlockEntityRenderer(FittingRoomMod.DISPLAY_CASE_BE.get(), DisplayCaseRenderer::new);
        event.registerEntityRenderer(FittingRoomMod.SELLER.get(), SellerRenderer::new);
    }

    /** F3+T reloads the garment models too, handy while editing them. */
    @SubscribeEvent
    public static void registerReloadListeners(RegisterClientReloadListenersEvent event) {
        event.registerReloadListener((ResourceManagerReloadListener) manager -> GarmentModels.clear());
    }
}
