package com.fittingroom.client;

import com.fittingroom.client.garment.GarmentModel;
import com.fittingroom.client.garment.GarmentModels;
import com.fittingroom.wardrobe.ClientWardrobeStore;
import com.fittingroom.wardrobe.ClothingCatalog;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;

import java.util.List;

/** Draws the 3D clothes of a player on top of the player model. */
public class WardrobeLayer extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {

    private final boolean slim;

    public WardrobeLayer(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> parent, boolean slim) {
        super(parent);
        this.slim = slim;
    }

    @Override
    public void render(PoseStack poseStack, MultiBufferSource buffer, int packedLight, AbstractClientPlayer player,
                       float limbSwing, float limbSwingAmount, float partialTick, float ageInTicks,
                       float netHeadYaw, float headPitch) {
        if (player.isInvisible()) {
            return;
        }
        List<String> ids = ClientWardrobeStore.get(player.getUUID());
        if (ids.isEmpty()) {
            return;
        }
        PlayerModel<AbstractClientPlayer> parent = getParentModel();
        int overlay = LivingEntityRenderer.getOverlayCoords(player, 0.0F);
        for (ClothingCatalog.Item item : ClothingCatalog.forRender(ids)) {
            GarmentModel garment = GarmentModels.get(item.id(), slim);
            if (garment != null) {
                garment.render(parent, poseStack, buffer, packedLight, overlay);
            }
        }
    }
}
