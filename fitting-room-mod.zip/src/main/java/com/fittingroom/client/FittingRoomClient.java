package com.fittingroom.client;

import com.fittingroom.client.gui.WardrobeScreen;
import net.minecraft.client.Minecraft;

/** Client-only entry points. Only ever called from code that runs on the client. */
public final class FittingRoomClient {
    private FittingRoomClient() {}

    public static void openWardrobe() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) {
            mc.setScreen(new WardrobeScreen(mc.player));
        }
    }
}
