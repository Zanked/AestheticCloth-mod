package com.fittingroom.client.garment;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.resources.ResourceLocation;

/**
 * One garment: a set of cubes attached to the player's bones (head, body, arms, legs).
 * Before drawing, every bone copies the pose of the matching part of the player model,
 * so the clothes move together with the body.
 */
public final class GarmentModel {
    private final ModelPart root;
    private final ResourceLocation texture;

    GarmentModel(ModelPart root, ResourceLocation texture) {
        this.root = root;
        this.texture = texture;
    }

    private void copy(String bone, ModelPart from) {
        if (root.hasChild(bone)) {
            root.getChild(bone).copyFrom(from);
        }
    }

    public void render(PlayerModel<?> parent, PoseStack poseStack, MultiBufferSource buffer, int light, int overlay) {
        copy("head", parent.head);
        copy("body", parent.body);
        copy("right_arm", parent.rightArm);
        copy("left_arm", parent.leftArm);
        copy("right_leg", parent.rightLeg);
        copy("left_leg", parent.leftLeg);
        VertexConsumer consumer = buffer.getBuffer(RenderType.entityCutoutNoCull(texture));
        root.render(poseStack, consumer, light, overlay, -1);
    }
}
