package com.fittingroom.client.garment;

import com.fittingroom.FittingRoomMod;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mojang.logging.LogUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.Resource;
import org.slf4j.Logger;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

/**
 * Loads garment models from assets/fittingroom/clothes_models/&lt;id&gt;.json (see docs/clothes-models.md)
 * and keeps them cached until the resources are reloaded.
 */
public final class GarmentModels {
    private static final Logger LOGGER = LogUtils.getLogger();
    private static final String[] BONES = {"head", "body", "right_arm", "left_arm", "right_leg", "left_leg"};
    private static final Map<String, Optional<GarmentModel>> CACHE = new HashMap<>();

    private GarmentModels() {}

    /** @return the model, or null if the file is missing or broken */
    public static GarmentModel get(String id) {
        return CACHE.computeIfAbsent(id, GarmentModels::load).orElse(null);
    }

    public static void clear() {
        CACHE.clear();
    }

    private static float[] floats(JsonArray array) {
        float[] out = new float[array.size()];
        for (int i = 0; i < out.length; i++) {
            out[i] = array.get(i).getAsFloat();
        }
        return out;
    }

    private static Optional<GarmentModel> load(String id) {
        ResourceLocation file = ResourceLocation.fromNamespaceAndPath(FittingRoomMod.MOD_ID, "clothes_models/" + id + ".json");
        Optional<Resource> resource = Minecraft.getInstance().getResourceManager().getResource(file);
        if (resource.isEmpty()) {
            LOGGER.warn("Garment model {} not found", file);
            return Optional.empty();
        }
        try (BufferedReader reader = resource.get().openAsReader()) {
            JsonObject json = JsonParser.parseReader(reader).getAsJsonObject();
            ResourceLocation texture = ResourceLocation.parse(json.get("texture").getAsString());
            JsonArray size = json.getAsJsonArray("texture_size");
            int texW = size.get(0).getAsInt();
            int texH = size.get(1).getAsInt();

            MeshDefinition mesh = new MeshDefinition();
            PartDefinition root = mesh.getRoot();
            Map<String, PartDefinition> bones = new HashMap<>();
            for (String bone : BONES) {
                bones.put(bone, root.addOrReplaceChild(bone, CubeListBuilder.create(), PartPose.ZERO));
            }

            int index = 0;
            for (JsonElement element : json.getAsJsonArray("cubes")) {
                JsonObject cube = element.getAsJsonObject();
                PartDefinition bone = bones.get(cube.get("bone").getAsString());
                if (bone == null) {
                    continue;
                }
                float[] pos = floats(cube.getAsJsonArray("pos"));
                float[] dims = floats(cube.getAsJsonArray("size"));
                float[] uv = floats(cube.getAsJsonArray("uv"));
                float[] grow = floats(cube.getAsJsonArray("grow"));
                boolean mirror = cube.has("mirror") && cube.get("mirror").getAsBoolean();

                CubeListBuilder builder = CubeListBuilder.create()
                        .texOffs((int) uv[0], (int) uv[1])
                        .mirror(mirror)
                        .addBox(pos[0], pos[1], pos[2], dims[0], dims[1], dims[2],
                                new CubeDeformation(grow[0], grow[1], grow[2]));

                PartPose pose = PartPose.ZERO;
                if (cube.has("rot")) {
                    float[] pivot = floats(cube.getAsJsonArray("pivot"));
                    float[] rot = floats(cube.getAsJsonArray("rot"));
                    pose = PartPose.offsetAndRotation(pivot[0], pivot[1], pivot[2],
                            (float) Math.toRadians(rot[0]), (float) Math.toRadians(rot[1]), (float) Math.toRadians(rot[2]));
                }
                bone.addOrReplaceChild("cube" + index++, builder, pose);
            }

            ModelPart baked = LayerDefinition.create(mesh, texW, texH).bakeRoot();
            return Optional.of(new GarmentModel(baked, texture));
        } catch (IOException | RuntimeException e) {
            LOGGER.error("Could not load garment model {}", file, e);
            return Optional.empty();
        }
    }
}
