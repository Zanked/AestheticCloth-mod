package com.fittingroom.client.render;

import com.fittingroom.FittingRoomMod;
import com.fittingroom.block.DisplayCaseBlock;
import com.fittingroom.blockentity.DisplayCaseBlockEntity;
import com.fittingroom.economy.Money;
import com.fittingroom.wardrobe.ClientWardrobeStore;
import com.fittingroom.wardrobe.ClothingCatalog;
import com.fittingroom.wardrobe.Sales;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.gui.Font;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.state.BlockState;
import org.joml.Matrix4f;

import java.time.LocalDate;

/**
 * Draws the garments of a display case as flat pictures (the icons of the wardrobe) standing on the three
 * pedestals, and a small price tag for each one on the front of the cabinet (the price of today, with the sale).
 * Everything is drawn in a frame whose front is +z and is then turned to the way the case faces.
 */
public class DisplayCaseRenderer implements BlockEntityRenderer<DisplayCaseBlockEntity> {
    /** Centres of the three pedestals, in 1/16 block counted from the left of the front view. */
    private static final float[] SLOT_X = {3.5F, 8.0F, 12.5F};
    private static final float ICON_SIZE = 4.6F / 16.0F;
    private static final int TAG_BACKGROUND = 0xFFF8EFE2;
    private static final int TAG_TEXT = 0xFF5E3E36;
    private static final int TAG_SALE_TEXT = 0xFFB3263E;

    private final Font font;

    public DisplayCaseRenderer(BlockEntityRendererProvider.Context context) {
        this.font = context.getFont();
    }

    @Override
    public void render(DisplayCaseBlockEntity showcase, float partialTick, PoseStack poseStack,
                       MultiBufferSource buffer, int light, int overlay) {
        BlockState state = showcase.getBlockState();
        if (!state.hasProperty(DisplayCaseBlock.FACING)) {
            return;
        }
        Direction facing = state.getValue(DisplayCaseBlock.FACING);
        LocalDate today = ClientWardrobeStore.saleDate();

        poseStack.pushPose();
        poseStack.translate(0.5, 0.0, 0.5);
        poseStack.mulPose(Axis.YP.rotationDegrees(-facing.toYRot()));

        for (int i = 0; i < DisplayCaseBlockEntity.SLOTS; i++) {
            ClothingCatalog.Item item = ClothingCatalog.byId(showcase.slot(i));
            if (item == null) {
                continue;
            }
            float cx = (SLOT_X[i] - 8.0F) / 16.0F;
            drawIcon(poseStack, buffer, item, cx, light);
            drawTag(poseStack, buffer, item, today, cx, light);
        }
        poseStack.popPose();
    }

    private void drawIcon(PoseStack poseStack, MultiBufferSource buffer, ClothingCatalog.Item item, float cx, int light) {
        ResourceLocation icon = ResourceLocation.fromNamespaceAndPath(FittingRoomMod.MOD_ID,
                "textures/gui/clothes/" + item.id() + ".png");
        VertexConsumer vc = buffer.getBuffer(RenderType.entityCutoutNoCull(icon));
        poseStack.pushPose();
        // bottom edge of the picture on the pedestal (7.6/16), leaning a little back
        poseStack.translate(cx, 7.7F / 16.0F, 0.0F);
        poseStack.mulPose(Axis.XP.rotationDegrees(-8.0F));
        PoseStack.Pose pose = poseStack.last();
        float h = ICON_SIZE / 2.0F;
        vertex(vc, pose, -h, 0.0F, 0.0F, 1.0F, light);
        vertex(vc, pose, h, 0.0F, 1.0F, 1.0F, light);
        vertex(vc, pose, h, ICON_SIZE, 1.0F, 0.0F, light);
        vertex(vc, pose, -h, ICON_SIZE, 0.0F, 0.0F, light);
        poseStack.popPose();
    }

    private static void vertex(VertexConsumer vc, PoseStack.Pose pose, float x, float y, float u, float v, int light) {
        vc.addVertex(pose, x, y, 0.0F)
                .setColor(-1)
                .setUv(u, v)
                .setOverlay(OverlayTexture.NO_OVERLAY)
                .setLight(light)
                .setNormal(pose, 0.0F, 0.0F, 1.0F);
    }

    private void drawTag(PoseStack poseStack, MultiBufferSource buffer, ClothingCatalog.Item item, LocalDate today,
                         float cx, int light) {
        long price = Sales.price(item, today);
        boolean onSale = Sales.percentOff(item, today) > 0;
        String text = Money.format(price);
        float width = font.width(text);

        poseStack.pushPose();
        // on the front panel of the cabinet (z = +0.5), a hair in front of it
        poseStack.translate(cx, 3.0F / 16.0F, 0.5F + 0.003F);
        // a tag is at most 4.4/16 block wide; normal text size is that of a sign (1/96 block per pixel)
        float scale = Math.min(0.0104F, (4.4F / 16.0F) / (width + 2.0F));
        poseStack.scale(scale, -scale, scale);
        Matrix4f matrix = poseStack.last().pose();
        font.drawInBatch(text, -width / 2.0F, -4.0F, onSale ? TAG_SALE_TEXT : TAG_TEXT, false, matrix, buffer,
                Font.DisplayMode.NORMAL, TAG_BACKGROUND, light);
        poseStack.popPose();
    }
}
