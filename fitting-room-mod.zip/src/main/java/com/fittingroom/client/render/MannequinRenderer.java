package com.fittingroom.client.render;

import com.fittingroom.FittingRoomMod;
import com.fittingroom.block.MannequinBlock;
import com.fittingroom.blockentity.MannequinBlockEntity;
import com.fittingroom.client.garment.GarmentModel;
import com.fittingroom.client.garment.GarmentModels;
import com.fittingroom.wardrobe.ClothingCatalog;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Draws the mannequin: a player model (wide arms) with the ivory mannequin texture, and on top of it the same
 * 3D garments that players wear. The stand (plate and rod) is an ordinary block model.
 */
public class MannequinRenderer implements BlockEntityRenderer<MannequinBlockEntity> {
    private static final ResourceLocation TEXTURE =
            ResourceLocation.fromNamespaceAndPath(FittingRoomMod.MOD_ID, "textures/entity/mannequin.png");

    private final PlayerModel<AbstractClientPlayer> model;

    public MannequinRenderer(BlockEntityRendererProvider.Context context) {
        this.model = new PlayerModel<>(context.bakeLayer(ModelLayers.PLAYER), false);
    }

    @Override
    public void render(MannequinBlockEntity mannequin, float partialTick, PoseStack poseStack,
                       MultiBufferSource buffer, int light, int overlay) {
        BlockState state = mannequin.getBlockState();
        if (!state.hasProperty(MannequinBlock.FACING)) {
            return;
        }
        Direction facing = state.getValue(MannequinBlock.FACING);

        poseStack.pushPose();
        // stand on top of the marble plate (1/16 block), then do what the player renderer does
        poseStack.translate(0.5, 1.0 / 16.0, 0.5);
        poseStack.mulPose(Axis.YP.rotationDegrees(180.0F - facing.toYRot()));
        poseStack.scale(-1.0F, -1.0F, 1.0F);
        poseStack.translate(0.0F, -1.501F, 0.0F);

        // relaxed pose: arms a little away from the body, no overlay layers
        model.setAllVisible(true);
        model.hat.visible = false;
        model.jacket.visible = false;
        model.leftSleeve.visible = false;
        model.rightSleeve.visible = false;
        model.leftPants.visible = false;
        model.rightPants.visible = false;
        model.rightArm.zRot = 0.07F;
        model.leftArm.zRot = -0.07F;

        VertexConsumer body = buffer.getBuffer(RenderType.entityCutoutNoCull(TEXTURE));
        model.renderToBuffer(poseStack, body, light, overlay, -1);

        for (ClothingCatalog.Item item : ClothingCatalog.forRender(mannequin.outfit())) {
            GarmentModel garment = GarmentModels.get(item.id(), false);
            if (garment != null) {
                garment.render(model, poseStack, buffer, light, overlay);
            }
        }
        poseStack.popPose();
    }

    @Override
    public boolean shouldRenderOffScreen(MannequinBlockEntity mannequin) {
        return true;
    }
}
