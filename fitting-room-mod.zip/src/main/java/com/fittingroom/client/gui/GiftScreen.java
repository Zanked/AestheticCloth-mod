package com.fittingroom.client.gui;

import com.fittingroom.economy.Money;
import com.fittingroom.network.GiftPayload;
import com.fittingroom.wardrobe.ClientWardrobeStore;
import com.fittingroom.wardrobe.ClothingCatalog;
import com.fittingroom.wardrobe.Sales;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.neoforged.neoforge.network.PacketDistributor;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

/**
 * "Gift": pick another player who is online; the clothes selected in the fitting room are bought for them
 * (the server charges you, with the sale applied, and skips what they already own).
 * Uses the same colours as the fitting room; all text goes through {@link GuiText}.
 */
public class GiftScreen extends Screen {
    private static final int TEXT = 0xFF5E3E36;
    private static final int TEXT_DISABLED = 0xFFA09482;
    private static final int PRICE_GOLD = 0xFFB8860B;
    private static final int PRICE_RED = 0xFFD94A4A;
    private static final int OUTLINE = 0xFF765448;
    private static final int PAPER = 0xFFF2E8D6;
    private static final int PINK = 0xFFF8C8CC;
    private static final int PINK_HOVER = 0xFFFFDEE0;
    private static final int GOLD_EDGE = 0xFFF0BE46;
    private static final int ROW_BG = 0xFFFAF0E6;

    private static final int W = 176, H = 190;
    private static final int LIST_Y = 82, ROW_H = 13, ROWS = 6;
    private static final int BTN_Y = 166;

    /** A player that can get a gift. */
    record Recipient(UUID id, String name) {}

    /** Everybody online except you. */
    static List<Recipient> recipients() {
        List<Recipient> out = new ArrayList<>();
        Minecraft mc = Minecraft.getInstance();
        ClientPacketListener connection = mc.getConnection();
        LocalPlayer me = mc.player;
        if (connection == null || me == null) {
            return out;
        }
        for (var info : connection.getOnlinePlayers()) {
            UUID id = info.getProfile().getId();
            if (!id.equals(me.getUUID())) {
                out.add(new Recipient(id, info.getProfile().getName()));
            }
        }
        out.sort(Comparator.comparing(r -> r.name().toLowerCase(Locale.ROOT)));
        return out;
    }

    private final Screen parent;
    private final List<String> items;
    private final LocalDate day;
    private List<Recipient> list = List.of();
    private UUID chosen;
    private int scroll;
    private int left;
    private int top;

    GiftScreen(Screen parent, List<String> items, LocalDate day) {
        super(Component.translatable("gui.fittingroom.gift.title"));
        this.parent = parent;
        this.items = List.copyOf(items);
        this.day = day;
    }

    @Override
    protected void init() {
        this.left = (this.width - W) / 2;
        this.top = Math.max(4, (this.height - H) / 2);
        this.list = recipients();
        if (chosen != null && list.stream().noneMatch(r -> r.id().equals(chosen))) {
            chosen = null;
        }
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void onClose() {
        if (this.minecraft != null) {
            this.minecraft.setScreen(parent);
        }
    }

    /** The most the gift can cost: the recipient may already own some of it (that is not charged). */
    private long estimate() {
        long total = 0;
        for (String id : items) {
            ClothingCatalog.Item item = ClothingCatalog.byId(id);
            if (item != null) {
                total += Sales.price(item, day);
            }
        }
        return total;
    }

    private int maxScroll() {
        return Math.max(0, list.size() - ROWS);
    }

    private static boolean in(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    private boolean overSend(double mx, double my) {
        return in(mx, my, left + 14, top + BTN_Y, GuiLayout.BTN_W, GuiLayout.BTN_H);
    }

    private boolean overBack(double mx, double my) {
        return in(mx, my, left + W - 14 - GuiLayout.BTN_W, top + BTN_Y, GuiLayout.BTN_W, GuiLayout.BTN_H);
    }

    private int rowAt(double mx, double my) {
        for (int i = 0; i < ROWS; i++) {
            int idx = scroll + i;
            if (idx < list.size() && in(mx, my, left + 8, top + LIST_Y + i * ROW_H, W - 16, ROW_H - 1)) {
                return idx;
            }
        }
        return -1;
    }

    private void click() {
        if (this.minecraft != null) {
            this.minecraft.getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.UI_BUTTON_CLICK, 1.0F));
        }
    }

    private void drawButton(GuiGraphics g, int x, int y, Component label, boolean enabled, boolean hovered) {
        int u = !enabled ? GuiLayout.BTN_DISABLED_U : (hovered ? GuiLayout.BTN_HOVER_U : GuiLayout.BTN_U);
        g.blit(GuiLayout.TEXTURE, x, y, u, GuiLayout.BTN_V, GuiLayout.BTN_W, GuiLayout.BTN_H,
                GuiLayout.TEX_W, GuiLayout.TEX_H);
        GuiText.centered(g, this.font, label, x + GuiLayout.BTN_W / 2, y + 5, GuiLayout.BTN_W - 8,
                enabled ? TEXT : TEXT_DISABLED, false);
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float partialTick) {
        super.render(g, mx, my, partialTick);

        // panel
        g.fill(left, top, left + W, top + H, OUTLINE);
        g.fill(left + 2, top + 2, left + W - 2, top + H - 2, PAPER);
        g.fill(left + 2, top + 2, left + W - 2, top + 20, PINK);
        GuiText.centered(g, this.font, this.title, left + W / 2, top + 7, W - 24, TEXT, false);

        int textWidth = W - 20;
        GuiText.left(g, this.font, Component.translatable("gui.fittingroom.gift.items", items.size()),
                left + 10, top + 25, textWidth, TEXT, false);
        long cost = estimate();
        boolean poor = ClientWardrobeStore.balance() < cost;
        GuiText.left(g, this.font, Component.translatable("gui.fittingroom.gift.cost", Money.format(cost)),
                left + 10, top + 36, textWidth, poor ? PRICE_RED : PRICE_GOLD, false);
        int noteY = top + 48;
        List<String> note = GuiText.wrap(this.font, I18n_get("gui.fittingroom.gift.note"), textWidth);
        for (int i = 0; i < Math.min(2, note.size()); i++) {
            GuiText.left(g, this.font, Component.literal(note.get(i)), left + 10, noteY + i * 9, textWidth,
                    TEXT_DISABLED, false);
        }
        GuiText.left(g, this.font, Component.translatable("gui.fittingroom.gift.pick"), left + 10, top + 70,
                textWidth, TEXT, false);

        // player list
        g.fill(left + 7, top + LIST_Y - 1, left + W - 7, top + LIST_Y + ROWS * ROW_H, OUTLINE);
        g.fill(left + 8, top + LIST_Y, left + W - 8, top + LIST_Y + ROWS * ROW_H - 1, ROW_BG);
        if (list.isEmpty()) {
            GuiText.centered(g, this.font, Component.translatable("gui.fittingroom.gift.nobody"), left + W / 2,
                    top + LIST_Y + 30, W - 24, TEXT_DISABLED, false);
        }
        int hovered = rowAt(mx, my);
        for (int i = 0; i < ROWS; i++) {
            int idx = scroll + i;
            if (idx >= list.size()) {
                break;
            }
            Recipient r = list.get(idx);
            int y = top + LIST_Y + i * ROW_H;
            boolean isChosen = r.id().equals(chosen);
            if (isChosen) {
                g.fill(left + 8, y, left + W - 8, y + ROW_H - 1, GOLD_EDGE);
                g.fill(left + 9, y + 1, left + W - 9, y + ROW_H - 2, PINK);
            } else if (idx == hovered) {
                g.fill(left + 8, y, left + W - 8, y + ROW_H - 1, PINK_HOVER);
            }
            GuiText.left(g, this.font, Component.literal(r.name()), left + 12, y + 3, W - 32, TEXT, false);
        }
        if (maxScroll() > 0) {
            int trackH = ROWS * ROW_H - 2;
            int thumbH = Math.max(8, trackH * ROWS / list.size());
            int thumbY = top + LIST_Y + (trackH - thumbH) * scroll / maxScroll();
            g.fill(left + W - 11, thumbY, left + W - 9, thumbY + thumbH, OUTLINE);
        }

        // buttons
        boolean canSend = chosen != null && !items.isEmpty();
        drawButton(g, left + 14, top + BTN_Y, Component.translatable("gui.fittingroom.gift.send"), canSend,
                canSend && overSend(mx, my));
        drawButton(g, left + W - 14 - GuiLayout.BTN_W, top + BTN_Y, Component.translatable("gui.fittingroom.gift.back"),
                true, overBack(mx, my));
    }

    private static String I18n_get(String key) {
        return net.minecraft.client.resources.language.I18n.get(key);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button == 0) {
            int row = rowAt(mx, my);
            if (row >= 0) {
                chosen = list.get(row).id();
                click();
                return true;
            }
            if (overSend(mx, my) && chosen != null && !items.isEmpty()) {
                click();
                PacketDistributor.sendToServer(new GiftPayload(chosen, items));
                onClose();
                return true;
            }
            if (overBack(mx, my)) {
                click();
                onClose();
                return true;
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double scrollX, double scrollY) {
        int max = maxScroll();
        if (max > 0) {
            scroll = Math.max(0, Math.min(max, scroll - (int) Math.signum(scrollY)));
            return true;
        }
        return super.mouseScrolled(mx, my, scrollX, scrollY);
    }
}
