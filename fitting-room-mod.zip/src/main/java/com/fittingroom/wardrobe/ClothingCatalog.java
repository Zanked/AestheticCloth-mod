package com.fittingroom.wardrobe;

import com.fittingroom.FittingRoomMod;

import java.time.LocalDate;
import java.time.MonthDay;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * All clothes known to the mod. Used on both sides (the server validates, the client displays).
 * A garment's 3D model lives in assets/fittingroom/clothes_models/&lt;id&gt;.json.
 */
public final class ClothingCatalog {
    private ClothingCatalog() {}

    /** Slot of the scarves: part of the Accessories tab, but worn together with another accessory. */
    public static final String NECK = "neck";
    /** Jewelry slots: worn together with scarves, backpacks, glasses and gloves. */
    public static final String CHOKER = "choker";
    public static final String NECKLACE = "necklace";
    public static final String WRIST = "wrist";

    /** New Year season: from December 15th to January 14th (inclusive). Santa's clothes only exist then. */
    private static final MonthDay NEW_YEAR_FROM = MonthDay.of(12, 15);
    private static final MonthDay NEW_YEAR_TO = MonthDay.of(1, 14);

    /**
     * @param seasonFrom first day of the season (null = available all year)
     * @param seasonTo   last day of the season; may be "before" seasonFrom when the season spans New Year
     * @param slot       what the item occupies: one item per slot can be worn. Normally the category id;
     *                   scarves sit in the Accessories tab but in their own slot, so they go with a backpack or glasses
     */
    public record Item(String id, Category category, MonthDay seasonFrom, MonthDay seasonTo, String slot) {
        public Item(String id, Category category, MonthDay seasonFrom, MonthDay seasonTo) {
            this(id, category, seasonFrom, seasonTo, category.id());
        }

        public Item(String id, Category category) {
            this(id, category, null, null);
        }

        /** Lower values are drawn first. A scarf is drawn above the tops and below the other accessories. */
        public int renderOrder() {
            int extra = slot.equals(NECK) ? 5
                    : slot.equals(CHOKER) || slot.equals(NECKLACE) ? 6
                    : slot.equals(WRIST) ? 7 : 0;
            return category.renderOrder() * 10 + extra;
        }

        /** Shelf price in US cents (see {@link ClothingPrices}). */
        public long priceCents() {
            return ClothingPrices.cents(id, category);
        }

        public String translationKey() {
            return "clothes." + FittingRoomMod.MOD_ID + "." + id;
        }

        /** Is the garment in season today? Seasonal clothes are hidden and cannot be worn the rest of the year. */
        public boolean isAvailable() {
            if (seasonFrom == null || seasonTo == null) {
                return true;
            }
            MonthDay today = MonthDay.from(today());
            if (seasonFrom.compareTo(seasonTo) <= 0) {
                return today.compareTo(seasonFrom) >= 0 && today.compareTo(seasonTo) <= 0;
            }
            return today.compareTo(seasonFrom) >= 0 || today.compareTo(seasonTo) <= 0;
        }
    }

    /** Today's date; start the game with -Dfittingroom.date=2026-12-31 to test the seasons. */
    public static LocalDate today() {
        String forced = System.getProperty("fittingroom.date");
        if (forced != null) {
            try {
                return LocalDate.parse(forced);
            } catch (RuntimeException ignored) {
                // fall through to the real date
            }
        }
        return LocalDate.now();
    }

    private static Item newYear(String id, Category category) {
        return new Item(id, category, NEW_YEAR_FROM, NEW_YEAR_TO);
    }

    private static Item jewel(String id, String slot) {
        return new Item(id, Category.ACCESSORY, null, null, slot);
    }

    private static Item scarf(String id) {
        return new Item(id, Category.ACCESSORY, null, null, NECK);
    }

    public static final List<Item> ITEMS = List.of(
            newYear("santa_hat", Category.HAT),
            newYear("santa_coat", Category.TOP),
            newYear("santa_pants", Category.BOTTOM),
            newYear("santa_boots", Category.SHOES),
            new Item("casual_cap", Category.HAT),
            new Item("casual_hoodie", Category.TOP),
            new Item("casual_jeans", Category.BOTTOM),
            new Item("casual_sneakers", Category.SHOES),
            new Item("punk_jacket_black", Category.TOP),
            new Item("punk_jacket_brown", Category.TOP),
            new Item("punk_boots_black", Category.SHOES),
            new Item("punk_boots_brown", Category.SHOES),
            new Item("casual_tee_white", Category.TOP),
            new Item("casual_tee_black", Category.TOP),
            new Item("casual_tee_pink", Category.TOP),
            new Item("casual_tee_striped", Category.TOP),
            new Item("casual_shorts_denim", Category.BOTTOM),
            new Item("casual_shorts_black", Category.BOTTOM),
            new Item("casual_shorts_khaki", Category.BOTTOM),
            new Item("casual_skirt_denim", Category.BOTTOM),
            new Item("casual_skirt_pink", Category.BOTTOM),
            new Item("casual_skirt_plaid", Category.BOTTOM),
            new Item("casual_cardigan_cream", Category.TOP),
            new Item("casual_cardigan_pink", Category.TOP),
            new Item("casual_cardigan_blue", Category.TOP),
            new Item("casual_kedy_white", Category.SHOES),
            new Item("casual_kedy_red", Category.SHOES),
            new Item("casual_kedy_black", Category.SHOES),
            new Item("punk_tee", Category.TOP),
            new Item("punk_jeans", Category.BOTTOM),
            new Item("cat_ears", Category.HAT),
            new Item("cat_sweater", Category.TOP),
            new Item("cat_pants", Category.BOTTOM),
            new Item("cat_paws", Category.SHOES),
            new Item("dino_hood", Category.HAT),
            new Item("dino_top", Category.TOP),
            new Item("dino_pants", Category.BOTTOM),
            new Item("dino_slippers", Category.SHOES),
            new Item("dino_blue_hood", Category.HAT),
            new Item("dino_blue_top", Category.TOP),
            new Item("dino_blue_pants", Category.BOTTOM),
            new Item("dino_blue_slippers", Category.SHOES),
            new Item("school_bow", Category.HAT),
            new Item("school_top", Category.TOP),
            new Item("school_skirt", Category.BOTTOM),
            new Item("school_socks", Category.SHOES),
            new Item("school_bag", Category.ACCESSORY),
            new Item("school_black_bow", Category.HAT),
            new Item("school_black_top", Category.TOP),
            new Item("school_black_skirt", Category.BOTTOM),
            new Item("school_black_socks", Category.SHOES),
            new Item("school_black_bag", Category.ACCESSORY),
            new Item("boy_cap", Category.HAT),
            new Item("boy_gakuran", Category.TOP),
            new Item("boy_trousers", Category.BOTTOM),
            new Item("boy_shoes", Category.SHOES),
            new Item("plush_cat", Category.ACCESSORY),
            new Item("plush_dino", Category.ACCESSORY),
            new Item("plush_bear", Category.ACCESSORY),
            new Item("balloon_red", Category.ACCESSORY),
            new Item("balloon_pink", Category.ACCESSORY),
            new Item("balloon_blue", Category.ACCESSORY),
            new Item("balloon_yellow", Category.ACCESSORY),
            new Item("balloon_green", Category.ACCESSORY),
            new Item("balloon_purple", Category.ACCESSORY),
            new Item("balloon_bunch_rainbow", Category.ACCESSORY),
            new Item("balloon_bunch_pastel", Category.ACCESSORY),
            new Item("gloves_white", Category.ACCESSORY),
            new Item("gloves_black", Category.ACCESSORY),
            new Item("gloves_red", Category.ACCESSORY),
            new Item("gloves_pink", Category.ACCESSORY),
            new Item("gloves_blue", Category.ACCESSORY),
            new Item("gloves_yellow", Category.ACCESSORY),
            new Item("gloves_green", Category.ACCESSORY),
            new Item("gloves_purple", Category.ACCESSORY),
            new Item("casual_backpack", Category.ACCESSORY),
            new Item("punk_cuffs", Category.ACCESSORY),
            newYear("santa_sack", Category.ACCESSORY),
            new Item("glasses_round", Category.ACCESSORY),
            new Item("glasses_sun", Category.ACCESSORY),
            new Item("glasses_heart", Category.ACCESSORY),
            new Item("glasses_3d", Category.ACCESSORY),
            new Item("glasses_pixel", Category.ACCESSORY),
            scarf("scarf_red"),
            scarf("scarf_blue"),
            scarf("scarf_pink"),
            scarf("scarf_plaid"),
            scarf("scarf_rainbow"),
            new Item("scarf_xmas", Category.ACCESSORY, NEW_YEAR_FROM, NEW_YEAR_TO, NECK),
            jewel("choker_black", CHOKER),
            jewel("choker_pink", CHOKER),
            jewel("choker_lace", CHOKER),
            jewel("choker_chain", CHOKER),
            jewel("necklace_pearl", NECKLACE),
            jewel("necklace_heart", NECKLACE),
            jewel("necklace_star", NECKLACE),
            jewel("necklace_beads", NECKLACE),
            jewel("bracelet_gold", WRIST),
            jewel("bracelet_charm", WRIST),
            jewel("bracelet_beads", WRIST),
            jewel("bracelet_friendship", WRIST),
            jewel("choker_spiked", CHOKER)
    );

    private static final Map<String, Item> BY_ID = new HashMap<>();

    static {
        for (Item item : ITEMS) {
            BY_ID.put(item.id(), item);
        }
    }

    /** @return the item, or null if the id is unknown */
    public static Item byId(String id) {
        return BY_ID.get(id);
    }

    public static List<Item> inCategory(Category category) {
        List<Item> out = new ArrayList<>();
        for (Item item : ITEMS) {
            if (item.category() == category && item.isAvailable()) {
                out.add(item);
            }
        }
        return out;
    }

    /** Keeps only known ids, at most one per slot (the last one wins). */
    public static List<String> sanitize(Collection<String> ids) {
        Map<String, String> chosen = new LinkedHashMap<>();
        for (String id : ids) {
            Item item = BY_ID.get(id);
            if (item != null && item.isAvailable()) {
                chosen.put(item.slot(), item.id());
            }
        }
        return new ArrayList<>(chosen.values());
    }

    /** Known items from the list, in the order they should be drawn (bottom layers first). */
    public static List<Item> forRender(Collection<String> ids) {
        List<Item> out = new ArrayList<>();
        for (String id : ids) {
            Item item = BY_ID.get(id);
            if (item != null && item.isAvailable()) {
                out.add(item);
            }
        }
        out.sort(Comparator.comparingInt(Item::renderOrder));
        return out;
    }
}
