package com.fittingroom.wardrobe;

import com.fittingroom.FittingRoomMod;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * All clothes known to the mod. Used on both sides (the server validates, the client displays).
 * A garment's 3D model lives in assets/fittingroom/clothes_models/&lt;id&gt;.json.
 */
public final class ClothingCatalog {
    private ClothingCatalog() {}

    public record Item(String id, Category category) {
        public String translationKey() {
            return "clothes." + FittingRoomMod.MOD_ID + "." + id;
        }
    }

    public static final List<Item> ITEMS = List.of(
            new Item("santa_hat", Category.HAT),
            new Item("santa_coat", Category.TOP),
            new Item("santa_pants", Category.BOTTOM),
            new Item("santa_boots", Category.SHOES),
            new Item("casual_cap", Category.HAT),
            new Item("casual_hoodie", Category.TOP),
            new Item("casual_jeans", Category.BOTTOM),
            new Item("casual_sneakers", Category.SHOES),
            new Item("punk_tee", Category.TOP),
            new Item("punk_jeans", Category.BOTTOM)
    );

    private static final Map<String, Item> BY_ID = new HashMap<>();

    static {
        for (Item item : ITEMS) {
            BY_ID.put(item.id(), item);
        }
    }

    /** @return the item, or null if the id is unknown */
    public static Item byId(String id) {
        return BY_ID.get(id);
    }

    public static List<Item> inCategory(Category category) {
        List<Item> out = new ArrayList<>();
        for (Item item : ITEMS) {
            if (item.category() == category) {
                out.add(item);
            }
        }
        return out;
    }

    /** Keeps only known ids, at most one per category (the last one wins), ordered by category. */
    public static List<String> sanitize(Collection<String> ids) {
        EnumMap<Category, String> chosen = new EnumMap<>(Category.class);
        for (String id : ids) {
            Item item = BY_ID.get(id);
            if (item != null) {
                chosen.put(item.category(), item.id());
            }
        }
        return new ArrayList<>(chosen.values());
    }

    /** Known items from the list, in the order they should be drawn (bottom layers first). */
    public static List<Item> forRender(Collection<String> ids) {
        List<Item> out = new ArrayList<>();
        for (String id : ids) {
            Item item = BY_ID.get(id);
            if (item != null) {
                out.add(item);
            }
        }
        out.sort(Comparator.comparingInt(i -> i.category().renderOrder()));
        return out;
    }
}
