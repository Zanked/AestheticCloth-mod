package com.fittingroom.wardrobe;

import com.fittingroom.FittingRoomMod;

import java.time.LocalDate;
import java.time.MonthDay;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * All clothes known to the mod. Used on both sides (the server validates, the client displays).
 * A garment's 3D model lives in assets/fittingroom/clothes_models/&lt;id&gt;.json.
 */
public final class ClothingCatalog {
    private ClothingCatalog() {}

    /** New Year season: from December 15th to January 14th (inclusive). Santa's clothes only exist then. */
    private static final MonthDay NEW_YEAR_FROM = MonthDay.of(12, 15);
    private static final MonthDay NEW_YEAR_TO = MonthDay.of(1, 14);

    /**
     * @param seasonFrom first day of the season (null = available all year)
     * @param seasonTo   last day of the season; may be "before" seasonFrom when the season spans New Year
     */
    public record Item(String id, Category category, MonthDay seasonFrom, MonthDay seasonTo) {
        public Item(String id, Category category) {
            this(id, category, null, null);
        }

        public String translationKey() {
            return "clothes." + FittingRoomMod.MOD_ID + "." + id;
        }

        /** Is the garment in season today? Seasonal clothes are hidden and cannot be worn the rest of the year. */
        public boolean isAvailable() {
            if (seasonFrom == null || seasonTo == null) {
                return true;
            }
            MonthDay today = MonthDay.from(today());
            if (seasonFrom.compareTo(seasonTo) <= 0) {
                return today.compareTo(seasonFrom) >= 0 && today.compareTo(seasonTo) <= 0;
            }
            return today.compareTo(seasonFrom) >= 0 || today.compareTo(seasonTo) <= 0;
        }
    }

    /** Today's date; start the game with -Dfittingroom.date=2026-12-31 to test the seasons. */
    private static LocalDate today() {
        String forced = System.getProperty("fittingroom.date");
        if (forced != null) {
            try {
                return LocalDate.parse(forced);
            } catch (RuntimeException ignored) {
                // fall through to the real date
            }
        }
        return LocalDate.now();
    }

    private static Item newYear(String id, Category category) {
        return new Item(id, category, NEW_YEAR_FROM, NEW_YEAR_TO);
    }

    public static final List<Item> ITEMS = List.of(
            newYear("santa_hat", Category.HAT),
            newYear("santa_coat", Category.TOP),
            newYear("santa_pants", Category.BOTTOM),
            newYear("santa_boots", Category.SHOES),
            new Item("casual_cap", Category.HAT),
            new Item("casual_hoodie", Category.TOP),
            new Item("casual_jeans", Category.BOTTOM),
            new Item("casual_sneakers", Category.SHOES),
            new Item("punk_tee", Category.TOP),
            new Item("punk_jeans", Category.BOTTOM),
            new Item("cat_ears", Category.HAT),
            new Item("cat_sweater", Category.TOP),
            new Item("cat_pants", Category.BOTTOM),
            new Item("cat_paws", Category.SHOES),
            new Item("casual_backpack", Category.ACCESSORY),
            new Item("punk_cuffs", Category.ACCESSORY),
            newYear("santa_sack", Category.ACCESSORY),
            new Item("glasses_round", Category.ACCESSORY),
            new Item("glasses_sun", Category.ACCESSORY),
            new Item("glasses_heart", Category.ACCESSORY),
            new Item("glasses_3d", Category.ACCESSORY),
            new Item("glasses_pixel", Category.ACCESSORY)
    );

    private static final Map<String, Item> BY_ID = new HashMap<>();

    static {
        for (Item item : ITEMS) {
            BY_ID.put(item.id(), item);
        }
    }

    /** @return the item, or null if the id is unknown */
    public static Item byId(String id) {
        return BY_ID.get(id);
    }

    public static List<Item> inCategory(Category category) {
        List<Item> out = new ArrayList<>();
        for (Item item : ITEMS) {
            if (item.category() == category && item.isAvailable()) {
                out.add(item);
            }
        }
        return out;
    }

    /** Keeps only known ids, at most one per category (the last one wins), ordered by category. */
    public static List<String> sanitize(Collection<String> ids) {
        EnumMap<Category, String> chosen = new EnumMap<>(Category.class);
        for (String id : ids) {
            Item item = BY_ID.get(id);
            if (item != null && item.isAvailable()) {
                chosen.put(item.category(), item.id());
            }
        }
        return new ArrayList<>(chosen.values());
    }

    /** Known items from the list, in the order they should be drawn (bottom layers first). */
    public static List<Item> forRender(Collection<String> ids) {
        List<Item> out = new ArrayList<>();
        for (String id : ids) {
            Item item = BY_ID.get(id);
            if (item != null && item.isAvailable()) {
                out.add(item);
            }
        }
        out.sort(Comparator.comparingInt(i -> i.category().renderOrder()));
        return out;
    }
}
