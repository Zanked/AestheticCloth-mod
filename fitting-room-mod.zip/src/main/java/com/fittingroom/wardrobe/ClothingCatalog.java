package com.fittingroom.wardrobe;

import com.fittingroom.FittingRoomMod;

import java.time.LocalDate;
import java.time.MonthDay;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * All clothes known to the mod. Used on both sides (the server validates, the client displays).
 * A garment's 3D model lives in assets/fittingroom/clothes_models/&lt;id&gt;.json.
 */
public final class ClothingCatalog {
    private ClothingCatalog() {}

    /** Slot of the scarves: part of the Accessories tab, but worn together with another accessory. */
    public static final String NECK = "neck";
    /** Jewelry slots: worn together with scarves, backpacks, glasses and gloves. */
    public static final String CHOKER = "choker";
    public static final String NECKLACE = "necklace";
    public static final String WRIST = "wrist";
    /** More accessory slots: a shoulder bag, a sleep mask and earrings can be worn with everything else. */
    public static final String BAG = "bag";
    public static final String MASK = "mask";
    public static final String EARRINGS = "earrings";

    /** New Year season: from December 15th to January 14th (inclusive). Santa's clothes only exist then. */
    private static final MonthDay NEW_YEAR_FROM = MonthDay.of(12, 15);
    private static final MonthDay NEW_YEAR_TO = MonthDay.of(1, 14);

    /**
     * @param seasonFrom first day of the season (null = available all year)
     * @param seasonTo   last day of the season; may be "before" seasonFrom when the season spans New Year
     * @param slot       what the item occupies: one item per slot can be worn. Normally the category id;
     *                   scarves sit in the Accessories tab but in their own slot, so they go with a backpack or glasses
     */
    public record Item(String id, Category category, MonthDay seasonFrom, MonthDay seasonTo, String slot) {
        public Item(String id, Category category, MonthDay seasonFrom, MonthDay seasonTo) {
            this(id, category, seasonFrom, seasonTo, category.id());
        }

        public Item(String id, Category category) {
            this(id, category, null, null);
        }

        /** Lower values are drawn first. A scarf is drawn above the tops and below the other accessories. */
        public int renderOrder() {
            int extra = slot.equals(NECK) ? 5
                    : slot.equals(CHOKER) || slot.equals(NECKLACE) ? 6
                    : slot.equals(WRIST) ? 7
                    : slot.equals(BAG) ? 4
                    : slot.equals(MASK) ? 8
                    : slot.equals(EARRINGS) ? 9 : 0;
            return category.renderOrder() * 10 + extra;
        }

        /** Shelf price in US cents (see {@link ClothingPrices}). */
        public long priceCents() {
            return ClothingPrices.cents(id, category);
        }

        public String translationKey() {
            return "clothes." + FittingRoomMod.MOD_ID + "." + id;
        }

        /** Is the garment in season today? Seasonal clothes are hidden and cannot be worn the rest of the year. */
        public boolean isAvailable() {
            if (seasonFrom == null || seasonTo == null) {
                return true;
            }
            MonthDay today = MonthDay.from(today());
            if (seasonFrom.compareTo(seasonTo) <= 0) {
                return today.compareTo(seasonFrom) >= 0 && today.compareTo(seasonTo) <= 0;
            }
            return today.compareTo(seasonFrom) >= 0 || today.compareTo(seasonTo) <= 0;
        }
    }

    /** Today's date; start the game with -Dfittingroom.date=2026-12-31 to test the seasons. */
    public static LocalDate today() {
        String forced = System.getProperty("fittingroom.date");
        if (forced != null) {
            try {
                return LocalDate.parse(forced);
            } catch (RuntimeException ignored) {
                // fall through to the real date
            }
        }
        return LocalDate.now();
    }

    private static Item newYear(String id, Category category) {
        return new Item(id, category, NEW_YEAR_FROM, NEW_YEAR_TO);
    }

    private static Item jewel(String id, String slot) {
        return new Item(id, Category.ACCESSORY, null, null, slot);
    }

    private static Item scarf(String id) {
        return new Item(id, Category.ACCESSORY, null, null, NECK);
    }

    public static final List<Item> ITEMS = List.of(
            newYear("santa_hat", Category.HAT),
            newYear("santa_coat", Category.TOP),
            newYear("santa_pants", Category.BOTTOM),
            newYear("santa_boots", Category.SHOES),
            newYear("reindeer_antlers", Category.HAT),
            newYear("snow_kokoshnik", Category.HAT),
            newYear("xmas_sweater", Category.TOP),
            newYear("snow_coat", Category.TOP),
            newYear("snow_valenki", Category.SHOES),
            newYear("candy_cane", Category.ACCESSORY),
            new Item("necklace_snowflake", Category.ACCESSORY, NEW_YEAR_FROM, NEW_YEAR_TO, NECKLACE),
            new Item("bracelet_bells", Category.ACCESSORY, NEW_YEAR_FROM, NEW_YEAR_TO, WRIST),
            new Item("casual_cap", Category.HAT),
            new Item("casual_hoodie", Category.TOP),
            new Item("casual_jeans", Category.BOTTOM),
            new Item("casual_sneakers", Category.SHOES),
            new Item("halloween_pumpkin_hat", Category.HAT),
            new Item("halloween_ghost_hood", Category.HAT),
            new Item("halloween_bat_headband", Category.HAT),
            new Item("halloween_devil_horns", Category.HAT),
            new Item("halloween_ghost_sheet", Category.TOP),
            new Item("halloween_vampire_cape", Category.TOP),
            new Item("halloween_witch_dress", Category.TOP),
            new Item("halloween_skeleton_top", Category.TOP),
            new Item("halloween_skeleton_pants", Category.BOTTOM),
            new Item("halloween_mummy_top", Category.TOP),
            new Item("halloween_mummy_pants", Category.BOTTOM),
            new Item("halloween_devil_pants", Category.BOTTOM),
            new Item("halloween_witch_boots", Category.SHOES),
            new Item("halloween_candy_bucket", Category.ACCESSORY),
            new Item("pants_jeans_ripped", Category.BOTTOM),
            new Item("pants_jeans_flared", Category.BOTTOM),
            new Item("pants_jeans_white", Category.BOTTOM),
            new Item("pants_trousers_black", Category.BOTTOM),
            new Item("pants_chino_beige", Category.BOTTOM),
            new Item("pants_cargo_khaki", Category.BOTTOM),
            new Item("pants_sweat_gray", Category.BOTTOM),
            new Item("pants_sweat_black", Category.BOTTOM),
            new Item("pants_leggings_black", Category.BOTTOM),
            new Item("pants_leggings_pink", Category.BOTTOM),
            new Item("skirt_maxi_floral", Category.BOTTOM),
            new Item("skirt_maxi_satin", Category.BOTTOM),
            new Item("skirt_tennis", Category.BOTTOM),
            new Item("overalls_denim", Category.TOP),
            new Item("overalls_cord", Category.TOP),
            new Item("shoes_rain_yellow", Category.SHOES),
            new Item("shoes_rain_red", Category.SHOES),
            new Item("shoes_rain_pink", Category.SHOES),
            new Item("shoes_ballet_pink", Category.SHOES),
            new Item("shoes_ballet_black", Category.SHOES),
            new Item("shoes_ballet_white", Category.SHOES),
            new Item("shoes_platform_black", Category.SHOES),
            new Item("shoes_platform_white", Category.SHOES),
            new Item("shoes_platform_pink", Category.SHOES),
            new Item("shoes_bunny_white", Category.SHOES),
            new Item("shoes_bunny_pink", Category.SHOES),
            new Item("shoes_bunny_gray", Category.SHOES),
            new Item("dress_floral", Category.TOP),
            new Item("dress_sundress", Category.TOP),
            new Item("dress_evening", Category.TOP),
            new Item("dress_polka", Category.TOP),
            new Item("windbreaker_blue", Category.TOP),
            new Item("windbreaker_pink", Category.TOP),
            new Item("windbreaker_yellow", Category.TOP),
            new Item("trench_beige", Category.TOP),
            new Item("trench_black", Category.TOP),
            new Item("coat_camel", Category.TOP),
            new Item("coat_gray", Category.TOP),
            new Item("coat_red", Category.TOP),
            new Item("sweater_cable", Category.TOP),
            new Item("sweater_nordic", Category.TOP),
            new Item("sweater_pink", Category.TOP),
            new Item("sweater_stripe", Category.TOP),
            new Item("kimono_sakura", Category.TOP),
            new Item("kimono_red", Category.TOP),
            new Item("yukata_indigo", Category.TOP),
            new Item("yukata_light", Category.TOP),
            new Item("pajama_stars_top", Category.TOP),
            new Item("pajama_stars_pants", Category.BOTTOM),
            new Item("pajama_hearts_top", Category.TOP),
            new Item("pajama_hearts_pants", Category.BOTTOM),
            new Item("pajama_stripe_top", Category.TOP),
            new Item("pajama_stripe_pants", Category.BOTTOM),
            new Item("punk_jacket_black", Category.TOP),
            new Item("punk_jacket_brown", Category.TOP),
            new Item("punk_boots_black", Category.SHOES),
            new Item("punk_boots_brown", Category.SHOES),
            new Item("casual_tee_white", Category.TOP),
            new Item("casual_tee_black", Category.TOP),
            new Item("casual_tee_pink", Category.TOP),
            new Item("casual_tee_striped", Category.TOP),
            new Item("casual_shorts_denim", Category.BOTTOM),
            new Item("casual_shorts_black", Category.BOTTOM),
            new Item("casual_shorts_khaki", Category.BOTTOM),
            new Item("casual_skirt_denim", Category.BOTTOM),
            new Item("casual_skirt_pink", Category.BOTTOM),
            new Item("casual_skirt_plaid", Category.BOTTOM),
            new Item("casual_cardigan_cream", Category.TOP),
            new Item("casual_cardigan_pink", Category.TOP),
            new Item("casual_cardigan_blue", Category.TOP),
            new Item("casual_kedy_white", Category.SHOES),
            new Item("casual_kedy_red", Category.SHOES),
            new Item("casual_kedy_black", Category.SHOES),
            new Item("punk_tee", Category.TOP),
            new Item("punk_jeans", Category.BOTTOM),
            new Item("cat_ears", Category.HAT),
            new Item("cat_sweater", Category.TOP),
            new Item("cat_pants", Category.BOTTOM),
            new Item("cat_paws", Category.SHOES),
            new Item("dino_hood", Category.HAT),
            new Item("dino_top", Category.TOP),
            new Item("dino_pants", Category.BOTTOM),
            new Item("dino_slippers", Category.SHOES),
            new Item("dino_blue_hood", Category.HAT),
            new Item("dino_blue_top", Category.TOP),
            new Item("dino_blue_pants", Category.BOTTOM),
            new Item("dino_blue_slippers", Category.SHOES),
            new Item("school_bow", Category.HAT),
            new Item("school_top", Category.TOP),
            new Item("school_skirt", Category.BOTTOM),
            new Item("school_socks", Category.SHOES),
            new Item("school_bag", Category.ACCESSORY),
            new Item("school_black_bow", Category.HAT),
            new Item("school_black_top", Category.TOP),
            new Item("school_black_skirt", Category.BOTTOM),
            new Item("school_black_socks", Category.SHOES),
            new Item("school_black_bag", Category.ACCESSORY),
            new Item("boy_cap", Category.HAT),
            new Item("boy_gakuran", Category.TOP),
            new Item("boy_trousers", Category.BOTTOM),
            new Item("boy_shoes", Category.SHOES),
            new Item("plush_cat", Category.ACCESSORY),
            new Item("plush_dino", Category.ACCESSORY),
            new Item("plush_bear", Category.ACCESSORY),
            new Item("balloon_red", Category.ACCESSORY),
            new Item("balloon_pink", Category.ACCESSORY),
            new Item("balloon_blue", Category.ACCESSORY),
            new Item("balloon_yellow", Category.ACCESSORY),
            new Item("balloon_green", Category.ACCESSORY),
            new Item("balloon_purple", Category.ACCESSORY),
            new Item("balloon_bunch_rainbow", Category.ACCESSORY),
            new Item("balloon_bunch_pastel", Category.ACCESSORY),
            new Item("gloves_white", Category.ACCESSORY),
            new Item("gloves_black", Category.ACCESSORY),
            new Item("gloves_red", Category.ACCESSORY),
            new Item("gloves_pink", Category.ACCESSORY),
            new Item("gloves_blue", Category.ACCESSORY),
            new Item("gloves_yellow", Category.ACCESSORY),
            new Item("gloves_green", Category.ACCESSORY),
            new Item("gloves_purple", Category.ACCESSORY),
            new Item("casual_backpack", Category.ACCESSORY),
            new Item("punk_cuffs", Category.ACCESSORY),
            newYear("santa_sack", Category.ACCESSORY),
            new Item("glasses_round", Category.ACCESSORY),
            new Item("glasses_sun", Category.ACCESSORY),
            new Item("glasses_heart", Category.ACCESSORY),
            new Item("glasses_3d", Category.ACCESSORY),
            new Item("glasses_pixel", Category.ACCESSORY),
            scarf("scarf_red"),
            scarf("scarf_blue"),
            scarf("scarf_pink"),
            scarf("scarf_plaid"),
            scarf("scarf_rainbow"),
            new Item("scarf_xmas", Category.ACCESSORY, NEW_YEAR_FROM, NEW_YEAR_TO, NECK),
            jewel("choker_black", CHOKER),
            jewel("choker_pink", CHOKER),
            jewel("choker_lace", CHOKER),
            jewel("choker_chain", CHOKER),
            jewel("necklace_pearl", NECKLACE),
            jewel("necklace_heart", NECKLACE),
            jewel("necklace_star", NECKLACE),
            jewel("necklace_beads", NECKLACE),
            jewel("bracelet_gold", WRIST),
            jewel("bracelet_charm", WRIST),
            jewel("bracelet_beads", WRIST),
            jewel("bracelet_friendship", WRIST),
            jewel("choker_spiked", CHOKER),
            new Item("hat_witch", Category.HAT),
            new Item("hat_mushroom", Category.HAT),
            new Item("hat_crown", Category.HAT),
            new Item("hat_bunny", Category.HAT),
            new Item("hat_frog", Category.HAT),
            new Item("hat_halo", Category.HAT),
            new Item("hat_chef", Category.HAT),
            new Item("hat_propeller", Category.HAT),
            new Item("hat_strawberry", Category.HAT),
            new Item("hat_flowers", Category.HAT),
            new Item("hat_beanie_gray", Category.HAT),
            new Item("hat_beanie_mustard", Category.HAT),
            new Item("hat_beanie_pink", Category.HAT),
            new Item("hat_beret_red", Category.HAT),
            new Item("hat_beret_black", Category.HAT),
            new Item("hat_beret_cream", Category.HAT),
            new Item("hat_panama_natural", Category.HAT),
            new Item("hat_panama_white", Category.HAT),
            new Item("hat_panama_pink", Category.HAT),
            new Item("hat_cowboy_brown", Category.HAT),
            new Item("hat_cowboy_black", Category.HAT),
            new Item("hat_cowboy_cream", Category.HAT),
            jewel("bag_brown", BAG),
            jewel("bag_pink", BAG),
            jewel("bag_black", BAG),
            new Item("umbrella_pink", Category.ACCESSORY),
            new Item("umbrella_rainbow", Category.ACCESSORY),
            new Item("umbrella_black", Category.ACCESSORY),
            new Item("wings_angel", Category.ACCESSORY),
            new Item("wings_butterfly", Category.ACCESSORY),
            new Item("wings_bat", Category.ACCESSORY),
            jewel("mask_pink", MASK),
            jewel("mask_black", MASK),
            jewel("mask_lavender", MASK),
            jewel("earring_pearl", EARRINGS),
            jewel("earring_hoop", EARRINGS),
            jewel("earring_star", EARRINGS),
            jewel("earring_heart", EARRINGS),
            jewel("necklace_spider", NECKLACE)
    );

    private static final Map<String, Item> BY_ID = new HashMap<>();

    static {
        for (Item item : ITEMS) {
            BY_ID.put(item.id(), item);
        }
    }

    /** @return the item, or null if the id is unknown */
    public static Item byId(String id) {
        return BY_ID.get(id);
    }

    public static List<Item> inCategory(Category category) {
        List<Item> out = new ArrayList<>();
        for (Item item : ITEMS) {
            if (item.category() == category && item.isAvailable()) {
                out.add(item);
            }
        }
        return out;
    }

    /** Keeps only known ids, at most one per slot (the last one wins). */
    public static List<String> sanitize(Collection<String> ids) {
        Map<String, String> chosen = new LinkedHashMap<>();
        for (String id : ids) {
            Item item = BY_ID.get(id);
            if (item != null && item.isAvailable()) {
                chosen.put(item.slot(), item.id());
            }
        }
        return new ArrayList<>(chosen.values());
    }

    /** Known items from the list, in the order they should be drawn (bottom layers first). */
    public static List<Item> forRender(Collection<String> ids) {
        List<Item> out = new ArrayList<>();
        for (String id : ids) {
            Item item = BY_ID.get(id);
            if (item != null && item.isAvailable()) {
                out.add(item);
            }
        }
        out.sort(Comparator.comparingInt(Item::renderOrder));
        return out;
    }
}
