package com.fittingroom.wardrobe;

import com.fittingroom.FittingRoomMod;
import com.fittingroom.network.SyncOutfitPayload;
import com.fittingroom.network.WalletPayload;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.network.PacketDistributor;

/** Keeps every client's {@link ClientWardrobeStore} up to date. */
@EventBusSubscriber(modid = FittingRoomMod.MOD_ID)
public final class ServerEvents {
    private ServerEvents() {}

    public static SyncOutfitPayload payloadFor(ServerPlayer player) {
        return new SyncOutfitPayload(player.getUUID(), player.getData(FittingRoomMod.WARDROBE).items());
    }

    /** Tell the player and everyone who can see them what they are wearing now. */
    public static void syncToTrackers(ServerPlayer player) {
        PacketDistributor.sendToPlayersTrackingEntityAndSelf(player, payloadFor(player));
    }

    /** Tell the player what they own and how much money they have; {@code open} also opens the fitting room. */
    public static void sendWallet(ServerPlayer player, boolean open) {
        PacketDistributor.sendToPlayer(player,
                new WalletPayload(Shop.owned(player).items(), Shop.balance(player), open,
                        ClothingCatalog.today().toEpochDay(), player.getData(FittingRoomMod.SLOTS).padded()));
    }

    private static void syncToSelf(ServerPlayer player) {
        PacketDistributor.sendToPlayer(player, payloadFor(player));
    }

    /** A player starts seeing another player: send the other player's outfit. */
    @SubscribeEvent
    public static void onStartTracking(PlayerEvent.StartTracking event) {
        if (event.getEntity() instanceof ServerPlayer viewer && event.getTarget() instanceof ServerPlayer target) {
            PacketDistributor.sendToPlayer(viewer, payloadFor(target));
        }
    }

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            Shop.grandfather(player);
            syncToSelf(player);
            sendWallet(player, false);
        }
    }

    @SubscribeEvent
    public static void onRespawn(PlayerEvent.PlayerRespawnEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            syncToSelf(player);
            sendWallet(player, false);
        }
    }

    @SubscribeEvent
    public static void onChangedDimension(PlayerEvent.PlayerChangedDimensionEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            syncToSelf(player);
        }
    }
}
