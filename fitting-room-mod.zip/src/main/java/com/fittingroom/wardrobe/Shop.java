package com.fittingroom.wardrobe;

import com.fittingroom.FittingRoomMod;
import com.fittingroom.FittingSounds;
import com.fittingroom.economy.BankBridge;
import com.fittingroom.economy.Money;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Server side of the shop: clothes are paid from the player's account in the aestheticjobs bank.
 * Only the server decides: the client just says what it wants to wear (or to give away).
 * Prices come from {@link Sales#price}, so a running sale is applied here as well.
 */
public final class Shop {
    private Shop() {}

    public static OwnedData owned(ServerPlayer player) {
        return player.getData(FittingRoomMod.OWNED);
    }

    /** Current balance of the player's bank account, in cents. */
    public static long balance(ServerPlayer player) {
        return BankBridge.balance(player.server, player.getUUID());
    }

    /**
     * Wear the requested outfit: everything in it that the player does not own yet is bought first, all in one
     * payment. If the money is not enough (or the bank refuses) nothing is bought and the outfit stays as it was.
     *
     * @param wanted a list that already went through {@link ClothingCatalog#sanitize}
     * @return true if the outfit may be worn
     */
    public static boolean buyAndWear(ServerPlayer player, List<String> wanted) {
        OwnedData owned = owned(player);
        LocalDate day = ClothingCatalog.today();
        List<ClothingCatalog.Item> toBuy = new ArrayList<>();
        long total = 0;
        long shelf = 0;
        for (String id : wanted) {
            ClothingCatalog.Item item = ClothingCatalog.byId(id);
            if (item != null && !owned.owns(id)) {
                toBuy.add(item);
                total += Sales.price(item, day);
                shelf += item.priceCents();
            }
        }
        if (toBuy.isEmpty()) {
            return true;
        }

        MinecraftServer server = player.server;
        UUID account = player.getUUID();
        long balance = BankBridge.balance(server, account);
        if (balance < total) {
            player.sendSystemMessage(Component.translatable("message.fittingroom.not_enough",
                    Money.format(total), Money.format(balance)));
            FittingSounds.play(player, FittingSounds.ERROR, 0.8F);
            return false;
        }

        List<String> ids = ids(toBuy);
        if (!BankBridge.withdraw(server, account, total, reason("fittingroom: ", ids))) {
            player.sendSystemMessage(Component.translatable("message.fittingroom.payment_failed"));
            FittingSounds.play(player, FittingSounds.ERROR, 0.8F);
            return false;
        }

        player.setData(FittingRoomMod.OWNED, owned.with(ids));
        player.sendSystemMessage(Component.translatable("message.fittingroom.bought",
                toBuy.size(), Money.format(total), Money.format(balance - total)));
        if (shelf > total) {
            player.sendSystemMessage(Component.translatable("message.fittingroom.saved", Money.format(shelf - total)));
        }
        FittingSounds.play(player, FittingSounds.PURCHASE, 0.9F);
        return true;
    }

    /**
     * Buys the clothes for another player: the buyer pays (with the sale applied), the recipient gets them in
     * their wardrobe. Items the recipient already owns are skipped and not charged.
     *
     * @param wanted a list that already went through {@link ClothingCatalog#sanitize}
     * @return true if something was bought
     */
    public static boolean gift(ServerPlayer buyer, ServerPlayer recipient, List<String> wanted) {
        if (buyer.getUUID().equals(recipient.getUUID())) {
            return false;
        }
        OwnedData theirs = owned(recipient);
        LocalDate day = ClothingCatalog.today();
        List<ClothingCatalog.Item> toBuy = new ArrayList<>();
        long total = 0;
        for (String id : wanted) {
            ClothingCatalog.Item item = ClothingCatalog.byId(id);
            if (item != null && !theirs.owns(id)) {
                toBuy.add(item);
                total += Sales.price(item, day);
            }
        }
        if (toBuy.isEmpty()) {
            buyer.sendSystemMessage(Component.translatable("message.fittingroom.gift_nothing", recipient.getName()));
            return false;
        }

        UUID account = buyer.getUUID();
        long balance = BankBridge.balance(buyer.server, account);
        if (balance < total) {
            buyer.sendSystemMessage(Component.translatable("message.fittingroom.not_enough",
                    Money.format(total), Money.format(balance)));
            FittingSounds.play(buyer, FittingSounds.ERROR, 0.8F);
            return false;
        }

        List<String> ids = ids(toBuy);
        String reason = reason("fittingroom gift to " + recipient.getName().getString() + ": ", ids);
        if (!BankBridge.withdraw(buyer.server, account, total, reason)) {
            buyer.sendSystemMessage(Component.translatable("message.fittingroom.payment_failed"));
            FittingSounds.play(buyer, FittingSounds.ERROR, 0.8F);
            return false;
        }

        recipient.setData(FittingRoomMod.OWNED, theirs.with(ids));
        MutableComponent names = Component.empty();
        for (int i = 0; i < toBuy.size(); i++) {
            if (i > 0) {
                names.append(", ");
            }
            names.append(Component.translatable(toBuy.get(i).translationKey()));
        }
        buyer.sendSystemMessage(Component.translatable("message.fittingroom.gift_sent",
                toBuy.size(), recipient.getName(), Money.format(total), Money.format(balance - total)));
        recipient.sendSystemMessage(Component.translatable("message.fittingroom.gift_received",
                buyer.getName(), names));
        FittingSounds.play(buyer, FittingSounds.GIFT, 0.9F);
        FittingSounds.play(recipient, FittingSounds.GIFT, 0.9F);
        return true;
    }

    private static List<String> ids(List<ClothingCatalog.Item> items) {
        List<String> ids = new ArrayList<>();
        for (ClothingCatalog.Item item : items) {
            ids.add(item.id());
        }
        return ids;
    }

    private static String reason(String prefix, List<String> ids) {
        String reason = prefix + String.join(", ", ids);
        return reason.length() > 120 ? reason.substring(0, 117) + "..." : reason;
    }

    /**
     * Clothes that are worn but not owned (saved before the shop existed) become owned for free, once.
     * After that the worn list can only contain owned clothes, so this changes nothing any more.
     */
    public static void grandfather(ServerPlayer player) {
        List<String> worn = player.getData(FittingRoomMod.WARDROBE).items();
        OwnedData owned = owned(player);
        List<String> missing = new ArrayList<>();
        for (String id : worn) {
            if (ClothingCatalog.byId(id) != null && !owned.owns(id)) {
                missing.add(id);
            }
        }
        if (!missing.isEmpty()) {
            player.setData(FittingRoomMod.OWNED, owned.with(missing));
        }
    }
}
