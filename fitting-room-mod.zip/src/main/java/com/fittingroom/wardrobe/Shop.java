package com.fittingroom.wardrobe;

import com.fittingroom.FittingRoomMod;
import com.fittingroom.economy.BankBridge;
import com.fittingroom.economy.Money;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Server side of the shop: clothes are paid from the player's account in the aestheticjobs bank.
 * Only the server decides: the client just says what it wants to wear.
 */
public final class Shop {
    private Shop() {}

    public static OwnedData owned(ServerPlayer player) {
        return player.getData(FittingRoomMod.OWNED);
    }

    /** Current balance of the player's bank account, in cents. */
    public static long balance(ServerPlayer player) {
        return BankBridge.balance(player.server, player.getUUID());
    }

    /**
     * Wear the requested outfit: everything in it that the player does not own yet is bought first, all in one
     * payment. If the money is not enough (or the bank refuses) nothing is bought and the outfit stays as it was.
     *
     * @param wanted a list that already went through {@link ClothingCatalog#sanitize}
     * @return true if the outfit may be worn
     */
    public static boolean buyAndWear(ServerPlayer player, List<String> wanted) {
        OwnedData owned = owned(player);
        List<ClothingCatalog.Item> toBuy = new ArrayList<>();
        long total = 0;
        for (String id : wanted) {
            ClothingCatalog.Item item = ClothingCatalog.byId(id);
            if (item != null && !owned.owns(id)) {
                toBuy.add(item);
                total += item.priceCents();
            }
        }
        if (toBuy.isEmpty()) {
            return true;
        }

        MinecraftServer server = player.server;
        UUID account = player.getUUID();
        long balance = BankBridge.balance(server, account);
        if (balance < total) {
            player.sendSystemMessage(Component.translatable("message.fittingroom.not_enough",
                    Money.format(total), Money.format(balance)));
            return false;
        }

        List<String> ids = new ArrayList<>();
        for (ClothingCatalog.Item item : toBuy) {
            ids.add(item.id());
        }
        String reason = "fittingroom: " + String.join(", ", ids);
        if (reason.length() > 120) {
            reason = reason.substring(0, 117) + "...";
        }
        if (!BankBridge.withdraw(server, account, total, reason)) {
            player.sendSystemMessage(Component.translatable("message.fittingroom.payment_failed"));
            return false;
        }

        player.setData(FittingRoomMod.OWNED, owned.with(ids));
        player.sendSystemMessage(Component.translatable("message.fittingroom.bought",
                toBuy.size(), Money.format(total), Money.format(balance - total)));
        return true;
    }

    /**
     * Clothes that are worn but not owned (saved before the shop existed) become owned for free, once.
     * After that the worn list can only contain owned clothes, so this changes nothing any more.
     */
    public static void grandfather(ServerPlayer player) {
        List<String> worn = player.getData(FittingRoomMod.WARDROBE).items();
        OwnedData owned = owned(player);
        List<String> missing = new ArrayList<>();
        for (String id : worn) {
            if (ClothingCatalog.byId(id) != null && !owned.owns(id)) {
                missing.add(id);
            }
        }
        if (!missing.isEmpty()) {
            player.setData(FittingRoomMod.OWNED, owned.with(missing));
        }
    }
}
