package com.fittingroom.wardrobe;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Client-side copy of what every nearby player wears. Plain Java on purpose (no Minecraft client
 * classes), so it is safe to touch from the network handler on a dedicated server too.
 */
public final class ClientWardrobeStore {
    private ClientWardrobeStore() {}

    private static final Map<UUID, List<String>> OUTFITS = new ConcurrentHashMap<>();

    public static List<String> get(UUID player) {
        return OUTFITS.getOrDefault(player, List.of());
    }

    public static void set(UUID player, List<String> items) {
        OUTFITS.put(player, List.copyOf(items));
    }

    // ---- the local player's wallet: what they have bought and what is on their bank account ----
    private static volatile Set<String> owned = Set.of();
    private static volatile long balanceCents = 0L;

    public static boolean owns(String id) {
        return owned.contains(id);
    }

    public static long balance() {
        return balanceCents;
    }

    public static void setWallet(Collection<String> ownedIds, long balance) {
        owned = Set.copyOf(ownedIds);
        balanceCents = balance;
    }

    public static void clear() {
        OUTFITS.clear();
        owned = Set.of();
        balanceCents = 0L;
    }
}
