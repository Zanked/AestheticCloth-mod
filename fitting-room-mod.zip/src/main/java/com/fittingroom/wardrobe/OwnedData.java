package com.fittingroom.wardrobe;

import com.mojang.serialization.Codec;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * Clothes a player has bought (ids from {@link ClothingCatalog}). Saved as a data attachment on the player,
 * kept after death. Only things in this list can be worn.
 */
public record OwnedData(List<String> items) {
    public static final OwnedData EMPTY = new OwnedData(List.of());

    public static final Codec<OwnedData> CODEC =
            Codec.STRING.listOf().xmap(OwnedData::new, OwnedData::items);

    public boolean owns(String id) {
        return items.contains(id);
    }

    /** A copy with the ids added (order of purchase is kept, no duplicates). */
    public OwnedData with(Iterable<String> ids) {
        Set<String> all = new LinkedHashSet<>(items);
        for (String id : ids) {
            all.add(id);
        }
        return new OwnedData(new ArrayList<>(all));
    }
}
