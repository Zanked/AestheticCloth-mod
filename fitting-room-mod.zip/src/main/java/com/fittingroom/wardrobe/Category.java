package com.fittingroom.wardrobe;

/** Clothing categories. Declaration order = order of the tabs in the GUI. */
public enum Category {
    HAT("hat", 4),
    TOP("top", 2),
    BOTTOM("bottom", 0),
    SHOES("shoes", 1),
    ACCESSORY("accessory", 3);

    private final String id;
    private final int renderOrder;

    Category(String id, int renderOrder) {
        this.id = id;
        this.renderOrder = renderOrder;
    }

    public String id() {
        return id;
    }

    /** Lower values are drawn first (so later ones end up on top). */
    public int renderOrder() {
        return renderOrder;
    }
}
