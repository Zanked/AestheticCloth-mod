package com.fittingroom.wardrobe;

import com.mojang.serialization.Codec;

import java.util.List;

/** What a player is wearing (ids from {@link ClothingCatalog}). Saved as a data attachment on the player. */
public record WardrobeData(List<String> items) {
    public static final WardrobeData EMPTY = new WardrobeData(List.of());

    public static final Codec<WardrobeData> CODEC =
            Codec.STRING.listOf().xmap(WardrobeData::new, WardrobeData::items);
}
