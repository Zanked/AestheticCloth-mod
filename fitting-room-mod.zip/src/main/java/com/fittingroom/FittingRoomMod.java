package com.fittingroom;

import com.fittingroom.block.FittingRoomBlock;
import com.fittingroom.network.ModNetwork;
import com.fittingroom.wardrobe.OwnedData;
import com.fittingroom.wardrobe.WardrobeData;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.material.PushReaction;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.attachment.AttachmentType;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.NeoForgeRegistries;

import java.util.function.Supplier;

@Mod(FittingRoomMod.MOD_ID)
public class FittingRoomMod {
    public static final String MOD_ID = "fittingroom";

    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(MOD_ID);
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(MOD_ID);
    public static final DeferredRegister<AttachmentType<?>> ATTACHMENT_TYPES =
            DeferredRegister.create(NeoForgeRegistries.ATTACHMENT_TYPES, MOD_ID);

    public static final DeferredBlock<Block> FITTING_ROOM = BLOCKS.register("fitting_room",
            () -> new FittingRoomBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.COLOR_CYAN)
                    .strength(1.0F)
                    .sound(SoundType.WOOL)
                    .noOcclusion()
                    .pushReaction(PushReaction.DESTROY)));

    public static final DeferredItem<BlockItem> FITTING_ROOM_ITEM =
            ITEMS.registerSimpleBlockItem("fitting_room", FITTING_ROOM);

    /** What the player is wearing. Saved with the player and kept after death. */
    public static final Supplier<AttachmentType<WardrobeData>> WARDROBE = ATTACHMENT_TYPES.register("wardrobe",
            () -> AttachmentType.builder(() -> WardrobeData.EMPTY)
                    .serialize(WardrobeData.CODEC)
                    .copyOnDeath()
                    .build());

    /** What the player has bought. Saved with the player and kept after death. */
    public static final Supplier<AttachmentType<OwnedData>> OWNED = ATTACHMENT_TYPES.register("owned",
            () -> AttachmentType.builder(() -> OwnedData.EMPTY)
                    .serialize(OwnedData.CODEC)
                    .copyOnDeath()
                    .build());

    public FittingRoomMod(IEventBus modBus) {
        BLOCKS.register(modBus);
        ITEMS.register(modBus);
        ATTACHMENT_TYPES.register(modBus);
        modBus.addListener(this::addToCreativeTab);
        modBus.addListener(ModNetwork::register);
    }

    private void addToCreativeTab(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.FUNCTIONAL_BLOCKS) {
            event.accept(FITTING_ROOM_ITEM);
        }
    }
}
