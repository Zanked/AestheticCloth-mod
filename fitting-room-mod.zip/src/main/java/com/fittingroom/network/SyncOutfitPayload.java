package com.fittingroom.network;

import com.fittingroom.FittingRoomMod;
import io.netty.buffer.ByteBuf;
import net.minecraft.core.UUIDUtil;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

import java.util.List;
import java.util.UUID;

/** Server -> client: "this player wears these clothes". */
public record SyncOutfitPayload(UUID player, List<String> items) implements CustomPacketPayload {
    public static final CustomPacketPayload.Type<SyncOutfitPayload> TYPE =
            new CustomPacketPayload.Type<>(ResourceLocation.fromNamespaceAndPath(FittingRoomMod.MOD_ID, "sync_outfit"));

    public static final StreamCodec<ByteBuf, SyncOutfitPayload> STREAM_CODEC = StreamCodec.composite(
            UUIDUtil.STREAM_CODEC, SyncOutfitPayload::player,
            ByteBufCodecs.stringUtf8(64).apply(ByteBufCodecs.list(8)), SyncOutfitPayload::items,
            SyncOutfitPayload::new);

    @Override
    public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
