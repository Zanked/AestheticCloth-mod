package com.fittingroom.network;

import com.fittingroom.FittingRoomMod;
import com.fittingroom.FittingSounds;
import com.fittingroom.wardrobe.OutfitSlotsData;
import com.fittingroom.wardrobe.ClientWardrobeStore;
import com.fittingroom.wardrobe.ClothingCatalog;
import com.fittingroom.wardrobe.ServerEvents;
import com.fittingroom.wardrobe.Shop;
import com.fittingroom.wardrobe.WardrobeData;
import com.fittingroom.client.FittingRoomClient;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.handling.IPayloadContext;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;

import java.util.List;

public final class ModNetwork {
    private ModNetwork() {}

    public static void register(RegisterPayloadHandlersEvent event) {
        PayloadRegistrar registrar = event.registrar("3");
        registrar.playToServer(SetOutfitPayload.TYPE, SetOutfitPayload.STREAM_CODEC, ModNetwork::handleSetOutfit);
        registrar.playToServer(GiftPayload.TYPE, GiftPayload.STREAM_CODEC, ModNetwork::handleGift);
        registrar.playToServer(SaveSlotPayload.TYPE, SaveSlotPayload.STREAM_CODEC, ModNetwork::handleSaveSlot);
        registrar.playToClient(SyncOutfitPayload.TYPE, SyncOutfitPayload.STREAM_CODEC, ModNetwork::handleSync);
        registrar.playToClient(WalletPayload.TYPE, WalletPayload.STREAM_CODEC, ModNetwork::handleWallet);
    }

    /** Runs on the server: validate, pay for new clothes from the bank, save on the player, tell everybody. */
    private static void handleSetOutfit(SetOutfitPayload payload, IPayloadContext context) {
        if (!(context.player() instanceof ServerPlayer player)) {
            return;
        }
        // clothes can only be changed next to a fitting room
        if (!isNearFittingRoom(player)) {
            return;
        }
        List<String> clean = ClothingCatalog.sanitize(payload.items());
        List<String> before = player.getData(FittingRoomMod.WARDROBE).items();
        if (Shop.buyAndWear(player, clean)) {
            player.setData(FittingRoomMod.WARDROBE, new WardrobeData(clean));
            if (!clean.equals(before)) {
                FittingSounds.play(player, clean.isEmpty() ? FittingSounds.UNDRESS : FittingSounds.RUSTLE, 0.8F);
            }
        }
        // Always answer: the client already shows the new outfit as a preview, and if the purchase was refused
        // this puts the old outfit back. It also refreshes what the player owns and the balance.
        ServerEvents.syncToTrackers(player);
        ServerEvents.sendWallet(player, false);
    }

    /** Runs on the server: buy clothes for another player. */
    private static void handleGift(GiftPayload payload, IPayloadContext context) {
        if (!(context.player() instanceof ServerPlayer player) || !isNearFittingRoom(player)) {
            return;
        }
        ServerPlayer recipient = player.server.getPlayerList().getPlayer(payload.recipient());
        if (recipient == null) {
            player.sendSystemMessage(Component.translatable("message.fittingroom.gift_no_player"));
        } else {
            Shop.gift(player, recipient, ClothingCatalog.sanitize(payload.items()));
            ServerEvents.sendWallet(recipient, false);
        }
        ServerEvents.sendWallet(player, false);
    }

    /** Runs on the server: remember an outfit in one of the slots. */
    private static void handleSaveSlot(SaveSlotPayload payload, IPayloadContext context) {
        if (!(context.player() instanceof ServerPlayer player) || !isNearFittingRoom(player)) {
            return;
        }
        if (payload.slot() < 0 || payload.slot() >= OutfitSlotsData.COUNT) {
            return;
        }
        List<String> clean = ClothingCatalog.sanitize(payload.items());
        player.setData(FittingRoomMod.SLOTS, player.getData(FittingRoomMod.SLOTS).with(payload.slot(), clean));
        FittingSounds.play(player, FittingSounds.SLOT_SAVE, 0.6F);
        ServerEvents.sendWallet(player, false);
    }

    /** Runs on the client (no client-only classes are touched here). */
    private static void handleSync(SyncOutfitPayload payload, IPayloadContext context) {
        ClientWardrobeStore.set(payload.player(), payload.items());
    }

    /** Runs on the client. Opens the fitting room when the server asks for it. */
    private static void handleWallet(WalletPayload payload, IPayloadContext context) {
        context.enqueueWork(() -> {
            ClientWardrobeStore.setWallet(payload.owned(), payload.balanceCents(), payload.saleDay(), payload.slots());
            if (payload.open()) {
                FittingRoomClient.openWardrobe();
            }
        });
    }

    private static boolean isNearFittingRoom(ServerPlayer player) {
        BlockPos center = player.blockPosition();
        for (BlockPos pos : BlockPos.betweenClosed(center.offset(-4, -3, -4), center.offset(4, 3, 4))) {
            if (player.level().getBlockState(pos).is(FittingRoomMod.FITTING_ROOM.get())) {
                return true;
            }
        }
        return false;
    }
}
