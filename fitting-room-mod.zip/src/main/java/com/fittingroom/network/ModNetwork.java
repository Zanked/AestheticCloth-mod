package com.fittingroom.network;

import com.fittingroom.FittingRoomMod;
import com.fittingroom.wardrobe.ClientWardrobeStore;
import com.fittingroom.wardrobe.ClothingCatalog;
import com.fittingroom.wardrobe.ServerEvents;
import com.fittingroom.wardrobe.WardrobeData;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.handling.IPayloadContext;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;

import java.util.List;

public final class ModNetwork {
    private ModNetwork() {}

    public static void register(RegisterPayloadHandlersEvent event) {
        PayloadRegistrar registrar = event.registrar("1");
        registrar.playToServer(SetOutfitPayload.TYPE, SetOutfitPayload.STREAM_CODEC, ModNetwork::handleSetOutfit);
        registrar.playToClient(SyncOutfitPayload.TYPE, SyncOutfitPayload.STREAM_CODEC, ModNetwork::handleSync);
    }

    /** Runs on the server: validate, save on the player, tell everybody. */
    private static void handleSetOutfit(SetOutfitPayload payload, IPayloadContext context) {
        if (!(context.player() instanceof ServerPlayer player)) {
            return;
        }
        // clothes can only be changed next to a fitting room
        if (!isNearFittingRoom(player)) {
            return;
        }
        List<String> clean = ClothingCatalog.sanitize(payload.items());
        player.setData(FittingRoomMod.WARDROBE, new WardrobeData(clean));
        ServerEvents.syncToTrackers(player);
    }

    /** Runs on the client (no client-only classes are touched here). */
    private static void handleSync(SyncOutfitPayload payload, IPayloadContext context) {
        ClientWardrobeStore.set(payload.player(), payload.items());
    }

    private static boolean isNearFittingRoom(ServerPlayer player) {
        BlockPos center = player.blockPosition();
        for (BlockPos pos : BlockPos.betweenClosed(center.offset(-4, -3, -4), center.offset(4, 3, 4))) {
            if (player.level().getBlockState(pos).is(FittingRoomMod.FITTING_ROOM.get())) {
                return true;
            }
        }
        return false;
    }
}
