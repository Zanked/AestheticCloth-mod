package com.fittingroom.economy;

import java.lang.reflect.Method;

/**
 * Formats amounts given in US cents. Uses the formatter of the aestheticjobs mod when it is loaded (so both mods
 * always show money the same way), otherwise a plain built-in "$1,234.56" format.
 */
public final class Money {
    private Money() {}

    private static volatile Method external;
    private static volatile boolean looked;

    public static String format(long cents) {
        Method m = findExternal();
        if (m != null) {
            try {
                Object s = m.invoke(null, cents);
                if (s != null) {
                    return s.toString();
                }
            } catch (ReflectiveOperationException | RuntimeException ignored) {
                // fall through to the built-in format
            }
        }
        return fallback(cents);
    }

    private static Method findExternal() {
        if (!looked) {
            synchronized (Money.class) {
                if (!looked) {
                    try {
                        Class<?> c = Class.forName("dev.aestheticjobs.economy.Money");
                        external = c.getMethod("format", long.class);
                    } catch (ReflectiveOperationException | LinkageError ignored) {
                        external = null;
                    }
                    looked = true;
                }
            }
        }
        return external;
    }

    private static String fallback(long cents) {
        String sign = cents < 0 ? "-" : "";
        long abs = Math.abs(cents);
        return String.format(java.util.Locale.US, "%s$%,d.%02d", sign, abs / 100, abs % 100);
    }
}
