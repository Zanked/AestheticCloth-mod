package com.fittingroom.block;

import com.fittingroom.client.FittingRoomClient;
import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.level.gameevent.GameEvent;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * Two-block-tall fitting room. The front faces {@code FACING}.
 * Right click toggles the curtain (OPEN). The inside is hollow, so players can walk in
 * and close the curtain behind them.
 */
public class FittingRoomBlock extends HorizontalDirectionalBlock {
    public static final MapCodec<FittingRoomBlock> CODEC = simpleCodec(FittingRoomBlock::new);
    public static final DirectionProperty FACING = HorizontalDirectionalBlock.FACING;
    public static final EnumProperty<DoubleBlockHalf> HALF = BlockStateProperties.DOUBLE_BLOCK_HALF;
    public static final BooleanProperty OPEN = BlockStateProperties.OPEN;

    // [direction horizontal index][open ? 1 : 0]
    private static final VoxelShape[][] SHAPES = new VoxelShape[4][2];      // outline
    private static final VoxelShape[][] COLLISION = new VoxelShape[4][2];   // collision

    static {
        for (Direction dir : Direction.Plane.HORIZONTAL) {
            int i = dir.get2DDataValue();
            VoxelShape walls = Shapes.or(
                    box(dir, 1, 15, 15, 16),    // back wall
                    box(dir, 0, 0, 1, 16),      // left wall
                    box(dir, 15, 0, 16, 16));   // right wall
            VoxelShape frontCurtain = box(dir, 0, 0, 16, 1);
            VoxelShape bunch = box(dir, 1, 0, 5.4, 2.8);
            COLLISION[i][0] = Shapes.or(walls, frontCurtain);
            COLLISION[i][1] = walls;
            SHAPES[i][0] = COLLISION[i][0];
            SHAPES[i][1] = Shapes.or(walls, bunch);
        }
    }

    /** Box in "north-facing" coordinates (x1,z1)-(x2,z2), full height, rotated to the given direction. */
    private static VoxelShape box(Direction dir, double x1, double z1, double x2, double z2) {
        return switch (dir) {
            case EAST -> Block.box(16 - z2, 0, x1, 16 - z1, 16, x2);
            case SOUTH -> Block.box(16 - x2, 0, 16 - z2, 16 - x1, 16, 16 - z1);
            case WEST -> Block.box(z1, 0, 16 - x2, z2, 16, 16 - x1);
            default -> Block.box(x1, 0, z1, x2, 16, z2);
        };
    }

    public FittingRoomBlock(Properties properties) {
        super(properties);
        registerDefaultState(stateDefinition.any()
                .setValue(FACING, Direction.NORTH)
                .setValue(HALF, DoubleBlockHalf.LOWER)
                .setValue(OPEN, false));
    }

    @Override
    protected MapCodec<? extends HorizontalDirectionalBlock> codec() {
        return CODEC;
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(FACING, HALF, OPEN);
    }

    @Override
    protected VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext ctx) {
        return SHAPES[state.getValue(FACING).get2DDataValue()][state.getValue(OPEN) ? 1 : 0];
    }

    @Override
    protected VoxelShape getCollisionShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext ctx) {
        return COLLISION[state.getValue(FACING).get2DDataValue()][state.getValue(OPEN) ? 1 : 0];
    }

    // ---------- placement ----------

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext ctx) {
        BlockPos pos = ctx.getClickedPos();
        Level level = ctx.getLevel();
        if (pos.getY() < level.getMaxBuildHeight() - 1 && level.getBlockState(pos.above()).canBeReplaced(ctx)) {
            return defaultBlockState()
                    .setValue(FACING, ctx.getHorizontalDirection().getOpposite())
                    .setValue(HALF, DoubleBlockHalf.LOWER)
                    .setValue(OPEN, false);
        }
        return null;
    }

    @Override
    public void setPlacedBy(Level level, BlockPos pos, BlockState state, LivingEntity placer, ItemStack stack) {
        level.setBlock(pos.above(), state.setValue(HALF, DoubleBlockHalf.UPPER), 3);
    }

    @Override
    protected boolean canSurvive(BlockState state, LevelReader level, BlockPos pos) {
        BlockPos below = pos.below();
        BlockState belowState = level.getBlockState(below);
        if (state.getValue(HALF) == DoubleBlockHalf.LOWER) {
            return belowState.isFaceSturdy(level, below, Direction.UP);
        }
        return belowState.is(this) && belowState.getValue(HALF) == DoubleBlockHalf.LOWER;
    }

    @Override
    protected BlockState updateShape(BlockState state, Direction direction, BlockState neighborState,
                                     LevelAccessor level, BlockPos pos, BlockPos neighborPos) {
        DoubleBlockHalf half = state.getValue(HALF);
        boolean towardOtherHalf = direction.getAxis() == Direction.Axis.Y
                && (half == DoubleBlockHalf.LOWER) == (direction == Direction.UP);
        if (towardOtherHalf) {
            if (neighborState.is(this) && neighborState.getValue(HALF) != half) {
                return state;
            }
            return Blocks.AIR.defaultBlockState();
        }
        if (half == DoubleBlockHalf.LOWER && direction == Direction.DOWN && !state.canSurvive(level, pos)) {
            return Blocks.AIR.defaultBlockState();
        }
        return super.updateShape(state, direction, neighborState, level, pos, neighborPos);
    }

    @Override
    public BlockState playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        if (!level.isClientSide && player.isCreative() && state.getValue(HALF) == DoubleBlockHalf.UPPER) {
            BlockPos below = pos.below();
            BlockState belowState = level.getBlockState(below);
            if (belowState.is(this) && belowState.getValue(HALF) == DoubleBlockHalf.LOWER) {
                level.setBlock(below, Blocks.AIR.defaultBlockState(), 35);
                level.levelEvent(player, 2001, below, Block.getId(belowState));
            }
        }
        return super.playerWillDestroy(level, pos, state, player);
    }

    // ---------- curtain ----------

    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player,
                                               BlockHitResult hit) {
        // Standing inside the cabin: right click opens the wardrobe, sneak + right click moves the curtain.
        BlockPos lower = state.getValue(HALF) == DoubleBlockHalf.LOWER ? pos : pos.below();
        BlockPos feet = player.blockPosition();
        boolean inside = feet.equals(lower) || feet.equals(lower.above());
        if (inside && !player.isSecondaryUseActive()) {
            if (level.isClientSide) {
                FittingRoomClient.openWardrobe();
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }

        BlockState newState = state.cycle(OPEN);
        boolean open = newState.getValue(OPEN);
        BlockPos otherPos = state.getValue(HALF) == DoubleBlockHalf.LOWER ? pos.above() : pos.below();
        BlockState other = level.getBlockState(otherPos);

        level.setBlock(pos, newState, 10);
        if (other.is(this)) {
            level.setBlock(otherPos, other.setValue(OPEN, open), 10);
        }
        level.playSound(player, pos, SoundEvents.WOOL_PLACE, SoundSource.BLOCKS, 1.0F, open ? 1.15F : 0.85F);
        level.gameEvent(player, open ? GameEvent.BLOCK_OPEN : GameEvent.BLOCK_CLOSE, pos);
        return InteractionResult.sidedSuccess(level.isClientSide);
    }

    @Override
    protected BlockState rotate(BlockState state, Rotation rotation) {
        return state.setValue(FACING, rotation.rotate(state.getValue(FACING)));
    }

    @Override
    protected BlockState mirror(BlockState state, Mirror mirror) {
        return state.rotate(mirror.getRotation(state.getValue(FACING)));
    }
}
