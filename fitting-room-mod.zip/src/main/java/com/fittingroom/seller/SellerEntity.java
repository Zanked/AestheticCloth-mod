package com.fittingroom.seller;

import com.fittingroom.FittingRoomMod;
import com.fittingroom.wardrobe.ClothingCatalog;
import com.fittingroom.wardrobe.Sales;
import com.fittingroom.wardrobe.ServerEvents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * The shop assistant. She stands where she was put, looks at customers, greets them (chat + speech bubble),
 * and every payment for clothes goes through her: see {@link Sellers}.
 * <ul>
 *   <li>right click: opens the wardrobe in shop mode</li>
 *   <li>sneak + right click: haggle (once a day)</li>
 *   <li>the owner (or an op in creative) picks her up with sneak + attack and gets the contract back</li>
 * </ul>
 */
public class SellerEntity extends PathfinderMob {
    private static final EntityDataAccessor<Integer> VARIANT =
            SynchedEntityData.defineId(SellerEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<String> BUBBLE_KEY =
            SynchedEntityData.defineId(SellerEntity.class, EntityDataSerializers.STRING);
    private static final EntityDataAccessor<String> BUBBLE_ARG =
            SynchedEntityData.defineId(SellerEntity.class, EntityDataSerializers.STRING);

    public static final String[] NAMES = {"Mia", "Lily", "Sakura", "Nika", "Chloe", "Emi", "Alisa", "Hana"};
    public static final int VARIANTS = 3;
    private static final int GREET_RANGE = 5;
    private static final long GREET_COOLDOWN = 2400L; // 2 minutes

    private UUID owner;
    private int bubbleTicks;
    private final Map<UUID, Long> lastGreeted = new HashMap<>();

    public SellerEntity(EntityType<? extends SellerEntity> type, Level level) {
        super(type, level);
        this.setPersistenceRequired();
        this.setInvulnerable(true);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 20.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0D);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(VARIANT, 0);
        builder.define(BUBBLE_KEY, "");
        builder.define(BUBBLE_ARG, "");
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new LookAtPlayerGoal(this, Player.class, 7.0F));
        this.goalSelector.addGoal(2, new RandomLookAroundGoal(this));
    }

    // ---------------------------------------------------------------- data
    public int variant() {
        return Math.floorMod(this.entityData.get(VARIANT), VARIANTS);
    }

    public UUID owner() {
        return owner;
    }

    /** Gives a freshly placed seller her look and name. */
    public void setup(UUID ownerId) {
        this.owner = ownerId;
        this.entityData.set(VARIANT, this.random.nextInt(VARIANTS));
        this.setCustomName(Component.literal(NAMES[this.random.nextInt(NAMES.length)]));
        this.setCustomNameVisible(true);
    }

    /** The speech bubble above her head (empty key = none). The text is a translation key, so it fits the language. */
    public String bubbleKey() {
        return this.entityData.get(BUBBLE_KEY);
    }

    public String bubbleArg() {
        return this.entityData.get(BUBBLE_ARG);
    }

    public void say(String key, String arg) {
        this.entityData.set(BUBBLE_KEY, key);
        this.entityData.set(BUBBLE_ARG, arg);
        this.bubbleTicks = 110;
    }

    public void say(String key) {
        say(key, "");
    }

    // ---------------------------------------------------------------- behaviour
    @Override
    public void tick() {
        super.tick();
        if (!this.level().isClientSide) {
            if (this.bubbleTicks > 0 && --this.bubbleTicks == 0) {
                this.entityData.set(BUBBLE_KEY, "");
            }
            if (this.tickCount % 20 == 0) {
                greetNearby();
            }
        }
    }

    private void greetNearby() {
        long now = this.level().getGameTime();
        for (ServerPlayer player : this.level().getEntitiesOfClass(ServerPlayer.class,
                this.getBoundingBox().inflate(GREET_RANGE), p -> !p.isSpectator())) {
            Long last = lastGreeted.get(player.getUUID());
            if (last != null && now - last < GREET_COOLDOWN) {
                continue;
            }
            lastGreeted.put(player.getUUID(), now);
            greet(player);
            if (this.bubbleTicks > 0) {
                break; // one customer at a time, the others get their turn after the cooldown
            }
        }
        if (lastGreeted.size() > 64) {
            lastGreeted.values().removeIf(t -> now - t > GREET_COOLDOWN);
        }
    }

    private void greet(ServerPlayer player) {
        this.getLookControl().setLookAt(player, 30.0F, 30.0F);
        this.swing(InteractionHand.MAIN_HAND);
        Sales.Offer offer = Sales.headline(ClothingCatalog.today());
        if (offer != null) {
            say("seller.fittingroom.bubble.greet_sale", Integer.toString(offer.percent()));
        } else {
            say("seller.fittingroom.bubble.greet" + this.random.nextInt(4));
        }
        player.sendSystemMessage(Component.translatable("seller.fittingroom.chat", this.getDisplayName(),
                Component.translatable(bubbleKey(), bubbleArg())));
        // the new customer learns at once that paying here works
        ServerEvents.sendWallet(player, false);
    }

    @Override
    protected InteractionResult mobInteract(Player player, InteractionHand hand) {
        if (hand != InteractionHand.MAIN_HAND) {
            return InteractionResult.PASS;
        }
        if (!this.level().isClientSide && player instanceof ServerPlayer serverPlayer) {
            this.getLookControl().setLookAt(player, 30.0F, 30.0F);
            if (player.isShiftKeyDown()) {
                Sellers.haggle(serverPlayer, this);
            } else {
                this.swing(InteractionHand.MAIN_HAND);
                ServerEvents.sendWallet(serverPlayer, true);
            }
        }
        return InteractionResult.sidedSuccess(this.level().isClientSide);
    }

    // ---------------------------------------------------------------- protection / pick up
    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (this.level().isClientSide) {
            return false;
        }
        if (source.getEntity() instanceof ServerPlayer player) {
            boolean mayTake = player.getUUID().equals(owner) || (player.isCreative() && player.hasPermissions(2));
            if (mayTake && player.isShiftKeyDown()) {
                pickUp(player);
            } else {
                say("seller.fittingroom.bubble.hands_off");
            }
            return false;
        }
        // /kill and the void still work
        if (source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            return super.hurt(source, amount);
        }
        return false;
    }

    private void pickUp(ServerPlayer player) {
        ItemStack contract = new ItemStack(FittingRoomMod.SELLER_CONTRACT.get());
        if (!player.getInventory().add(contract)) {
            player.drop(contract, false);
        }
        this.discard();
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    @Override
    public boolean removeWhenFarAway(double distance) {
        return false;
    }

    // ---------------------------------------------------------------- save
    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("Variant", this.entityData.get(VARIANT));
        if (owner != null) {
            tag.putUUID("Owner", owner);
        }
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        this.entityData.set(VARIANT, tag.getInt("Variant"));
        this.owner = tag.hasUUID("Owner") ? tag.getUUID("Owner") : null;
    }
}
