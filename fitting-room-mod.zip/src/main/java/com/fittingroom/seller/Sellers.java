package com.fittingroom.seller;

import com.fittingroom.FittingRoomMod;
import com.fittingroom.FittingSounds;
import com.fittingroom.economy.BankBridge;
import com.fittingroom.economy.Money;
import com.fittingroom.network.SellerStatePayload;
import com.fittingroom.wardrobe.ClothingCatalog;
import com.fittingroom.wardrobe.Sales;
import net.minecraft.ChatFormatting;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.ItemLore;
import net.neoforged.neoforge.network.PacketDistributor;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Server-side rules of the seller: who is near, haggling, the loyalty card, commission and the receipt. */
public final class Sellers {
    private Sellers() {}

    /** A customer must stand this close to a seller to pay. */
    public static final double RANGE = 10.0D;
    /** Share of the paid amount that goes to the owner of the seller. */
    public static final int COMMISSION_PERCENT = 30;

    private record Haggle(long day, int percent) {}

    private static final Map<UUID, Haggle> HAGGLES = new ConcurrentHashMap<>();

    public static SellerEntity nearest(ServerPlayer player, double range) {
        SellerEntity best = null;
        double bestDist = Double.MAX_VALUE;
        for (SellerEntity seller : player.level().getEntitiesOfClass(SellerEntity.class,
                player.getBoundingBox().inflate(range), SellerEntity::isAlive)) {
            double d = seller.distanceToSqr(player);
            if (d <= range * range && d < bestDist) {
                best = seller;
                bestDist = d;
            }
        }
        return best;
    }

    public static boolean nearSeller(ServerPlayer player) {
        return nearest(player, RANGE) != null;
    }

    public static long spent(ServerPlayer player) {
        return player.getData(FittingRoomMod.LOYALTY).spent();
    }

    /** Today's haggle discount of the player (0 if none or from another day). */
    public static int haggle(ServerPlayer player) {
        Haggle h = HAGGLES.get(player.getUUID());
        return h != null && h.day() == ClothingCatalog.today().toEpochDay() ? h.percent() : 0;
    }

    /** Loyalty card + haggle, the discount that is applied at the till. */
    public static int percent(ServerPlayer player) {
        return Loyalty.total(spent(player), haggle(player));
    }

    public static void sendState(ServerPlayer player) {
        PacketDistributor.sendToPlayer(player, new SellerStatePayload(nearSeller(player), haggle(player), spent(player)));
    }

    // ---------------------------------------------------------------- haggling
    public static void haggle(ServerPlayer player, SellerEntity seller) {
        long today = ClothingCatalog.today().toEpochDay();
        Haggle old = HAGGLES.get(player.getUUID());
        if (old != null && old.day() == today) {
            seller.say("seller.fittingroom.bubble.haggle_again");
            player.displayClientMessage(Component.translatable("seller.fittingroom.haggle_again"), true);
            return;
        }
        int tier = Loyalty.tier(spent(player));
        boolean win = player.getRandom().nextFloat() < 0.35F + 0.08F * tier;
        int pct = win ? 3 + player.getRandom().nextInt(9) : 0;
        HAGGLES.put(player.getUUID(), new Haggle(today, pct));
        seller.swing(net.minecraft.world.InteractionHand.MAIN_HAND);
        ServerLevel level = (ServerLevel) player.level();
        if (win) {
            seller.say("seller.fittingroom.bubble.haggle_win", Integer.toString(pct));
            player.sendSystemMessage(Component.translatable("seller.fittingroom.haggle_win", seller.getDisplayName(), pct));
            level.sendParticles(ParticleTypes.HAPPY_VILLAGER, seller.getX(), seller.getY() + 1.9, seller.getZ(), 8, 0.3, 0.3, 0.3, 0.0);
            FittingSounds.play(player, FittingSounds.GIFT, 0.8F);
        } else {
            seller.say("seller.fittingroom.bubble.haggle_lose");
            player.sendSystemMessage(Component.translatable("seller.fittingroom.haggle_lose", seller.getDisplayName()));
            level.sendParticles(ParticleTypes.SMOKE, seller.getX(), seller.getY() + 1.9, seller.getZ(), 5, 0.2, 0.2, 0.2, 0.01);
            FittingSounds.play(player, FittingSounds.ERROR, 0.6F);
        }
        sendState(player);
    }

    // ---------------------------------------------------------------- after a sale
    /**
     * Called after the bank took the money: loyalty points, owner's commission, receipt, little show.
     *
     * @param paid what the customer really paid (cents)
     */
    public static void afterSale(ServerPlayer player, SellerEntity seller, long paid,
                                 List<ClothingCatalog.Item> items, int percent) {
        LocalDate day = ClothingCatalog.today();
        int tierBefore = Loyalty.tier(spent(player));
        player.setData(FittingRoomMod.LOYALTY, player.getData(FittingRoomMod.LOYALTY).plus(paid));
        int tierAfter = Loyalty.tier(spent(player));

        commission(player, seller, paid);
        giveReceipt(player, seller, paid, items, percent, day);

        ServerLevel level = (ServerLevel) player.level();
        seller.swing(net.minecraft.world.InteractionHand.MAIN_HAND);
        level.sendParticles(ParticleTypes.HEART, seller.getX(), seller.getY() + 2.1, seller.getZ(), 5, 0.3, 0.2, 0.3, 0.0);
        if (tierAfter > tierBefore) {
            seller.say("seller.fittingroom.bubble.tier_up");
            player.sendSystemMessage(Component.translatable("seller.fittingroom.tier_up",
                    Component.translatable("seller.fittingroom.tier." + Loyalty.IDS[tierAfter]),
                    Loyalty.PERCENT[tierAfter]).withStyle(ChatFormatting.LIGHT_PURPLE));
            level.sendParticles(ParticleTypes.HAPPY_VILLAGER, player.getX(), player.getY() + 1.0, player.getZ(), 14, 0.5, 0.6, 0.5, 0.0);
        } else {
            seller.say("seller.fittingroom.bubble.thanks");
        }
    }

    private static void commission(ServerPlayer buyer, SellerEntity seller, long paid) {
        UUID owner = seller.owner();
        if (owner == null || owner.equals(buyer.getUUID())) {
            return;
        }
        long cut = paid * COMMISSION_PERCENT / 100;
        if (cut <= 0) {
            return;
        }
        String reason = "fittingroom commission from " + buyer.getName().getString();
        if (BankBridge.deposit(buyer.server, owner, cut, reason)) {
            ServerPlayer ownerPlayer = buyer.server.getPlayerList().getPlayer(owner);
            if (ownerPlayer != null) {
                ownerPlayer.sendSystemMessage(Component.translatable("seller.fittingroom.commission",
                        Money.format(cut), buyer.getName(), seller.getDisplayName()).withStyle(ChatFormatting.GOLD));
            }
        }
    }

    private static void giveReceipt(ServerPlayer player, SellerEntity seller, long paid,
                                    List<ClothingCatalog.Item> items, int percent, LocalDate day) {
        ItemStack receipt = new ItemStack(Items.PAPER);
        receipt.set(DataComponents.CUSTOM_NAME, plain(Component.translatable("seller.fittingroom.receipt"), ChatFormatting.LIGHT_PURPLE));
        List<Component> lore = new ArrayList<>();
        lore.add(plain(Component.translatable("seller.fittingroom.receipt.seller", seller.getDisplayName()), ChatFormatting.GRAY));
        lore.add(plain(Component.literal(day.toString()), ChatFormatting.DARK_GRAY));
        int shown = Math.min(8, items.size());
        for (int i = 0; i < shown; i++) {
            ClothingCatalog.Item item = items.get(i);
            lore.add(plain(Component.literal("• ").append(Component.translatable(item.translationKey()))
                    .append(" — " + Money.format(Sales.price(item, day))), ChatFormatting.WHITE));
        }
        if (items.size() > shown) {
            lore.add(plain(Component.translatable("seller.fittingroom.receipt.more", items.size() - shown), ChatFormatting.GRAY));
        }
        if (percent > 0) {
            lore.add(plain(Component.translatable("seller.fittingroom.receipt.discount", percent), ChatFormatting.GREEN));
        }
        lore.add(plain(Component.translatable("seller.fittingroom.receipt.total", Money.format(paid)), ChatFormatting.GOLD));
        receipt.set(DataComponents.LORE, new ItemLore(lore));
        if (!player.getInventory().add(receipt)) {
            player.drop(receipt, false);
        }
    }

    private static Component plain(Component c, ChatFormatting color) {
        return c.copy().withStyle(s -> s.withItalic(false).withColor(color));
    }
}
