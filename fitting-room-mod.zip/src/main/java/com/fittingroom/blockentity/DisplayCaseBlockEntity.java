package com.fittingroom.blockentity;

import com.fittingroom.FittingRoomMod;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

/** The three garments standing in a display case ("" = empty slot). */
public class DisplayCaseBlockEntity extends BlockEntity {
    public static final int SLOTS = 3;

    private final String[] slots = {"", "", ""};
    /** Counts the clicks: which of your worn clothes goes in next, and into which slot. */
    private int cursor = 0;

    public DisplayCaseBlockEntity(BlockPos pos, BlockState state) {
        super(FittingRoomMod.DISPLAY_CASE_BE.get(), pos, state);
    }

    public String slot(int index) {
        return slots[index];
    }

    public int cursor() {
        return cursor;
    }

    /** Puts a garment into the next slot (the oldest one is replaced when the case is full). */
    public void put(String id) {
        slots[cursor % SLOTS] = id;
        cursor++;
        changed();
    }

    public void clear() {
        for (int i = 0; i < SLOTS; i++) {
            slots[i] = "";
        }
        cursor = 0;
        changed();
    }

    private void changed() {
        setChanged();
        if (level != null) {
            level.sendBlockUpdated(worldPosition, getBlockState(), getBlockState(), 3);
        }
    }

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        for (int i = 0; i < SLOTS; i++) {
            tag.putString("slot" + i, slots[i]);
        }
        tag.putInt("cursor", cursor);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        for (int i = 0; i < SLOTS; i++) {
            slots[i] = tag.getString("slot" + i);
        }
        cursor = tag.getInt("cursor");
    }

    @Override
    public CompoundTag getUpdateTag(HolderLookup.Provider registries) {
        return saveWithoutMetadata(registries);
    }

    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }
}
