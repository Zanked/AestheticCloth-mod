#!/usr/bin/env python3
"""
Generates the scarves of the fitting room (accessories, slot "neck": worn together with a backpack, glasses ...).
 - scarf_red, scarf_blue: knitted striped scarves with fringe
 - scarf_pink: soft pastel knit with pom-poms
 - scarf_plaid: camel tartan scarf with fringe
 - scarf_rainbow: rainbow stripes
 - scarf_xmas: red/white/green candy stripes (New Year season)
Each scarf = two chunky rings around the neck/shoulders (outside of every top and the skin's hat layer),
a knot on the front left and two tails that hang down the chest, slightly tilted towards the body.
Models, 32x textures and 16x16 icons; same smooth painter as gen_dino.py.

Run from the project root:  python3 tools/gen_scarves.py
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from gen_dino import build, mix  # noqa: E402
from gen_accessories import Cube, Icon, shade  # noqa: E402

WHITE = (252, 250, 246)
RAINBOW = [(228, 66, 76), (246, 150, 66), (252, 214, 80), (96, 190, 112), (80, 146, 226), (150, 108, 220)]

SCARVES = {
    "red": dict(main=(206, 62, 74), acc=(250, 238, 220), dark=(148, 38, 52), fringe=(250, 238, 220), pattern="stripes"),
    "blue": dict(main=(84, 138, 214), acc=(250, 240, 222), dark=(48, 92, 166), fringe=(250, 240, 222), pattern="stripes"),
    "pink": dict(main=(248, 172, 198), acc=(255, 246, 250), dark=(226, 126, 160), fringe=WHITE, pattern="knit", pom=True),
    "plaid": dict(main=(214, 178, 132), acc=(188, 54, 54), dark=(96, 66, 52), fringe=(214, 178, 132), pattern="plaid"),
    "rainbow": dict(main=(246, 150, 66), acc=WHITE, dark=(120, 80, 60), fringe=WHITE, pattern="rainbow"),
    "xmas": dict(main=(204, 50, 62), acc=(252, 250, 246), dark=(46, 140, 82), fringe=WHITE, pattern="stripes"),
}


# ---------------------------------------------------------------- texture patterns (pixel rows: 2 px per unit)
def pattern(pal, ring=0):
    """Returns deco(f, x, y, w, h) for a part of the scarf. ring > 0: a neck ring (low, so only a thin pattern)."""
    main, acc, dark, kind = pal["main"], pal["acc"], pal["dark"], pal["pattern"]

    def d(f, x, y, w, h):
        if f in ("top", "bottom"):
            return None
        if kind == "stripes":
            if ring:
                return acc if y == (1 if ring == 1 else 2) else None
            r = y % 14
            if r in (4, 5, 6):
                return acc
            if r in (3, 7):
                return dark
            return None
        if kind == "knit":
            c = mix(main, WHITE, 0.2) if x % 4 in (0, 1) else None
            if not ring and y % 18 in (7, 8):
                return acc
            return c
        if kind == "plaid":
            hb = y % 12 in (3, 4)
            vb = x % 12 in (3, 4)
            thin_h, thin_v = y % 12 == 8, x % 12 == 8
            if hb and vb:
                return mix(acc, dark, 0.5)
            if hb or vb:
                return acc
            if thin_h or thin_v:
                return dark
            return None
        if kind == "rainbow":
            idx = (y + (0 if ring <= 1 else 2)) // (1 if ring else 4)
            return RAINBOW[idx % len(RAINBOW)]
        return None
    return d


def d_fringe(pal):
    def d(f, x, y, w, h):
        if f in ("top", "bottom"):
            return None
        if f in ("front", "back") and y >= 1 and x % 2 == 1:
            return "clear"
        return mix(pal["fringe"], pal["dark"], 0.18) if f in ("front", "back") and y % 3 == 2 else pal["fringe"]
    return d


def d_pom(pal):
    def d(f, x, y, w, h):
        return mix(pal["fringe"], WHITE, 0.35) if (x * 5 + y * 3) % 7 == 0 else pal["fringe"]
    return d


def scarf(name):
    pal = SCARVES[name]
    main = pal["main"]
    cubes = [
        # two chunky rings, both outside the hat layer of the skin (+-4.5) and of every top
        Cube("wrap_a", "body", (0, -0.7, 0), (9.8, 1.8, 9.4), main, pattern(pal, 1)),
        Cube("wrap_b", "body", (0, 1.1, 0), (11.0, 2.0, 9.8), main, pattern(pal, 2)),
        Cube("knot", "body", (2.0, 1.6, -5.5), (3.0, 2.6, 1.6), shade(main, 0.92), pattern(pal, 2)),
    ]
    tails = [("long", 1.3, 2.6, 2.2, 7.4, -5.3, 0.9), ("short", 3.4, 2.8, 2.0, 5.0, -5.55, 0.8)]
    for tag, cx, top, w, h, z, dep in tails:
        piv = (cx, top, z)
        rot = (12, 0, 0)
        cubes.append(Cube(f"tail_{tag}", "body", (cx, top + h / 2, z), (w, h, dep), main, pattern(pal), pivot=piv, rot=rot))
        if pal.get("pom"):
            cubes.append(Cube(f"end_{tag}", "body", (cx, top + h + 0.7, z), (1.9, 1.9, 1.9), pal["fringe"], d_pom(pal),
                              pivot=piv, rot=rot))
        else:
            cubes.append(Cube(f"end_{tag}", "body", (cx, top + h + 0.6, z), (w, 1.2, dep - 0.2), pal["fringe"], d_fringe(pal),
                              pivot=piv, rot=rot))
    return build(f"scarf_{name}", cubes)


# ---------------------------------------------------------------- icons
def icon(name):
    pal = SCARVES[name]
    main, acc, dark, kind = pal["main"], pal["acc"], pal["dark"], pal["pattern"]
    i = Icon()

    def band(y):
        if kind == "rainbow":
            return RAINBOW[y % 6]
        if kind == "plaid":
            return acc if y in (10, 11) else main
        if kind == "knit":
            return acc if y == 10 else main
        return acc if y in (10, 11) else main

    i.rect(3, 3, 12, 3, mix(main, WHITE, 0.25))
    i.rect(2, 4, 13, 5, main)
    i.rect(3, 6, 12, 6, shade(main, 0.84))
    if kind == "rainbow":
        for x, col in zip(range(2, 14, 2), RAINBOW):
            i.rect(x, 4, x + 1, 5, col)
    i.rect(8, 5, 11, 8, shade(main, 0.9))
    i.put(9, 6, mix(main, WHITE, 0.3))
    for y in range(8, 14):
        for x in (8, 9, 10):
            i.put(x, y, band(y))
    for y in range(8, 12):
        for x in (11, 12, 13):
            i.put(x, y, band(y + 2))
    if pal.get("pom"):
        i.rect(8, 14, 10, 14, pal["fringe"])
        i.rect(11, 12, 13, 12, pal["fringe"])
    else:
        for x in (8, 10):
            i.put(x, 14, pal["fringe"])
        for x in (11, 13):
            i.put(x, 12, pal["fringe"])
    i.save(f"scarf_{name}")


if __name__ == "__main__":
    for n in SCARVES:
        scarf(n)
        icon(n)
    print("scarves generated:", ", ".join(SCARVES))
