#!/usr/bin/env python3
"""
Z-fighting ("flicker") detector and fixer for the garment models (assets/fittingroom/clothes_models/*.json).

Two faces z-fight when they lie in (almost) the same plane, look the same way and overlap. In the garment
models that happens between two cubes of one garment (e.g. a stripe cube sitting exactly on the base cube)
and between a cube and the player's own skin layers (head 8x8x8, hat layer +0.5, jacket +0.25 ...).

The fix never touches textures or UV: the cube that should stay on top (the one with the smaller face, or
the garment against the skin) is made a hair bigger with `grow` on the axis of the clashing face, so its
face ends up MIN_GAP units in front of the other one. Running it twice changes nothing.

    python3 tools/zfight.py            # fix every model in place and print what was changed
    python3 tools/zfight.py --check    # only report, exit code 1 if anything flickers
"""
import json
import sys
from pathlib import Path

ASSETS = Path(__file__).resolve().parent.parent / "src/main/resources/assets/fittingroom"
MODELS = ASSETS / "clothes_models"

DETECT = 0.02   # faces closer than this (in model units, 1 unit = 1/16 block) and facing the same way flicker
MIN_GAP = 0.03  # after the fix the winning face is at least this far in front
MIN_AREA = 1e-4

# vanilla player boxes in bone space (lo, hi): skin and the outer skin layer
GROW_OVERLAY = {"head": 0.5, "body": 0.25, "right_arm": 0.25, "left_arm": 0.25, "right_leg": 0.25, "left_leg": 0.25}


def vanilla(bone, slim):
    if bone == "head":
        b = ((-4, -8, -4), (4, 0, 4))
    elif bone == "body":
        b = ((-4, 0, -2), (4, 12, 2))
    elif bone == "right_arm":
        b = ((-2 if slim else -3, -2, -2), (1, 10, 2))
    elif bone == "left_arm":
        b = ((-1, -2, -2), (2 if slim else 3, 10, 2))
    else:
        b = ((-2, 0, -2), (2, 12, 2))
    g = GROW_OVERLAY[bone]
    skin = b
    layer = (tuple(v - g for v in b[0]), tuple(v + g for v in b[1]))
    return [("skin", skin), ("skin layer", layer)]


def cube_box(cube, slim):
    """Box (lo, hi) of a cube in bone space after `grow`, or None if the cube is rotated."""
    rot = cube.get("rot")
    if rot and any(abs(r) > 1e-6 for r in rot):
        return None
    p, s, g = cube["pos"], cube["size"], cube["grow"]
    lo = [p[i] - g[i] for i in range(3)]
    hi = [p[i] + s[i] + g[i] for i in range(3)]
    if slim and cube["bone"] in ("right_arm", "left_arm"):
        centre = -0.5 if cube["bone"] == "right_arm" else 0.5
        half = (s[0] / 2 + g[0]) * 0.75
        lo[0], hi[0] = centre - half, centre + half
    return lo, hi


def faces(box):
    """Yield (axis, sign, plane, (u0, u1), (v0, v1)) for the six faces of a box."""
    lo, hi = box
    for a in range(3):
        o = [i for i in range(3) if i != a]
        for sign, plane in ((-1, lo[a]), (1, hi[a])):
            yield a, sign, plane, (lo[o[0]], hi[o[0]]), (lo[o[1]], hi[o[1]])


def overlap(r1, r2):
    return max(0.0, min(r1[1], r2[1]) - max(r1[0], r2[0]))


def area(f):
    return (f[3][1] - f[3][0]) * (f[4][1] - f[4][0])


def clashes(box_a, box_b):
    """Faces of A and B that flicker: list of (axis, sign, face_a, face_b)."""
    out = []
    fb = list(faces(box_b))
    for fa in faces(box_a):
        for fb_ in fb:
            if fa[0] != fb_[0] or fa[1] != fb_[1] or abs(fa[2] - fb_[2]) >= DETECT:
                continue
            if overlap(fa[3], fb_[3]) * overlap(fa[4], fb_[4]) > MIN_AREA:
                out.append((fa[0], fa[1], fa, fb_))
    return out


def rank(boxes, i):
    lo, hi = boxes[i]
    return ((hi[0] - lo[0]) * (hi[1] - lo[1]) * (hi[2] - lo[2]), -i)


def analyse(model, slim):
    """Return a list of fixes [(cube_index, axis, needed_extra_grow, text)] for one model and arm type."""
    cubes = model["cubes"]
    boxes = [cube_box(c, slim) for c in cubes]
    fixes = []
    for i, bi in enumerate(boxes):
        if bi is None:
            continue
        ci = cubes[i]
        for name, ref in vanilla(ci["bone"], slim):
            for axis, sign, fa, fb in clashes(bi, ref):
                need = MIN_GAP - (fa[2] - fb[2]) * sign
                fixes.append((i, axis, need, f"{ci['name']} vs player {name}"))
        for j in range(i + 1, len(boxes)):
            bj = boxes[j]
            if bj is None or cubes[j]["bone"] != ci["bone"]:
                continue
            for axis, sign, fa, fb in clashes(bi, bj):
                # one fixed order for the whole pair, so the two faces of an axis never ask for opposite things:
                # the smaller cube stays on top (a detail on a base); equal volumes: the later cube
                top, under, f_top, f_under = (i, j, fa, fb) if rank(boxes, i) < rank(boxes, j) else (j, i, fb, fa)
                need = MIN_GAP - (f_top[2] - f_under[2]) * sign
                fixes.append((top, axis, need, f"{cubes[top]['name']} over {cubes[under]['name']}"))
    return fixes


def fix_model(model, apply=True):
    """Grow cubes until nothing flickers (for wide and slim arms). Returns the list of messages."""
    messages = []
    for _ in range(20):
        changed = False
        for slim in (False, True):
            for idx, axis, need, text in analyse(model, slim):
                cube = model["cubes"][idx]
                if need > 0:
                    cube["grow"][axis] = round(cube["grow"][axis] + need + 0.0005, 4)
                    messages.append(f"{text} ({'xyz'[axis]} +{need:.3f})")
                    changed = True
        if not changed or not apply:
            break
    return messages


def main():
    check = "--check" in sys.argv
    bad = 0
    for path in sorted(MODELS.glob("*.json")):
        model = json.loads(path.read_text())
        found = [m for slim in (False, True) for *_, m in analyse(model, slim)]
        if check:
            if found:
                bad += 1
                print(f"{path.stem}: {len(set(found))} clash(es): {sorted(set(found))[:4]}")
            continue
        messages = fix_model(model)
        if messages:
            path.write_text(json.dumps(model, indent=1) + "\n")
            print(f"{path.stem}: fixed {len(messages)} -> {sorted(set(m.split(' (')[0] for m in messages))[:5]}")
    if check:
        print("flicker-free" if not bad else f"{bad} model(s) flicker")
        sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
