#!/usr/bin/env python3
"""
Generates the jewelry of the fitting room (accessories, each kind in its own slot, so jewelry goes together with a
backpack, glasses, scarves and gloves; one piece per slot):
  choker_*     (slot "choker")   black velvet with a heart, pink ribbon with a bow, white lace with a pearl,
                                 silver chain with a star
  necklace_*   (slot "necklace") pearls, gold chain with a heart, silver chain with a star, rainbow beads
  bracelet_*   (slot "wrist")    gold bangles, silver charm bracelet, beaded, friendship bracelet (both wrists)
Chokers and necklaces sit on the chest in front of every top; bracelets are rings round the wrists, drawn over gloves.
Models, 32x textures, 16x16 GUI icons and (idempotently) the entries in clothes.json, the lang files and
ClothingCatalog.java. Same smooth painter as gen_dino.py.

Run from the project root:  python3 tools/gen_jewelry.py
"""
import json
import math
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from gen_dino import build, mix  # noqa: E402
from gen_accessories import Cube, Icon, shade  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent
WHITE = (252, 250, 246)
RAINBOW = [(236, 84, 96), (248, 160, 70), (250, 216, 84), (110, 196, 120), (90, 160, 236), (166, 120, 230)]
GOLD, GOLD_D, GOLD_L = (240, 196, 84), (186, 136, 48), (255, 232, 150)
SILVER, SILVER_D, SILVER_L = (206, 212, 228), (134, 140, 162), (248, 250, 255)


# ------------------------------------------------------------------ shapes (u, v in 0..1 over the face)
def in_heart(u, v):
    x, y = (u - 0.5) * 2.5, 1.25 - v * 2.3
    return (x * x + y * y - 1) ** 3 - x * x * y ** 3 <= 0


STAR_PTS = [((0.5 + (0.5 if k % 2 == 0 else 0.21) * math.sin(k * math.pi / 5)),
             (0.54 - (0.52 if k % 2 == 0 else 0.22) * math.cos(k * math.pi / 5))) for k in range(10)]


def in_star(u, v):
    inside, j = False, len(STAR_PTS) - 1
    for i, (xi, yi) in enumerate(STAR_PTS):
        xj, yj = STAR_PTS[j]
        if (yi > v) != (yj > v) and u < (xj - xi) * (v - yi) / (yj - yi) + xi:
            inside = not inside
        j = i
    return inside


def shaped(mask, col, hi, edge, side, faces=("front", "back")):
    """Deco for a flat charm: the shape is cut out of the big faces, with an outline and a glint."""
    def d(f, x, y, w, h):
        if f not in faces:
            return side
        def inside(px, py):
            return 0 <= px < w and 0 <= py < h and mask((px + 0.5) / w, (py + 0.5) / h)
        if not inside(x, y):
            return "clear"
        if not all(inside(x + dx, y + dy) for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1))):
            return edge
        if x + y <= 2 + (w + h) // 8:
            return hi
        return col
    return d


def band(base, hi, dark):
    """Plain band: lit top row, dark bottom row."""
    def d(f, x, y, w, h):
        if f in ("top", "bottom"):
            return None
        return hi if y == 0 else dark if y == h - 1 else base
    return d


def tw(side, n):
    return None if side == "r" else n + "_r"


# ====================================================================== CHOKERS
CHOKERS = {
    "black": dict(base=(34, 32, 44), hi=(78, 74, 96), dark=(22, 20, 30), kind="heart",
                  ru="Чёрный чокер с сердечком", en="Black Heart Choker"),
    "pink": dict(base=(246, 150, 188), hi=(255, 204, 226), dark=(212, 108, 150), kind="bow",
                 ru="Розовый чокер с бантиком", en="Pink Bow Choker"),
    "lace": dict(base=(248, 246, 242), hi=WHITE, dark=(214, 206, 220), kind="pearl",
                 ru="Кружевной чокер с жемчужиной", en="Lace Pearl Choker"),
    "chain": dict(base=SILVER, hi=SILVER_L, dark=SILVER_D, kind="star",
                  ru="Чокер-цепочка со звездой", en="Star Chain Choker"),
    "spiked": dict(base=(28, 26, 34), hi=(70, 66, 86), dark=(16, 14, 22), kind="spikes",
                   ru="Панк-чокер с шипами", en="Punk Spiked Choker"),
}


def choker_deco(p):
    if p["kind"] == "pearl":
        def d(f, x, y, w, h):
            if f in ("top", "bottom"):
                return None
            if y == h - 1:
                return p["dark"] if x % 2 == 0 else p["base"]
            if x % 4 == 1 and y % 3 == 1:
                return p["dark"]
            return p["hi"] if y == 0 else p["base"]
        return d
    if p["kind"] == "star":
        def d(f, x, y, w, h):
            if f in ("top", "bottom"):
                return None
            return p["dark"] if (x // 2) % 2 == 0 and y in (0, h - 1) else p["hi"] if (x // 2) % 2 == 1 else p["base"]
        return d
    return band(p["base"], p["hi"], p["dark"])


def choker(name, p):
    dec = choker_deco(p)
    cubes = [Cube("strip", "body", (0, 1.0, -3.1), (3.0, 1.0, 1.4), p["base"], dec)]
    for side, sx in (("r", -1), ("l", 1)):
        m = side == "l"
        cubes.append(Cube(f"mid_{side}", "body", (sx * 2.25, 1.0, -2.95), (1.5, 1.0, 1.2), p["base"], dec,
                          twin_of=tw(side, "mid"), mirror=m))
        cubes.append(Cube(f"end_{side}", "body", (sx * 3.2, 1.0, -2.5), (0.9, 1.0, 1.0), p["base"], dec,
                          twin_of=tw(side, "end"), mirror=m))
    k = p["kind"]
    if k == "heart":
        cubes.append(Cube("link", "body", (0, 1.9, -3.75), (0.6, 0.7, 0.4), SILVER_D, None))
        cubes.append(Cube("charm", "body", (0, 3.0, -3.75), (2.6, 2.4, 0.4), SILVER,
                          shaped(in_heart, SILVER, SILVER_L, SILVER_D, SILVER_D)))
    elif k == "star":
        cubes.append(Cube("link", "body", (0, 1.9, -3.75), (0.6, 0.7, 0.4), SILVER_D, None))
        cubes.append(Cube("charm", "body", (0, 3.2, -3.75), (3.0, 3.0, 0.4), GOLD,
                          shaped(in_star, GOLD, GOLD_L, GOLD_D, GOLD_D)))
    elif k == "pearl":
        cubes.append(Cube("drop", "body", (0, 2.4, -3.65), (1.4, 1.4, 1.2), (250, 242, 240),
                          lambda f, x, y, w, h: (255, 255, 255) if f == "front" and x == 0 and y == 0 else None))
    elif k == "spikes":
        def cone(n, x, z, side=None):
            """A little pyramid: a metal base and a bright tip, sticking out of the strap."""
            for part, dims, dz, col in (("base", (0.9, 0.9, 0.6), 0.0, SILVER), ("tip", (0.5, 0.5, 0.6), -0.55, SILVER_L)):
                dec = band(col, SILVER_L, SILVER_D)
                if side is None:
                    cubes.append(Cube(f"{n}_{part}", "body", (x, 1.0, z + dz), dims, col, dec))
                else:
                    sx, m = (-1, False) if side == "r" else (1, True)
                    cubes.append(Cube(f"{n}_{part}_{side}", "body", (sx * x, 1.0, z + dz), dims, col, dec,
                                      twin_of=None if side == "r" else f"{n}_{part}_r", mirror=m))
        cone("sp_c", 0.0, -4.1)
        for side in ("r", "l"):
            cone("sp_a", 1.2, -4.0, side)
            cone("sp_b", 2.5, -3.85, side)
    elif k == "bow":
        cubes.append(Cube("knot", "body", (0, 1.0, -3.95), (1.0, 1.0, 0.8), p["dark"], band(p["base"], p["hi"], p["dark"])))
        for side, sx in (("r", -1), ("l", 1)):
            m = side == "l"
            cubes.append(Cube(f"loop_{side}", "body", (sx * 1.2, 1.0, -3.95), (1.6, 1.4, 0.6), p["base"],
                              band(p["base"], p["hi"], p["dark"]), twin_of=tw(side, "loop"), mirror=m))
            cubes.append(Cube(f"tail_{side}", "body", (sx * 0.6, 2.5, -3.9), (0.8, 1.8, 0.4), p["base"],
                              band(p["base"], p["hi"], p["dark"]), twin_of=tw(side, "tail"), mirror=m))
    return build(name, cubes)


# ====================================================================== NECKLACES
NECKLACES = {
    "pearl": dict(base=(248, 242, 240), alt=(236, 226, 228), kind="pearl",
                  ru="Жемчужное ожерелье", en="Pearl Necklace"),
    "heart": dict(base=GOLD, alt=GOLD_D, kind="heart", ru="Цепочка с сердечком", en="Heart Necklace"),
    "star": dict(base=SILVER, alt=SILVER_D, kind="star", ru="Цепочка со звездой", en="Star Necklace"),
    "beads": dict(base=RAINBOW[0], alt=RAINBOW[1], kind="beads", ru="Разноцветные бусы", en="Rainbow Beads"),
}
NZ = -3.2  # in front of every top (hoodie, cardigan ...)


def chain_points(n, x0=2.6, x1=0.5, y0=1.0, y1=4.0):
    pts = []
    for i in range(n):
        t = i / (n - 1)
        pts.append((-(x0 + (x1 - x0) * t), y0 + (y1 - y0) * t ** 1.15))
    return pts


def necklace(name, p):
    k = p["kind"]
    n, d = {"pearl": (6, 1.0), "beads": (7, 1.0)}.get(k, (8, 0.7))
    cubes = []
    for i, (x, y) in enumerate(chain_points(n)):
        if k == "beads":
            col = RAINBOW[i % 6]
        elif k == "pearl":
            col = p["base"] if i % 2 == 0 else p["alt"]
        else:
            col = p["base"] if i % 2 == 0 else p["alt"]
        dec = (lambda f, x_, y_, w, h: (255, 255, 255) if f == "front" and x_ == 0 and y_ == 0 else None) \
            if k in ("pearl", "beads") else None
        depth = d if k in ("pearl", "beads") else 0.5
        cubes.append(Cube(f"c{i}_r", "body", (x, y, NZ), (d, d, depth), col, dec))
        cubes.append(Cube(f"c{i}_l", "body", (-x, y, NZ), (d, d, depth), col, dec, twin_of=f"c{i}_r", mirror=True))
    if k == "pearl":
        cubes.append(Cube("drop", "body", (0, 4.7, NZ - 0.1), (1.6, 1.6, 1.3), p["base"],
                          lambda f, x, y, w, h: (255, 255, 255) if f == "front" and x == 0 and y == 0 else None))
    elif k == "beads":
        cubes.append(Cube("drop", "body", (0, 4.7, NZ - 0.1), (1.6, 1.6, 1.3), (244, 120, 170),
                          lambda f, x, y, w, h: (255, 255, 255) if f == "front" and x == 0 and y == 0 else None))
    elif k == "heart":
        cubes.append(Cube("charm", "body", (0, 5.0, NZ - 0.1), (3.4, 3.0, 0.4), (230, 56, 92),
                          shaped(in_heart, (230, 56, 92), (255, 156, 180), (170, 30, 66), GOLD_D)))
    elif k == "star":
        cubes.append(Cube("charm", "body", (0, 5.1, NZ - 0.1), (3.4, 3.4, 0.4), (252, 220, 92),
                          shaped(in_star, (252, 220, 92), (255, 246, 170), (200, 150, 40), SILVER_D)))
    return build(name, cubes)


# ====================================================================== BRACELETS
BRACELETS = {
    "gold": dict(kind="gold", ru="Золотые браслеты", en="Gold Bangles"),
    "charm": dict(kind="charm", ru="Серебряный браслет с сердечком", en="Silver Charm Bracelet"),
    "beads": dict(kind="beads", ru="Браслет из бусин", en="Beaded Bracelet"),
    "friendship": dict(kind="friendship", ru="Плетёный браслет дружбы", en="Friendship Bracelet"),
}
FR = [(246, 150, 188), WHITE, (166, 120, 230)]
RW = 5.1  # ring width: a bit more than the arm (4)


def bracelet(name, p):
    k = p["kind"]
    cubes = []
    for side, sx in (("r", -1), ("l", 1)):
        bone, m = ("right_arm" if side == "r" else "left_arm"), side == "l"
        cx = sx * 1

        def add(n, center, dims, base, deco=None):
            cubes.append(Cube(f"{n}_{side}", bone, center, dims, base, deco, twin_of=tw(side, n), mirror=m))

        if k == "gold":
            add("ring_a", (cx, 6.4, 0), (RW, 0.7, RW), GOLD, band(GOLD, GOLD_L, GOLD_D))
            add("ring_b", (cx, 7.4, 0), (RW, 0.7, RW), GOLD, band(GOLD, GOLD_L, GOLD_D))
            add("gem", (sx * 3.65, 6.9, 0), (0.6, 0.9, 0.9), (236, 70, 100),
                lambda f, x, y, w, h: (255, 170, 190) if x == 0 and y == 0 else None)
        elif k == "charm":
            add("ring", (cx, 7.0, 0), (RW, 0.7, RW), SILVER,
                lambda f, x, y, w, h: None if f in ("top", "bottom") else (SILVER_D if (x // 2) % 2 else SILVER_L))
            add("link", (sx * 3.7, 7.5, 0), (0.5, 0.7, 0.5), SILVER_D, None)
            add("charm", (sx * 3.8, 8.9, 0), (0.5, 2.2, 2.2), (244, 120, 170),
                shaped(in_heart, (244, 120, 170), (255, 190, 214), (190, 70, 120), SILVER_D, ("left", "right")))
        elif k == "beads":
            add("ring", (cx, 7.0, 0), (RW, 1.1, RW), RAINBOW[0],
                lambda f, x, y, w, h: None if f in ("top", "bottom") else RAINBOW[((x // 2) + (y // 2) * 2) % 6])
        else:  # friendship
            add("ring", (cx, 7.0, 0), (RW, 1.6, RW), FR[0],
                lambda f, x, y, w, h: None if f in ("top", "bottom") else FR[((x + y) // 2) % 3])
            add("knot", (sx * 3.7, 7.0, 0), (0.8, 1.2, 1.2), FR[2], None)
            add("tail_a", (sx * 3.85, 8.4, -0.4), (0.5, 1.8, 0.5), FR[0], None)
            add("tail_b", (sx * 3.85, 8.1, 0.4), (0.5, 1.4, 0.5), FR[1], None)
    return build(name, cubes)


# ====================================================================== icons
HEART_I = [".X.X.", "XXXXX", ".XXX.", "..X.."]
STAR_I = ["..X..", "XXXXX", ".XXX.", ".X.X."]


def stamp(i, pat, x0, y0, col, hi=None):
    for dy, row in enumerate(pat):
        for dx, ch in enumerate(row):
            if ch == "X":
                i.put(x0 + dx, y0 + dy, col)
    if hi:
        i.put(x0 + 1, y0, hi)


def icon_choker(name, p):
    i = Icon()
    arc = {4: [(2, 3), (12, 13)], 5: [(3, 4), (11, 12)], 6: [(4, 11)], 7: [(5, 10)]}
    for y, runs in arc.items():
        for x0, x1 in runs:
            for x in range(x0, x1 + 1):
                i.put(x, y, p["hi"] if y == 6 else p["base"])
    for x in range(5, 11):
        i.put(x, 7, p["base"]); i.put(x, 8, p["dark"])
    for x0, x1 in ((4, 4), (11, 11)):
        i.put(x0, 7, p["dark"])
    k = p["kind"]
    if k == "heart":
        stamp(i, HEART_I, 5, 9, SILVER, SILVER_L)
    elif k == "star":
        stamp(i, STAR_I, 5, 9, GOLD, GOLD_L)
    elif k == "pearl":
        i.rect(7, 9, 8, 10, (250, 242, 240)); i.put(7, 9, WHITE)
        i.put(6, 7, p["dark"]); i.put(9, 7, p["dark"])
    elif k == "spikes":
        for x in (5, 7, 8, 10):
            i.put(x, 6, SILVER); i.put(x, 5, SILVER_L)
        i.put(4, 7, SILVER_D); i.put(11, 7, SILVER_D)
    elif k == "bow":
        i.rect(4, 8, 6, 10, p["base"]); i.rect(9, 8, 11, 10, p["base"])
        i.rect(7, 9, 8, 9, p["dark"])
        i.put(4, 8, p["hi"]); i.put(9, 8, p["hi"])
        i.rect(6, 11, 6, 12, p["base"]); i.rect(9, 11, 9, 12, p["base"])
    i.save(name)


def icon_necklace(name, p):
    i = Icon()
    k = p["kind"]
    pts = [(2, 2), (3, 3), (3, 4), (4, 5), (4, 6), (5, 7), (6, 8), (6, 9)]
    for n, (x, y) in enumerate(pts):
        for xx in (x, 15 - x):
            if k == "pearl":
                if n % 2 == 0:
                    i.rect(xx, y, xx + (1 if xx < 8 else 0) - (0 if xx < 8 else 0), y, p["base"])
                i.put(xx, y, p["base"] if n % 2 == 0 else p["alt"])
            elif k == "beads":
                i.put(xx, y, RAINBOW[n % 6])
            else:
                i.put(xx, y, p["base"] if n % 2 == 0 else p["alt"])
    if k == "pearl":
        i.rect(7, 9, 8, 11, (250, 242, 240)); i.put(7, 9, WHITE)
    elif k == "beads":
        i.rect(7, 9, 8, 11, (244, 120, 170)); i.put(7, 9, (255, 200, 224))
    elif k == "heart":
        stamp(i, HEART_I, 5, 10, (230, 56, 92), (255, 156, 180))
    else:
        stamp(i, STAR_I, 5, 10, (252, 220, 92), (255, 246, 170))
    i.save(name)


def icon_bracelet(name, p):
    i = Icon()
    k = p["kind"]
    cx, cy = 7.5, 7.5
    for y in range(16):
        for x in range(16):
            dx, dy = (x - cx) / 6.2, (y - cy) / 4.4
            e = dx * dx + dy * dy
            ein = ((x - cx) / 4.2) ** 2 + ((y - cy) / 2.5) ** 2
            if e <= 1.0 and ein > 1.0:
                ang = math.atan2(y - cy, x - cx)
                top = y < cy
                if k == "gold":
                    col = GOLD_L if top else GOLD
                    if not top and y > 10:
                        col = GOLD_D
                elif k == "charm":
                    col = SILVER_L if top else SILVER_D if (x // 2) % 2 else SILVER
                elif k == "beads":
                    col = RAINBOW[int((ang + math.pi) / (2 * math.pi) * 8) % 6]
                else:
                    col = FR[((x + y) // 2) % 3]
                i.put(x, y, col)
    if k == "charm":
        stamp(i, HEART_I, 10, 10, (244, 120, 170), (255, 190, 214))
    elif k == "gold":
        i.put(7, 11, (236, 70, 100)); i.put(8, 11, (236, 70, 100))
    elif k == "friendship":
        i.rect(12, 9, 13, 10, FR[2]); i.put(13, 11, FR[0]); i.put(12, 12, FR[1])
    i.save(name)


# ====================================================================== run + registration
SETS = [
    ("choker_", "choker", CHOKERS, choker, icon_choker),
    ("necklace_", "necklace", NECKLACES, necklace, icon_necklace),
    ("bracelet_", "wrist", BRACELETS, bracelet, icon_bracelet),
]
CONST = {"choker": "CHOKER", "necklace": "NECKLACE", "wrist": "WRIST"}


def register(entries):
    res = ROOT / "src/main/resources/assets/fittingroom"
    cj = json.loads((res / "clothes.json").read_text(encoding="utf-8"))
    have = {it["id"] for it in cj["items"]}
    for e in entries:
        if e["id"] in have:
            continue
        cj["items"].append({
            "id": e["id"], "category": "accessory", "slot": e["slot"],
            "name": {"ru_ru": e["ru"], "en_us": e["en"]},
            "model": f"fittingroom:clothes_models/{e['id']}.json",
            "texture": f"fittingroom:textures/clothes/{e['id']}.png",
            "icon": f"fittingroom:textures/gui/clothes/{e['id']}.png"})
    (res / "clothes.json").write_text(json.dumps(cj, ensure_ascii=False) + "\n", encoding="utf-8")
    for lang, key in (("ru_ru", "ru"), ("en_us", "en")):
        path = res / f"lang/{lang}.json"
        data = json.loads(path.read_text(encoding="utf-8"))
        for e in entries:
            data.setdefault(f"clothes.fittingroom.{e['id']}", e[key])
        path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    java = ROOT / "src/main/java/com/fittingroom/wardrobe/ClothingCatalog.java"
    text = java.read_text(encoding="utf-8")
    if "CHOKER" not in text:
        old = '    public static final String NECK = "neck";\n'
        assert old in text
        text = text.replace(old, old + '    /** Jewelry slots: worn together with scarves, backpacks, glasses and gloves. */\n'
                            '    public static final String CHOKER = "choker";\n'
                            '    public static final String NECKLACE = "necklace";\n'
                            '    public static final String WRIST = "wrist";\n')
        old = "return category.renderOrder() * 10 + (slot.equals(NECK) ? 5 : 0);"
        assert old in text
        text = text.replace(old, "int extra = slot.equals(NECK) ? 5\n"
                            "                    : slot.equals(CHOKER) || slot.equals(NECKLACE) ? 6\n"
                            "                    : slot.equals(WRIST) ? 7 : 0;\n"
                            "            return category.renderOrder() * 10 + extra;")
        old = "    private static Item scarf(String id) {"
        assert old in text
        text = text.replace(old, "    private static Item jewel(String id, String slot) {\n"
                            "        return new Item(id, Category.ACCESSORY, null, null, slot);\n"
                            "    }\n\n" + old)
    close = "\n    );\n\n    private static final Map<String, Item> BY_ID"
    new_lines = [f'            jewel("{e["id"]}", {CONST[e["slot"]]})' for e in entries if f'"{e["id"]}"' not in text]
    if new_lines:
        assert close in text, "end of the item list not found"
        text = text.replace(close, ",\n" + ",\n".join(new_lines) + close)
    java.write_text(text, encoding="utf-8")


if __name__ == "__main__":
    entries = []
    for prefix, slot, palettes, model_fn, icon_fn in SETS:
        for key, p in palettes.items():
            name = prefix + key
            model_fn(name, p)
            icon_fn(name, p)
            entries.append(dict(id=name, slot=slot, ru=p["ru"], en=p["en"]))
    register(entries)
    print("jewelry generated:", len(entries), "items")
