#!/usr/bin/env python3
"""
Generates the Japanese boys' school uniform (gakuran) of the fitting room:
boy_cap (hat: peaked school cap), boy_gakuran (top: black jacket with gold buttons and a white collar tab),
boy_trousers (bottom: black trousers with a belt) and boy_shoes (shoes: black laced shoes).
Same smooth painter as gen_dino.py / gen_school.py. The satchel is shared with the girls' set (school_black_bag).

Run from the project root:  python3 tools/gen_school_boy.py
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from gen_dino import blk, build, grad, mix  # noqa: E402
from gen_accessories import Cube, Icon, shade  # noqa: E402

BLK = (32, 32, 42)
BLK_L = (66, 66, 86)
BLK_D = (22, 22, 30)
GOLD = (238, 200, 94)
GOLD_D = (180, 136, 54)
WHITE = (246, 246, 250)
SILVER = (206, 210, 224)


# ---------------------------------------------------------------- cap
def d_band(f, x, y, w, h):
    if f == "front" and 7 <= x <= 10 and 1 <= y <= 2:
        return GOLD if y == 1 else GOLD_D
    return None


def cap():
    piv = (0, -7.8, -4.4)
    cubes = [
        Cube("band", "head", (0, -7.9, 0), (9.0, 1.6, 9.0), BLK_D, d_band),
        Cube("crown", "head", (0, -9.5, 0), (9.4, 1.6, 9.4), BLK, grad(BLK_L, BLK)),
        Cube("plate", "head", (0, -10.6, 0), (9.2, 0.6, 9.2), BLK_L, grad(BLK_L, BLK)),
        Cube("visor", "head", (0, -7.8, -5.9), (6.4, 0.5, 3.0), BLK_D,
             lambda f, x, y, w, h: mix(BLK_L, BLK, 0.3) if f == "top" else None, pivot=piv, rot=(10, 0, 0)),
    ]
    return build("boy_cap", cubes)


# ---------------------------------------------------------------- gakuran jacket
def d_placket(f, x, y, w, h):
    if f != "front":
        return BLK_D
    if x in (0, w - 1):
        return BLK_L
    for y0 in (2, 7, 12, 17, 22):
        if y0 <= y <= y0 + 1 and 1 <= x <= 2:
            if (x, y) == (1, y0):
                return mix(GOLD, WHITE, 0.45)
            if (x, y) == (2, y0 + 1):
                return GOLD_D
            return GOLD
    return BLK_D


def d_tab(f, x, y, w, h):
    if f == "front" and y <= 1 and w // 2 - 3 <= x <= w // 2 + 2:
        return WHITE
    return None


def d_flap(f, x, y, w, h):
    if f == "front":
        if 2 <= x <= 3 and 2 <= y <= 3:
            return GOLD if (x, y) != (2, 2) else mix(GOLD, WHITE, 0.45)
        if y == h - 1:
            return BLK_L
    return None


def top():
    cubes = [
        Cube("body", "body", (0, 6.1, 0), (9.9, 13.0, 5.9), BLK, grad(BLK_L, BLK)),
        Cube("placket", "body", (0, 6.0, -3.2), (2, 12, 0.5), BLK_D, d_placket),
        Cube("collar", "body", (0, 0.0, 0), (10.3, 1.6, 6.3), BLK, d_tab),
        Cube("badge_r", "body", (-2.8, -0.1, -3.3), (0.8, 0.8, 0.4), GOLD, grad(mix(GOLD, WHITE, 0.4), GOLD_D)),
        Cube("badge_l", "body", (2.8, -0.1, -3.3), (0.8, 0.8, 0.4), GOLD, grad(mix(GOLD, WHITE, 0.4), GOLD_D),
             twin_of="badge_r"),
        Cube("pocket_r", "body", (-2.8, 9.0, -3.2), (3, 1.4, 0.5), BLK_D, d_flap),
        Cube("pocket_l", "body", (2.8, 9.0, -3.2), (3, 1.4, 0.5), BLK_D, d_flap, twin_of="pocket_r", mirror=True),
    ]
    for side, sx, bone in (("r", -1, "right_arm"), ("l", 1, "left_arm")):
        m = side == "l"
        cubes.append(Cube(f"sleeve_{side}", bone, (sx * 1, 2.65, 0), (5.5, 10.0, 5.5), BLK, grad(BLK_L, BLK),
                          twin_of="sleeve_r" if m else None, mirror=m))
        cubes.append(Cube(f"cuff_{side}", bone, (sx * 1, 8.3, 0), (5.8, 2.6, 5.8), BLK_D,
                          lambda f, x, y, w, h: BLK_L if (f not in ("top", "bottom") and y == 1) else None,
                          twin_of="cuff_r" if m else None, mirror=m))
    return build("boy_gakuran", cubes)


# ---------------------------------------------------------------- trousers
def d_belt(f, x, y, w, h):
    if f == "front" and w // 2 - 2 <= x <= w // 2 + 1 and 1 <= y <= h - 2:
        return SILVER if x not in (w // 2 - 2, w // 2 + 1) else mix(SILVER, BLK, 0.5)
    return None


def d_leg(f, x, y, w, h):
    if f in ("top", "bottom"):
        return None
    base = mix(BLK_L, BLK, y / max(1, h - 1) * 0.9)
    if f in ("front", "back") and x == w // 2 - 1:
        return mix(base, BLK_L, 0.55)  # pressed crease
    return base


def trousers():
    cubes = [
        Cube("waist", "body", (0, 11.4, 0), (9.5, 3.2, 5.5), BLK, grad(BLK, BLK_D)),
        Cube("belt", "body", (0, 10.9, 0), (9.7, 0.9, 5.7), BLK_D, d_belt),
    ]
    for side, sx in (("r", -1), ("l", 1)):
        m = side == "l"
        cubes.append(Cube(f"leg_{side}", "right_leg" if side == "r" else "left_leg", (sx * 0.1, 5.25, 0),
                          (4.8, 11.5, 4.8), BLK, d_leg, twin_of="leg_r" if m else None, mirror=m))
    return build("boy_trousers", cubes)


# ---------------------------------------------------------------- shoes
def d_laces(f, x, y, w, h):
    if f == "top" and y % 2 == 1 and 2 <= x <= w - 3:
        return (150, 150, 170)
    return None


def shoes():
    cubes = []
    for side, sx in (("r", -1), ("l", 1)):
        m = side == "l"
        ox = sx * 0.1
        bone = "right_leg" if side == "r" else "left_leg"

        def tw(n):
            return None if side == "r" else n + "_r"
        cubes += [
            Cube(f"shoe_{side}", bone, (ox, 10.9, 0.2), (4.9, 2.2, 4.6), BLK, grad(BLK_L, BLK),
                 twin_of=tw("shoe"), mirror=m),
            Cube(f"toe_{side}", bone, (ox, 11.0, -3.0), (4.5, 2.0, 2.4), BLK, d_laces, twin_of=tw("toe"), mirror=m),
            Cube(f"sole_{side}", bone, (ox, 11.85, -0.8), (4.9, 0.6, 7.2), (18, 16, 22), None,
                 twin_of=tw("sole"), mirror=m),
        ]
    return build("boy_shoes", cubes)


# ---------------------------------------------------------------- icons
def icon_cap():
    i = Icon()
    blk(i, 4, 2, 11, 3, BLK_L)
    blk(i, 3, 4, 12, 8, BLK)
    blk(i, 3, 8, 12, 10, BLK_D)
    i.rect(7, 9, 8, 9, GOLD)
    i.put(7, 8, GOLD_D); i.put(8, 8, GOLD_D)
    blk(i, 4, 11, 11, 12, BLK_L)
    i.rect(5, 13, 10, 13, BLK_D)
    i.save("boy_cap")


def icon_top():
    i = Icon()
    blk(i, 1, 4, 3, 12, BLK)
    blk(i, 12, 4, 14, 12, BLK)
    i.rect(1, 10, 3, 10, BLK_L); i.rect(12, 10, 14, 10, BLK_L)
    blk(i, 4, 3, 11, 14, BLK)
    i.rect(7, 3, 8, 3, WHITE)
    i.put(5, 3, GOLD); i.put(10, 3, GOLD)
    i.rect(7, 4, 8, 14, BLK_D)
    for y in (5, 7, 9, 11, 13):
        i.put(7, y, GOLD); i.put(8, y, GOLD_D)
    i.rect(4, 11, 6, 11, BLK_L); i.rect(9, 11, 11, 11, BLK_L)
    i.put(5, 12, GOLD); i.put(10, 12, GOLD)
    i.save("boy_gakuran")


def icon_trousers():
    i = Icon()
    blk(i, 3, 2, 12, 4, BLK)
    i.rect(3, 3, 12, 3, BLK_D)
    i.rect(7, 3, 8, 3, SILVER)
    blk(i, 3, 5, 7, 14, BLK)
    blk(i, 8, 5, 12, 14, BLK)
    i.rect(5, 6, 5, 14, BLK_L); i.rect(10, 6, 10, 14, BLK_L)
    i.rect(7, 5, 8, 14, BLK_D)
    i.save("boy_trousers")


def icon_shoes():
    i = Icon()
    for x0 in (1, 9):
        blk(i, x0 + 1, 4, x0 + 4, 9, BLK)
        i.rect(x0 + 1, 4, x0 + 4, 4, BLK_L)
        blk(i, x0, 9, x0 + 5, 12, BLK)
        for y in (9, 11):
            i.rect(x0 + 1, y, x0 + 3, y, (150, 150, 170))
        i.rect(x0, 13, x0 + 5, 13, (18, 16, 22))
    i.save("boy_shoes")


if __name__ == "__main__":
    for fn in (cap, top, trousers, shoes, icon_cap, icon_top, icon_trousers, icon_shoes):
        fn()
    print("boys uniform generated")
