#!/usr/bin/env python3
"""
Generates the punk additions of the fitting room, each in black and brown:
  punk_jacket_*  (top)   biker leather jacket: wide lapels, zipper, zipped pockets, belt with a buckle, studs on the
                         shoulders, zipped cuffs
  punk_boots_*   (shoes) combat boots (beret): laced shaft with eyelets, buckled ankle strap, toe cap, thick lugged sole
Models, 32x textures, 16x16 GUI icons and (idempotently) the entries in clothes.json, the lang files and
ClothingCatalog.java (reuses register() of gen_casual.py).

Run from the project root:  python3 tools/gen_punk.py
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from gen_dino import blk, build, grad, mix  # noqa: E402
from gen_accessories import Cube, Icon, shade  # noqa: E402
from gen_casual import register, tw  # noqa: E402

SILVER, SILVER_D, SILVER_L = (206, 212, 228), (134, 140, 162), (248, 250, 255)

JACKETS = {
    "black": dict(base=(36, 34, 42), hi=(84, 82, 100), dark=(20, 18, 26), lap=(52, 50, 62),
                  ru="Чёрная кожаная куртка", en="Black Leather Jacket"),
    "brown": dict(base=(118, 70, 44), hi=(172, 116, 76), dark=(72, 42, 28), lap=(142, 88, 56),
                  ru="Коричневая кожаная куртка", en="Brown Leather Jacket"),
}
BOOTS = {
    "black": dict(base=(34, 32, 40), hi=(80, 76, 94), dark=(20, 18, 26), lace=(206, 54, 66), sole=(22, 20, 28),
                  ru="Чёрные берцы", en="Black Combat Boots"),
    "brown": dict(base=(104, 62, 40), hi=(160, 106, 70), dark=(64, 38, 26), lace=(240, 226, 196), sole=(30, 24, 22),
                  ru="Коричневые берцы", en="Brown Combat Boots"),
}


# ====================================================================== LEATHER JACKET
def leather(p, crease=True):
    """Leather: a faint sheen and a few creases, no per-pixel noise."""
    def d(f, x, y, w, h):
        if f in ("top", "bottom"):
            return None
        col = p["base"]
        if x % 6 in (1, 2) and y % 9 < 5:
            col = mix(col, p["hi"], 0.16)
        if crease and y % 9 == 4 and x % 7 < 3:
            col = p["dark"]
        return col
    return d


def jacket_body(p):
    def d(f, x, y, w, h):
        if f in ("top", "bottom"):
            return None
        col = leather(p)(f, x, y, w, h)
        c = w / 2 - 0.5
        if f == "front":
            dist = abs(x - c)
            # lapels: wide folded flaps, lighter, with a dark edge
            if y < 10 and 1.5 < dist < 8.5 - y * 0.6:
                col = p["lap"] if dist < 8.5 - y * 0.6 - 1 else p["dark"]
            # zipper with teeth
            if dist < 1 and y >= 1 and y < h - 3:
                col = SILVER_L if y % 2 == 0 else SILVER_D
            # snaps on the lapel tips
            if (x, y) in ((int(c - 5), 9), (int(c + 5) + 1, 9)):
                col = SILVER_L
            # zipped pockets
            for x0 in (2, w - 8):
                if x0 <= x <= x0 + 5 and 14 <= y <= 18:
                    if y == 14:
                        col = SILVER_D if x % 2 == 0 else SILVER_L
                    elif x in (x0, x0 + 5):
                        col = p["dark"]
        if f == "back" and y == 7 and x % 3 == 1:
            col = SILVER_L
        if y >= h - 2:
            col = mix(col, p["dark"], 0.5)
        return col
    return d


def jacket(name, p):
    cubes = [
        Cube("body", "body", (0, 5.9, 0), (9.6, 11.6, 5.6), p["base"], jacket_body(p)),
        Cube("collar", "body", (0, -0.1, 0), (10.0, 1.4, 6.0), p["lap"], grad(p["hi"], p["lap"])),
        Cube("belt", "body", (0, 11.2, 0), (9.8, 1.0, 5.8), p["dark"], grad(p["base"], p["dark"])),
        Cube("buckle", "body", (0, 11.2, -3.0), (1.8, 1.2, 0.4), SILVER, grad(SILVER_L, SILVER_D)),
    ]
    for side, sx in (("r", -1), ("l", 1)):
        bone, m = ("right_arm" if side == "r" else "left_arm"), side == "l"
        cubes.append(Cube(f"sleeve_{side}", bone, (sx * 1, 3.9, 0), (5.4, 11.4, 5.4), p["base"], leather(p),
                          twin_of=tw(side, "sleeve"), mirror=m))
        cubes.append(Cube(f"cuff_{side}", bone, (sx * 1, 9.0, 0), (5.6, 1.8, 5.6), p["dark"],
                          lambda f, x, y, w, h, c=p: None if f in ("top", "bottom") else
                          (SILVER_L if y == 1 and x % 2 == 0 else SILVER_D if y == 1 else c["dark"]),
                          twin_of=tw(side, "cuff"), mirror=m))
        for k, z in enumerate((-1.5, 0.0, 1.5)):
            n = f"stud{k}"
            cubes.append(Cube(f"{n}_{side}", bone, (sx * 1, -2.3, z), (0.9, 0.8, 0.9), SILVER,
                              grad(SILVER_L, SILVER_D), twin_of=tw(side, n), mirror=m))
    return build(name, cubes)


def icon_jacket(name, p):
    i = Icon()
    blk(i, 1, 4, 3, 13, p["base"]); blk(i, 12, 4, 14, 13, p["base"])
    i.rect(1, 12, 3, 13, p["dark"]); i.rect(12, 12, 14, 13, p["dark"])
    i.put(2, 3, SILVER_L); i.put(13, 3, SILVER_L)
    blk(i, 4, 3, 11, 14, p["base"])
    i.rect(4, 3, 11, 3, p["lap"])
    for k in range(5):  # lapels
        i.rect(4 + k // 2, 4 + k, 6 - k // 2, 4 + k, p["lap"]) if 4 + k // 2 <= 6 - k // 2 else None
        i.rect(9 + k // 2, 4 + k, 11 - k // 2, 4 + k, p["lap"]) if 9 + k // 2 <= 11 - k // 2 else None
    for y in range(4, 12):
        i.put(7, y, SILVER_L if y % 2 == 0 else SILVER_D); i.put(8, y, SILVER_L if y % 2 == 0 else SILVER_D)
    i.rect(4, 12, 11, 12, p["dark"]); i.rect(7, 12, 8, 12, SILVER_L)
    i.rect(5, 10, 6, 10, SILVER_D); i.rect(9, 10, 10, 10, SILVER_D)
    i.save(name)


# ====================================================================== COMBAT BOOTS
def boot_shaft(p):
    def d(f, x, y, w, h):
        if f == "top":
            return p["dark"]
        if f == "bottom":
            return None
        if y <= 1:
            return p["hi"]
        col = p["base"]
        if x % 5 in (1, 2) and y % 8 < 4:
            col = mix(col, p["hi"], 0.14)
        if f == "front":
            if 2 <= y <= 11 and y % 2 == 0 and 2 <= x <= w - 3:
                return p["lace"]
            if 2 <= y <= 11 and y % 2 == 0 and x in (1, w - 2):
                return SILVER_L
        if f == "back" and 2 <= x <= 7 and y >= h - 4:
            return p["dark"]
        return col
    return d


def boots(name, p):
    cubes = []
    for side, sx in (("r", -1), ("l", 1)):
        bone, m, ox = ("right_leg" if side == "r" else "left_leg"), side == "l", sx * 0.1

        def add(n, center, dims, base, deco=None):
            cubes.append(Cube(f"{n}_{side}", bone, center, dims, base, deco, twin_of=tw(side, n), mirror=m))

        add("shaft", (ox, 8.2, 0), (4.9, 6.8, 4.9), p["base"], boot_shaft(p))
        add("rim", (ox, 4.95, 0), (5.1, 0.9, 5.1), p["dark"], grad(p["hi"], p["dark"]))
        add("cap", (ox, 10.7, -2.9), (4.6, 2.4, 2.6), p["base"], grad(p["hi"], p["base"]))
        add("sole", (ox, 11.75, -0.7), (5.1, 1.1, 7.4), p["sole"],
            lambda f, x, y, w, h, c=p: None if f in ("top", "bottom") else
            ((214, 208, 196) if y == 0 else c["sole"] if x % 3 else shade(c["sole"], 1.5)))
        add("strap", (ox, 10.0, 0), (5.1, 0.8, 5.1), p["dark"], grad(p["hi"], p["dark"]))
        add("buckle", (ox + sx * 2.75, 10.0, 0), (0.4, 1.0, 1.1), SILVER, grad(SILVER_L, SILVER_D))
        add("loop", (ox, 5.6, 2.6), (1.2, 1.2, 0.4), p["dark"], None)
    return build(name, cubes)


def icon_boots(name, p):
    i = Icon()
    for x0 in (1, 9):
        blk(i, x0 + 1, 1, x0 + 4, 9, p["base"])
        i.rect(x0 + 1, 1, x0 + 4, 1, p["hi"])
        for y in (3, 5, 7):
            i.rect(x0 + 2, y, x0 + 3, y, p["lace"])
        i.put(x0 + 1, 3, SILVER_L); i.put(x0 + 4, 5, SILVER_L)
        i.rect(x0 + 1, 9, x0 + 4, 9, SILVER_D)
        blk(i, x0, 10, x0 + 5, 12, p["base"])
        i.put(x0 + 1, 10, p["hi"]); i.put(x0 + 2, 10, p["hi"])
        i.rect(x0, 13, x0 + 5, 13, p["sole"])
    i.save(name)


SETS = [
    ("punk_jacket_", "top", JACKETS, jacket, icon_jacket),
    ("punk_boots_", "shoes", BOOTS, boots, icon_boots),
]

if __name__ == "__main__":
    entries = []
    for prefix, cat, palettes, model_fn, icon_fn in SETS:
        for key, p in palettes.items():
            name = prefix + key
            model_fn(name, p)
            icon_fn(name, p)
            entries.append(dict(id=name, category=cat, ru=p["ru"], en=p["en"]))
    register(entries)
    print("punk jackets and boots generated:", len(entries), "items")
