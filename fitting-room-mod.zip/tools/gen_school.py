#!/usr/bin/env python3
"""
Generates the Japanese school uniform (seifuku) of the fitting room in two colourways (navy: school_*, black:
school_black_*); the five pieces are:
school_bow (hat: hair ribbon), school_top (sailor blouse with a red bow), school_skirt (bottom: plaid pleated skirt),
school_socks (shoes: knee socks + loafers) and school_bag (accessory: leather satchel carried in the right hand).
Models, 32x textures and 16x16 GUI icons. Same smooth painter as gen_dino.py.

Run from the project root:  python3 tools/gen_school.py
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import gen_dino as gd  # noqa: E402
from gen_dino import blk, build as _build, grad, mix  # noqa: E402
from gen_accessories import Cube, Icon, shade  # noqa: E402

WHITE = (244, 246, 252)
WHITE_D = (214, 220, 236)
NAVY = (38, 50, 100)
NAVY_L = (72, 90, 152)
RED = (208, 54, 74)
RED_D = (156, 36, 56)
RED_L = (240, 108, 124)
BLACK = (34, 30, 40)
BLACK_L = (96, 96, 118)
LEATHER = (140, 84, 52)
LEATHER_D = (104, 58, 36)
LEATHER_L = (178, 118, 76)
GOLD = (232, 190, 84)

# colour roles that differ between the colourways (module globals, swapped by main)
BLOUSE, BLOUSE_D = WHITE, WHITE_D
SOCK, SOCK_D = WHITE, WHITE_D
SHOE, SHOE_L = BLACK, BLACK_L
PREFIX = "school"

PALETTES = {
    "school": {},
    "school_black": dict(
        NAVY=(34, 34, 44), NAVY_L=(88, 88, 110), BLOUSE=(42, 42, 54), BLOUSE_D=(28, 28, 38),
        SOCK=(40, 40, 52), SOCK_D=(26, 26, 36), SHOE=(84, 56, 46), SHOE_L=(136, 96, 80),
        LEATHER=(46, 44, 56), LEATHER_D=(30, 28, 38), LEATHER_L=(92, 90, 112), GOLD=(206, 210, 224)),
}


def build(model_id, cubes):
    return _build(model_id, cubes)


def ring_stripes(f, x, y, w, h, col=WHITE, insets=(2, 4)):
    """White sailor-collar stripes running parallel to the three outer edges."""
    if f not in ("front", "back"):
        return None
    for k in insets:
        if y <= h - 1 - k and k <= x <= w - 1 - k and (x in (k, w - 1 - k) or y == h - 1 - k):
            return col
    return None


# ---------------------------------------------------------------- hair ribbon (head bone)
def bow():
    cx, cy, cz = -2.7, -8.9, -0.9
    cubes = [Cube("knot", "head", (cx, cy, cz), (1.2, 1.2, 1.2), RED_D, grad(RED, RED_D))]
    for side, sx in (("r", -1), ("l", 1)):
        piv = (cx + sx * 1.8, cy, cz)
        cubes.append(Cube(f"wing_{side}", "head", piv, (2.6, 1.8, 1.0), RED, grad(RED_L, RED),
                          pivot=piv, rot=(0, 0, sx * 16), twin_of=None if side == "r" else "wing_r",
                          mirror=side == "l"))
        tp = (cx + sx * 0.6, cy + 1.6, cz)
        cubes.append(Cube(f"tail_{side}", "head", tp, (1.0, 2.4, 0.6), RED, grad(RED, RED_D),
                          pivot=tp, rot=(0, 0, sx * 10), twin_of=None if side == "r" else "tail_r",
                          mirror=side == "l"))
    return build(PREFIX + "_bow", cubes)


# ---------------------------------------------------------------- sailor blouse
def d_cuff(f, x, y, w, h):
    if f in ("top", "bottom"):
        return None
    if y == 1:
        return WHITE
    return NAVY


def top():
    cubes = [
        Cube("body", "body", (0, 6.0, 0), (9.5, 12.8, 5.5), BLOUSE, grad(BLOUSE, BLOUSE_D)),
        Cube("collar_neck", "body", (0, -0.1, 0), (9.9, 1.4, 5.9), NAVY, grad(NAVY_L, NAVY)),
        Cube("collar_back", "body", (0, 2.5, 2.95), (9.0, 5.0, 0.6), NAVY, lambda f, x, y, w, h:
             ring_stripes(f, x, y, w, h) or mix(NAVY_L, NAVY, y / max(1, h - 1))),
    ]
    for side, sx in (("r", -1), ("l", 1)):
        c = (sx * 2.6, 3.1, -2.95)
        cubes.append(Cube(f"collar_{side}", "body", c, (3.4, 5.6, 0.6), NAVY,
                          lambda f, x, y, w, h: ring_stripes(f, x, y, w, h) or mix(NAVY_L, NAVY, y / max(1, h - 1)),
                          pivot=c, rot=(0, 0, sx * 30), twin_of=None if side == "r" else "collar_r",
                          mirror=side == "l"))
    # red ribbon bow at the chest
    cubes.append(Cube("knot", "body", (0, 5.6, -3.4), (1.2, 1.2, 0.8), RED_D, grad(RED, RED_D)))
    for side, sx in (("r", -1), ("l", 1)):
        c = (sx * 1.6, 5.5, -3.4)
        cubes.append(Cube(f"bow_{side}", "body", c, (2.2, 1.6, 0.6), RED, grad(RED_L, RED),
                          pivot=c, rot=(0, 0, sx * 14), twin_of=None if side == "r" else "bow_r", mirror=side == "l"))
        t = (sx * 0.5, 7.3, -3.3)
        cubes.append(Cube(f"tail_{side}", "body", t, (1.0, 2.6, 0.5), RED, grad(RED, RED_D),
                          pivot=t, rot=(0, 0, sx * 8), twin_of=None if side == "r" else "tail_r", mirror=side == "l"))
    # short sleeves with a navy cuff and a white stripe
    for side, sx, bone in (("r", -1, "right_arm"), ("l", 1, "left_arm")):
        m = side == "l"
        cubes.append(Cube(f"sleeve_{side}", bone, (sx * 1, 0.7, 0), (5.5, 6.0, 5.5), BLOUSE, grad(BLOUSE, BLOUSE_D),
                          twin_of="sleeve_r" if m else None, mirror=m))
        cubes.append(Cube(f"cuff_{side}", bone, (sx * 1, 3.5, 0), (5.7, 1.2, 5.7), NAVY, d_cuff,
                          twin_of="cuff_r" if m else None, mirror=m))
    return build(PREFIX + "_top", cubes)


# ---------------------------------------------------------------- plaid pleated skirt
def d_plaid(f, x, y, w, h):
    if f in ("top", "bottom"):
        return mix(NAVY, BLACK, 0.2)
    col = NAVY
    if x % 8 == 3 or y % 8 == 3:
        col = NAVY_L
    if x % 8 == 3 and y % 8 == 3:
        col = mix(NAVY_L, WHITE, 0.25)
    if y == h - 1:
        col = mix(col, NAVY_L, 0.5)
    k = {0: 1.05, 1: 1.0, 2: 0.97, 3: 0.88}[x % 4]  # pleat creases every two units
    return tuple(max(0, min(255, int(v * k))) for v in col)


def skirt():
    cubes = [
        Cube("skirt_a", "body", (0, 10.9, 0), (10.0, 2.6, 6.2), NAVY, d_plaid),
        Cube("skirt_b", "body", (0, 13.1, 0), (11.4, 2.4, 7.6), NAVY, d_plaid),
    ]
    return build(PREFIX + "_skirt", cubes)


# ---------------------------------------------------------------- knee socks + loafers
def d_band(f, x, y, w, h):
    if f in ("top", "bottom"):
        return NAVY
    return {0: NAVY, 1: NAVY, 2: WHITE, 3: NAVY}.get(y, NAVY)


def socks():
    cubes = []
    for side, sx in (("r", -1), ("l", 1)):
        m = side == "l"
        ox = sx * 0.1
        bone = "right_leg" if side == "r" else "left_leg"

        def tw(n):
            return None if side == "r" else n + "_r"
        cubes += [
            Cube(f"sock_{side}", bone, (ox, 8.7, 0), (4.7, 6.6, 4.7), SOCK, grad(SOCK, SOCK_D),
                 twin_of=tw("sock"), mirror=m),
            Cube(f"band_{side}", bone, (ox, 5.7, 0), (4.9, 1.4, 4.9), NAVY, d_band, twin_of=tw("band"), mirror=m),
            Cube(f"shoe_{side}", bone, (ox, 10.9, 0.2), (4.9, 2.2, 4.6), SHOE, grad(SHOE_L, SHOE),
                 twin_of=tw("shoe"), mirror=m),
            Cube(f"toe_{side}", bone, (ox, 11.0, -3.0), (4.5, 2.0, 2.4), SHOE, grad(mix(SHOE_L, WHITE, 0.15), SHOE),
                 twin_of=tw("toe"), mirror=m),
            Cube(f"sole_{side}", bone, (ox, 11.85, -0.8), (4.9, 0.6, 7.2), (22, 20, 28), None,
                 twin_of=tw("sole"), mirror=m),
        ]
    return build(PREFIX + "_socks", cubes)


# ---------------------------------------------------------------- satchel carried in the right hand
def bag():
    def d_side(f, x, y, w, h):
        """Big outer faces: stitched border and a gold clasp on the flap."""
        if f in ("left", "right"):
            if x in (1, w - 2) and 1 <= y <= h - 2 or y in (1, h - 2) and 1 <= x <= w - 2:
                if (x + y) % 2 == 0:
                    return LEATHER_L
            return mix(LEATHER_L, LEATHER, y / max(1, h - 1))
        return None

    def d_flap(f, x, y, w, h):
        if f in ("left", "right"):
            if f == "right" and x in (w // 2 - 1, w // 2) and y in (h - 3, h - 2):
                return GOLD
            if y >= h - 2:
                return LEATHER_D
            return mix(LEATHER_L, LEATHER_D, 0.45 + 0.4 * y / max(1, h - 1))
        return None

    def d_handle(f, x, y, w, h):
        if f in ("left", "right") and 1 <= x <= w - 2 and 1 <= y <= h - 2:
            return "clear"  # a loop: the hand goes through it
        return None

    cubes = [
        Cube("body", "right_arm", (-1.4, 13.4, 0), (2.6, 5.6, 7.8), LEATHER, d_side),
        Cube("flap", "right_arm", (-1.4, 11.8, 0), (2.8, 2.4, 8.0), LEATHER_D, d_flap),
        Cube("handle", "right_arm", (-1.0, 9.9, 0), (0.8, 2.2, 3.4), LEATHER_D, d_handle),
    ]
    return build(PREFIX + "_bag", cubes)


# ---------------------------------------------------------------- icons
def icon_bow():
    i = Icon()
    blk(i, 2, 5, 6, 9, RED)
    blk(i, 9, 5, 13, 9, RED)
    i.px.pop((2, 5)); i.px.pop((13, 5)); i.px.pop((2, 9)); i.px.pop((13, 9))
    blk(i, 6, 6, 9, 8, RED_D)
    blk(i, 5, 9, 6, 13, RED)
    blk(i, 9, 9, 10, 13, RED)
    i.put(3, 6, RED_L); i.put(11, 6, RED_L)
    i.save(PREFIX + "_bow")


def icon_top():
    i = Icon()
    blk(i, 1, 4, 3, 8, BLOUSE)
    blk(i, 12, 4, 14, 8, BLOUSE)
    i.rect(1, 7, 3, 8, NAVY); i.rect(12, 7, 14, 8, NAVY)
    i.rect(1, 7, 3, 7, WHITE); i.rect(12, 7, 14, 7, WHITE)
    blk(i, 4, 3, 11, 14, BLOUSE)
    i.rect(4, 3, 11, 4, NAVY)
    i.rect(5, 4, 10, 4, WHITE)
    i.rect(4, 5, 6, 5, NAVY); i.rect(9, 5, 11, 5, NAVY)
    i.rect(4, 6, 5, 6, NAVY); i.rect(10, 6, 11, 6, NAVY)
    i.put(4, 7, NAVY); i.put(11, 7, NAVY)
    i.put(6, 5, WHITE); i.put(9, 5, WHITE)
    i.rect(5, 8, 6, 9, RED); i.rect(9, 8, 10, 9, RED)
    i.rect(7, 8, 8, 9, RED_D)
    i.rect(7, 10, 8, 12, RED)
    i.save(PREFIX + "_top")


def icon_skirt():
    i = Icon()
    rows = {3: (5, 10), 4: (5, 10), 5: (4, 11), 6: (4, 11), 7: (3, 12), 8: (3, 12), 9: (2, 13), 10: (2, 13),
            11: (2, 13), 12: (1, 14), 13: (1, 14)}
    for y, (x0, x1) in rows.items():
        for x in range(x0, x1 + 1):
            col = NAVY
            if x % 3 == 0:
                col = shade(NAVY, 0.84)
            elif x % 3 == 1:
                col = shade(NAVY, 1.1)
            if y in (7, 11):
                col = mix(col, NAVY_L, 0.8)
            if y == 13:
                col = shade(col, 0.8)
            i.put(x, y, col)
    i.rect(5, 3, 10, 3, shade(NAVY, 1.25))
    i.save(PREFIX + "_skirt")


def icon_socks():
    i = Icon()
    for x0 in (1, 9):
        blk(i, x0 + 1, 2, x0 + 4, 9, SOCK)
        i.rect(x0 + 1, 2, x0 + 4, 3, NAVY)
        i.rect(x0 + 1, 4, x0 + 4, 4, WHITE)
        i.rect(x0 + 1, 5, x0 + 4, 5, NAVY)
        blk(i, x0, 10, x0 + 5, 12, SHOE)
        i.put(x0 + 1, 10, SHOE_L); i.put(x0 + 2, 10, SHOE_L)
        i.rect(x0, 13, x0 + 5, 13, (22, 20, 28))
    i.save(PREFIX + "_socks")


def icon_bag():
    i = Icon()
    i.rect(5, 2, 10, 2, LEATHER_D)
    i.put(5, 3, LEATHER_D); i.put(10, 3, LEATHER_D)
    blk(i, 2, 5, 13, 13, LEATHER)
    blk(i, 2, 5, 13, 8, LEATHER_D)
    i.rect(2, 8, 13, 8, shade(LEATHER_D, 0.8))
    i.rect(7, 8, 8, 9, GOLD)
    i.put(7, 8, mix(GOLD, WHITE, 0.5))
    i.rect(4, 10, 11, 10, LEATHER_L)
    i.save(PREFIX + "_bag")


if __name__ == "__main__":
    DEFAULTS = {k: globals()[k] for k in ("NAVY", "NAVY_L", "BLOUSE", "BLOUSE_D", "SOCK", "SOCK_D", "SHOE", "SHOE_L",
                                         "LEATHER", "LEATHER_D", "LEATHER_L", "GOLD")}
    for prefix, palette in PALETTES.items():
        PREFIX = prefix
        globals().update(DEFAULTS)
        globals().update(palette)
        for fn in (bow, top, skirt, socks, bag, icon_bow, icon_top, icon_skirt, icon_socks, icon_bag):
            fn()
    print("school uniform generated:", ", ".join(PALETTES))
