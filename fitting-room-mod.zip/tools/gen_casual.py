#!/usr/bin/env python3
"""
Generates the extra casual wear of the fitting room, every piece in several colours:
  casual_tee_*       (top)    T-shirts: white, black (star print), pink (heart print), striped
  casual_shorts_*    (bottom) Shorts: denim, black, khaki
  casual_skirt_*     (bottom) Skirts: denim, pink pleated, red plaid
  casual_cardigan_*  (top)    Button cardigans: cream, pink, blue
  casual_kedy_*      (shoes)  High-top canvas sneakers: white, red, black
Models, 32x textures, 16x16 GUI icons, and (idempotently) the entries in clothes.json, the lang files and
ClothingCatalog.java. Same smooth painter as gen_dino.py.

Run from the project root:  python3 tools/gen_casual.py
"""
import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from gen_dino import blk, build, grad, mix  # noqa: E402
from gen_accessories import ASSETS, Cube, Icon, shade  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent
WHITE = (244, 246, 252)
BLACK = (34, 30, 40)
NAVY = (54, 76, 140)
RED = (214, 58, 78)


def tw(side, n):
    return None if side == "r" else n + "_r"


# ====================================================================== T-SHIRTS
HEART = [" XX XX ", "XXXXXXX", "XXXXXXX", " XXXXX ", "  XXX  ", "   X   "]
STAR = ["  X  ", "XXXXX", " XXX ", " X X "]

TEES = {
    "white": dict(base=(240, 242, 248), dark=(206, 212, 228), trim=(214, 220, 236), mode="plain",
                  ru="Белая футболка", en="White T-shirt"),
    "black": dict(base=(46, 44, 56), dark=(28, 26, 36), trim=(30, 28, 40), mode="star", glyph=(244, 214, 96),
                  ru="Чёрная футболка со звездой", en="Black Star T-shirt"),
    "pink": dict(base=(246, 164, 194), dark=(214, 122, 158), trim=(232, 138, 172), mode="heart", glyph=(226, 54, 88),
                 ru="Розовая футболка с сердечком", en="Pink Heart T-shirt"),
    "striped": dict(base=(244, 246, 252), dark=(206, 212, 228), trim=(54, 76, 140), mode="striped", glyph=NAVY,
                    ru="Полосатая футболка", en="Striped T-shirt"),
}


def tee_deco(p):
    def d(f, x, y, w, h):
        if f in ("top", "bottom"):
            return None
        col = p["base"]
        if p["mode"] == "striped" and (y // 5) % 2 == 1:
            col = p["glyph"]
        if y >= h - 2 and f != "front" or y >= h - 2:
            col = mix(col, p["dark"], 0.55)
        if f == "front" and p["mode"] in ("heart", "star"):
            pat = HEART if p["mode"] == "heart" else STAR
            x0, y0 = (w - len(pat[0])) // 2, 6
            if 0 <= y - y0 < len(pat) and 0 <= x - x0 < len(pat[0]) and pat[y - y0][x - x0] == "X":
                return p["glyph"]
        return col
    return d


def tee(name, p):
    cubes = [
        Cube("body", "body", (0, 6.0, 0), (9.3, 12.2, 5.3), p["base"], tee_deco(p)),
        Cube("collar", "body", (0, -0.1, 0), (9.6, 1.2, 5.6), p["trim"], grad(shade(p["trim"], 1.1), p["trim"])),
    ]
    for side, sx in (("r", -1), ("l", 1)):
        bone, m = ("right_arm" if side == "r" else "left_arm"), side == "l"
        cubes.append(Cube(f"sleeve_{side}", bone, (sx * 1, 0.7, 0), (5.5, 6.0, 5.5), p["base"], tee_deco(p),
                          twin_of=tw(side, "sleeve"), mirror=m))
        cubes.append(Cube(f"hem_{side}", bone, (sx * 1, 3.4, 0), (5.7, 0.8, 5.7), mix(p["base"], p["dark"], 0.6),
                          None, twin_of=tw(side, "hem"), mirror=m))
    return build(name, cubes)


def icon_tee(name, p):
    i = Icon()
    blk(i, 1, 4, 3, 7, p["base"]); blk(i, 12, 4, 14, 7, p["base"])
    i.rect(1, 7, 3, 7, mix(p["base"], p["dark"], 0.6)); i.rect(12, 7, 14, 7, mix(p["base"], p["dark"], 0.6))
    blk(i, 4, 3, 11, 14, p["base"])
    if p["mode"] == "striped":
        for y in (6, 8, 10, 12):
            i.rect(4, y, 11, y, p["glyph"])
        for y in (6,):
            i.rect(1, y, 3, y, p["glyph"]); i.rect(12, y, 14, y, p["glyph"])
    i.rect(5, 3, 10, 3, p["trim"]); i.rect(6, 4, 9, 4, p["trim"])
    if p["mode"] == "heart":
        for dy, row in enumerate(HEART):
            for dx, ch in enumerate(row):
                if ch == "X":
                    i.put(4 + dx, 7 + dy, p["glyph"])
    if p["mode"] == "star":
        for dy, row in enumerate(STAR):
            for dx, ch in enumerate(row):
                if ch == "X":
                    i.put(6 + dx, 7 + dy, p["glyph"])
    i.rect(4, 14, 11, 14, mix(p["base"], p["dark"], 0.7))
    i.save(name)


# ====================================================================== SHORTS
SHORTS = {
    "denim": dict(base=(78, 120, 190), dark=(52, 84, 144), light=(122, 162, 222), stitch=(232, 190, 96),
                  ru="Джинсовые шорты", en="Denim Shorts"),
    "black": dict(base=(44, 42, 52), dark=(26, 24, 34), light=(86, 84, 104), stitch=(150, 150, 170),
                  ru="Чёрные шорты", en="Black Shorts"),
    "khaki": dict(base=(176, 150, 98), dark=(136, 112, 68), light=(212, 190, 140), stitch=(240, 224, 170),
                  ru="Шорты цвета хаки", en="Khaki Shorts"),
}


def shorts_deco(p):
    def d(f, x, y, w, h):
        if f in ("top", "bottom"):
            return None
        col = mix(p["base"], p["light"], 0.12) if (x + y) % 5 == 0 else p["base"]
        if f == "back":
            if 2 <= x <= 7 and 2 <= y <= 7 and (x in (2, 7) or y in (2, 7)):
                return p["stitch"]
        if f == "front" and x in (w - 3,) and 1 <= y <= 5 and y % 2 == 1:
            return p["stitch"]
        if y == h - 1:
            return p["dark"]
        return col
    return d


def shorts(name, p):
    cubes = [Cube("belt", "body", (0, 11.3, 0), (8.9, 1.6, 4.9), p["dark"], grad(p["base"], p["dark"]))]
    for side, sx in (("r", -1), ("l", 1)):
        bone, m, ox = ("right_leg" if side == "r" else "left_leg"), side == "l", sx * 0.1
        cubes.append(Cube(f"leg_{side}", bone, (ox, 2.7, 0), (5.0, 5.4, 5.0), p["base"], shorts_deco(p),
                          twin_of=tw(side, "leg"), mirror=m))
        cubes.append(Cube(f"cuff_{side}", bone, (ox, 5.2, 0), (5.2, 1.0, 5.2), p["light"],
                          lambda f, x, y, w, h, c=p: None if f in ("top", "bottom") else
                          (c["stitch"] if y == 0 and x % 2 == 0 else c["light"]),
                          twin_of=tw(side, "cuff"), mirror=m))
    return build(name, cubes)


def icon_shorts(name, p):
    i = Icon()
    blk(i, 3, 3, 12, 5, p["dark"])
    blk(i, 3, 6, 7, 11, p["base"]); blk(i, 8, 6, 12, 11, p["base"])
    i.rect(3, 11, 7, 12, p["light"]); i.rect(8, 11, 12, 12, p["light"])
    i.rect(3, 12, 7, 12, p["stitch"]); i.rect(8, 12, 12, 12, p["stitch"])
    i.rect(7, 6, 8, 10, p["dark"])
    i.put(5, 8, p["stitch"]); i.put(10, 8, p["stitch"])
    i.save(name)


# ====================================================================== SKIRTS
SKIRTS = {
    "denim": dict(base=(78, 120, 190), dark=(52, 84, 144), light=(124, 164, 224), mode="denim",
                  ru="Джинсовая юбка", en="Denim Skirt"),
    "pink": dict(base=(246, 170, 198), dark=(206, 120, 156), light=(255, 214, 230), mode="pleat",
                 ru="Розовая плиссе юбка", en="Pink Pleated Skirt"),
    "plaid": dict(base=(178, 40, 58), dark=(110, 22, 40), light=(240, 224, 214), mode="plaid",
                  ru="Красная клетчатая юбка", en="Red Plaid Skirt"),
}


def skirt_deco(p):
    def d(f, x, y, w, h):
        if f in ("top", "bottom"):
            return mix(p["base"], p["dark"], 0.3)
        col = p["base"]
        if p["mode"] == "plaid":
            if x % 8 == 3 or y % 8 == 3:
                col = p["dark"]
            if x % 8 == 3 and y % 8 == 3:
                col = mix(p["dark"], p["light"], 0.3)
            if x % 8 == 6:
                col = mix(col, p["light"], 0.5) if y % 2 == 0 else col
        elif p["mode"] == "denim":
            if (x + y) % 6 == 0:
                col = mix(col, p["light"], 0.18)
            if y == h - 3 and x % 2 == 0:
                col = (232, 190, 96)
            if f == "front" and x == w // 2:
                col = p["dark"]
        if p["mode"] in ("pleat", "plaid"):
            k = {0: 1.05, 1: 1.0, 2: 0.97, 3: 0.88}[x % 4]
            col = tuple(max(0, min(255, int(v * k))) for v in col)
        if y == h - 1:
            col = mix(col, p["dark"], 0.35)
        return col
    return d


def skirt(name, p):
    cubes = [
        Cube("skirt_a", "body", (0, 10.9, 0), (10.0, 2.6, 6.2), p["base"], skirt_deco(p)),
        Cube("skirt_b", "body", (0, 13.1, 0), (11.4, 2.4, 7.6), p["base"], skirt_deco(p)),
    ]
    if p["mode"] == "denim":
        cubes.append(Cube("band", "body", (0, 9.7, 0), (9.8, 1.0, 6.0), p["dark"], None))
    return build(name, cubes)


def icon_skirt(name, p):
    i = Icon()
    rows = {3: (5, 10), 4: (5, 10), 5: (4, 11), 6: (4, 11), 7: (3, 12), 8: (3, 12), 9: (2, 13), 10: (2, 13),
            11: (2, 13), 12: (1, 14), 13: (1, 14)}
    for y, (x0, x1) in rows.items():
        for x in range(x0, x1 + 1):
            col = p["base"]
            if p["mode"] == "plaid" and (x % 4 == 0 or y % 4 == 0):
                col = p["dark"]
            elif x % 3 == 0:
                col = shade(p["base"], 0.86)
            elif x % 3 == 1:
                col = shade(p["base"], 1.08)
            if y == 13:
                col = shade(col, 0.8)
            i.put(x, y, col)
    i.rect(5, 3, 10, 3, shade(p["base"], 1.25))
    if p["mode"] == "denim":
        i.rect(2, 12, 13, 12, (232, 190, 96))
        i.rect(7, 4, 7, 11, p["dark"])
    i.save(name)


# ====================================================================== CARDIGANS
CARDIGANS = {
    "cream": dict(base=(238, 224, 196), dark=(196, 176, 140), btn=(150, 100, 70), inner=(252, 250, 244),
                  ru="Кремовый кардиган", en="Cream Cardigan"),
    "pink": dict(base=(246, 170, 200), dark=(206, 122, 160), btn=(255, 246, 250), inner=(252, 250, 244),
                 ru="Розовый кардиган", en="Pink Cardigan"),
    "blue": dict(base=(142, 182, 232), dark=(92, 130, 188), btn=(252, 248, 236), inner=(252, 250, 244),
                 ru="Голубой кардиган", en="Blue Cardigan"),
}


def card_deco(p):
    def d(f, x, y, w, h):
        if f in ("top", "bottom"):
            return None
        col = mix(p["base"], p["dark"], 0.12) if (x + y) % 4 == 0 else p["base"]
        if y >= h - 3:
            col = p["dark"] if x % 2 == 0 else mix(p["dark"], p["base"], 0.4)
        if f == "front":
            c = w // 2
            if c - 1 <= x <= c:
                col = mix(p["base"], p["dark"], 0.55)
                if y % 6 in (4, 5) and 3 <= y <= h - 5:
                    col = p["btn"]
            for px0 in (3, w - 8):
                if px0 <= x <= px0 + 4 and 14 <= y <= 18:
                    col = mix(p["base"], p["dark"], 0.4 if (y == 14 or x in (px0, px0 + 4)) else 0.15)
        return col
    return d


def cardigan(name, p):
    cubes = [
        Cube("body", "body", (0, 6.1, 0), (9.8, 12.6, 5.8), p["base"], card_deco(p)),
        Cube("collar", "body", (0, -0.1, 0), (10.0, 1.4, 6.0), p["dark"], grad(shade(p["dark"], 1.1), p["dark"])),
        Cube("tee_v", "body", (0, 1.6, -2.95), (3.0, 2.8, 0.3), p["inner"], None),
    ]
    for side, sx in (("r", -1), ("l", 1)):
        bone, m = ("right_arm" if side == "r" else "left_arm"), side == "l"
        cubes.append(Cube(f"sleeve_{side}", bone, (sx * 1, 3.9, 0), (5.4, 11.4, 5.4), p["base"],
                          lambda f, x, y, w, h, c=p: None if f in ("top", "bottom") else
                          (mix(c["base"], c["dark"], 0.12) if (x + y) % 4 == 0 else c["base"]),
                          twin_of=tw(side, "sleeve"), mirror=m))
        cubes.append(Cube(f"cuff_{side}", bone, (sx * 1, 9.0, 0), (5.6, 2.0, 5.6), p["dark"],
                          lambda f, x, y, w, h, c=p: None if f in ("top", "bottom") else
                          (c["dark"] if x % 2 == 0 else mix(c["dark"], c["base"], 0.4)),
                          twin_of=tw(side, "cuff"), mirror=m))
    return build(name, cubes)


def icon_cardigan(name, p):
    i = Icon()
    blk(i, 1, 4, 3, 12, p["base"]); blk(i, 12, 4, 14, 12, p["base"])
    i.rect(1, 11, 3, 12, p["dark"]); i.rect(12, 11, 14, 12, p["dark"])
    blk(i, 4, 3, 11, 14, p["base"])
    i.rect(4, 14, 11, 14, p["dark"]); i.rect(5, 3, 10, 3, p["dark"])
    i.rect(7, 4, 8, 13, mix(p["base"], p["dark"], 0.55))
    for y in (5, 8, 11):
        i.put(7, y, p["btn"]); i.put(8, y, p["btn"])
    i.rect(5, 10, 6, 11, p["dark"]); i.rect(9, 10, 10, 11, p["dark"])
    i.save(name)


# ====================================================================== HIGH-TOP SNEAKERS (kedy)
KEDY = {
    "white": dict(base=(244, 246, 252), dark=(206, 212, 228), accent=(204, 52, 66), lace=(250, 250, 255),
                  ru="Белые высокие кеды", en="White High-top Sneakers"),
    "red": dict(base=(204, 52, 66), dark=(150, 32, 48), accent=(250, 250, 255), lace=(250, 250, 255),
                ru="Красные высокие кеды", en="Red High-top Sneakers"),
    "black": dict(base=(44, 42, 54), dark=(26, 24, 34), accent=(204, 52, 66), lace=(236, 238, 246),
                  ru="Чёрные высокие кеды", en="Black High-top Sneakers"),
}
RUBBER = (246, 244, 238)
RUBBER_D = (206, 202, 192)


def kedy_shaft(p):
    def d(f, x, y, w, h):
        if f == "top":
            return p["dark"]
        if f == "bottom":
            return None
        if y <= 1:
            return RUBBER
        if f == "front":
            if y in (3, 5, 7, 9) and 2 <= x <= w - 3:
                return p["lace"]
            if y in (3, 5, 7, 9) and x in (1, w - 2):
                return RUBBER_D
            if y > 9:
                return mix(p["base"], p["dark"], 0.3)
            return None
        if f in ("left", "right"):
            if 3 <= x <= 6 and 4 <= y <= 7:
                if 4 <= x <= 5 and 5 <= y <= 6:
                    return p["accent"]
                return RUBBER
            return None
        if f == "back" and 3 <= x <= 6 and 7 <= y <= 9:
            return p["accent"]
        return None
    return d


def kedy(name, p):
    cubes = []
    for side, sx in (("r", -1), ("l", 1)):
        bone, m, ox = ("right_leg" if side == "r" else "left_leg"), side == "l", sx * 0.1
        cubes += [
            Cube(f"shaft_{side}", bone, (ox, 8.6, 0), (4.9, 6.0, 4.9), p["base"], kedy_shaft(p),
                 twin_of=tw(side, "shaft"), mirror=m),
            Cube(f"cap_{side}", bone, (ox, 10.9, -2.9), (4.6, 2.2, 2.6), RUBBER,
                 grad(RUBBER, RUBBER_D), twin_of=tw(side, "cap"), mirror=m),
            Cube(f"sole_{side}", bone, (ox, 11.85, -0.8), (5.0, 0.7, 7.2), RUBBER_D,
                 lambda f, x, y, w, h, c=p: None if f in ("top", "bottom") else (c["accent"] if y == 0 else RUBBER),
                 twin_of=tw(side, "sole"), mirror=m),
        ]
    return build(name, cubes)


def icon_kedy(name, p):
    i = Icon()
    for x0 in (1, 9):
        blk(i, x0 + 1, 2, x0 + 4, 9, p["base"])
        i.rect(x0 + 1, 2, x0 + 4, 2, RUBBER)
        for y in (4, 6, 8):
            i.rect(x0 + 2, y, x0 + 3, y, p["lace"])
        i.put(x0 + 1, 7, RUBBER)
        blk(i, x0, 10, x0 + 5, 12, RUBBER)
        i.rect(x0, 13, x0 + 5, 13, p["accent"])
    i.save(name)


# ====================================================================== run + registration
SETS = [
    ("casual_tee_", "top", TEES, tee, icon_tee),
    ("casual_shorts_", "bottom", SHORTS, shorts, icon_shorts),
    ("casual_skirt_", "bottom", SKIRTS, skirt, icon_skirt),
    ("casual_cardigan_", "top", CARDIGANS, cardigan, icon_cardigan),
    ("casual_kedy_", "shoes", KEDY, kedy, icon_kedy),
]
CATEGORY = {"top": "TOP", "bottom": "BOTTOM", "shoes": "SHOES"}


def register(entries):
    res = ROOT / "src/main/resources/assets/fittingroom"
    cj = json.loads((res / "clothes.json").read_text(encoding="utf-8"))
    have = {it["id"] for it in cj["items"]}
    for e in entries:
        if e["id"] in have:
            continue
        cj["items"].append({
            "id": e["id"], "category": e["category"], "name": {"ru_ru": e["ru"], "en_us": e["en"]},
            "model": f"fittingroom:clothes_models/{e['id']}.json",
            "texture": f"fittingroom:textures/clothes/{e['id']}.png",
            "icon": f"fittingroom:textures/gui/clothes/{e['id']}.png"})
    (res / "clothes.json").write_text(json.dumps(cj, ensure_ascii=False) + "\n", encoding="utf-8")
    for lang, key in (("ru_ru", "ru"), ("en_us", "en")):
        path = res / f"lang/{lang}.json"
        data = json.loads(path.read_text(encoding="utf-8"))
        for e in entries:
            data.setdefault(f"clothes.fittingroom.{e['id']}", e[key])
        path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    java = ROOT / "src/main/java/com/fittingroom/wardrobe/ClothingCatalog.java"
    text = java.read_text(encoding="utf-8")
    anchor = '            new Item("casual_sneakers", Category.SHOES),\n'
    add = "".join(f'            new Item("{e["id"]}", Category.{CATEGORY[e["category"]]}),\n'
                  for e in entries if f'"{e["id"]}"' not in text)
    if add:
        assert anchor in text, "anchor for the catalog not found"
        java.write_text(text.replace(anchor, anchor + add), encoding="utf-8")


if __name__ == "__main__":
    entries = []
    for prefix, cat, palettes, model_fn, icon_fn in SETS:
        for key, p in palettes.items():
            name = prefix + key
            model_fn(name, p)
            icon_fn(name, p)
            entries.append(dict(id=name, category=cat, ru=p["ru"], en=p["en"]))
    register(entries)
    print("casual set generated:", len(entries), "items")
