#!/usr/bin/env python3
"""
Generates balloons and gloves of the fitting room (accessories).
 - balloon_<colour> (red, pink, blue, yellow, green, purple): a glossy balloon on a string held in the right hand,
   floating beside the head and swinging with the arm; balloon_bunch_rainbow / balloon_bunch_pastel: three balloons.
 - gloves_<colour> (white, black, red, pink, blue, yellow, green, purple): short gloves with a ribbed cuff on both hands.
Models, 32x textures and 16x16 icons; same smooth painter as gen_dino.py.

Run from the project root:  python3 tools/gen_balloons_gloves.py
"""
import math
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from gen_dino import blk, build, grad, mix  # noqa: E402
from gen_accessories import Cube, Icon, shade  # noqa: E402

WHITE = (250, 250, 252)
STRING = (238, 238, 244)

COLOURS = {
    "red": (228, 66, 76), "pink": (248, 146, 182), "blue": (74, 140, 228), "yellow": (252, 212, 72),
    "green": (88, 194, 124), "purple": (154, 106, 224), "white": (246, 246, 250), "black": (46, 46, 58),
}
BALLOONS = ("red", "pink", "blue", "yellow", "green", "purple")
GLOVES = ("white", "black", "red", "pink", "blue", "yellow", "green", "purple")
BUNCHES = {"rainbow": ("red", "yellow", "blue"), "pastel": ("pink", "green", "purple")}

# how far the balloons are lifted: the lowest knot ends up above the top of the head (hat layer) so they never hide the model
LIFT = 10.5
HAND = (-3.3, 9.4, 0.0)  # where the strings start: just outside the right hand (right_arm space)


# ---------------------------------------------------------------- balloons
def d_balloon(col, highlight=True):
    def d(f, x, y, w, h):
        if f in ("top", "bottom"):
            return shade(col, 1.12 if f == "top" else 0.8)
        base = mix(mix(col, WHITE, 0.16), shade(col, 0.82), y / max(1, h - 1))
        if highlight and f in ("front", "right") and 2 <= x <= 3 and 1 <= y <= 2:
            return mix(col, WHITE, 0.75 if (x, y) == (2, 1) else 0.55)
        return base
    return d


def balloon_cubes(tag, col, centre):
    cx, cy, cz = centre
    d = d_balloon(col)
    dim_mid, dim_up, dim_low = (5.2, 3.4, 5.2), (3.8, 1.6, 3.8), (3.4, 1.4, 3.4)
    parts = [("mid", cy, dim_mid), ("up", cy - 2.5, dim_up), ("low", cy + 2.4, dim_low)]
    cubes = []
    for name, y, dims in parts:
        cubes.append(Cube(f"{tag}_{name}", "right_arm", (cx, y, cz), dims, col, d))
        cubes.append(Cube(f"{tag}_{name}45", "right_arm", (cx, y, cz), dims, col, d, pivot=(cx, y, cz),
                          rot=(0, 45, 0), twin_of=f"{tag}_{name}"))
    cubes.append(Cube(f"{tag}_cap", "right_arm", (cx, cy - 3.6, cz), (1.8, 0.8, 1.8), col, grad(shade(col, 1.15), col)))
    knot = (cx, cy + 3.5, cz)
    cubes.append(Cube(f"{tag}_knot", "right_arm", knot, (0.9, 0.9, 0.9), shade(col, 0.7), grad(col, shade(col, 0.6))))
    # string from the hand to the knot
    kx, ky, kz = knot[0], knot[1] + 0.45, knot[2]
    hx, hy, hz = HAND
    dx, dy, dz = kx - hx, ky - hy, kz - hz
    length = math.sqrt(dx * dx + dy * dy + dz * dz)
    mid = ((kx + hx) / 2, (ky + hy) / 2, (kz + hz) / 2)
    rz = math.degrees(math.atan2(dx, -dy))
    rx = -math.degrees(math.atan2(dz, -dy))
    cubes.append(Cube(f"{tag}_string", "right_arm", mid, (0.5, length, 0.5), STRING,
                      grad(STRING, mix(STRING, (190, 190, 204), 0.6)), pivot=mid, rot=(rx, 0, rz)))
    return cubes


def balloon(colour):
    cubes = balloon_cubes("b", COLOURS[colour], (-5.6, -7.0 - LIFT, 0.0))
    return build(f"balloon_{colour}", cubes)


def bunch(name):
    spots = [(-4.6, -5.0 - LIFT, 0.0), (-9.6, -7.6 - LIFT, 0.5), (-6.4, -12.2 - LIFT, -0.5)]
    cubes = []
    for k, (colour, spot) in enumerate(zip(BUNCHES[name], spots)):
        cubes += balloon_cubes(f"b{k}", COLOURS[colour], spot)
    return build(f"balloon_bunch_{name}", cubes)


# ---------------------------------------------------------------- gloves
def glove(colour):
    col = COLOURS[colour]
    dark = shade(col, 0.74)

    def d_hand(f, x, y, w, h):
        if f in ("top", "bottom"):
            return shade(col, 1.06 if f == "top" else 0.85)
        if f in ("front", "back"):
            if y >= 2 and x in (2, 4, 6, 8):
                return mix(col, dark, 0.7)
            if y == 1:
                return mix(col, WHITE, 0.22)
        return mix(mix(col, WHITE, 0.1), shade(col, 0.9), y / max(1, h - 1))

    def d_cuff(f, x, y, w, h):
        if f in ("top", "bottom"):
            return shade(col, 1.1)
        return mix(col, WHITE, 0.18) if x % 2 == 0 else mix(col, dark, 0.25)

    cubes = []
    for side, sx, bone in (("r", -1, "right_arm"), ("l", 1, "left_arm")):
        m = side == "l"
        cubes.append(Cube(f"hand_{side}", bone, (sx * 1, 8.7, 0), (4.6, 3.0, 4.6), col, d_hand,
                          twin_of="hand_r" if m else None, mirror=m))
        cubes.append(Cube(f"cuff_{side}", bone, (sx * 1, 6.9, 0), (5.0, 1.2, 5.0), col, d_cuff,
                          twin_of="cuff_r" if m else None, mirror=m))
    return build(f"gloves_{colour}", cubes)


# ---------------------------------------------------------------- icons
OVAL = {1: (5, 9), 2: (4, 10), 3: (3, 11), 4: (3, 11), 5: (3, 11), 6: (3, 11), 7: (4, 10), 8: (5, 9)}


def draw_balloon(i, col, dx=0, dy=0, small=False):
    rows = OVAL if not small else {1: (6, 8), 2: (5, 9), 3: (4, 9), 4: (4, 9), 5: (4, 9), 6: (5, 8), 7: (6, 8)}
    top = min(rows)
    for y, (x0, x1) in rows.items():
        for x in range(x0, x1 + 1):
            c = mix(mix(col, WHITE, 0.2), shade(col, 0.78), (x - x0) / max(1, x1 - x0) * 0.6 + (y - top) / 14)
            i.put(x + dx, y + dy, c)
    last = max(rows)
    i.put(rows[top][0] + 2 + dx, top + 1 + dy, mix(col, WHITE, 0.8))
    i.put(rows[top][0] + 1 + dx, top + 2 + dy, mix(col, WHITE, 0.6))
    kx = (rows[last][0] + rows[last][1]) // 2 + dx
    i.put(kx, last + 1 + dy, shade(col, 0.65))
    return kx, last + 2 + dy


def icon_balloon(colour):
    i = Icon()
    kx, ky = draw_balloon(i, COLOURS[colour], dy=1)
    for y in range(ky, 14):
        i.put(kx, y, STRING)
    i.save(f"balloon_{colour}")


def icon_bunch(name):
    i = Icon()
    pos = [(-2, 3), (3, 1), (0, -1)]
    for colour, (dx, dy) in zip(BUNCHES[name], pos):
        kx, ky = draw_balloon(i, COLOURS[colour], dx=dx, dy=dy, small=True)
        for y in range(ky, 14):
            i.put(kx, y, STRING)
    i.save(f"balloon_bunch_{name}")


def icon_gloves(colour):
    col = COLOURS[colour]
    i = Icon()
    blk(i, 4, 11, 11, 13, mix(col, WHITE, 0.15))
    for x in (5, 7, 9):
        i.rect(x, 11, x, 13, shade(col, 0.8))
    blk(i, 3, 6, 12, 10, col)
    for x0, x1, y0 in ((3, 4, 2), (6, 7, 1), (8, 9, 1), (10, 11, 2)):
        blk(i, x0, y0, x1, 6, col)
    for x in (5, 8):
        i.rect(x, 3, x, 9, shade(col, 0.78))
    blk(i, 1, 6, 3, 8, col)
    i.save(f"gloves_{colour}")


if __name__ == "__main__":
    for c in BALLOONS:
        balloon(c)
        icon_balloon(c)
    for n in BUNCHES:
        bunch(n)
        icon_bunch(n)
    for c in GLOVES:
        glove(c)
        icon_gloves(c)
    print("balloons and gloves generated")
