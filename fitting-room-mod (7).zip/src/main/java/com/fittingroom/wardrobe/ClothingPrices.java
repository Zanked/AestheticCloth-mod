package com.fittingroom.wardrobe;

import java.util.HashMap;
import java.util.Map;

/**
 * Shelf prices of the clothes, in US cents (same currency as the aestheticjobs bank: $24.99 = 2499).
 * The numbers follow what such things cost in a normal shop in the USA (before sales tax): a T-shirt about
 * $15-25, jeans about $60, a leather biker jacket a couple of hundred, a pearl necklace about a hundred.
 * For comparison, the cafe job pays $12 per hour.
 * <p>
 * An id that is missing here still gets a price: {@link #fallback(Category)}.
 */
public final class ClothingPrices {
    private ClothingPrices() {}

    private static final Map<String, Long> CENTS = new HashMap<>();

    private static void p(String id, long cents) {
        CENTS.put(id, cents);
    }

    static {
        // ---- New Year (seasonal) ----
        p("santa_hat", 1299);
        p("santa_coat", 4999);
        p("santa_pants", 2999);
        p("santa_boots", 3999);
        p("santa_sack", 1999);
        p("scarf_xmas", 2499);
        p("reindeer_antlers", 1499);
        p("snow_kokoshnik", 2999);
        p("xmas_sweater", 4499);
        p("snow_coat", 5999);
        p("snow_valenki", 3999);
        p("candy_cane", 799);
        p("necklace_snowflake", 3999);
        p("bracelet_bells", 1499);

        // ---- everyday clothes ----
        p("casual_cap", 2499);
        p("casual_hoodie", 4999);
        p("casual_jeans", 5999);
        p("casual_sneakers", 7999);
        p("casual_tee_white", 1499);
        p("casual_tee_black", 1999);
        p("casual_tee_pink", 1999);
        p("casual_tee_striped", 2499);
        p("casual_shorts_denim", 3499);
        p("casual_shorts_black", 2999);
        p("casual_shorts_khaki", 3499);
        p("casual_skirt_denim", 3999);
        p("casual_skirt_pink", 2999);
        p("casual_skirt_plaid", 3499);
        p("casual_cardigan_cream", 4499);
        p("casual_cardigan_pink", 4499);
        p("casual_cardigan_blue", 4499);
        p("casual_kedy_white", 6499);
        p("casual_kedy_red", 6499);
        p("casual_kedy_black", 6499);
        p("casual_backpack", 4999);

        // ---- punk ----
        p("punk_tee", 2499);
        p("punk_jeans", 6999);
        p("punk_jacket_black", 24999);
        p("punk_jacket_brown", 24999);
        p("punk_boots_black", 14999);
        p("punk_boots_brown", 14999);
        p("punk_cuffs", 1999);

        // ---- cat costume ----
        p("cat_ears", 999);
        p("cat_sweater", 3999);
        p("cat_pants", 3499);
        p("cat_paws", 2499);

        // ---- dino kigurumi (green and blue cost the same) ----
        for (String colour : new String[]{"", "blue_"}) {
            p("dino_" + colour + "hood", 2999);
            p("dino_" + colour + "top", 5999);
            p("dino_" + colour + "pants", 3499);
            p("dino_" + colour + "slippers", 2499);
        }

        // ---- school uniform, girls (white and black sets cost the same) ----
        for (String colour : new String[]{"", "black_"}) {
            p("school_" + colour + "bow", 699);
            p("school_" + colour + "top", 4499);
            p("school_" + colour + "skirt", 3999);
            p("school_" + colour + "socks", 6999);
            p("school_" + colour + "bag", 5999);
        }

        // ---- school uniform, boys (gakuran) ----
        p("boy_cap", 2999);
        p("boy_gakuran", 8999);
        p("boy_trousers", 4499);
        p("boy_shoes", 6999);

        // ---- plush backpacks ----
        p("plush_cat", 3499);
        p("plush_dino", 3499);
        p("plush_bear", 3499);

        // ---- balloons ----
        for (String colour : new String[]{"red", "pink", "blue", "yellow", "green", "purple"}) {
            p("balloon_" + colour, 399);
        }
        p("balloon_bunch_rainbow", 1299);
        p("balloon_bunch_pastel", 1299);

        // ---- gloves ----
        for (String colour : new String[]{"white", "black", "red", "pink", "blue", "yellow", "green", "purple"}) {
            p("gloves_" + colour, 1499);
        }

        // ---- glasses ----
        p("glasses_round", 4999);
        p("glasses_sun", 2999);
        p("glasses_heart", 1499);
        p("glasses_3d", 599);
        p("glasses_pixel", 1299);

        // ---- hats (all year) ----
        p("hat_witch", 3499);
        p("hat_mushroom", 2999);
        p("hat_crown", 4999);
        p("hat_bunny", 2499);
        p("hat_frog", 2799);
        p("hat_halo", 1999);
        p("hat_chef", 1999);
        p("hat_propeller", 1799);
        p("hat_strawberry", 2299);
        p("hat_flowers", 2499);

        // ---- scarves ----
        p("scarf_red", 2499);
        p("scarf_blue", 2499);
        p("scarf_pink", 2799);
        p("scarf_plaid", 3499);
        p("scarf_rainbow", 2299);

        // ---- jewelry ----
        p("choker_black", 999);
        p("choker_pink", 899);
        p("choker_lace", 1299);
        p("choker_chain", 1499);
        p("choker_spiked", 1499);
        p("necklace_pearl", 9999);
        p("necklace_heart", 3999);
        p("necklace_star", 3999);
        p("necklace_beads", 1299);
        p("bracelet_gold", 19999);
        p("bracelet_charm", 5999);
        p("bracelet_beads", 999);
        p("bracelet_friendship", 499);
    }

    /** Price of a garment in cents. Never zero, so that nothing is free by accident. */
    public static long cents(String id, Category category) {
        Long cents = CENTS.get(id);
        return cents != null ? cents : fallback(category);
    }

    /** True if the id has its own price in the table (used by the self-check). */
    public static boolean hasOwnPrice(String id) {
        return CENTS.containsKey(id);
    }

    private static long fallback(Category category) {
        return switch (category) {
            case HAT -> 1999;
            case TOP -> 3499;
            case BOTTOM -> 3999;
            case SHOES -> 5999;
            case ACCESSORY -> 1999;
        };
    }
}
