package com.fittingroom.wardrobe;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * The shop's ready-made outfits ("looks"): what the mannequins show and what a customer puts into the cart with one
 * click. A look is hidden while fewer than three of its pieces are in season.
 */
public final class Looks {
    private Looks() {}

    public record Look(String id, List<String> items) {}

    public static final List<Look> ALL = List.of(
            new Look("casual", List.of("casual_cap", "casual_hoodie", "casual_jeans", "casual_sneakers", "casual_backpack")),
            new Look("denim_summer", List.of("casual_cap", "casual_tee_striped", "casual_shorts_denim", "casual_kedy_red", "bracelet_friendship")),
            new Look("pink_day", List.of("hat_flowers", "casual_tee_pink", "casual_skirt_pink", "casual_kedy_white", "glasses_heart", "necklace_pearl")),
            new Look("cozy_plaid", List.of("casual_cardigan_cream", "casual_skirt_plaid", "casual_kedy_white", "scarf_plaid", "bracelet_charm")),
            new Look("cat", List.of("cat_ears", "cat_sweater", "cat_pants", "cat_paws", "plush_cat")),
            new Look("dino_green", List.of("dino_hood", "dino_top", "dino_pants", "dino_slippers", "plush_dino")),
            new Look("dino_blue", List.of("dino_blue_hood", "dino_blue_top", "dino_blue_pants", "dino_blue_slippers", "plush_dino")),
            new Look("school_pink", List.of("school_bow", "school_top", "school_skirt", "school_socks", "school_bag")),
            new Look("school_black", List.of("school_black_bow", "school_black_top", "school_black_skirt", "school_black_socks", "school_black_bag")),
            new Look("school_boy", List.of("boy_cap", "boy_gakuran", "boy_trousers", "boy_shoes")),
            new Look("punk_black", List.of("punk_jacket_black", "punk_jeans", "punk_boots_black", "choker_spiked", "punk_cuffs", "glasses_sun")),
            new Look("punk_brown", List.of("punk_jacket_brown", "punk_jeans", "punk_boots_brown", "choker_chain", "punk_cuffs")),
            new Look("witch", List.of("hat_witch", "cat_sweater", "casual_skirt_plaid", "casual_kedy_black", "necklace_star", "choker_black")),
            new Look("santa", List.of("santa_hat", "santa_coat", "santa_pants", "santa_boots", "santa_sack")),
            new Look("snow_maiden", List.of("snow_kokoshnik", "snow_coat", "snow_valenki", "necklace_snowflake", "candy_cane")),
            new Look("xmas_sweater", List.of("reindeer_antlers", "xmas_sweater", "casual_jeans", "casual_kedy_white", "scarf_xmas", "bracelet_bells"))
    );

    /** The pieces of the look that can be worn today (known and in season). */
    public static List<String> items(Look look) {
        return ClothingCatalog.sanitize(look.items());
    }

    /** Looks that are on sale today (enough of their pieces are in season). */
    public static List<Look> available() {
        List<Look> out = new ArrayList<>();
        for (Look look : ALL) {
            if (items(look).size() >= 3) {
                out.add(look);
            }
        }
        return out;
    }

    public static Look byId(String id) {
        for (Look look : ALL) {
            if (look.id().equals(id)) {
                return look;
            }
        }
        return null;
    }

    /** The look after {@code currentId} among the available ones (the first one if the id is unknown or empty). */
    public static Look next(String currentId) {
        List<Look> list = available();
        if (list.isEmpty()) {
            return null;
        }
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).id().equals(currentId)) {
                return list.get((i + 1) % list.size());
            }
        }
        return list.get(0);
    }

    /** Price of the whole look with today's sales applied (cents), before the loyalty discount. */
    public static long price(Look look, LocalDate day) {
        long sum = 0;
        for (String id : items(look)) {
            ClothingCatalog.Item item = ClothingCatalog.byId(id);
            if (item != null) {
                sum += Sales.price(item, day);
            }
        }
        return sum;
    }
}
